# Roadmap

Source of truth: docs/phase-1-build-spec.md (15 Oct version).

## Built
- [x] Steps 1 to 20
- [x] C1 Catch-up
- [x] F1
- [x] B1 Brain foundation
- [x] B3 Brain bar
- [x] B4 Ask Trade Brain
- [x] B5 Watcher and push
- [x] B6 Overnight draft and look-ahead
- [x] R1a (15 Oct)
- [x] R1b (15 Oct)
- [x] R1c (15 Oct)
- [x] R1d (15 Oct)
- [x] F2 (15 Oct)
- [x] 18b (15 Oct)
- [x] P1 (15 Oct)

## Next, in order
- [x] T0 Housekeeping (15 Oct)
- [x] T1 Review fixes (15 Oct)
- [x] S1 Security controls (15 Oct)
- [x] M1 Materials catalogue (15 Oct)
- [ ] B2 Speech-to-text
- [x] B8 Photos (15 Oct)
- [ ] B7 Email actions and replies
- [ ] B13 SMS
- [ ] M2
- [ ] B9 Documents and site-walk video
- [ ] B10 Variations
- [ ] B11 Safety and handover
- [ ] B12 Memory
- [ ] M3
- [ ] B14 Brain security pass
- [ ] P2
- [ ] P3
- [ ] 21 Phone app
- [ ] 22 Elliot's real data

## Decisions waiting on Ged
- [ ] D1
- [ ] K1
