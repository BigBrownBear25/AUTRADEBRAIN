# Trade Brain — Build step 1: Project setup (app shell)

Following the Phase 1 build spec, one step at a time. This plan covers **step 1 only**: design tokens and the empty app shell with office and field navigation. No data, sign-in or backend yet.

## What you'll see

- **Office (desktop):** top navigation — Overview, Schedule, Jobs, Messages, Crew — with an account menu holding Settings, Help and a light/dark switch.
- **Field (phone):** bottom tab bar — My day, Messages, My schedule, My jobs — with large tap targets and safe-area padding for the notch and home bar.
- A temporary **Office / Field view switcher** in the account menu, so both layouts can be checked before sign-in and roles exist (removed in step 2).
- Each page is an empty placeholder with its title and a one-line description of what's coming.
- A **Help ("What's where")** page with a sentence or two per area, taken from the spec.

## Look and feel (from spec section 2)

- Concrete-grey background, white panels, chalk-line blue accent.
- Oak brown for domestic jobs, steel teal for commercial; red / amber / green kept for clash / warning / fit.
- Barlow Condensed headings, Public Sans text, IBM Plex Mono for job codes (e.g. `FZ-1041`).
- Light and dark themes.

## Pages

```text
/              -> redirects to /overview
/overview      /schedule   /jobs   /messages   /crew   /settings   /help
/my-day        /my-schedule        /my-jobs     (field)
```

## Check for this step

The shell runs on desktop and in a phone-sized window, in light and dark.

## Things to flag before later steps

1. **Server logic differs from the spec.** This project runs on TanStack Start, which uses its own server functions instead of Supabase Edge Functions. Same security outcome (secrets never reach the browser, every call checks the caller), just a different place in the code. I'll treat "Edge Function" in the spec as "server function".
2. **Backend for step 2.** The spec asks for your own Supabase project in Sydney. Database features are currently switched off for your account, so before step 2 you'll need to either connect your Supabase project or enable Lovable Cloud.
3. **Prototype screenshots.** The spec mentions Floorzy screenshots as the visual reference. Upload them whenever you can; for now I'll follow the written look-and-feel rules.
4. **Saving the spec.** I'll store the build spec and brief in the project so every later step can follow them.

## Technical details

- Design tokens in `src/styles.css` (oklch, light + `.dark`): `--domestic`, `--commercial`, `--fit`, `--warn`, `--clash`, plus base surfaces. Fonts via `<link>` in `__root.tsx`.
- `AppShell` in `__root.tsx`: desktop top nav (md+) and phone bottom tabs; view mode (office/field) and theme held in a small client-side context, read after hydration.
- Route files for each path above with unique `head()` metadata; replace the root "Lovable App" metadata.
- Copy both spec documents into `docs/` and record the server-function-instead-of-Edge-Function rule in `AGENTS.md`; save design rules to project memory.
