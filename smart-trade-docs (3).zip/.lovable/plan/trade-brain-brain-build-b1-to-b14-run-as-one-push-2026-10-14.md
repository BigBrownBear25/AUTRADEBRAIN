# Trade Brain — Brain build (B1 to B14), run as one push

## Where you're up to

- Steps 1 to 20 of the spec are built. Step 20 (security pass) is done; the Security Advisor is clear.
- C1 (catch-up) is built: client and builder PM phones, Start and Finish, move reasons, video and Brain fields on files, variation margin.
- Steps 21 (phone app) and 22 (Elliot's real data) come after the Brain, as the spec says.
- Next up: B1 to B14.

## How I'll run it

I'll build the steps in the spec's order, one after another, without stopping. After each step I check the code compiles, the logic tests pass and no access rule is weakened. Where a step needs a key from an outside service, I build all of it and put a switch in front, so it stays off with a clear "not connected yet" note until you add the key. Then I carry on with the next step. At the end you get one list of jobs only you can do.

## The steps

1. **B1 Brain foundation.** Proposals store every suggested change: apply (re-checks fit, offers "Apply anyway" to office, saves the reason "Brain: source"), 7-second Undo, Edit, Dismiss with a reason, expiry, superseded, groups, and no Apply on locked jobs. A bell in the top bar opens the Brain feed (red/amber/info filters, History tab). Settings gets a Brain section: features on or off, quiet hours, monthly AI budget and usage. Each workspace gets per-task model settings and a log of every AI run. One shared Brain runner: the shared instruction, outside text wrapped as untrusted data, at most 8 tool rounds, answer checks (shape, real codes, names and dates, no money), a 60-second timeout, 30 requests per person per 10 minutes, and the budget pause at 100% (owner told at 80%). Its tools are search_jobs, get_job, get_schedule, get_crew, fit_check, find_crew, find_slot, suggest_plan, needs_attention, drive_time and propose; field users only get get_job, search_memory and propose. Fixes in the morning brief become proposals. An owner-only AI test page lists the examples and passes or fails each one, with its cost.
2. **B2 Speech-to-text.** Every voice note and video gets a transcript through ElevenLabs. **Needs your ElevenLabs key.**
3. **B3 Brain bar.** Talk or type on every screen, see a "Here's what I understood" card and confirm it. It handles enquiries, call logs, job updates, leave and problems; questions open Ask. Field users can only do this for their own jobs and leave.
4. **B4 Ask Trade Brain.** Streaming answers in a side panel (full screen on phones). Jobs and people in the answer are links, suggested changes show as cards, and each person's past conversations are kept.
5. **B5 Watcher and push.** The database records events: leave, bookings, problems, emails, materials, dates, tickets expiring within 30 days. A check runs every minute and waits 2 minutes after the last change on a job. Red items alert office straight away, amber items go to the feed only, and quiet hours apply. Field users only hear about their own bookings changing. Web push on each device, using keys I generate myself.
6. **B6 Overnight draft and look-ahead.** A draft plan at 03:30 every night, ticked and ready to apply, and a six-week look-ahead every Monday at 03:45. Both run on a timer protected by a secret I generate myself.
7. **B7 Email actions and replies.** The Brain sorts each filed email and creates proposals and a draft reply. Replies go out from the job's own address only after office approval. **Needs an email-sending account and your domain.**
8. **B8 Photos.** Tags, moisture readings, delivery dockets and ticket cards, read with the cheaper Claude model.
9. **B9 Documents and site-walk video.** A Documents tab: the Brain reads each file and you Confirm to copy what it found into the job. Quotes and purchase orders are visible to finance users only. Site-walk videos become inspection notes and a summary.
10. **B10 Variations.** The Brain drafts each variation from the photos and voice note, and the rules price it for finance users only. The office must press Send and confirm. The builder approves or declines on a page that needs no sign-in and has a one-time link. Sending **needs the email account from B7**.
11. **B11 Safety and handover.** SWMS drafts with versions and approval, crew sign-on on the phone, pre-start, quality and handover checklists, and handover packs.
12. **B12 Memory.** One search box across jobs, chat, transcripts, emails, call logs and documents. It only returns what you're allowed to see. Plus "The Brain remembers" on each job file, close-out write-ups, and learned job durations.
13. **B13 SMS.** Texts through Twilio: templates, office approval, STOP and START opt-outs, and day-before reminders (off by default). **Needs your Twilio account.**
14. **B14 Brain security pass.** I re-run the security check over every new table and function and fix what it finds. The full access check and AI test page still need your real test accounts.
15. **Stripe billing for workspaces.** The spec puts this at SaaS launch; I'm bringing it forward. It uses the payment service built into Lovable, so you don't need your own Stripe account to start. Each business gets a subscription: plans, checkout, a "Manage billing" page for the owner, and a payment record kept up to date. Workspaces that haven't paid get a gentle lock: the owner can still sign in and pay, and data is never deleted. Only the owner sees billing; it's hidden from office, and from field users completely. Everything runs in test mode until you take it live. **Needs you to:** approve switching on payments (Stripe asks a few business details), pick your plan names and prices, and later claim the Stripe account to take real money.

## What you'll get at the end

A numbered list of jobs only you can do, each with where to click and what to paste:
- the ElevenLabs key
- switching on Stripe payments, your plans and prices, and claiming the account to go live
- the email account and domain
- Twilio
- the Postmark inbound address
- the test accounts from section 5
- signing in to run the access check, the export and the AI test page
- confirming the public holiday dates

## Technical details

- Proposals change data only through an apply_proposal function in the private schema, with a thin wrapper in public. It re-checks the role and fit, writes the audit reason and stores the undo. Field users can only turn their own leave proposals into requested leave.
- Stripe: the built-in (managed) Stripe payments, not bring-your-own-key. A subscriptions table keyed by workspace (owner-read; written only by the signed webhook at /api/public/stripe-webhook) and a billing gate in the _authenticated layout that leaves Settings → Billing open to the owner. Australian GST through Stripe Tax. Enabling it needs your approval in a form, so I build everything around it and switch it on once you approve.
- New tables: brain_settings, ai_config (defaults seeded per workspace), proposals, brain_events, notifications, push_subscriptions, ai_runs, ask_messages, call_logs, documents, variations, variation_prices, swms, swms_signons, checklists, handover_packs, closeouts, memory_chunks (pgvector 384), outbound_emails, sms_messages and sms_optouts. Each gets row-level security per section 5, the audit trigger, a workspace_id set by trigger from its parent, and an entry in EXPORT_TABLES.
- The Brain runner lives in src/lib/brain/ and is server-only. Claude is called through the built-in AI service: Sonnet for capture, Ask and drafting, the cheaper model for sorting and tagging. Model names come from ai_config, with defaults in src/lib/ai-config.ts. Person requests run with the caller's own sign-in; background jobs use the admin client.
- Scheduled jobs are routes under /api/public/ protected by CRON_SECRET and run every minute and nightly. The ElevenLabs, SendGrid and Twilio code uses connectors where they exist, otherwise secrets, and is switched off until connected.
- New rules (expiry, superseded, look-ahead maths, variation pricing, learned durations) go in src/lib/rules/ as pure functions with vitest tests.
