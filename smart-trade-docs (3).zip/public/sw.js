/* Trade Brain service worker: web push only. */
self.addEventListener("push", (event) => {
  let d = { title: "Trade Brain", body: "", url: "/" };
  try { d = { ...d, ...event.data.json() }; } catch (e) { /* plain text */ }
  event.waitUntil(self.registration.showNotification(d.title, { body: d.body, data: { url: d.url }, icon: "/icon-192.png", badge: "/icon-192.png" }));
});
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || "/";
  event.waitUntil(clients.matchAll({ type: "window" }).then((list) => {
    for (const c of list) if ("focus" in c) { c.navigate(url); return c.focus(); }
    return clients.openWindow(url);
  }));
});
