CREATE TABLE public.drive_cache (
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  from_key text NOT NULL,
  to_key text NOT NULL,
  km numeric NOT NULL,
  minutes integer NOT NULL,
  fetched_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (workspace_id, from_key, to_key)
);
GRANT SELECT ON public.drive_cache TO authenticated;
GRANT ALL ON public.drive_cache TO service_role;
ALTER TABLE public.drive_cache ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Members read drive cache" ON public.drive_cache FOR SELECT TO authenticated USING (public.is_member(workspace_id));
CREATE TRIGGER audit_drive_cache AFTER INSERT OR UPDATE OR DELETE ON public.drive_cache FOR EACH ROW EXECUTE FUNCTION public.write_audit();