-- F2: Brain bar posts, capture feedback, and "Move to another job"
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS via text CHECK (via IS NULL OR via = 'brain_bar');

CREATE TABLE public.capture_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  input text NOT NULL,
  candidates jsonb NOT NULL DEFAULT '[]'::jsonb,
  preselected_job_id uuid,
  chosen_job_id uuid REFERENCES public.jobs(id) ON DELETE SET NULL,
  no_job text CHECK (no_job IS NULL OR no_job IN ('enquiry','unfiled')),
  changed boolean NOT NULL DEFAULT false,
  moved boolean NOT NULL DEFAULT false,
  message_id uuid REFERENCES public.messages(id) ON DELETE SET NULL,
  proposal_ids uuid[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.capture_feedback TO authenticated;
GRANT ALL ON public.capture_feedback TO service_role;
ALTER TABLE public.capture_feedback ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Members record own capture feedback" ON public.capture_feedback FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() AND public.is_member(workspace_id) AND moved = false
    AND (chosen_job_id IS NULL OR EXISTS (SELECT 1 FROM public.jobs j WHERE j.id = chosen_job_id AND j.workspace_id = capture_feedback.workspace_id)));
CREATE POLICY "Own or office read capture feedback" ON public.capture_feedback FOR SELECT TO authenticated
  USING (public.is_member(workspace_id) AND (user_id = auth.uid() OR public.is_office(workspace_id)));
CREATE TRIGGER audit_capture_feedback AFTER INSERT OR UPDATE OR DELETE ON public.capture_feedback FOR EACH ROW EXECUTE FUNCTION public.write_audit();

-- Audit accepts the move reason
CREATE OR REPLACE FUNCTION public.write_audit()
 RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $function$
DECLARE _ws uuid; _row jsonb; _reason text;
BEGIN
  _row := to_jsonb(COALESCE(NEW, OLD));
  IF TG_TABLE_NAME = 'workspaces' THEN _ws := (_row->>'id')::uuid;
  ELSE _ws := (_row->>'workspace_id')::uuid; END IF;
  _reason := nullif(current_setting('app.move_reason', true), '');
  IF _reason IS NOT NULL AND NOT (_reason IN ('builder_delay','weather','crew_away','materials','client_request','other','moved: wrong job') OR _reason ~ '^brain:[a-z_]+$') THEN _reason := NULL; END IF;
  INSERT INTO public.audit_log(workspace_id, actor_user_id, action, table_name, row_id, before, after, reason)
  VALUES (_ws, auth.uid(), lower(TG_OP), TG_TABLE_NAME, _row->>'id',
    CASE WHEN TG_OP IN ('UPDATE','DELETE') THEN to_jsonb(OLD) END,
    CASE WHEN TG_OP IN ('INSERT','UPDATE') THEN to_jsonb(NEW) END, _reason);
  RETURN COALESCE(NEW, OLD);
END $function$;

-- Messages: soft delete as before; a Brain bar post may also change job, only under the move rules
CREATE OR REPLACE FUNCTION public.message_before_write()
 RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $function$
BEGIN
  SELECT workspace_id INTO NEW.workspace_id FROM public.jobs WHERE id = NEW.job_id;
  IF NEW.workspace_id IS NULL THEN RAISE EXCEPTION 'Unknown job'; END IF;
  IF TG_OP = 'INSERT' THEN
    IF NEW.task_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.tasks t WHERE t.id = NEW.task_id AND t.job_id = NEW.job_id) THEN RAISE EXCEPTION 'Task is on another job'; END IF;
    IF NEW.reply_to_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.messages m WHERE m.id = NEW.reply_to_id AND m.job_id = NEW.job_id) THEN RAISE EXCEPTION 'Reply is on another job'; END IF;
    NEW.created_at := now();
  ELSIF NEW.job_id IS DISTINCT FROM OLD.job_id THEN
    IF current_setting('app.move_reason', true) IS DISTINCT FROM 'moved: wrong job'
       OR OLD.via IS DISTINCT FROM 'brain_bar' OR OLD.deleted_at IS NOT NULL
       OR OLD.created_at < now() - interval '7 days'
       OR NEW.workspace_id <> OLD.workspace_id
       OR NOT (OLD.author_user_id = auth.uid() OR private.is_office(OLD.workspace_id))
       OR NOT private.is_job_reader(NEW.job_id)
       OR (to_jsonb(NEW) - 'job_id' - 'reply_to_id' - 'task_id') IS DISTINCT FROM (to_jsonb(OLD) - 'job_id' - 'reply_to_id' - 'task_id') THEN
      RAISE EXCEPTION 'This post can''t be moved';
    END IF;
  ELSE
    IF (to_jsonb(NEW) - 'deleted_at') IS DISTINCT FROM (to_jsonb(OLD) - 'deleted_at') OR NEW.deleted_at IS NULL OR OLD.deleted_at IS NOT NULL THEN
      RAISE EXCEPTION 'Messages can only be deleted';
    END IF;
    NEW.deleted_at := now();
  END IF;
  RETURN NEW;
END $function$;
REVOKE EXECUTE ON FUNCTION public.message_before_write() FROM PUBLIC, anon, authenticated;

-- Move a Brain bar post (and its files, tasks and proposals) to the right job
CREATE OR REPLACE FUNCTION private.move_brain_post(_message_id uuid, _to_job uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _m public.messages; _to public.jobs; _paths jsonb := '[]'::jsonb; _a record; _new text; _fb public.capture_feedback; _pids uuid[] := '{}'; _tids uuid[] := '{}'; _u uuid;
BEGIN
  SELECT * INTO _m FROM public.messages WHERE id = _message_id;
  IF _m.id IS NULL OR NOT private.is_job_reader(_m.job_id) THEN RAISE EXCEPTION 'Post not found'; END IF;
  IF _m.via IS DISTINCT FROM 'brain_bar' THEN RAISE EXCEPTION 'Only Brain bar posts can be moved'; END IF;
  IF _m.created_at < now() - interval '7 days' THEN RAISE EXCEPTION 'Posts can only be moved for 7 days'; END IF;
  IF NOT (_m.author_user_id = auth.uid() OR private.is_office(_m.workspace_id)) THEN RAISE EXCEPTION 'Only the author or the office can move this post'; END IF;
  SELECT * INTO _to FROM public.jobs WHERE id = _to_job;
  IF _to.id IS NULL OR _to.workspace_id <> _m.workspace_id OR NOT private.is_job_reader(_to.id) THEN RAISE EXCEPTION 'That job isn''t available to you'; END IF;
  IF _to.id = _m.job_id THEN RAISE EXCEPTION 'It''s already on that job'; END IF;

  PERFORM set_config('app.move_reason', 'moved: wrong job', true);
  SELECT * INTO _fb FROM public.capture_feedback WHERE message_id = _m.id LIMIT 1;
  IF _fb.id IS NOT NULL THEN _pids := _fb.proposal_ids; END IF;
  SELECT coalesce(array_agg((p.result->>'task_id')::uuid) FILTER (WHERE p.result ? 'task_id'), '{}') INTO _tids
    FROM public.proposals p WHERE p.id = ANY(_pids) AND p.workspace_id = _m.workspace_id;
  IF _m.task_id IS NOT NULL THEN _tids := _tids || _m.task_id; END IF;

  UPDATE public.messages SET job_id = _to.id, reply_to_id = NULL WHERE id = _m.id;
  FOR _a IN SELECT id, storage_path FROM public.attachments WHERE message_id = _m.id LOOP
    _new := _m.workspace_id::text || '/' || _to.id::text || '/' || substr(_a.storage_path, length(split_part(_a.storage_path, '/', 1)) + length(split_part(_a.storage_path, '/', 2)) + 3);
    UPDATE public.attachments SET job_id = _to.id, storage_path = _new WHERE id = _a.id;
    _paths := _paths || jsonb_build_object('from', _a.storage_path, 'to', _new);
  END LOOP;
  UPDATE public.tasks SET job_id = _to.id WHERE id = ANY(_tids) AND workspace_id = _m.workspace_id;
  UPDATE public.proposals SET job_id = _to.id WHERE id = ANY(_pids) AND workspace_id = _m.workspace_id;
  UPDATE public.capture_feedback SET moved = true, chosen_job_id = _to.id WHERE message_id = _m.id;
  FOR _u IN SELECT user_id FROM public.memberships WHERE workspace_id = _m.workspace_id AND status = 'active' AND role IN ('owner','office') AND user_id IS NOT NULL LOOP
    INSERT INTO public.notifications(workspace_id, user_id, kind, level, title, body, job_id)
    VALUES (_m.workspace_id, _u, 'post_moved', 'info', 'Brain bar post moved to ' || _to.code, left(_m.body, 300), _to.id);
  END LOOP;
  PERFORM set_config('app.move_reason', '', true);
  RETURN jsonb_build_object('job_id', _to.id, 'code', _to.code, 'paths', _paths);
END $$;
REVOKE ALL ON FUNCTION private.move_brain_post(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION private.move_brain_post(uuid, uuid) TO authenticated, service_role;
CREATE OR REPLACE FUNCTION public.move_brain_post(_message_id uuid, _to_job uuid)
RETURNS jsonb LANGUAGE sql SECURITY INVOKER SET search_path = public AS $$ SELECT private.move_brain_post(_message_id, _to_job) $$;
REVOKE ALL ON FUNCTION public.move_brain_post(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.move_brain_post(uuid, uuid) TO authenticated, service_role;