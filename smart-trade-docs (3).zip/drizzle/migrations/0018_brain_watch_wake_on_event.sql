-- lovable-cron-fallback-reviewed: wake-on-enqueue; the 2-minute debounce needs a delayed recheck, and the job unschedules itself once events drain
CREATE OR REPLACE FUNCTION private.brain_watch_wake() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = private, public, cron AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'brain-watch') THEN
    PERFORM cron.schedule('brain-watch', '* * * * *',
      $c$SELECT net.http_post(url := 'https://smart-trade-docs.lovable.app/api/public/brain-watch',
        headers := jsonb_build_object('Content-Type','application/json','x-cron-token',(SELECT value FROM private.app_tokens WHERE name='cron')),
        body := '{}'::jsonb)$c$);
  END IF;
  RETURN NULL;
END $$;
REVOKE EXECUTE ON FUNCTION private.brain_watch_wake() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER brain_events_wake AFTER INSERT ON public.brain_events FOR EACH STATEMENT EXECUTE FUNCTION private.brain_watch_wake();

CREATE OR REPLACE FUNCTION private.brain_watch_sleep() RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = private, public, cron AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.brain_events WHERE processed_at IS NULL)
     AND EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'brain-watch') THEN
    PERFORM cron.unschedule('brain-watch');
  END IF;
END $$;
REVOKE EXECUTE ON FUNCTION private.brain_watch_sleep() FROM PUBLIC, anon, authenticated;
CREATE OR REPLACE FUNCTION public.brain_watch_sleep() RETURNS void LANGUAGE sql SECURITY INVOKER SET search_path = public AS $$ SELECT private.brain_watch_sleep() $$;
REVOKE EXECUTE ON FUNCTION public.brain_watch_sleep() FROM PUBLIC, anon, authenticated;
GRANT USAGE ON SCHEMA private TO service_role;
GRANT EXECUTE ON FUNCTION private.brain_watch_sleep() TO service_role;
GRANT EXECUTE ON FUNCTION public.brain_watch_sleep() TO service_role;