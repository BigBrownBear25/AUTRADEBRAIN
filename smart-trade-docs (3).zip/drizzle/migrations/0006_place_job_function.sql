-- Replaces a job's assignments and dates in one transaction. Runs as the caller, so RLS
-- (office only) and the audit triggers on assignments and jobs apply as normal.
CREATE OR REPLACE FUNCTION public.place_job(
  _job_id uuid, _rows jsonb, _start_date date, _start_time time, _status public.job_status, _ignore_lock boolean DEFAULT false
) RETURNS void LANGUAGE plpgsql SECURITY INVOKER SET search_path = public AS $$
DECLARE _ws uuid; _locked boolean;
BEGIN
  SELECT workspace_id, locked INTO _ws, _locked FROM public.jobs WHERE id = _job_id;
  IF _ws IS NULL OR NOT public.is_office(_ws) THEN RAISE EXCEPTION 'Only office users can place jobs'; END IF;
  IF _locked AND NOT _ignore_lock THEN RAISE EXCEPTION 'This job is locked. Unlock it to move it.'; END IF;
  DELETE FROM public.assignments WHERE job_id = _job_id;
  INSERT INTO public.assignments (id, job_id, workspace_id, crew_member_id, date, start_time, end_time, is_lead)
  SELECT COALESCE((r->>'id')::uuid, gen_random_uuid()), _job_id, _ws, (r->>'crew_member_id')::uuid, (r->>'date')::date,
         (r->>'start_time')::time, (r->>'end_time')::time, COALESCE((r->>'is_lead')::boolean, false)
  FROM jsonb_array_elements(COALESCE(_rows, '[]'::jsonb)) r;
  UPDATE public.jobs SET start_date = _start_date, start_time = _start_time, status = _status
  WHERE id = _job_id AND (start_date IS DISTINCT FROM _start_date OR start_time IS DISTINCT FROM _start_time OR status IS DISTINCT FROM _status);
END $$;
REVOKE EXECUTE ON FUNCTION public.place_job(uuid, jsonb, date, time, public.job_status, boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.place_job(uuid, jsonb, date, time, public.job_status, boolean) TO authenticated;