CREATE OR REPLACE FUNCTION public.catalogue_links_same_ws()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _r jsonb := to_jsonb(NEW); _ws uuid := (to_jsonb(NEW)->>'workspace_id')::uuid;
BEGIN
  IF (_r->>'supplier_id') IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.suppliers s WHERE s.id = (_r->>'supplier_id')::uuid AND s.workspace_id = _ws) THEN
    RAISE EXCEPTION 'Supplier belongs to another workspace'; END IF;
  IF (_r->>'catalogue_item_id') IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.catalogue_items c WHERE c.id = (_r->>'catalogue_item_id')::uuid AND c.workspace_id = _ws) THEN
    RAISE EXCEPTION 'Catalogue item belongs to another workspace'; END IF;
  IF (_r->>'default_item_id') IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.catalogue_items c WHERE c.id = (_r->>'default_item_id')::uuid AND c.workspace_id = _ws) THEN
    RAISE EXCEPTION 'Catalogue item belongs to another workspace'; END IF;
  RETURN NEW;
END $$;