CREATE TABLE public.usage_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('ai','maps','email')),
  units integer NOT NULL DEFAULT 0,
  detail text,
  at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.usage_events TO authenticated;
GRANT ALL ON public.usage_events TO service_role;
ALTER TABLE public.usage_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owner reads usage" ON public.usage_events FOR SELECT TO authenticated USING (public.is_owner(workspace_id));
CREATE TRIGGER audit_usage_events AFTER INSERT OR UPDATE OR DELETE ON public.usage_events FOR EACH ROW EXECUTE FUNCTION public.write_audit();

-- Inspection notes: office users and foremen on the job may add them.
DROP POLICY "Job readers add own messages" ON public.messages;
CREATE POLICY "Job readers add own messages" ON public.messages FOR INSERT TO authenticated
  WITH CHECK (public.is_job_reader(job_id) AND author_user_id = auth.uid() AND deleted_at IS NULL
    AND (kind IN ('message','problem') OR public.is_office(workspace_id)
         OR (kind = 'inspection' AND public.is_foreman_on_job(job_id))));

-- Office users and foremen on the job can save or edit the Claude results; nothing else on the job changes.
CREATE OR REPLACE FUNCTION public.set_job_ai(_job_id uuid, _field text, _value jsonb)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _ws uuid;
BEGIN
  SELECT workspace_id INTO _ws FROM public.jobs WHERE id = _job_id;
  IF _ws IS NULL OR NOT (public.is_office(_ws) OR public.is_foreman_on_job(_job_id)) THEN
    RAISE EXCEPTION 'Only office users and the foreman on this job can change this';
  END IF;
  IF _field = 'inspection_summary' THEN UPDATE public.jobs SET inspection_summary = _value WHERE id = _job_id;
  ELSIF _field = 'guidance' THEN UPDATE public.jobs SET guidance = _value WHERE id = _job_id;
  ELSE RAISE EXCEPTION 'Unknown field'; END IF;
END $$;
REVOKE EXECUTE ON FUNCTION public.set_job_ai(uuid, text, jsonb) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.set_job_ai(uuid, text, jsonb) TO authenticated;