-- 1. Trigger functions are never called directly.
REVOKE EXECUTE ON FUNCTION public.attachment_before_write() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.message_before_write() FROM PUBLIC, anon, authenticated;

-- 2. drive_cache keys are home-base addresses: office only (field drive times come through the server function).
DROP POLICY "Members read drive cache" ON public.drive_cache;
CREATE POLICY "Office reads drive cache" ON public.drive_cache FOR SELECT TO authenticated USING (public.is_office(workspace_id));

-- 3. Privileged functions move to a schema the Data API doesn't expose; public keeps thin SECURITY INVOKER wrappers.
CREATE SCHEMA IF NOT EXISTS private;
REVOKE ALL ON SCHEMA private FROM PUBLIC, anon;
GRANT USAGE ON SCHEMA private TO authenticated, service_role;

ALTER FUNCTION public.has_workspace_role(uuid, public.app_role[]) SET SCHEMA private;
ALTER FUNCTION public.is_member(uuid) SET SCHEMA private;
ALTER FUNCTION public.is_office(uuid) SET SCHEMA private;
ALTER FUNCTION public.is_owner(uuid) SET SCHEMA private;
ALTER FUNCTION public.is_finance(uuid) SET SCHEMA private;
ALTER FUNCTION public.is_assigned_to_job(uuid) SET SCHEMA private;
ALTER FUNCTION public.is_job_reader(uuid) SET SCHEMA private;
ALTER FUNCTION public.is_foreman_on_job(uuid) SET SCHEMA private;
ALTER FUNCTION public.my_crew_member_ids() SET SCHEMA private;
ALTER FUNCTION public.crew_mates(uuid) SET SCHEMA private;
ALTER FUNCTION public.away_days(uuid) SET SCHEMA private;
ALTER FUNCTION public.job_people(uuid) SET SCHEMA private;
ALTER FUNCTION public.accept_pending_invites() SET SCHEMA private;
ALTER FUNCTION public.link_membership_crew(uuid, uuid) SET SCHEMA private;
ALTER FUNCTION public.set_job_ai(uuid, text, jsonb) SET SCHEMA private;
ALTER FUNCTION public.set_demo_data(uuid, boolean) SET SCHEMA private;

REVOKE ALL ON ALL FUNCTIONS IN SCHEMA private FROM PUBLIC, anon;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA private TO authenticated, service_role;

CREATE FUNCTION public.has_workspace_role(_ws uuid, _roles public.app_role[]) RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$ SELECT private.has_workspace_role(_ws, _roles) $$;
CREATE FUNCTION public.is_member(_ws uuid) RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$ SELECT private.is_member(_ws) $$;
CREATE FUNCTION public.is_office(_ws uuid) RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$ SELECT private.is_office(_ws) $$;
CREATE FUNCTION public.is_owner(_ws uuid) RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$ SELECT private.is_owner(_ws) $$;
CREATE FUNCTION public.is_finance(_ws uuid) RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$ SELECT private.is_finance(_ws) $$;
CREATE FUNCTION public.is_assigned_to_job(_job_id uuid) RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$ SELECT private.is_assigned_to_job(_job_id) $$;
CREATE FUNCTION public.is_job_reader(_job_id uuid) RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$ SELECT private.is_job_reader(_job_id) $$;
CREATE FUNCTION public.is_foreman_on_job(_job_id uuid) RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$ SELECT private.is_foreman_on_job(_job_id) $$;
CREATE FUNCTION public.my_crew_member_ids() RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$ SELECT private.my_crew_member_ids() $$;
CREATE FUNCTION public.crew_mates(_job_id uuid) RETURNS TABLE(crew_member_id uuid, name text, role public.crew_role, phone text) LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$ SELECT * FROM private.crew_mates(_job_id) $$;
CREATE FUNCTION public.away_days(_job_id uuid) RETURNS TABLE(crew_member_id uuid, date date) LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$ SELECT * FROM private.away_days(_job_id) $$;
CREATE FUNCTION public.job_people(_job_id uuid) RETURNS TABLE(user_id uuid, name text, role public.app_role) LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$ SELECT * FROM private.job_people(_job_id) $$;
CREATE FUNCTION public.accept_pending_invites() RETURNS integer LANGUAGE sql SECURITY INVOKER SET search_path = public AS $$ SELECT private.accept_pending_invites() $$;
CREATE FUNCTION public.link_membership_crew(_membership_id uuid, _crew_member_id uuid) RETURNS void LANGUAGE sql SECURITY INVOKER SET search_path = public AS $$ SELECT private.link_membership_crew(_membership_id, _crew_member_id) $$;
CREATE FUNCTION public.set_job_ai(_job_id uuid, _field text, _value jsonb) RETURNS void LANGUAGE sql SECURITY INVOKER SET search_path = public AS $$ SELECT private.set_job_ai(_job_id, _field, _value) $$;
CREATE FUNCTION public.set_demo_data(_ws uuid, _on boolean) RETURNS void LANGUAGE sql SECURITY INVOKER SET search_path = public AS $$ SELECT private.set_demo_data(_ws, _on) $$;

DO $$ DECLARE f record; BEGIN
  FOR f IN SELECT p.oid::regprocedure AS sig FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.proname IN ('has_workspace_role','is_member','is_office','is_owner','is_finance','is_assigned_to_job','is_job_reader','is_foreman_on_job','my_crew_member_ids','crew_mates','away_days','job_people','accept_pending_invites','link_membership_crew','set_job_ai','set_demo_data')
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC, anon', f.sig);
    EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO authenticated, service_role', f.sig);
  END LOOP;
END $$;