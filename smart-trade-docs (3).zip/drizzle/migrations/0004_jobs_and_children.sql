CREATE TYPE public.job_status AS ENUM ('enquiry','quoted','ready','scheduled','on site','complete','closed');
CREATE TYPE public.job_importance AS ENUM ('key','standard','minor');
CREATE TYPE public.job_urgency AS ENUM ('critical','soon','flexible');
CREATE TYPE public.job_sector AS ENUM ('domestic','commercial');
CREATE TYPE public.duration_unit AS ENUM ('hours','days');
CREATE TYPE public.dependency_kind AS ENUM ('trade handover','test result','delivery','approval','other');
CREATE TYPE public.dependency_status AS ENUM ('pending','confirmed','failed');
CREATE TYPE public.material_status AS ENUM ('to order','ordered','delivered');

ALTER TABLE public.workspaces ADD COLUMN next_job_number integer NOT NULL DEFAULT 1001;

CREATE TABLE public.jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  code text NOT NULL DEFAULT '',
  name text NOT NULL,
  client_name text,
  client_contact text,
  builder_company text,
  builder_pm_name text,
  builder_pm_email text,
  job_type text,
  sector public.job_sector NOT NULL DEFAULT 'domestic',
  address text,
  suburb text,
  lat double precision,
  lng double precision,
  flooring text,
  area_m2 numeric CHECK (area_m2 IS NULL OR area_m2 >= 0),
  duration_value numeric NOT NULL DEFAULT 1 CHECK (duration_value > 0),
  duration_unit public.duration_unit NOT NULL DEFAULT 'days',
  crew_size integer NOT NULL DEFAULT 1 CHECK (crew_size >= 1),
  start_date date,
  start_time time,
  status public.job_status NOT NULL DEFAULT 'ready',
  importance public.job_importance NOT NULL DEFAULT 'standard',
  urgency public.job_urgency NOT NULL DEFAULT 'soon',
  due_by date,
  due_hard boolean NOT NULL DEFAULT false,
  main_skill text,
  other_skills text[] NOT NULL DEFAULT '{}',
  hazards text[] NOT NULL DEFAULT '{}',
  extra_tickets text[] NOT NULL DEFAULT '{}',
  access_window jsonb NOT NULL DEFAULT '{"days":[],"from":null,"to":null,"note":""}',
  locked boolean NOT NULL DEFAULT false,
  unique_notes text,
  safety_notes text,
  inspection_summary jsonb,
  guidance jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX jobs_ws_code_uq ON public.jobs(workspace_id, code);
CREATE INDEX jobs_ws_status_idx ON public.jobs(workspace_id, status, start_date);

CREATE TABLE public.job_finance (
  job_id uuid PRIMARY KEY REFERENCES public.jobs(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL,
  quote_value numeric CHECK (quote_value IS NULL OR quote_value >= 0),
  notes text
);

CREATE TABLE public.dependencies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL,
  kind public.dependency_kind NOT NULL DEFAULT 'other',
  description text NOT NULL,
  party text,
  due_date date,
  status public.dependency_status NOT NULL DEFAULT 'pending',
  blocks_start boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX dependencies_job_idx ON public.dependencies(job_id);

CREATE TABLE public.tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL,
  label text NOT NULL,
  due_date date,
  owner_crew_member_id uuid REFERENCES public.crew_members(id) ON DELETE SET NULL,
  done boolean NOT NULL DEFAULT false,
  done_by uuid,
  done_at timestamptz,
  sort integer NOT NULL DEFAULT 0
);
CREATE INDEX tasks_job_idx ON public.tasks(job_id, sort);

CREATE TABLE public.materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL,
  item text NOT NULL,
  qty numeric,
  unit text,
  status public.material_status NOT NULL DEFAULT 'to order',
  sort integer NOT NULL DEFAULT 0
);
CREATE INDEX materials_job_idx ON public.materials(job_id, sort);

CREATE TABLE public.material_costs (
  material_id uuid PRIMARY KEY REFERENCES public.materials(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL,
  unit_cost numeric NOT NULL CHECK (unit_cost >= 0)
);

-- Job readers: office for now; field users with an assignment are added in build step 6.
CREATE OR REPLACE FUNCTION public.is_job_reader(_job_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.jobs j WHERE j.id = _job_id AND public.is_office(j.workspace_id))
$$;
REVOKE EXECUTE ON FUNCTION public.is_job_reader(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_job_reader(uuid) TO authenticated;

-- Job code, status-from-dates, updated_at
CREATE OR REPLACE FUNCTION public.jobs_before_write()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _prefix text; _n integer;
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.workspaces SET next_job_number = next_job_number + 1
      WHERE id = NEW.workspace_id RETURNING code_prefix, next_job_number - 1 INTO _prefix, _n;
    NEW.code := _prefix || '-' || _n;
  ELSE
    NEW.code := OLD.code;
    NEW.workspace_id := OLD.workspace_id;
  END IF;
  IF NEW.start_date IS NULL AND NEW.status IN ('scheduled','on site') THEN NEW.status := 'ready'; END IF;
  IF NEW.start_date IS NOT NULL AND NEW.status = 'ready' THEN NEW.status := 'scheduled'; END IF;
  IF NEW.duration_unit = 'hours' AND NEW.duration_value > 24 THEN RAISE EXCEPTION 'Use days for jobs longer than a day'; END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;
CREATE TRIGGER jobs_before_write BEFORE INSERT OR UPDATE ON public.jobs
  FOR EACH ROW EXECUTE FUNCTION public.jobs_before_write();

CREATE OR REPLACE FUNCTION public.jobs_default_tasks()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.tasks(job_id, workspace_id, label, sort) VALUES
    (NEW.id, NEW.workspace_id, 'Site measure & inspection', 1),
    (NEW.id, NEW.workspace_id, 'Materials delivered', 2),
    (NEW.id, NEW.workspace_id, 'Subfloor prep complete', 3),
    (NEW.id, NEW.workspace_id, 'Install complete', 4),
    (NEW.id, NEW.workspace_id, 'Client walkthrough & sign-off', 5);
  RETURN NEW;
END $$;
CREATE TRIGGER jobs_default_tasks AFTER INSERT ON public.jobs
  FOR EACH ROW EXECUTE FUNCTION public.jobs_default_tasks();

-- Children take workspace_id from their job (or material)
CREATE OR REPLACE FUNCTION public.job_child_workspace()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  SELECT workspace_id INTO NEW.workspace_id FROM public.jobs WHERE id = NEW.job_id;
  IF NEW.workspace_id IS NULL THEN RAISE EXCEPTION 'Unknown job'; END IF;
  RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION public.material_child_workspace()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  SELECT workspace_id INTO NEW.workspace_id FROM public.materials WHERE id = NEW.material_id;
  IF NEW.workspace_id IS NULL THEN RAISE EXCEPTION 'Unknown material'; END IF;
  RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION public.task_done_stamp()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.done AND (TG_OP = 'INSERT' OR NOT OLD.done) THEN NEW.done_by := auth.uid(); NEW.done_at := now(); END IF;
  IF NOT NEW.done THEN NEW.done_by := NULL; NEW.done_at := NULL; END IF;
  RETURN NEW;
END $$;
REVOKE EXECUTE ON FUNCTION public.jobs_before_write(), public.jobs_default_tasks(), public.job_child_workspace(), public.material_child_workspace(), public.task_done_stamp() FROM PUBLIC, anon, authenticated;

CREATE TRIGGER job_finance_ws BEFORE INSERT OR UPDATE ON public.job_finance FOR EACH ROW EXECUTE FUNCTION public.job_child_workspace();
CREATE TRIGGER dependencies_ws BEFORE INSERT OR UPDATE ON public.dependencies FOR EACH ROW EXECUTE FUNCTION public.job_child_workspace();
CREATE TRIGGER tasks_ws BEFORE INSERT OR UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.job_child_workspace();
CREATE TRIGGER tasks_done BEFORE INSERT OR UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.task_done_stamp();
CREATE TRIGGER materials_ws BEFORE INSERT OR UPDATE ON public.materials FOR EACH ROW EXECUTE FUNCTION public.job_child_workspace();
CREATE TRIGGER material_costs_ws BEFORE INSERT OR UPDATE ON public.material_costs FOR EACH ROW EXECUTE FUNCTION public.material_child_workspace();

GRANT SELECT, INSERT, UPDATE, DELETE ON public.jobs, public.job_finance, public.dependencies, public.tasks, public.materials, public.material_costs TO authenticated;
GRANT ALL ON public.jobs, public.job_finance, public.dependencies, public.tasks, public.materials, public.material_costs TO service_role;

ALTER TABLE public.jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.job_finance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dependencies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.materials ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.material_costs ENABLE ROW LEVEL SECURITY;

-- jobs: job readers read; office writes
CREATE POLICY "Job readers read jobs" ON public.jobs FOR SELECT TO authenticated USING (public.is_job_reader(id));
CREATE POLICY "Office adds jobs" ON public.jobs FOR INSERT TO authenticated WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office updates jobs" ON public.jobs FOR UPDATE TO authenticated USING (public.is_office(workspace_id)) WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office deletes jobs" ON public.jobs FOR DELETE TO authenticated USING (public.is_office(workspace_id));

-- finance tables (rule 3)
CREATE POLICY "Finance reads job finance" ON public.job_finance FOR SELECT TO authenticated USING (public.is_finance(workspace_id));
CREATE POLICY "Finance adds job finance" ON public.job_finance FOR INSERT TO authenticated WITH CHECK (public.is_finance(workspace_id));
CREATE POLICY "Finance updates job finance" ON public.job_finance FOR UPDATE TO authenticated USING (public.is_finance(workspace_id)) WITH CHECK (public.is_finance(workspace_id));
CREATE POLICY "Finance deletes job finance" ON public.job_finance FOR DELETE TO authenticated USING (public.is_finance(workspace_id));
CREATE POLICY "Finance reads material costs" ON public.material_costs FOR SELECT TO authenticated USING (public.is_finance(workspace_id));
CREATE POLICY "Finance adds material costs" ON public.material_costs FOR INSERT TO authenticated WITH CHECK (public.is_finance(workspace_id));
CREATE POLICY "Finance updates material costs" ON public.material_costs FOR UPDATE TO authenticated USING (public.is_finance(workspace_id)) WITH CHECK (public.is_finance(workspace_id));
CREATE POLICY "Finance deletes material costs" ON public.material_costs FOR DELETE TO authenticated USING (public.is_finance(workspace_id));

-- job children follow their job (rule 5); office writes (rule 9; field ticks/foreman delivered come with assignments)
CREATE POLICY "Job readers read dependencies" ON public.dependencies FOR SELECT TO authenticated USING (public.is_job_reader(job_id));
CREATE POLICY "Office adds dependencies" ON public.dependencies FOR INSERT TO authenticated WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office updates dependencies" ON public.dependencies FOR UPDATE TO authenticated USING (public.is_office(workspace_id)) WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office deletes dependencies" ON public.dependencies FOR DELETE TO authenticated USING (public.is_office(workspace_id));

CREATE POLICY "Job readers read tasks" ON public.tasks FOR SELECT TO authenticated USING (public.is_job_reader(job_id));
CREATE POLICY "Office adds tasks" ON public.tasks FOR INSERT TO authenticated WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office updates tasks" ON public.tasks FOR UPDATE TO authenticated USING (public.is_office(workspace_id)) WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office deletes tasks" ON public.tasks FOR DELETE TO authenticated USING (public.is_office(workspace_id));

CREATE POLICY "Job readers read materials" ON public.materials FOR SELECT TO authenticated USING (public.is_job_reader(job_id));
CREATE POLICY "Office adds materials" ON public.materials FOR INSERT TO authenticated WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office updates materials" ON public.materials FOR UPDATE TO authenticated USING (public.is_office(workspace_id)) WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office deletes materials" ON public.materials FOR DELETE TO authenticated USING (public.is_office(workspace_id));

CREATE TRIGGER audit_jobs AFTER INSERT OR UPDATE OR DELETE ON public.jobs FOR EACH ROW EXECUTE FUNCTION public.write_audit();
CREATE TRIGGER audit_job_finance AFTER INSERT OR UPDATE OR DELETE ON public.job_finance FOR EACH ROW EXECUTE FUNCTION public.write_audit();
CREATE TRIGGER audit_dependencies AFTER INSERT OR UPDATE OR DELETE ON public.dependencies FOR EACH ROW EXECUTE FUNCTION public.write_audit();
CREATE TRIGGER audit_tasks AFTER INSERT OR UPDATE OR DELETE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.write_audit();
CREATE TRIGGER audit_materials AFTER INSERT OR UPDATE OR DELETE ON public.materials FOR EACH ROW EXECUTE FUNCTION public.write_audit();
CREATE TRIGGER audit_material_costs AFTER INSERT OR UPDATE OR DELETE ON public.material_costs FOR EACH ROW EXECUTE FUNCTION public.write_audit();