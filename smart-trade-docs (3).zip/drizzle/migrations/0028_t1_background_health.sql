DROP POLICY IF EXISTS "owners read background health" ON public.job_runs;
REVOKE SELECT ON public.job_runs FROM authenticated;

-- Owners see each background job's name, last success and whether it's late; never error text.
-- Lateness mirrors src/lib/rules/job-health.ts (overnight late after 30 minutes; any failure after the last success).
CREATE OR REPLACE FUNCTION private.background_health()
RETURNS TABLE(job text, last_ok_at timestamptz, late boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT r.job, r.last_ok_at,
    (r.last_ok_at IS NULL AND (r.job = 'overnight' OR r.last_error_at IS NOT NULL))
    OR (r.last_error_at IS NOT NULL AND r.last_ok_at IS NOT NULL AND r.last_error_at > r.last_ok_at)
    OR (r.job = 'overnight' AND r.last_ok_at < now() - interval '30 minutes')
  FROM public.job_runs r
  WHERE EXISTS (SELECT 1 FROM public.memberships m WHERE m.user_id = auth.uid() AND m.role = 'owner' AND m.status = 'active' AND private.is_owner(m.workspace_id))
$$;
REVOKE ALL ON FUNCTION private.background_health() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION private.background_health() TO authenticated;
CREATE OR REPLACE FUNCTION public.background_health()
RETURNS TABLE(job text, last_ok_at timestamptz, late boolean)
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$ SELECT * FROM private.background_health() $$;
REVOKE ALL ON FUNCTION public.background_health() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.background_health() TO authenticated;