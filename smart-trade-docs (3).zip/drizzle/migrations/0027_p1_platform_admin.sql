-- P1: platform admin foundation (spec section 12). Platform admins see health, not content.

-- Who is a platform admin. Server code only: no client policies, no client grants.
CREATE TABLE public.platform_admins (
  user_id uuid PRIMARY KEY,
  role text NOT NULL DEFAULT 'superadmin' CHECK (role IN ('superadmin','support')),
  last_seen_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.platform_admins TO service_role;
ALTER TABLE public.platform_admins ENABLE ROW LEVEL SECURITY;

-- Plan and status per workspace. The owner can read their own; only server code writes.
CREATE TABLE public.workspace_billing (
  workspace_id uuid PRIMARY KEY REFERENCES public.workspaces(id) ON DELETE CASCADE,
  plan text NOT NULL DEFAULT 'trial',
  status text NOT NULL DEFAULT 'trial' CHECK (status IN ('trial','active','past_due','paused','cancelled')),
  seats integer NOT NULL DEFAULT 0,
  price_aud numeric NOT NULL DEFAULT 0,
  notes text NOT NULL DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.workspace_billing TO authenticated;
GRANT ALL ON public.workspace_billing TO service_role;
ALTER TABLE public.workspace_billing ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owner reads own billing" ON public.workspace_billing FOR SELECT TO authenticated USING (public.is_owner(workspace_id));
CREATE TRIGGER audit_workspace_billing AFTER INSERT OR UPDATE OR DELETE ON public.workspace_billing FOR EACH ROW EXECUTE FUNCTION public.write_audit();
INSERT INTO public.workspace_billing (workspace_id) SELECT id FROM public.workspaces ON CONFLICT DO NOTHING;

-- Feature and kill switches. workspace_id NULL = platform-wide. Members read theirs and platform-wide; only server code writes.
CREATE TABLE public.workspace_flags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid REFERENCES public.workspaces(id) ON DELETE CASCADE,
  flag text NOT NULL,
  enabled boolean NOT NULL DEFAULT true,
  reason text,
  updated_by uuid,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX workspace_flags_unique ON public.workspace_flags (COALESCE(workspace_id, '00000000-0000-0000-0000-000000000000'::uuid), flag);
GRANT SELECT ON public.workspace_flags TO authenticated;
GRANT ALL ON public.workspace_flags TO service_role;
ALTER TABLE public.workspace_flags ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Members read their flags" ON public.workspace_flags FOR SELECT TO authenticated
  USING (workspace_id IS NULL OR public.is_member(workspace_id));

-- Every admin action. Insert from server code only; nobody updates or deletes.
CREATE TABLE public.platform_audit (
  id bigserial PRIMARY KEY,
  admin_user_id uuid,
  action text NOT NULL,
  workspace_id uuid,
  detail jsonb NOT NULL DEFAULT '{}'::jsonb,
  at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX platform_audit_ws_idx ON public.platform_audit (workspace_id, at DESC);
GRANT SELECT ON public.platform_audit TO authenticated;
GRANT SELECT, INSERT ON public.platform_audit TO service_role;
GRANT USAGE ON SEQUENCE public.platform_audit_id_seq TO service_role;
ALTER TABLE public.platform_audit ENABLE ROW LEVEL SECURITY;
-- The owner can see what platform admins did in their workspace.
CREATE POLICY "Owner reads own platform audit" ON public.platform_audit FOR SELECT TO authenticated
  USING (workspace_id IS NOT NULL AND public.is_owner(workspace_id));
CREATE OR REPLACE FUNCTION public.platform_audit_immutable() RETURNS trigger LANGUAGE plpgsql SET search_path TO 'public'
AS $$ BEGIN RAISE EXCEPTION 'platform_audit is append-only'; END $$;
CREATE TRIGGER platform_audit_no_change BEFORE UPDATE OR DELETE ON public.platform_audit FOR EACH ROW EXECUTE FUNCTION public.platform_audit_immutable();

-- Server errors: workspace, function and a scrubbed message only. Server code only.
CREATE TABLE public.error_events (
  id bigserial PRIMARY KEY,
  workspace_id uuid,
  fn text NOT NULL,
  message text NOT NULL,
  at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX error_events_at_idx ON public.error_events (at DESC);
GRANT ALL ON public.error_events TO service_role;
GRANT USAGE ON SEQUENCE public.error_events_id_seq TO service_role;
ALTER TABLE public.error_events ENABLE ROW LEVEL SECURITY;

-- Workspace switcher: which of their own memberships a person last chose.
ALTER TABLE public.memberships ADD COLUMN IF NOT EXISTS last_selected_at timestamptz;
CREATE OR REPLACE FUNCTION private.select_workspace(_ws uuid) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
BEGIN
  UPDATE public.memberships SET last_selected_at = now()
   WHERE user_id = auth.uid() AND workspace_id = _ws AND status = 'active';
  IF NOT FOUND THEN RAISE EXCEPTION 'You are not in that workspace'; END IF;
END $$;
REVOKE ALL ON FUNCTION private.select_workspace(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION private.select_workspace(uuid) TO authenticated;
CREATE OR REPLACE FUNCTION public.select_workspace(_ws uuid) RETURNS void LANGUAGE sql SET search_path TO 'public'
AS $$ SELECT private.select_workspace(_ws) $$;
GRANT EXECUTE ON FUNCTION public.select_workspace(uuid) TO authenticated;

-- Storage used per workspace (job-files bucket), for the admin area only.
CREATE OR REPLACE FUNCTION private.storage_by_workspace() RETURNS TABLE(workspace_id text, bytes bigint) LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT split_part(name, '/', 1), COALESCE(sum((metadata->>'size')::bigint), 0)::bigint FROM storage.objects WHERE bucket_id = 'job-files' GROUP BY 1 $$;
REVOKE ALL ON FUNCTION private.storage_by_workspace() FROM PUBLIC, authenticated, anon;
GRANT EXECUTE ON FUNCTION private.storage_by_workspace() TO service_role;
CREATE OR REPLACE FUNCTION public.storage_by_workspace() RETURNS TABLE(workspace_id text, bytes bigint) LANGUAGE sql STABLE SET search_path TO 'public'
AS $$ SELECT * FROM private.storage_by_workspace() $$;
REVOKE ALL ON FUNCTION public.storage_by_workspace() FROM PUBLIC, authenticated, anon;
GRANT EXECUTE ON FUNCTION public.storage_by_workspace() TO service_role;

-- New workspaces get a billing row.
CREATE OR REPLACE FUNCTION public.create_workspace_defaults() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
BEGIN
  INSERT INTO public.workspace_settings(workspace_id) VALUES (NEW.id) ON CONFLICT DO NOTHING;
  INSERT INTO public.workspace_finance_settings(workspace_id) VALUES (NEW.id) ON CONFLICT DO NOTHING;
  INSERT INTO public.workspace_billing(workspace_id) VALUES (NEW.id) ON CONFLICT DO NOTHING;
  RETURN NEW;
END $$;

-- Ged is the superadmin.
INSERT INTO public.platform_admins (user_id, role)
SELECT id, 'superadmin' FROM auth.users WHERE lower(email) = 'bourkeged@gmail.com'
ON CONFLICT (user_id) DO UPDATE SET role = 'superadmin';