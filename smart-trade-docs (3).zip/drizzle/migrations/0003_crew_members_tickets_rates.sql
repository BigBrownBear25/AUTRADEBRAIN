CREATE TYPE public.crew_role AS ENUM ('foreman','installer','apprentice');

CREATE TABLE public.crew_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  name text NOT NULL,
  role public.crew_role NOT NULL DEFAULT 'installer',
  is_subcontractor boolean NOT NULL DEFAULT false,
  company_name text,
  base_suburb text,
  base_lat double precision,
  base_lng double precision,
  phone text,
  email text,
  skills text[],
  active boolean NOT NULL DEFAULT true,
  sort integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX crew_members_ws_idx ON public.crew_members(workspace_id, sort);

CREATE TABLE public.crew_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  crew_member_id uuid NOT NULL REFERENCES public.crew_members(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL,
  ticket_type text NOT NULL,
  expires_on date,
  evidence_path text,
  UNIQUE (crew_member_id, ticket_type)
);

CREATE TABLE public.crew_rates (
  crew_member_id uuid PRIMARY KEY REFERENCES public.crew_members(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL,
  day_rate numeric NOT NULL CHECK (day_rate >= 0)
);

-- Helpers
CREATE OR REPLACE FUNCTION public.my_crew_member_ids()
RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT crew_member_id FROM public.memberships
  WHERE user_id = auth.uid() AND status = 'active' AND crew_member_id IS NOT NULL
$$;
REVOKE EXECUTE ON FUNCTION public.my_crew_member_ids() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.my_crew_member_ids() TO authenticated;

-- New person starts with every workspace skill unless skills were given
CREATE OR REPLACE FUNCTION public.crew_default_skills()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.skills IS NULL THEN
    SELECT skills INTO NEW.skills FROM public.workspace_settings WHERE workspace_id = NEW.workspace_id;
    NEW.skills := COALESCE(NEW.skills, '{}');
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER crew_default_skills BEFORE INSERT ON public.crew_members
  FOR EACH ROW EXECUTE FUNCTION public.crew_default_skills();

-- Child rows take workspace_id from their crew member (never from the client)
CREATE OR REPLACE FUNCTION public.crew_child_workspace()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  SELECT workspace_id INTO NEW.workspace_id FROM public.crew_members WHERE id = NEW.crew_member_id;
  IF NEW.workspace_id IS NULL THEN RAISE EXCEPTION 'Unknown crew member'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER crew_tickets_ws BEFORE INSERT OR UPDATE ON public.crew_tickets
  FOR EACH ROW EXECUTE FUNCTION public.crew_child_workspace();
CREATE TRIGGER crew_rates_ws BEFORE INSERT OR UPDATE ON public.crew_rates
  FOR EACH ROW EXECUTE FUNCTION public.crew_child_workspace();
REVOKE EXECUTE ON FUNCTION public.crew_default_skills(), public.crew_child_workspace() FROM PUBLIC, anon, authenticated;

-- A membership may only link to a crew record in the same workspace
CREATE OR REPLACE FUNCTION public.membership_crew_same_ws()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.crew_member_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM public.crew_members c WHERE c.id = NEW.crew_member_id AND c.workspace_id = NEW.workspace_id) THEN
    RAISE EXCEPTION 'Crew record belongs to another workspace';
  END IF;
  RETURN NEW;
END $$;
REVOKE EXECUTE ON FUNCTION public.membership_crew_same_ws() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER memberships_crew_ws BEFORE INSERT OR UPDATE OF crew_member_id ON public.memberships
  FOR EACH ROW EXECUTE FUNCTION public.membership_crew_same_ws();

GRANT SELECT, INSERT, UPDATE, DELETE ON public.crew_members, public.crew_tickets, public.crew_rates TO authenticated;
GRANT ALL ON public.crew_members, public.crew_tickets, public.crew_rates TO service_role;

ALTER TABLE public.crew_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crew_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crew_rates ENABLE ROW LEVEL SECURITY;

-- crew_members: office all (rule 2); field self only (rule 6 shared-job view comes with assignments)
CREATE POLICY "Office reads crew" ON public.crew_members FOR SELECT TO authenticated
  USING (public.is_office(workspace_id));
CREATE POLICY "Field reads own crew record" ON public.crew_members FOR SELECT TO authenticated
  USING (public.is_member(workspace_id) AND id IN (SELECT public.my_crew_member_ids()));
CREATE POLICY "Office adds crew" ON public.crew_members FOR INSERT TO authenticated
  WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office updates crew" ON public.crew_members FOR UPDATE TO authenticated
  USING (public.is_office(workspace_id)) WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office deletes crew" ON public.crew_members FOR DELETE TO authenticated
  USING (public.is_office(workspace_id));

-- crew_tickets: office + the crew member
CREATE POLICY "Office reads tickets" ON public.crew_tickets FOR SELECT TO authenticated
  USING (public.is_office(workspace_id));
CREATE POLICY "Crew member reads own tickets" ON public.crew_tickets FOR SELECT TO authenticated
  USING (public.is_member(workspace_id) AND crew_member_id IN (SELECT public.my_crew_member_ids()));
CREATE POLICY "Office adds tickets" ON public.crew_tickets FOR INSERT TO authenticated
  WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office updates tickets" ON public.crew_tickets FOR UPDATE TO authenticated
  USING (public.is_office(workspace_id)) WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office deletes tickets" ON public.crew_tickets FOR DELETE TO authenticated
  USING (public.is_office(workspace_id));

-- crew_rates: finance only (rule 3)
CREATE POLICY "Finance reads rates" ON public.crew_rates FOR SELECT TO authenticated
  USING (public.is_finance(workspace_id));
CREATE POLICY "Finance adds rates" ON public.crew_rates FOR INSERT TO authenticated
  WITH CHECK (public.is_finance(workspace_id));
CREATE POLICY "Finance updates rates" ON public.crew_rates FOR UPDATE TO authenticated
  USING (public.is_finance(workspace_id)) WITH CHECK (public.is_finance(workspace_id));
CREATE POLICY "Finance deletes rates" ON public.crew_rates FOR DELETE TO authenticated
  USING (public.is_finance(workspace_id));

CREATE TRIGGER audit_crew_members AFTER INSERT OR UPDATE OR DELETE ON public.crew_members
  FOR EACH ROW EXECUTE FUNCTION public.write_audit();
CREATE TRIGGER audit_crew_tickets AFTER INSERT OR UPDATE OR DELETE ON public.crew_tickets
  FOR EACH ROW EXECUTE FUNCTION public.write_audit();
CREATE TRIGGER audit_crew_rates AFTER INSERT OR UPDATE OR DELETE ON public.crew_rates
  FOR EACH ROW EXECUTE FUNCTION public.write_audit();

-- Owner links any membership (including their own) to a crew record
CREATE OR REPLACE FUNCTION public.link_membership_crew(_membership_id uuid, _crew_member_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _ws uuid;
BEGIN
  SELECT workspace_id INTO _ws FROM public.memberships WHERE id = _membership_id;
  IF _ws IS NULL OR NOT public.is_owner(_ws) THEN RAISE EXCEPTION 'Only the owner can link accounts'; END IF;
  IF _crew_member_id IS NOT NULL AND EXISTS (
    SELECT 1 FROM public.memberships WHERE crew_member_id = _crew_member_id AND id <> _membership_id AND status <> 'removed') THEN
    RAISE EXCEPTION 'That crew record is already linked to another account';
  END IF;
  UPDATE public.memberships SET crew_member_id = _crew_member_id WHERE id = _membership_id;
END $$;
REVOKE EXECUTE ON FUNCTION public.link_membership_crew(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.link_membership_crew(uuid, uuid) TO authenticated;

-- Accepting an invite also links the crew record (chosen at invite, else matched by email)
CREATE OR REPLACE FUNCTION public.accept_pending_invites()
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _email text; _n integer;
BEGIN
  SELECT lower(email) INTO _email FROM auth.users
    WHERE id = auth.uid() AND email_confirmed_at IS NOT NULL;
  IF _email IS NULL THEN RETURN 0; END IF;
  UPDATE public.memberships m SET user_id = auth.uid(), status = 'active',
    crew_member_id = COALESCE(m.crew_member_id, (
      SELECT c.id FROM public.crew_members c
      WHERE c.workspace_id = m.workspace_id AND lower(c.email) = _email
        AND NOT EXISTS (SELECT 1 FROM public.memberships x WHERE x.crew_member_id = c.id AND x.status <> 'removed')
      ORDER BY c.created_at LIMIT 1))
    WHERE m.status = 'invited' AND m.user_id IS NULL AND lower(m.invited_email) = _email
      AND NOT EXISTS (SELECT 1 FROM public.memberships m2 WHERE m2.workspace_id = m.workspace_id AND m2.user_id = auth.uid());
  GET DIAGNOSTICS _n = ROW_COUNT;
  RETURN _n;
END $$;