CREATE TYPE public.leave_status AS ENUM ('requested', 'approved', 'declined');

CREATE TABLE public.leave (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  crew_member_id uuid NOT NULL REFERENCES public.crew_members(id) ON DELETE CASCADE,
  type text NOT NULL,
  from_date date NOT NULL,
  to_date date NOT NULL,
  start_time time,
  end_time time,
  status public.leave_status NOT NULL DEFAULT 'requested',
  note text,
  decided_by uuid,
  decided_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT leave_dates_order CHECK (to_date >= from_date),
  CONSTRAINT leave_times_pair CHECK ((start_time IS NULL) = (end_time IS NULL) AND (start_time IS NULL OR end_time > start_time))
);
CREATE INDEX leave_crew_dates_idx ON public.leave(crew_member_id, from_date, to_date);
CREATE INDEX leave_ws_dates_idx ON public.leave(workspace_id, from_date);

CREATE OR REPLACE FUNCTION public.leave_before_write()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  SELECT workspace_id INTO NEW.workspace_id FROM public.crew_members WHERE id = NEW.crew_member_id;
  IF NEW.workspace_id IS NULL THEN RAISE EXCEPTION 'Unknown crew member'; END IF;
  IF auth.uid() IS NOT NULL AND NOT public.is_office(NEW.workspace_id) THEN
    -- Field users: own requests only, and only while still requested.
    IF NEW.crew_member_id NOT IN (SELECT public.my_crew_member_ids()) THEN RAISE EXCEPTION 'You can only request your own leave'; END IF;
    IF TG_OP = 'UPDATE' AND (OLD.status <> 'requested' OR OLD.crew_member_id <> NEW.crew_member_id) THEN RAISE EXCEPTION 'Leave can only be changed while it is still requested'; END IF;
    NEW.status := 'requested'; NEW.decided_by := NULL; NEW.decided_at := NULL;
  ELSIF TG_OP = 'INSERT' AND NEW.status <> 'requested' OR TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    NEW.decided_by := CASE WHEN NEW.status = 'requested' THEN NULL ELSE auth.uid() END;
    NEW.decided_at := CASE WHEN NEW.status = 'requested' THEN NULL ELSE now() END;
  END IF;
  RETURN NEW;
END $$;
REVOKE EXECUTE ON FUNCTION public.leave_before_write() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER leave_before_write BEFORE INSERT OR UPDATE ON public.leave FOR EACH ROW EXECUTE FUNCTION public.leave_before_write();

GRANT SELECT, INSERT, UPDATE, DELETE ON public.leave TO authenticated;
GRANT ALL ON public.leave TO service_role;
ALTER TABLE public.leave ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Office reads leave" ON public.leave FOR SELECT TO authenticated USING (public.is_office(workspace_id));
CREATE POLICY "Field reads own leave" ON public.leave FOR SELECT TO authenticated
  USING (public.is_member(workspace_id) AND crew_member_id IN (SELECT public.my_crew_member_ids()));
CREATE POLICY "Office adds leave" ON public.leave FOR INSERT TO authenticated WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Field requests own leave" ON public.leave FOR INSERT TO authenticated
  WITH CHECK (public.is_member(workspace_id) AND crew_member_id IN (SELECT public.my_crew_member_ids()) AND status = 'requested');
CREATE POLICY "Office updates leave" ON public.leave FOR UPDATE TO authenticated
  USING (public.is_office(workspace_id)) WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Field edits own requested leave" ON public.leave FOR UPDATE TO authenticated
  USING (status = 'requested' AND crew_member_id IN (SELECT public.my_crew_member_ids()))
  WITH CHECK (status = 'requested' AND crew_member_id IN (SELECT public.my_crew_member_ids()));
CREATE POLICY "Office deletes leave" ON public.leave FOR DELETE TO authenticated USING (public.is_office(workspace_id));
CREATE POLICY "Field withdraws own requested leave" ON public.leave FOR DELETE TO authenticated
  USING (status = 'requested' AND crew_member_id IN (SELECT public.my_crew_member_ids()));
CREATE TRIGGER audit_leave AFTER INSERT OR UPDATE OR DELETE ON public.leave FOR EACH ROW EXECUTE FUNCTION public.write_audit();

-- Rule 7: crew mates on a shared job show only as "Away" — crew member and date, never type or note.
CREATE OR REPLACE FUNCTION public.away_days(_job_id uuid)
RETURNS TABLE (crew_member_id uuid, date date)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT DISTINCT a.crew_member_id, a.date
  FROM public.assignments a
  JOIN public.leave l ON l.crew_member_id = a.crew_member_id AND l.status = 'approved' AND a.date BETWEEN l.from_date AND l.to_date
  WHERE a.job_id = _job_id AND public.is_job_reader(_job_id)
  ORDER BY a.date
$$;
REVOKE EXECUTE ON FUNCTION public.away_days(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.away_days(uuid) TO authenticated;

-- Public holidays: shared reference list by state, filtered per workspace by holiday_states.
CREATE TABLE public.public_holidays (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  state text NOT NULL,
  date date NOT NULL,
  name text NOT NULL,
  UNIQUE (state, date)
);
GRANT SELECT ON public.public_holidays TO authenticated;
GRANT ALL ON public.public_holidays TO service_role;
ALTER TABLE public.public_holidays ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Signed-in users read public holidays" ON public.public_holidays FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);