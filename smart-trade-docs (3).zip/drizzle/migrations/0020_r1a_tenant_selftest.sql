CREATE OR REPLACE FUNCTION public.selftest_proposal_tenant() RETURNS TABLE(test text, passed boolean)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE _ws uuid; _own uuid; _foreign uuid;
BEGIN
  SELECT w.id INTO _ws FROM public.workspaces w
   WHERE EXISTS (SELECT 1 FROM public.crew_members c WHERE c.workspace_id = w.id)
     AND EXISTS (SELECT 1 FROM public.crew_members c WHERE c.workspace_id <> w.id) LIMIT 1;
  IF _ws IS NULL THEN RETURN QUERY SELECT 'needs two workspaces with crew'::text, false; RETURN; END IF;
  SELECT id INTO _own FROM public.crew_members WHERE workspace_id = _ws LIMIT 1;
  SELECT id INTO _foreign FROM public.crew_members WHERE workspace_id <> _ws LIMIT 1;
  RETURN QUERY VALUES
    ('rows naming another workspace crew member are refused', NOT private.proposal_tenant_ok(_ws, NULL, 'place', jsonb_build_object('rows', jsonb_build_array(jsonb_build_object('crew_member_id', _foreign))))),
    ('mixed rows (one foreign) are refused', NOT private.proposal_tenant_ok(_ws, NULL, 'swap', jsonb_build_object('rows', jsonb_build_array(jsonb_build_object('crew_member_id', _own), jsonb_build_object('crew_member_id', _foreign))))),
    ('ticket for another workspace crew member is refused', NOT private.proposal_tenant_ok(_ws, NULL, 'update_ticket', jsonb_build_object('crew_member_id', _foreign, 'ticket_type', 'x'))),
    ('leave for another workspace crew member is refused', NOT private.proposal_tenant_ok(_ws, NULL, 'leave_request', jsonb_build_object('crew_member_id', _foreign))),
    ('own crew member is allowed', private.proposal_tenant_ok(_ws, NULL, 'place', jsonb_build_object('rows', jsonb_build_array(jsonb_build_object('crew_member_id', _own))))),
    ('undo naming another workspace crew member is refused', NOT private.undo_tenant_ok(_ws, NULL, jsonb_build_object('rows', jsonb_build_array(jsonb_build_object('crew_member_id', _foreign)))));
END $$;
REVOKE ALL ON FUNCTION public.selftest_proposal_tenant() FROM PUBLIC, anon, authenticated;
DO $$ BEGIN IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'supabase_read_only_user') THEN
  GRANT EXECUTE ON FUNCTION public.selftest_proposal_tenant() TO supabase_read_only_user; END IF; END $$;