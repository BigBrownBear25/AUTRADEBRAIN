ALTER TYPE public.message_speaker ADD VALUE IF NOT EXISTS 'email';

ALTER TABLE public.workspaces ADD COLUMN inbound_key text NOT NULL DEFAULT lower(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10));
CREATE UNIQUE INDEX workspaces_inbound_key_uq ON public.workspaces(inbound_key);

CREATE TYPE public.inbound_status AS ENUM ('unfiled', 'filed', 'ignored');
CREATE TABLE public.inbound_emails (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  job_id uuid REFERENCES public.jobs(id) ON DELETE SET NULL,
  message_id uuid REFERENCES public.messages(id) ON DELETE SET NULL,
  from_address text NOT NULL DEFAULT '',
  subject text NOT NULL DEFAULT '',
  body_text text NOT NULL DEFAULT '',
  files jsonb NOT NULL DEFAULT '[]'::jsonb,
  received_at timestamptz NOT NULL DEFAULT now(),
  status public.inbound_status NOT NULL DEFAULT 'unfiled',
  ai_suggestion jsonb,
  filed_by uuid,
  filed_at timestamptz
);
CREATE INDEX inbound_emails_ws_idx ON public.inbound_emails(workspace_id, status, received_at DESC);
GRANT SELECT ON public.inbound_emails TO authenticated;
GRANT ALL ON public.inbound_emails TO service_role;
ALTER TABLE public.inbound_emails ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Office reads inbound email" ON public.inbound_emails FOR SELECT TO authenticated USING (public.is_office(workspace_id));
CREATE TRIGGER audit_inbound_emails AFTER INSERT OR UPDATE OR DELETE ON public.inbound_emails FOR EACH ROW EXECUTE FUNCTION public.write_audit();