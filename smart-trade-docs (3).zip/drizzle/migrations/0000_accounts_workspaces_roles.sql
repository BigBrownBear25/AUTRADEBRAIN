CREATE TYPE public.app_role AS ENUM ('owner','office','foreman','installer','apprentice','subcontractor');
CREATE TYPE public.membership_status AS ENUM ('invited','active','removed');

CREATE TABLE public.workspaces (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code_prefix text NOT NULL DEFAULT 'TB',
  timezone text NOT NULL DEFAULT 'Australia/Melbourne',
  depot_name text,
  depot_lat double precision,
  depot_lng double precision,
  finance_visible_to_office boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.memberships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  user_id uuid,
  role public.app_role NOT NULL,
  crew_member_id uuid,
  status public.membership_status NOT NULL DEFAULT 'invited',
  invited_email text,
  invited_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT memberships_user_or_email CHECK (user_id IS NOT NULL OR invited_email IS NOT NULL)
);
CREATE UNIQUE INDEX memberships_ws_user_uq ON public.memberships(workspace_id, user_id) WHERE user_id IS NOT NULL;
CREATE UNIQUE INDEX memberships_ws_email_uq ON public.memberships(workspace_id, lower(invited_email)) WHERE status = 'invited';
CREATE INDEX memberships_user_idx ON public.memberships(user_id);

CREATE TABLE public.audit_log (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  workspace_id uuid,
  actor_user_id uuid,
  action text NOT NULL,
  table_name text NOT NULL,
  row_id text,
  before jsonb,
  after jsonb,
  at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_log_ws_idx ON public.audit_log(workspace_id, at DESC);

GRANT SELECT, UPDATE ON public.workspaces TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.memberships TO authenticated;
GRANT SELECT ON public.audit_log TO authenticated;
GRANT ALL ON public.workspaces, public.memberships, public.audit_log TO service_role;

ALTER TABLE public.workspaces ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

-- Helper functions (security definer avoids recursive RLS)
CREATE OR REPLACE FUNCTION public.has_workspace_role(_ws uuid, _roles public.app_role[])
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.memberships
    WHERE workspace_id = _ws AND user_id = auth.uid() AND status = 'active' AND role = ANY(_roles))
$$;
CREATE OR REPLACE FUNCTION public.is_member(_ws uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.memberships
    WHERE workspace_id = _ws AND user_id = auth.uid() AND status = 'active')
$$;
CREATE OR REPLACE FUNCTION public.is_office(_ws uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.has_workspace_role(_ws, ARRAY['owner','office']::public.app_role[])
$$;
CREATE OR REPLACE FUNCTION public.is_owner(_ws uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.has_workspace_role(_ws, ARRAY['owner']::public.app_role[])
$$;

-- workspaces: members read (rule 1), owner writes
CREATE POLICY "Members read their workspace" ON public.workspaces FOR SELECT TO authenticated
  USING (public.is_member(id));
CREATE POLICY "Owner updates workspace" ON public.workspaces FOR UPDATE TO authenticated
  USING (public.is_owner(id)) WITH CHECK (public.is_owner(id));

-- memberships: office reads all (rule 2), field reads own row only (rule 8)
CREATE POLICY "Office reads all memberships" ON public.memberships FOR SELECT TO authenticated
  USING (public.is_office(workspace_id));
CREATE POLICY "Members read own membership" ON public.memberships FOR SELECT TO authenticated
  USING (user_id = auth.uid() AND status = 'active');
CREATE POLICY "Owner invites any non-owner role" ON public.memberships FOR INSERT TO authenticated
  WITH CHECK (public.is_owner(workspace_id) AND role <> 'owner' AND status = 'invited' AND user_id IS NULL AND invited_by = auth.uid());
CREATE POLICY "Office invites field roles" ON public.memberships FOR INSERT TO authenticated
  WITH CHECK (public.is_office(workspace_id) AND role IN ('foreman','installer','apprentice','subcontractor') AND status = 'invited' AND user_id IS NULL AND invited_by = auth.uid());
CREATE POLICY "Owner updates memberships" ON public.memberships FOR UPDATE TO authenticated
  USING (public.is_owner(workspace_id) AND role <> 'owner')
  WITH CHECK (public.is_owner(workspace_id) AND role <> 'owner');
CREATE POLICY "Owner deletes pending invites" ON public.memberships FOR DELETE TO authenticated
  USING (public.is_owner(workspace_id) AND status = 'invited');

-- audit_log: owner reads only; no write policies (triggers only)
CREATE POLICY "Owner reads audit log" ON public.audit_log FOR SELECT TO authenticated
  USING (workspace_id IS NOT NULL AND public.is_owner(workspace_id));

-- Audit trigger
CREATE OR REPLACE FUNCTION public.write_audit()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _ws uuid; _row jsonb;
BEGIN
  _row := to_jsonb(COALESCE(NEW, OLD));
  IF TG_TABLE_NAME = 'workspaces' THEN _ws := (_row->>'id')::uuid;
  ELSE _ws := (_row->>'workspace_id')::uuid; END IF;
  INSERT INTO public.audit_log(workspace_id, actor_user_id, action, table_name, row_id, before, after)
  VALUES (_ws, auth.uid(), lower(TG_OP), TG_TABLE_NAME, _row->>'id',
    CASE WHEN TG_OP IN ('UPDATE','DELETE') THEN to_jsonb(OLD) END,
    CASE WHEN TG_OP IN ('INSERT','UPDATE') THEN to_jsonb(NEW) END);
  RETURN COALESCE(NEW, OLD);
END $$;
CREATE TRIGGER audit_workspaces AFTER INSERT OR UPDATE OR DELETE ON public.workspaces
  FOR EACH ROW EXECUTE FUNCTION public.write_audit();
CREATE TRIGGER audit_memberships AFTER INSERT OR UPDATE OR DELETE ON public.memberships
  FOR EACH ROW EXECUTE FUNCTION public.write_audit();

-- audit_log itself is append-only: block edits and deletes
CREATE OR REPLACE FUNCTION public.audit_log_immutable()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN RAISE EXCEPTION 'audit_log is append-only'; END $$;
CREATE TRIGGER audit_log_no_change BEFORE UPDATE OR DELETE ON public.audit_log
  FOR EACH ROW EXECUTE FUNCTION public.audit_log_immutable();

-- Sign-up creates a workspace when the user supplied a workspace name
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _ws uuid; _name text;
BEGIN
  _name := nullif(trim(NEW.raw_user_meta_data->>'workspace_name'), '');
  IF _name IS NOT NULL THEN
    INSERT INTO public.workspaces(name) VALUES (_name) RETURNING id INTO _ws;
    INSERT INTO public.memberships(workspace_id, user_id, role, status)
      VALUES (_ws, NEW.id, 'owner', 'active');
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Accept invites addressed to the caller's verified email
CREATE OR REPLACE FUNCTION public.accept_pending_invites()
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _email text; _n integer;
BEGIN
  SELECT lower(email) INTO _email FROM auth.users
    WHERE id = auth.uid() AND email_confirmed_at IS NOT NULL;
  IF _email IS NULL THEN RETURN 0; END IF;
  UPDATE public.memberships SET user_id = auth.uid(), status = 'active'
    WHERE status = 'invited' AND user_id IS NULL AND lower(invited_email) = _email
      AND NOT EXISTS (SELECT 1 FROM public.memberships m2 WHERE m2.workspace_id = memberships.workspace_id AND m2.user_id = auth.uid());
  GET DIAGNOSTICS _n = ROW_COUNT;
  RETURN _n;
END $$;

REVOKE EXECUTE ON FUNCTION public.handle_new_user(), public.write_audit(), public.audit_log_immutable() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.accept_pending_invites() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.accept_pending_invites() TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_workspace_role(uuid, public.app_role[]), public.is_member(uuid), public.is_office(uuid), public.is_owner(uuid) TO authenticated;