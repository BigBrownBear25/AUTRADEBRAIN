-- ===== Audit reason: allow "brain:<source>" alongside the move reasons =====
ALTER TABLE public.audit_log DROP CONSTRAINT IF EXISTS audit_log_reason_check;
ALTER TABLE public.audit_log ADD CONSTRAINT audit_log_reason_check CHECK (
  reason IS NULL OR reason IN ('builder_delay','weather','crew_away','materials','client_request','other') OR reason ~ '^brain:[a-z_]+$');

CREATE OR REPLACE FUNCTION public.write_audit()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _ws uuid; _row jsonb; _reason text;
BEGIN
  _row := to_jsonb(COALESCE(NEW, OLD));
  IF TG_TABLE_NAME = 'workspaces' THEN _ws := (_row->>'id')::uuid;
  ELSE _ws := (_row->>'workspace_id')::uuid; END IF;
  _reason := nullif(current_setting('app.move_reason', true), '');
  IF _reason IS NOT NULL AND NOT (_reason IN ('builder_delay','weather','crew_away','materials','client_request','other') OR _reason ~ '^brain:[a-z_]+$') THEN _reason := NULL; END IF;
  INSERT INTO public.audit_log(workspace_id, actor_user_id, action, table_name, row_id, before, after, reason)
  VALUES (_ws, auth.uid(), lower(TG_OP), TG_TABLE_NAME, _row->>'id',
    CASE WHEN TG_OP IN ('UPDATE','DELETE') THEN to_jsonb(OLD) END,
    CASE WHEN TG_OP IN ('INSERT','UPDATE') THEN to_jsonb(NEW) END, _reason);
  RETURN COALESCE(NEW, OLD);
END $$;
REVOKE EXECUTE ON FUNCTION public.write_audit() FROM PUBLIC, anon, authenticated;

-- ===== Enums =====
CREATE TYPE public.proposal_source AS ENUM ('brief','watcher','overnight','capture','ask','email','photo','document','variation');
CREATE TYPE public.proposal_kind AS ENUM ('place','move','swap','add_person','remove_person','create_job','update_job','add_task','add_dependency','update_dependency','mark_delivered','update_ticket','leave_request','log_call','send_email','send_sms');
CREATE TYPE public.proposal_status AS ENUM ('open','applied','dismissed','expired','superseded','undone');

-- ===== brain_settings =====
CREATE TABLE public.brain_settings (
  workspace_id uuid PRIMARY KEY REFERENCES public.workspaces(id) ON DELETE CASCADE,
  features jsonb NOT NULL DEFAULT '{"capture":true,"ask":true,"watcher":true,"overnight":true,"lookahead":true,"email":true,"photos":true,"documents":true,"variations":true,"swms":true,"memory":true,"sms":false}',
  quiet_from time NOT NULL DEFAULT '20:00',
  quiet_to time NOT NULL DEFAULT '05:00',
  monthly_ai_budget numeric(10,2) NOT NULL DEFAULT 100,
  sms_auto_reminders boolean NOT NULL DEFAULT false,
  variation_price_to_builder boolean NOT NULL DEFAULT false,
  sms_templates jsonb NOT NULL DEFAULT '{}',
  timezone text NOT NULL DEFAULT 'Australia/Melbourne',
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.brain_settings TO authenticated;
GRANT ALL ON public.brain_settings TO service_role;
ALTER TABLE public.brain_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY brain_settings_read ON public.brain_settings FOR SELECT TO authenticated USING (public.is_office(workspace_id));
CREATE POLICY brain_settings_insert ON public.brain_settings FOR INSERT TO authenticated WITH CHECK (public.is_owner(workspace_id));
CREATE POLICY brain_settings_update ON public.brain_settings FOR UPDATE TO authenticated USING (public.is_owner(workspace_id)) WITH CHECK (public.is_owner(workspace_id));
CREATE TRIGGER audit_brain_settings AFTER INSERT OR UPDATE OR DELETE ON public.brain_settings FOR EACH ROW EXECUTE FUNCTION public.write_audit();

-- ===== ai_config =====
CREATE TABLE public.ai_config (
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  function text NOT NULL,
  model text NOT NULL,
  max_tokens integer NOT NULL DEFAULT 4000 CHECK (max_tokens BETWEEN 256 AND 32000),
  max_tool_rounds integer NOT NULL DEFAULT 8 CHECK (max_tool_rounds BETWEEN 0 AND 12),
  PRIMARY KEY (workspace_id, function)
);
GRANT SELECT, INSERT, UPDATE ON public.ai_config TO authenticated;
GRANT ALL ON public.ai_config TO service_role;
ALTER TABLE public.ai_config ENABLE ROW LEVEL SECURITY;
CREATE POLICY ai_config_owner_read ON public.ai_config FOR SELECT TO authenticated USING (public.is_owner(workspace_id));
CREATE POLICY ai_config_owner_insert ON public.ai_config FOR INSERT TO authenticated WITH CHECK (public.is_owner(workspace_id));
CREATE POLICY ai_config_owner_update ON public.ai_config FOR UPDATE TO authenticated USING (public.is_owner(workspace_id)) WITH CHECK (public.is_owner(workspace_id));
CREATE TRIGGER audit_ai_config AFTER INSERT OR UPDATE OR DELETE ON public.ai_config FOR EACH ROW EXECUTE FUNCTION public.write_audit();

CREATE OR REPLACE FUNCTION private.seed_brain_defaults(_ws uuid) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.brain_settings(workspace_id) VALUES (_ws) ON CONFLICT DO NOTHING;
  INSERT INTO public.ai_config(workspace_id, function, model, max_tokens, max_tool_rounds) VALUES
    (_ws,'capture','anthropic/claude-sonnet-5',3000,4),
    (_ws,'ask','anthropic/claude-sonnet-5',4000,8),
    (_ws,'brief','anthropic/claude-sonnet-5',2000,0),
    (_ws,'summary','anthropic/claude-sonnet-5',4000,0),
    (_ws,'guidance','anthropic/claude-sonnet-5',4000,0),
    (_ws,'drafting','anthropic/claude-sonnet-5',4000,4),
    (_ws,'documents','anthropic/claude-sonnet-5',6000,0),
    (_ws,'lookahead','anthropic/claude-sonnet-5',3000,0),
    (_ws,'watcher','anthropic/claude-sonnet-5',2000,4),
    (_ws,'email_sort','anthropic/claude-haiku-5',2000,2),
    (_ws,'photo_tag','anthropic/claude-haiku-5',1500,0)
  ON CONFLICT DO NOTHING;
END $$;
REVOKE ALL ON FUNCTION private.seed_brain_defaults(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION private.seed_brain_defaults(uuid) TO service_role;

CREATE OR REPLACE FUNCTION private.workspace_brain_defaults() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN PERFORM private.seed_brain_defaults(NEW.id); RETURN NEW; END $$;
REVOKE ALL ON FUNCTION private.workspace_brain_defaults() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER workspace_brain_defaults AFTER INSERT ON public.workspaces FOR EACH ROW EXECUTE FUNCTION private.workspace_brain_defaults();
DO $$ DECLARE w record; BEGIN FOR w IN SELECT id FROM public.workspaces LOOP PERFORM private.seed_brain_defaults(w.id); END LOOP; END $$;

-- ===== proposals =====
CREATE TABLE public.proposals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  job_id uuid REFERENCES public.jobs(id) ON DELETE CASCADE,
  source public.proposal_source NOT NULL,
  kind public.proposal_kind NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}',
  fit jsonb,
  level text NOT NULL DEFAULT 'info' CHECK (level IN ('red','amber','info')),
  title text NOT NULL DEFAULT '',
  explanation text NOT NULL DEFAULT '',
  status public.proposal_status NOT NULL DEFAULT 'open',
  group_id uuid,
  group_label text,
  dedupe_key text,
  created_by uuid,
  created_by_brain boolean NOT NULL DEFAULT true,
  decided_by uuid,
  decided_at timestamptz,
  dismiss_reason text CHECK (dismiss_reason IS NULL OR dismiss_reason IN ('wrong','not_now','already_done','other')),
  undo jsonb,
  result jsonb,
  expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX proposals_ws_status_idx ON public.proposals(workspace_id, status, created_at DESC);
CREATE INDEX proposals_job_idx ON public.proposals(job_id);
CREATE INDEX proposals_group_idx ON public.proposals(group_id);
CREATE UNIQUE INDEX proposals_open_dedupe_uq ON public.proposals(workspace_id, dedupe_key) WHERE status = 'open' AND dedupe_key IS NOT NULL;
GRANT SELECT, INSERT ON public.proposals TO authenticated;
GRANT ALL ON public.proposals TO service_role;
ALTER TABLE public.proposals ENABLE ROW LEVEL SECURITY;
CREATE POLICY proposals_read ON public.proposals FOR SELECT TO authenticated
  USING (public.is_office(workspace_id) OR (created_by = auth.uid() AND public.is_member(workspace_id)));
-- People create proposals only as themselves and only while open; field users only on their own jobs or for leave
CREATE POLICY proposals_insert ON public.proposals FOR INSERT TO authenticated WITH CHECK (
  created_by = auth.uid() AND status = 'open' AND public.is_member(workspace_id) AND kind NOT IN ('send_email','send_sms')
  AND (public.is_office(workspace_id)
       OR (kind = 'leave_request' AND job_id IS NULL AND (payload->>'crew_member_id')::uuid IN (SELECT public.my_crew_member_ids()))
       OR (job_id IS NOT NULL AND public.is_assigned_to_job(job_id) AND kind IN ('add_task','update_dependency','mark_delivered'))));
CREATE TRIGGER audit_proposals AFTER INSERT OR UPDATE OR DELETE ON public.proposals FOR EACH ROW EXECUTE FUNCTION public.write_audit();
CREATE TRIGGER proposals_ws BEFORE INSERT OR UPDATE ON public.proposals FOR EACH ROW WHEN (NEW.job_id IS NOT NULL) EXECUTE FUNCTION public.job_child_workspace();

-- ===== notifications =====
CREATE TABLE public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  kind text NOT NULL,
  level text NOT NULL DEFAULT 'info' CHECK (level IN ('red','amber','info')),
  title text NOT NULL,
  body text NOT NULL DEFAULT '',
  job_id uuid REFERENCES public.jobs(id) ON DELETE CASCADE,
  proposal_id uuid REFERENCES public.proposals(id) ON DELETE CASCADE,
  read_at timestamptz,
  pushed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX notifications_user_idx ON public.notifications(user_id, created_at DESC);
GRANT SELECT, UPDATE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY notifications_own_read ON public.notifications FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY notifications_own_update ON public.notifications FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE TRIGGER audit_notifications AFTER INSERT OR DELETE ON public.notifications FOR EACH ROW EXECUTE FUNCTION public.write_audit();

-- ===== ai_runs =====
CREATE TABLE public.ai_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  user_id uuid,
  function text NOT NULL,
  model text NOT NULL,
  input_tokens integer NOT NULL DEFAULT 0,
  output_tokens integer NOT NULL DEFAULT 0,
  tool_calls jsonb NOT NULL DEFAULT '[]',
  ok boolean NOT NULL DEFAULT true,
  error text,
  ms integer NOT NULL DEFAULT 0,
  cost_aud numeric(10,4) NOT NULL DEFAULT 0,
  at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ai_runs_ws_idx ON public.ai_runs(workspace_id, at DESC);
CREATE INDEX ai_runs_user_idx ON public.ai_runs(user_id, at DESC);
GRANT SELECT ON public.ai_runs TO authenticated;
GRANT ALL ON public.ai_runs TO service_role;
ALTER TABLE public.ai_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY ai_runs_owner_read ON public.ai_runs FOR SELECT TO authenticated USING (public.is_owner(workspace_id));
CREATE TRIGGER audit_ai_runs AFTER INSERT ON public.ai_runs FOR EACH ROW EXECUTE FUNCTION public.write_audit();

-- ===== brain_events (filled by triggers; the watcher marks them processed) =====
CREATE TABLE public.brain_events (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  kind text NOT NULL,
  table_name text NOT NULL,
  row_id text,
  job_id uuid,
  crew_member_id uuid,
  at timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz
);
CREATE INDEX brain_events_pending_idx ON public.brain_events(workspace_id, at) WHERE processed_at IS NULL;
GRANT SELECT ON public.brain_events TO authenticated;
GRANT ALL ON public.brain_events TO service_role;
ALTER TABLE public.brain_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY brain_events_owner_read ON public.brain_events FOR SELECT TO authenticated USING (public.is_owner(workspace_id));

CREATE OR REPLACE FUNCTION private.record_brain_event() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _r jsonb := to_jsonb(COALESCE(NEW, OLD)); _o jsonb := CASE WHEN TG_OP = 'UPDATE' THEN to_jsonb(OLD) END;
  _kind text; _job uuid; _crew uuid;
BEGIN
  _job := CASE WHEN TG_TABLE_NAME = 'jobs' THEN (_r->>'id')::uuid ELSE nullif(_r->>'job_id','')::uuid END;
  _crew := nullif(_r->>'crew_member_id','')::uuid;
  IF TG_TABLE_NAME = 'leave' THEN _kind := CASE WHEN TG_OP = 'INSERT' THEN 'leave_created' ELSE 'leave_changed' END;
  ELSIF TG_TABLE_NAME = 'assignments' THEN _kind := 'assignments_changed';
  ELSIF TG_TABLE_NAME = 'messages' THEN
    IF _r->>'kind' <> 'problem' OR TG_OP <> 'INSERT' THEN RETURN NULL; END IF; _kind := 'problem_posted';
  ELSIF TG_TABLE_NAME = 'inbound_emails' THEN
    IF _r->>'status' <> 'filed' OR (_o IS NOT NULL AND _o->>'status' = 'filed') THEN RETURN NULL; END IF; _kind := 'email_filed';
  ELSIF TG_TABLE_NAME IN ('materials','dependencies') THEN
    IF TG_OP = 'UPDATE' AND _o->>'status' = _r->>'status' AND _o->>'due_date' IS NOT DISTINCT FROM _r->>'due_date' THEN RETURN NULL; END IF; _kind := TG_TABLE_NAME || '_changed';
  ELSIF TG_TABLE_NAME = 'jobs' THEN
    IF TG_OP = 'UPDATE' AND _o->>'start_date' IS NOT DISTINCT FROM _r->>'start_date' AND _o->>'due_by' IS NOT DISTINCT FROM _r->>'due_by'
       AND _o->>'crew_size' IS NOT DISTINCT FROM _r->>'crew_size' AND _o->>'status' IS NOT DISTINCT FROM _r->>'status' THEN RETURN NULL; END IF;
    _kind := 'job_changed';
  ELSIF TG_TABLE_NAME = 'crew_tickets' THEN
    IF nullif(_r->>'expires_on','') IS NULL OR (_r->>'expires_on')::date > current_date + 30 THEN RETURN NULL; END IF; _kind := 'ticket_expiring';
  ELSE RETURN NULL; END IF;
  IF (_r->>'workspace_id') IS NULL THEN RETURN NULL; END IF;
  INSERT INTO public.brain_events(workspace_id, kind, table_name, row_id, job_id, crew_member_id)
  VALUES ((_r->>'workspace_id')::uuid, _kind, TG_TABLE_NAME, _r->>'id', _job, _crew);
  RETURN NULL;
END $$;
REVOKE ALL ON FUNCTION private.record_brain_event() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER brain_event_leave AFTER INSERT OR UPDATE ON public.leave FOR EACH ROW EXECUTE FUNCTION private.record_brain_event();
CREATE TRIGGER brain_event_assignments AFTER INSERT OR UPDATE OR DELETE ON public.assignments FOR EACH ROW EXECUTE FUNCTION private.record_brain_event();
CREATE TRIGGER brain_event_messages AFTER INSERT ON public.messages FOR EACH ROW EXECUTE FUNCTION private.record_brain_event();
CREATE TRIGGER brain_event_emails AFTER INSERT OR UPDATE ON public.inbound_emails FOR EACH ROW EXECUTE FUNCTION private.record_brain_event();
CREATE TRIGGER brain_event_materials AFTER INSERT OR UPDATE ON public.materials FOR EACH ROW EXECUTE FUNCTION private.record_brain_event();
CREATE TRIGGER brain_event_dependencies AFTER INSERT OR UPDATE ON public.dependencies FOR EACH ROW EXECUTE FUNCTION private.record_brain_event();
CREATE TRIGGER brain_event_jobs AFTER UPDATE ON public.jobs FOR EACH ROW EXECUTE FUNCTION private.record_brain_event();
CREATE TRIGGER brain_event_tickets AFTER INSERT OR UPDATE ON public.crew_tickets FOR EACH ROW EXECUTE FUNCTION private.record_brain_event();

-- ===== push_subscriptions =====
CREATE TABLE public.push_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  endpoint text NOT NULL UNIQUE,
  p256dh text NOT NULL,
  auth text NOT NULL,
  device_label text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.push_subscriptions TO authenticated;
GRANT ALL ON public.push_subscriptions TO service_role;
ALTER TABLE public.push_subscriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY push_own_read ON public.push_subscriptions FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY push_own_insert ON public.push_subscriptions FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY push_own_delete ON public.push_subscriptions FOR DELETE TO authenticated USING (user_id = auth.uid());

-- ===== ask_messages =====
CREATE TABLE public.ask_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  thread_id uuid NOT NULL,
  role text NOT NULL CHECK (role IN ('user','brain')),
  content text NOT NULL,
  tool_calls jsonb NOT NULL DEFAULT '[]',
  proposal_ids uuid[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ask_messages_thread_idx ON public.ask_messages(user_id, thread_id, created_at);
GRANT SELECT, INSERT ON public.ask_messages TO authenticated;
GRANT ALL ON public.ask_messages TO service_role;
ALTER TABLE public.ask_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY ask_own_read ON public.ask_messages FOR SELECT TO authenticated USING (user_id = auth.uid() AND public.is_member(workspace_id));
CREATE POLICY ask_own_insert ON public.ask_messages FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid() AND role = 'user' AND public.is_member(workspace_id));
CREATE TRIGGER audit_ask_messages AFTER INSERT ON public.ask_messages FOR EACH ROW EXECUTE FUNCTION public.write_audit();

-- ===== call_logs =====
CREATE TABLE public.call_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  job_id uuid REFERENCES public.jobs(id) ON DELETE SET NULL,
  contact_name text NOT NULL DEFAULT '',
  contact_role text NOT NULL DEFAULT 'other' CHECK (contact_role IN ('client','builder','supplier','crew','other')),
  direction text NOT NULL DEFAULT 'in' CHECK (direction IN ('in','out')),
  summary text NOT NULL DEFAULT '',
  transcript text,
  audio_attachment_id uuid,
  actions jsonb NOT NULL DEFAULT '[]',
  logged_by uuid,
  at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX call_logs_ws_idx ON public.call_logs(workspace_id, at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.call_logs TO authenticated;
GRANT ALL ON public.call_logs TO service_role;
ALTER TABLE public.call_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY call_logs_office ON public.call_logs FOR ALL TO authenticated USING (public.is_office(workspace_id)) WITH CHECK (public.is_office(workspace_id));
CREATE TRIGGER audit_call_logs AFTER INSERT OR UPDATE OR DELETE ON public.call_logs FOR EACH ROW EXECUTE FUNCTION public.write_audit();

-- ===== apply / undo / dismiss =====
CREATE OR REPLACE FUNCTION private.apply_proposal(_id uuid, _anyway boolean DEFAULT false, _payload jsonb DEFAULT NULL)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE p public.proposals; j public.jobs; pl jsonb; _undo jsonb; _result jsonb := '{}'; _new uuid; _office boolean;
  _prev jsonb; r public.jobs; _f jsonb;
BEGIN
  SELECT * INTO p FROM public.proposals WHERE id = _id FOR UPDATE;
  IF p.id IS NULL THEN RAISE EXCEPTION 'Proposal not found'; END IF;
  _office := private.is_office(p.workspace_id);
  IF NOT _office AND NOT (p.kind = 'leave_request' AND p.created_by = auth.uid()) THEN
    RAISE EXCEPTION 'Only office users can apply proposals'; END IF;
  IF p.status <> 'open' THEN RAISE EXCEPTION 'This proposal is already %', p.status; END IF;
  IF p.expires_at IS NOT NULL AND p.expires_at < now() THEN
    UPDATE public.proposals SET status = 'expired' WHERE id = _id; RAISE EXCEPTION 'This proposal has expired'; END IF;
  IF p.kind IN ('send_email','send_sms') THEN RAISE EXCEPTION 'Messages are sent from their own Send screen'; END IF;
  pl := COALESCE(_payload, p.payload);
  IF p.job_id IS NOT NULL THEN
    SELECT * INTO j FROM public.jobs WHERE id = p.job_id;
    IF j.locked AND p.kind IN ('place','move','swap','add_person','remove_person','update_job') THEN
      RAISE EXCEPTION 'This job is locked. Unlock it before applying.'; END IF;
  END IF;
  PERFORM set_config('app.move_reason', 'brain:' || p.source::text, true);

  IF p.kind IN ('place','move','swap','add_person','remove_person') THEN
    SELECT COALESCE(jsonb_agg(jsonb_build_object('id',id,'crew_member_id',crew_member_id,'date',date,'start_time',start_time,'end_time',end_time,'is_lead',is_lead)), '[]')
      INTO _prev FROM public.assignments WHERE job_id = p.job_id;
    _undo := jsonb_build_object('rows', _prev, 'start_date', j.start_date, 'start_time', j.start_time, 'status', j.status);
    PERFORM public.place_job(p.job_id, pl->'rows', nullif(pl->>'start_date','')::date, nullif(pl->>'start_time','')::time,
      COALESCE(nullif(pl->>'status','')::public.job_status, CASE WHEN j.status IN ('ready','quoted','enquiry') THEN 'scheduled'::public.job_status ELSE j.status END), true, NULL);
    PERFORM set_config('app.move_reason', 'brain:' || p.source::text, true);

  ELSIF p.kind = 'create_job' THEN
    INSERT INTO public.jobs(workspace_id, name, client_name, client_phone, client_contact, builder_company, builder_pm_name, builder_pm_phone, builder_pm_email,
      sector, address, suburb, flooring, area_m2, duration_value, duration_unit, crew_size, status, due_by, unique_notes, job_type, main_skill)
    VALUES (p.workspace_id, COALESCE(nullif(pl->>'name',''),'New enquiry'), pl->>'client_name', pl->>'client_phone', pl->>'client_contact', pl->>'builder_company',
      pl->>'builder_pm_name', pl->>'builder_pm_phone', pl->>'builder_pm_email', COALESCE(nullif(pl->>'sector','')::public.job_sector,'domestic'),
      pl->>'address', pl->>'suburb', pl->>'flooring', nullif(pl->>'area_m2','')::numeric, COALESCE(nullif(pl->>'duration_value','')::numeric,1),
      COALESCE(nullif(pl->>'duration_unit','')::public.duration_unit,'days'), COALESCE(nullif(pl->>'crew_size','')::int,1), 'enquiry',
      nullif(pl->>'due_by','')::date, pl->>'unique_notes', pl->>'job_type', pl->>'main_skill')
    RETURNING id INTO _new;
    _undo := jsonb_build_object('delete_job', _new); _result := jsonb_build_object('job_id', _new);

  ELSIF p.kind = 'update_job' THEN
    _f := COALESCE(pl->'fields', pl);
    _f := (SELECT COALESCE(jsonb_object_agg(k, v), '{}') FROM jsonb_each(_f) e(k, v) WHERE k IN
      ('name','client_name','client_phone','client_contact','builder_company','builder_pm_name','builder_pm_phone','builder_pm_email','address','suburb',
       'flooring','area_m2','duration_value','duration_unit','crew_size','due_by','due_hard','importance','urgency','unique_notes','safety_notes','access_window','status','job_type'));
    IF _f = '{}' THEN RAISE EXCEPTION 'Nothing to change'; END IF;
    _undo := jsonb_build_object('job_fields', (SELECT jsonb_object_agg(k, to_jsonb(j)->k) FROM jsonb_object_keys(_f) k));
    r := jsonb_populate_record(j, _f);
    UPDATE public.jobs SET name=r.name, client_name=r.client_name, client_phone=r.client_phone, client_contact=r.client_contact, builder_company=r.builder_company,
      builder_pm_name=r.builder_pm_name, builder_pm_phone=r.builder_pm_phone, builder_pm_email=r.builder_pm_email, address=r.address, suburb=r.suburb,
      flooring=r.flooring, area_m2=r.area_m2, duration_value=r.duration_value, duration_unit=r.duration_unit, crew_size=r.crew_size, due_by=r.due_by,
      due_hard=r.due_hard, importance=r.importance, urgency=r.urgency, unique_notes=r.unique_notes, safety_notes=r.safety_notes,
      access_window=r.access_window, status=r.status, job_type=r.job_type
    WHERE id = p.job_id;

  ELSIF p.kind = 'add_task' THEN
    INSERT INTO public.tasks(job_id, workspace_id, label, due_date, owner_crew_member_id, sort)
    VALUES (p.job_id, p.workspace_id, pl->>'label', nullif(pl->>'due_date','')::date, nullif(pl->>'owner_crew_member_id','')::uuid,
      COALESCE((SELECT max(sort)+1 FROM public.tasks WHERE job_id = p.job_id), 0)) RETURNING id INTO _new;
    _undo := jsonb_build_object('delete_task', _new);

  ELSIF p.kind = 'add_dependency' THEN
    INSERT INTO public.dependencies(job_id, workspace_id, kind, description, party, due_date, blocks_start)
    VALUES (p.job_id, p.workspace_id, COALESCE(nullif(pl->>'kind','')::public.dependency_kind,'other'), pl->>'description', pl->>'party',
      nullif(pl->>'due_date','')::date, COALESCE((pl->>'blocks_start')::boolean,false)) RETURNING id INTO _new;
    _undo := jsonb_build_object('delete_dependency', _new);

  ELSIF p.kind = 'update_dependency' THEN
    SELECT jsonb_build_object('dependency', jsonb_build_object('id', id, 'status', status, 'due_date', due_date)) INTO _undo
      FROM public.dependencies WHERE id = (pl->>'id')::uuid AND job_id = p.job_id;
    IF _undo IS NULL THEN RAISE EXCEPTION 'Dependency not found on this job'; END IF;
    UPDATE public.dependencies SET status = COALESCE(nullif(pl->>'status','')::public.dependency_status, status),
      due_date = CASE WHEN pl ? 'due_date' THEN nullif(pl->>'due_date','')::date ELSE due_date END
    WHERE id = (pl->>'id')::uuid;

  ELSIF p.kind = 'mark_delivered' THEN
    SELECT jsonb_build_object('material', jsonb_build_object('id', id, 'status', status)) INTO _undo
      FROM public.materials WHERE id = (pl->>'material_id')::uuid AND job_id = p.job_id;
    IF _undo IS NULL THEN RAISE EXCEPTION 'Material not found on this job'; END IF;
    UPDATE public.materials SET status = 'delivered' WHERE id = (pl->>'material_id')::uuid;

  ELSIF p.kind = 'update_ticket' THEN
    SELECT jsonb_build_object('ticket', jsonb_build_object('crew_member_id', crew_member_id, 'ticket_type', ticket_type, 'expires_on', expires_on, 'existed', true)) INTO _undo
      FROM public.crew_tickets WHERE crew_member_id = (pl->>'crew_member_id')::uuid AND ticket_type = pl->>'ticket_type';
    _undo := COALESCE(_undo, jsonb_build_object('ticket', jsonb_build_object('crew_member_id', pl->>'crew_member_id', 'ticket_type', pl->>'ticket_type', 'existed', false)));
    INSERT INTO public.crew_tickets(crew_member_id, workspace_id, ticket_type, expires_on)
    VALUES ((pl->>'crew_member_id')::uuid, p.workspace_id, pl->>'ticket_type', nullif(pl->>'expires_on','')::date)
    ON CONFLICT (crew_member_id, ticket_type) DO UPDATE SET expires_on = EXCLUDED.expires_on;

  ELSIF p.kind = 'leave_request' THEN
    IF NOT _office AND NOT ((pl->>'crew_member_id')::uuid IN (SELECT private.my_crew_member_ids())) THEN
      RAISE EXCEPTION 'You can only request leave for yourself'; END IF;
    INSERT INTO public.leave(workspace_id, crew_member_id, type, from_date, to_date, start_time, end_time, note, status)
    VALUES (p.workspace_id, (pl->>'crew_member_id')::uuid, COALESCE(nullif(pl->>'type',''),'unavailable'), (pl->>'from_date')::date,
      COALESCE(nullif(pl->>'to_date','')::date, (pl->>'from_date')::date), nullif(pl->>'start_time','')::time, nullif(pl->>'end_time','')::time, pl->>'note', 'requested')
    RETURNING id INTO _new;
    _undo := jsonb_build_object('delete_leave', _new);

  ELSIF p.kind = 'log_call' THEN
    INSERT INTO public.call_logs(workspace_id, job_id, contact_name, contact_role, direction, summary, transcript, actions, logged_by)
    VALUES (p.workspace_id, p.job_id, COALESCE(pl->>'contact_name',''), COALESCE(nullif(pl->>'contact_role',''),'other'), COALESCE(nullif(pl->>'direction',''),'in'),
      COALESCE(pl->>'summary',''), pl->>'transcript', COALESCE(pl->'actions','[]'), auth.uid()) RETURNING id INTO _new;
    _undo := jsonb_build_object('delete_call', _new);
  END IF;

  UPDATE public.proposals SET status = 'applied', decided_by = auth.uid(), decided_at = now(), undo = _undo,
    result = _result || jsonb_build_object('anyway', _anyway, 'edited', _payload IS NOT NULL), payload = pl
  WHERE id = _id;
  PERFORM set_config('app.move_reason', '', true);
  RETURN _result;
END $$;

CREATE OR REPLACE FUNCTION private.undo_proposal(_id uuid) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE p public.proposals; u jsonb; j public.jobs; r public.jobs;
BEGIN
  SELECT * INTO p FROM public.proposals WHERE id = _id FOR UPDATE;
  IF p.id IS NULL THEN RAISE EXCEPTION 'Proposal not found'; END IF;
  IF NOT (private.is_office(p.workspace_id) OR (p.kind = 'leave_request' AND p.decided_by = auth.uid())) THEN RAISE EXCEPTION 'Only office users can undo'; END IF;
  IF p.status <> 'applied' THEN RAISE EXCEPTION 'Only applied proposals can be undone'; END IF;
  u := p.undo;
  PERFORM set_config('app.move_reason', 'brain:' || p.source::text, true);
  IF u ? 'rows' THEN
    PERFORM public.place_job(p.job_id, u->'rows', nullif(u->>'start_date','')::date, nullif(u->>'start_time','')::time, (u->>'status')::public.job_status, true, NULL);
  ELSIF u ? 'delete_job' THEN DELETE FROM public.jobs WHERE id = (u->>'delete_job')::uuid;
  ELSIF u ? 'job_fields' THEN
    SELECT * INTO j FROM public.jobs WHERE id = p.job_id; r := jsonb_populate_record(j, u->'job_fields');
    UPDATE public.jobs SET name=r.name, client_name=r.client_name, client_phone=r.client_phone, client_contact=r.client_contact, builder_company=r.builder_company,
      builder_pm_name=r.builder_pm_name, builder_pm_phone=r.builder_pm_phone, builder_pm_email=r.builder_pm_email, address=r.address, suburb=r.suburb,
      flooring=r.flooring, area_m2=r.area_m2, duration_value=r.duration_value, duration_unit=r.duration_unit, crew_size=r.crew_size, due_by=r.due_by,
      due_hard=r.due_hard, importance=r.importance, urgency=r.urgency, unique_notes=r.unique_notes, safety_notes=r.safety_notes,
      access_window=r.access_window, status=r.status, job_type=r.job_type WHERE id = p.job_id;
  ELSIF u ? 'delete_task' THEN DELETE FROM public.tasks WHERE id = (u->>'delete_task')::uuid;
  ELSIF u ? 'delete_dependency' THEN DELETE FROM public.dependencies WHERE id = (u->>'delete_dependency')::uuid;
  ELSIF u ? 'dependency' THEN UPDATE public.dependencies SET status = (u->'dependency'->>'status')::public.dependency_status, due_date = nullif(u->'dependency'->>'due_date','')::date WHERE id = (u->'dependency'->>'id')::uuid;
  ELSIF u ? 'material' THEN UPDATE public.materials SET status = (u->'material'->>'status')::public.material_status WHERE id = (u->'material'->>'id')::uuid;
  ELSIF u ? 'ticket' THEN
    IF (u->'ticket'->>'existed')::boolean THEN
      UPDATE public.crew_tickets SET expires_on = nullif(u->'ticket'->>'expires_on','')::date WHERE crew_member_id = (u->'ticket'->>'crew_member_id')::uuid AND ticket_type = u->'ticket'->>'ticket_type';
    ELSE DELETE FROM public.crew_tickets WHERE crew_member_id = (u->'ticket'->>'crew_member_id')::uuid AND ticket_type = u->'ticket'->>'ticket_type'; END IF;
  ELSIF u ? 'delete_leave' THEN DELETE FROM public.leave WHERE id = (u->>'delete_leave')::uuid AND status = 'requested';
  ELSIF u ? 'delete_call' THEN DELETE FROM public.call_logs WHERE id = (u->>'delete_call')::uuid;
  END IF;
  UPDATE public.proposals SET status = 'undone', decided_by = auth.uid(), decided_at = now() WHERE id = _id;
  PERFORM set_config('app.move_reason', '', true);
END $$;

CREATE OR REPLACE FUNCTION private.dismiss_proposal(_id uuid, _reason text DEFAULT NULL) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE p public.proposals;
BEGIN
  SELECT * INTO p FROM public.proposals WHERE id = _id FOR UPDATE;
  IF p.id IS NULL THEN RAISE EXCEPTION 'Proposal not found'; END IF;
  IF NOT (private.is_office(p.workspace_id) OR p.created_by = auth.uid()) THEN RAISE EXCEPTION 'Only office users can dismiss'; END IF;
  IF p.status <> 'open' THEN RAISE EXCEPTION 'This proposal is already %', p.status; END IF;
  UPDATE public.proposals SET status = 'dismissed', decided_by = auth.uid(), decided_at = now(),
    dismiss_reason = CASE WHEN _reason IN ('wrong','not_now','already_done','other') THEN _reason END WHERE id = _id;
END $$;

REVOKE ALL ON FUNCTION private.apply_proposal(uuid, boolean, jsonb) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION private.undo_proposal(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION private.dismiss_proposal(uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION private.apply_proposal(uuid, boolean, jsonb), private.undo_proposal(uuid), private.dismiss_proposal(uuid, text) TO authenticated, service_role;

CREATE FUNCTION public.apply_proposal(_id uuid, _anyway boolean DEFAULT false, _payload jsonb DEFAULT NULL) RETURNS jsonb LANGUAGE sql SECURITY INVOKER SET search_path = public AS $$ SELECT private.apply_proposal(_id, _anyway, _payload) $$;
CREATE FUNCTION public.undo_proposal(_id uuid) RETURNS void LANGUAGE sql SECURITY INVOKER SET search_path = public AS $$ SELECT private.undo_proposal(_id) $$;
CREATE FUNCTION public.dismiss_proposal(_id uuid, _reason text DEFAULT NULL) RETURNS void LANGUAGE sql SECURITY INVOKER SET search_path = public AS $$ SELECT private.dismiss_proposal(_id, _reason) $$;
REVOKE ALL ON FUNCTION public.apply_proposal(uuid, boolean, jsonb), public.undo_proposal(uuid), public.dismiss_proposal(uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.apply_proposal(uuid, boolean, jsonb), public.undo_proposal(uuid), public.dismiss_proposal(uuid, text) TO authenticated, service_role;

ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.proposals;