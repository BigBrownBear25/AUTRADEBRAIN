-- 1. Two-factor enforced in the office/owner/finance helpers
CREATE OR REPLACE FUNCTION private.has_aal2() RETURNS boolean LANGUAGE sql STABLE SET search_path TO 'public'
AS $$ SELECT coalesce(auth.jwt()->>'aal','') = 'aal2' $$;

CREATE OR REPLACE FUNCTION private.is_office(_ws uuid) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT private.has_aal2() AND public.has_workspace_role(_ws, ARRAY['owner','office']::public.app_role[]) $$;

CREATE OR REPLACE FUNCTION private.is_owner(_ws uuid) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT private.has_aal2() AND public.has_workspace_role(_ws, ARRAY['owner']::public.app_role[]) $$;

CREATE OR REPLACE FUNCTION private.is_finance(_ws uuid) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
  SELECT private.has_aal2() AND (public.is_owner(_ws)
    OR (public.has_workspace_role(_ws, ARRAY['office']::public.app_role[])
        AND EXISTS (SELECT 1 FROM public.workspaces w WHERE w.id = _ws AND w.finance_visible_to_office)))
$$;

-- 2. Sign-up no longer creates a workspace
CREATE OR REPLACE FUNCTION public.handle_new_user() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$ BEGIN RETURN NEW; END $$;

CREATE OR REPLACE FUNCTION private.create_workspace(name text, owner_email text) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE _ws uuid; _email text := lower(trim(owner_email));
BEGIN
  IF nullif(trim(name),'') IS NULL THEN RAISE EXCEPTION 'Workspace name is required'; END IF;
  IF _email IS NULL OR position('@' in _email) = 0 THEN RAISE EXCEPTION 'A valid owner email is required'; END IF;
  INSERT INTO public.workspaces(name) VALUES (trim(name)) RETURNING id INTO _ws;
  INSERT INTO public.memberships(workspace_id, role, status, invited_email) VALUES (_ws, 'owner', 'invited', _email);
  RETURN _ws;
END $$;
REVOKE ALL ON FUNCTION private.create_workspace(text, text) FROM PUBLIC, anon, authenticated;

-- 3. Tenant checks for proposals
CREATE OR REPLACE FUNCTION private.proposal_tenant_ok(_ws uuid, _job uuid, _kind public.proposal_kind, pl jsonb) RETURNS boolean
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE _id uuid; _r jsonb;
BEGIN
  IF _job IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.jobs WHERE id = _job AND workspace_id = _ws) THEN RETURN false; END IF;
  IF jsonb_typeof(pl->'rows') = 'array' THEN
    FOR _r IN SELECT * FROM jsonb_array_elements(pl->'rows') LOOP
      _id := nullif(_r->>'crew_member_id','')::uuid;
      IF _id IS NULL OR NOT EXISTS (SELECT 1 FROM public.crew_members WHERE id = _id AND workspace_id = _ws) THEN RETURN false; END IF;
    END LOOP;
  END IF;
  _id := nullif(pl->>'crew_member_id','')::uuid;
  IF _id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.crew_members WHERE id = _id AND workspace_id = _ws) THEN RETURN false; END IF;
  _id := nullif(pl->>'owner_crew_member_id','')::uuid;
  IF _id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.crew_members WHERE id = _id AND workspace_id = _ws) THEN RETURN false; END IF;
  _id := nullif(pl->>'material_id','')::uuid;
  IF _id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.materials WHERE id = _id AND workspace_id = _ws) THEN RETURN false; END IF;
  _id := nullif(pl->>'task_id','')::uuid;
  IF _id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.tasks WHERE id = _id AND workspace_id = _ws) THEN RETURN false; END IF;
  IF _kind = 'update_dependency' THEN
    _id := nullif(pl->>'id','')::uuid;
    IF _id IS NULL OR NOT EXISTS (SELECT 1 FROM public.dependencies WHERE id = _id AND workspace_id = _ws) THEN RETURN false; END IF;
  END IF;
  IF _kind IN ('update_ticket','leave_request') AND _id IS NULL AND nullif(pl->>'crew_member_id','') IS NULL THEN RETURN false; END IF;
  RETURN true;
END $$;
REVOKE ALL ON FUNCTION private.proposal_tenant_ok(uuid, uuid, public.proposal_kind, jsonb) FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION private.undo_tenant_ok(_ws uuid, _job uuid, u jsonb) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
  SELECT (_job IS NULL OR EXISTS (SELECT 1 FROM public.jobs WHERE id = _job AND workspace_id = _ws))
    AND (NOT u ? 'rows' OR NOT EXISTS (SELECT 1 FROM jsonb_array_elements(u->'rows') r
         WHERE NOT EXISTS (SELECT 1 FROM public.crew_members c WHERE c.id = nullif(r->>'crew_member_id','')::uuid AND c.workspace_id = _ws)))
    AND (NOT u ? 'delete_job' OR EXISTS (SELECT 1 FROM public.jobs WHERE id = (u->>'delete_job')::uuid AND workspace_id = _ws))
    AND (NOT u ? 'delete_task' OR EXISTS (SELECT 1 FROM public.tasks WHERE id = (u->>'delete_task')::uuid AND workspace_id = _ws))
    AND (NOT u ? 'delete_dependency' OR EXISTS (SELECT 1 FROM public.dependencies WHERE id = (u->>'delete_dependency')::uuid AND workspace_id = _ws))
    AND (NOT u ? 'dependency' OR EXISTS (SELECT 1 FROM public.dependencies WHERE id = (u->'dependency'->>'id')::uuid AND workspace_id = _ws))
    AND (NOT u ? 'material' OR EXISTS (SELECT 1 FROM public.materials WHERE id = (u->'material'->>'id')::uuid AND workspace_id = _ws))
    AND (NOT u ? 'ticket' OR EXISTS (SELECT 1 FROM public.crew_members WHERE id = (u->'ticket'->>'crew_member_id')::uuid AND workspace_id = _ws))
    AND (NOT u ? 'delete_leave' OR EXISTS (SELECT 1 FROM public.leave WHERE id = (u->>'delete_leave')::uuid AND workspace_id = _ws))
    AND (NOT u ? 'delete_call' OR EXISTS (SELECT 1 FROM public.call_logs WHERE id = (u->>'delete_call')::uuid AND workspace_id = _ws))
$$;
REVOKE ALL ON FUNCTION private.undo_tenant_ok(uuid, uuid, jsonb) FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION private.apply_proposal(_id uuid, _anyway boolean DEFAULT false, _payload jsonb DEFAULT NULL::jsonb)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE p public.proposals; j public.jobs; pl jsonb; _undo jsonb; _result jsonb := '{}'; _new uuid; _office boolean;
  _prev jsonb; r public.jobs; _f jsonb;
BEGIN
  SELECT * INTO p FROM public.proposals WHERE id = _id FOR UPDATE;
  IF p.id IS NULL THEN RAISE EXCEPTION 'Proposal not found'; END IF;
  _office := private.is_office(p.workspace_id);
  IF NOT _office AND NOT (p.kind = 'leave_request' AND p.created_by = auth.uid()) THEN
    RAISE EXCEPTION 'Only office users can apply proposals'; END IF;
  IF p.status <> 'open' THEN RAISE EXCEPTION 'This proposal is already %', p.status; END IF;
  IF p.expires_at IS NOT NULL AND p.expires_at < now() THEN
    UPDATE public.proposals SET status = 'expired' WHERE id = _id; RAISE EXCEPTION 'This proposal has expired'; END IF;
  IF p.kind IN ('send_email','send_sms') THEN RAISE EXCEPTION 'Messages are sent from their own Send screen'; END IF;
  pl := COALESCE(_payload, p.payload);
  IF NOT private.proposal_tenant_ok(p.workspace_id, p.job_id, p.kind, pl) THEN
    RAISE EXCEPTION 'This proposal names a job or record outside this workspace'; END IF;
  IF p.job_id IS NOT NULL THEN
    SELECT * INTO j FROM public.jobs WHERE id = p.job_id;
    IF j.locked AND p.kind IN ('place','move','swap','add_person','remove_person','update_job') THEN
      RAISE EXCEPTION 'This job is locked. Unlock it before applying.'; END IF;
  END IF;
  PERFORM set_config('app.move_reason', 'brain:' || p.source::text, true);

  IF p.kind IN ('place','move','swap','add_person','remove_person') THEN
    SELECT COALESCE(jsonb_agg(jsonb_build_object('id',id,'crew_member_id',crew_member_id,'date',date,'start_time',start_time,'end_time',end_time,'is_lead',is_lead)), '[]')
      INTO _prev FROM public.assignments WHERE job_id = p.job_id;
    _undo := jsonb_build_object('rows', _prev, 'start_date', j.start_date, 'start_time', j.start_time, 'status', j.status);
    PERFORM public.place_job(p.job_id, pl->'rows', nullif(pl->>'start_date','')::date, nullif(pl->>'start_time','')::time,
      COALESCE(nullif(pl->>'status','')::public.job_status, CASE WHEN j.status IN ('ready','quoted','enquiry') THEN 'scheduled'::public.job_status ELSE j.status END), true, NULL);
    PERFORM set_config('app.move_reason', 'brain:' || p.source::text, true);

  ELSIF p.kind = 'create_job' THEN
    INSERT INTO public.jobs(workspace_id, name, client_name, client_phone, client_contact, builder_company, builder_pm_name, builder_pm_phone, builder_pm_email,
      sector, address, suburb, flooring, area_m2, duration_value, duration_unit, crew_size, status, due_by, unique_notes, job_type, main_skill)
    VALUES (p.workspace_id, COALESCE(nullif(pl->>'name',''),'New enquiry'), pl->>'client_name', pl->>'client_phone', pl->>'client_contact', pl->>'builder_company',
      pl->>'builder_pm_name', pl->>'builder_pm_phone', pl->>'builder_pm_email', COALESCE(nullif(pl->>'sector','')::public.job_sector,'domestic'),
      pl->>'address', pl->>'suburb', pl->>'flooring', nullif(pl->>'area_m2','')::numeric, COALESCE(nullif(pl->>'duration_value','')::numeric,1),
      COALESCE(nullif(pl->>'duration_unit','')::public.duration_unit,'days'), COALESCE(nullif(pl->>'crew_size','')::int,1), 'enquiry',
      nullif(pl->>'due_by','')::date, pl->>'unique_notes', pl->>'job_type', pl->>'main_skill')
    RETURNING id INTO _new;
    _undo := jsonb_build_object('delete_job', _new); _result := jsonb_build_object('job_id', _new);

  ELSIF p.kind = 'update_job' THEN
    _f := COALESCE(pl->'fields', pl);
    _f := (SELECT COALESCE(jsonb_object_agg(k, v), '{}') FROM jsonb_each(_f) e(k, v) WHERE k IN
      ('name','client_name','client_phone','client_contact','builder_company','builder_pm_name','builder_pm_phone','builder_pm_email','address','suburb',
       'flooring','area_m2','duration_value','duration_unit','crew_size','due_by','due_hard','importance','urgency','unique_notes','safety_notes','access_window','status','job_type'));
    IF _f = '{}' THEN RAISE EXCEPTION 'Nothing to change'; END IF;
    _undo := jsonb_build_object('job_fields', (SELECT jsonb_object_agg(k, to_jsonb(j)->k) FROM jsonb_object_keys(_f) k));
    r := jsonb_populate_record(j, _f);
    UPDATE public.jobs SET name=r.name, client_name=r.client_name, client_phone=r.client_phone, client_contact=r.client_contact, builder_company=r.builder_company,
      builder_pm_name=r.builder_pm_name, builder_pm_phone=r.builder_pm_phone, builder_pm_email=r.builder_pm_email, address=r.address, suburb=r.suburb,
      flooring=r.flooring, area_m2=r.area_m2, duration_value=r.duration_value, duration_unit=r.duration_unit, crew_size=r.crew_size, due_by=r.due_by,
      due_hard=r.due_hard, importance=r.importance, urgency=r.urgency, unique_notes=r.unique_notes, safety_notes=r.safety_notes,
      access_window=r.access_window, status=r.status, job_type=r.job_type
    WHERE id = p.job_id;

  ELSIF p.kind = 'add_task' THEN
    INSERT INTO public.tasks(job_id, workspace_id, label, due_date, owner_crew_member_id, sort)
    VALUES (p.job_id, p.workspace_id, pl->>'label', nullif(pl->>'due_date','')::date, nullif(pl->>'owner_crew_member_id','')::uuid,
      COALESCE((SELECT max(sort)+1 FROM public.tasks WHERE job_id = p.job_id), 0)) RETURNING id INTO _new;
    _undo := jsonb_build_object('delete_task', _new);

  ELSIF p.kind = 'add_dependency' THEN
    INSERT INTO public.dependencies(job_id, workspace_id, kind, description, party, due_date, blocks_start)
    VALUES (p.job_id, p.workspace_id, COALESCE(nullif(pl->>'kind','')::public.dependency_kind,'other'), pl->>'description', pl->>'party',
      nullif(pl->>'due_date','')::date, COALESCE((pl->>'blocks_start')::boolean,false)) RETURNING id INTO _new;
    _undo := jsonb_build_object('delete_dependency', _new);

  ELSIF p.kind = 'update_dependency' THEN
    SELECT jsonb_build_object('dependency', jsonb_build_object('id', id, 'status', status, 'due_date', due_date)) INTO _undo
      FROM public.dependencies WHERE id = (pl->>'id')::uuid AND job_id = p.job_id;
    IF _undo IS NULL THEN RAISE EXCEPTION 'Dependency not found on this job'; END IF;
    UPDATE public.dependencies SET status = COALESCE(nullif(pl->>'status','')::public.dependency_status, status),
      due_date = CASE WHEN pl ? 'due_date' THEN nullif(pl->>'due_date','')::date ELSE due_date END
    WHERE id = (pl->>'id')::uuid;

  ELSIF p.kind = 'mark_delivered' THEN
    SELECT jsonb_build_object('material', jsonb_build_object('id', id, 'status', status)) INTO _undo
      FROM public.materials WHERE id = (pl->>'material_id')::uuid AND job_id = p.job_id;
    IF _undo IS NULL THEN RAISE EXCEPTION 'Material not found on this job'; END IF;
    UPDATE public.materials SET status = 'delivered' WHERE id = (pl->>'material_id')::uuid;

  ELSIF p.kind = 'update_ticket' THEN
    SELECT jsonb_build_object('ticket', jsonb_build_object('crew_member_id', crew_member_id, 'ticket_type', ticket_type, 'expires_on', expires_on, 'existed', true)) INTO _undo
      FROM public.crew_tickets WHERE crew_member_id = (pl->>'crew_member_id')::uuid AND ticket_type = pl->>'ticket_type';
    _undo := COALESCE(_undo, jsonb_build_object('ticket', jsonb_build_object('crew_member_id', pl->>'crew_member_id', 'ticket_type', pl->>'ticket_type', 'existed', false)));
    INSERT INTO public.crew_tickets(crew_member_id, workspace_id, ticket_type, expires_on)
    VALUES ((pl->>'crew_member_id')::uuid, p.workspace_id, pl->>'ticket_type', nullif(pl->>'expires_on','')::date)
    ON CONFLICT (crew_member_id, ticket_type) DO UPDATE SET expires_on = EXCLUDED.expires_on;

  ELSIF p.kind = 'leave_request' THEN
    IF NOT _office AND NOT ((pl->>'crew_member_id')::uuid IN (SELECT private.my_crew_member_ids())) THEN
      RAISE EXCEPTION 'You can only request leave for yourself'; END IF;
    INSERT INTO public.leave(workspace_id, crew_member_id, type, from_date, to_date, start_time, end_time, note, status)
    VALUES (p.workspace_id, (pl->>'crew_member_id')::uuid, COALESCE(nullif(pl->>'type',''),'unavailable'), (pl->>'from_date')::date,
      COALESCE(nullif(pl->>'to_date','')::date, (pl->>'from_date')::date), nullif(pl->>'start_time','')::time, nullif(pl->>'end_time','')::time, pl->>'note', 'requested')
    RETURNING id INTO _new;
    _undo := jsonb_build_object('delete_leave', _new);

  ELSIF p.kind = 'log_call' THEN
    INSERT INTO public.call_logs(workspace_id, job_id, contact_name, contact_role, direction, summary, transcript, actions, logged_by)
    VALUES (p.workspace_id, p.job_id, COALESCE(pl->>'contact_name',''), COALESCE(nullif(pl->>'contact_role',''),'other'), COALESCE(nullif(pl->>'direction',''),'in'),
      COALESCE(pl->>'summary',''), pl->>'transcript', COALESCE(pl->'actions','[]'), auth.uid()) RETURNING id INTO _new;
    _undo := jsonb_build_object('delete_call', _new);
  END IF;

  UPDATE public.proposals SET status = 'applied', decided_by = auth.uid(), decided_at = now(), undo = _undo,
    result = _result || jsonb_build_object('anyway', _anyway, 'edited', _payload IS NOT NULL), payload = pl
  WHERE id = _id;
  PERFORM set_config('app.move_reason', '', true);
  RETURN _result;
END $function$;

CREATE OR REPLACE FUNCTION private.undo_proposal(_id uuid) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE p public.proposals; u jsonb; j public.jobs; r public.jobs;
BEGIN
  SELECT * INTO p FROM public.proposals WHERE id = _id FOR UPDATE;
  IF p.id IS NULL THEN RAISE EXCEPTION 'Proposal not found'; END IF;
  IF NOT (private.is_office(p.workspace_id) OR (p.kind = 'leave_request' AND p.decided_by = auth.uid())) THEN RAISE EXCEPTION 'Only office users can undo'; END IF;
  IF p.status <> 'applied' THEN RAISE EXCEPTION 'Only applied proposals can be undone'; END IF;
  u := COALESCE(p.undo, '{}');
  IF NOT private.undo_tenant_ok(p.workspace_id, p.job_id, u) THEN
    RAISE EXCEPTION 'This undo names a job or record outside this workspace'; END IF;
  PERFORM set_config('app.move_reason', 'brain:' || p.source::text, true);
  IF u ? 'rows' THEN
    PERFORM public.place_job(p.job_id, u->'rows', nullif(u->>'start_date','')::date, nullif(u->>'start_time','')::time, (u->>'status')::public.job_status, true, NULL);
  ELSIF u ? 'delete_job' THEN DELETE FROM public.jobs WHERE id = (u->>'delete_job')::uuid AND workspace_id = p.workspace_id;
  ELSIF u ? 'job_fields' THEN
    SELECT * INTO j FROM public.jobs WHERE id = p.job_id; r := jsonb_populate_record(j, u->'job_fields');
    UPDATE public.jobs SET name=r.name, client_name=r.client_name, client_phone=r.client_phone, client_contact=r.client_contact, builder_company=r.builder_company,
      builder_pm_name=r.builder_pm_name, builder_pm_phone=r.builder_pm_phone, builder_pm_email=r.builder_pm_email, address=r.address, suburb=r.suburb,
      flooring=r.flooring, area_m2=r.area_m2, duration_value=r.duration_value, duration_unit=r.duration_unit, crew_size=r.crew_size, due_by=r.due_by,
      due_hard=r.due_hard, importance=r.importance, urgency=r.urgency, unique_notes=r.unique_notes, safety_notes=r.safety_notes,
      access_window=r.access_window, status=r.status, job_type=r.job_type WHERE id = p.job_id;
  ELSIF u ? 'delete_task' THEN DELETE FROM public.tasks WHERE id = (u->>'delete_task')::uuid AND workspace_id = p.workspace_id;
  ELSIF u ? 'delete_dependency' THEN DELETE FROM public.dependencies WHERE id = (u->>'delete_dependency')::uuid AND workspace_id = p.workspace_id;
  ELSIF u ? 'dependency' THEN UPDATE public.dependencies SET status = (u->'dependency'->>'status')::public.dependency_status, due_date = nullif(u->'dependency'->>'due_date','')::date WHERE id = (u->'dependency'->>'id')::uuid AND workspace_id = p.workspace_id;
  ELSIF u ? 'material' THEN UPDATE public.materials SET status = (u->'material'->>'status')::public.material_status WHERE id = (u->'material'->>'id')::uuid AND workspace_id = p.workspace_id;
  ELSIF u ? 'ticket' THEN
    IF (u->'ticket'->>'existed')::boolean THEN
      UPDATE public.crew_tickets SET expires_on = nullif(u->'ticket'->>'expires_on','')::date WHERE crew_member_id = (u->'ticket'->>'crew_member_id')::uuid AND ticket_type = u->'ticket'->>'ticket_type' AND workspace_id = p.workspace_id;
    ELSE DELETE FROM public.crew_tickets WHERE crew_member_id = (u->'ticket'->>'crew_member_id')::uuid AND ticket_type = u->'ticket'->>'ticket_type' AND workspace_id = p.workspace_id; END IF;
  ELSIF u ? 'delete_leave' THEN DELETE FROM public.leave WHERE id = (u->>'delete_leave')::uuid AND status = 'requested' AND workspace_id = p.workspace_id;
  ELSIF u ? 'delete_call' THEN DELETE FROM public.call_logs WHERE id = (u->>'delete_call')::uuid AND workspace_id = p.workspace_id;
  END IF;
  UPDATE public.proposals SET status = 'undone', decided_by = auth.uid(), decided_at = now() WHERE id = _id;
  PERFORM set_config('app.move_reason', '', true);
END $function$;