-- lovable-cron-fallback-reviewed: overnight draft and Monday look-ahead run at 03:30/03:45 in each workspace's local time; a 15-minute tick is the coarsest that hits those times across time zones
CREATE OR REPLACE FUNCTION private.brain_watch_wake() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = private, public, cron AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'brain-watch') THEN
    PERFORM cron.schedule('brain-watch', '* * * * *',
      $c$SELECT net.http_post(url := (SELECT value FROM private.app_tokens WHERE name='app_url') || '/api/public/brain-watch',
        headers := jsonb_build_object('Content-Type','application/json','x-cron-token',(SELECT value FROM private.app_tokens WHERE name='cron')),
        body := '{}'::jsonb)$c$);
  END IF;
  RETURN NULL;
END $$;
REVOKE EXECUTE ON FUNCTION private.brain_watch_wake() FROM PUBLIC, anon, authenticated;

DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'brain-watch') THEN PERFORM cron.unschedule('brain-watch'); END IF;
  IF EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'brain-overnight') THEN PERFORM cron.unschedule('brain-overnight'); END IF;
  PERFORM cron.schedule('brain-overnight', '*/15 * * * *',
    $c$SELECT net.http_post(url := (SELECT value FROM private.app_tokens WHERE name='app_url') || '/api/public/brain-overnight',
      headers := jsonb_build_object('Content-Type','application/json','x-cron-token',(SELECT value FROM private.app_tokens WHERE name='cron')),
      body := '{}'::jsonb)$c$);
END $$;

CREATE TABLE public.job_runs (
  job text PRIMARY KEY,
  last_ok_at timestamptz,
  last_error_at timestamptz,
  last_error text
);
GRANT SELECT ON public.job_runs TO authenticated;
GRANT ALL ON public.job_runs TO service_role;
ALTER TABLE public.job_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "owners read background health" ON public.job_runs FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.memberships m WHERE m.user_id = auth.uid() AND m.role = 'owner' AND m.status = 'active' AND public.is_owner(m.workspace_id)));