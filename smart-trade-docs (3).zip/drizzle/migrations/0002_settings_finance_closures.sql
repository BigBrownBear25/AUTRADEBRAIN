ALTER TABLE public.workspaces ALTER COLUMN code_prefix SET DEFAULT 'FZ';

CREATE OR REPLACE FUNCTION public.is_finance(_ws uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.is_owner(_ws)
    OR (public.has_workspace_role(_ws, ARRAY['office']::public.app_role[])
        AND EXISTS (SELECT 1 FROM public.workspaces w WHERE w.id = _ws AND w.finance_visible_to_office))
$$;
REVOKE EXECUTE ON FUNCTION public.is_finance(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_finance(uuid) TO authenticated;

CREATE TABLE public.workspace_settings (
  workspace_id uuid PRIMARY KEY REFERENCES public.workspaces(id) ON DELETE CASCADE,
  working_days smallint[] NOT NULL DEFAULT '{1,2,3,4,5}',
  day_start time NOT NULL DEFAULT '07:00',
  morning_end time NOT NULL DEFAULT '11:30',
  day_end time NOT NULL DEFAULT '15:30',
  skills text[] NOT NULL DEFAULT ARRAY['carpet','carpet tiles','vinyl plank','sheet vinyl','hybrid','engineered timber','solid timber','sanding and polishing','subfloor prep','epoxy and resin'],
  ticket_types jsonb NOT NULL DEFAULT '[{"name":"White Card","expires":false},{"name":"First Aid","expires":true},{"name":"WWCC","expires":true},{"name":"Asbestos Awareness","expires":false},{"name":"Silica Awareness","expires":false}]',
  hazards jsonb NOT NULL DEFAULT '[
    {"name":"old floor removal","controls":["Check building age before lifting","Wet methods and P2 masks for dust"],"required_tickets":[]},
    {"name":"pre-1990 building","controls":["Treat old coverings and adhesives as possible asbestos until tested"],"required_tickets":[]},
    {"name":"occupied site","controls":["Agree work areas and access with occupants","Keep walkways clear"],"required_tickets":[]},
    {"name":"vulnerable occupants","controls":["Sign in at reception","Never work alone with occupants"],"required_tickets":[{"ticket":"WWCC","who":"everyone"}]},
    {"name":"sanding","controls":["Dust extraction on","Hearing protection"],"required_tickets":[]},
    {"name":"resin or epoxy","controls":["Ventilate the area","Nitrile gloves and eye protection"],"required_tickets":[]},
    {"name":"concrete grinding","controls":["Wet cutting or H-class extraction","P2 mask fit-checked"],"required_tickets":[{"ticket":"Silica Awareness","who":"everyone"}]},
    {"name":"heat welding","controls":["Fire extinguisher on hand","Keep flammables clear"],"required_tickets":[]},
    {"name":"after-hours work","controls":["Tell the office start and finish times","Site lighting checked"],"required_tickets":[{"ticket":"First Aid","who":"one"}]},
    {"name":"stairs","controls":["Two-person carry on stairs","Keep stairs clear of offcuts"],"required_tickets":[]},
    {"name":"heavy rolls","controls":["Use a roll trolley","Two-person lift"],"required_tickets":[]}
  ]',
  ticket_rules jsonb NOT NULL DEFAULT '[
    {"when":"commercial","ticket":"White Card","who":"everyone"},
    {"when":"crew_size_2_plus","ticket":"First Aid","who":"one"},
    {"when":"all_hazards","hazards":["old floor removal","pre-1990 building"],"ticket":"Asbestos Awareness","who":"everyone"},
    {"when":"extra_tickets","who":"everyone"}
  ]',
  leave_types text[] NOT NULL DEFAULT ARRAY['annual leave','sick leave','training','RDO','unavailable'],
  job_types text[] NOT NULL DEFAULT ARRAY['supply and install','install only','repair','sand and polish','measure and quote'],
  avg_kmh numeric NOT NULL DEFAULT 75,
  unload_buffer_min integer NOT NULL DEFAULT 10,
  overnight_minutes integer NOT NULL DEFAULT 120,
  holiday_states text[] NOT NULL DEFAULT ARRAY['NSW','VIC'],
  CONSTRAINT ws_days_valid CHECK (working_days <@ ARRAY[1,2,3,4,5,6,7]::smallint[]),
  CONSTRAINT ws_hours_order CHECK (day_start < morning_end AND morning_end < day_end),
  CONSTRAINT ws_travel_positive CHECK (avg_kmh > 0 AND unload_buffer_min >= 0 AND overnight_minutes >= 0)
);

CREATE TABLE public.workspace_finance_settings (
  workspace_id uuid PRIMARY KEY REFERENCES public.workspaces(id) ON DELETE CASCADE,
  km_rate numeric NOT NULL DEFAULT 0.92 CHECK (km_rate >= 0),
  accommodation_rate numeric NOT NULL DEFAULT 185 CHECK (accommodation_rate >= 0),
  default_day_rate numeric NOT NULL DEFAULT 520 CHECK (default_day_rate >= 0)
);

CREATE TABLE public.closures (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  name text NOT NULL,
  from_date date NOT NULL,
  to_date date NOT NULL,
  kind text NOT NULL DEFAULT 'closure' CHECK (kind IN ('closure','public holiday')),
  state text,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT closures_range CHECK (to_date >= from_date)
);
CREATE INDEX closures_ws_idx ON public.closures(workspace_id, from_date);

GRANT SELECT, UPDATE ON public.workspace_settings TO authenticated;
GRANT SELECT, UPDATE ON public.workspace_finance_settings TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.closures TO authenticated;
GRANT ALL ON public.workspace_settings, public.workspace_finance_settings, public.closures TO service_role;

ALTER TABLE public.workspace_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workspace_finance_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.closures ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Members read workspace settings" ON public.workspace_settings FOR SELECT TO authenticated
  USING (public.is_member(workspace_id));
CREATE POLICY "Office updates workspace settings" ON public.workspace_settings FOR UPDATE TO authenticated
  USING (public.is_office(workspace_id)) WITH CHECK (public.is_office(workspace_id));

CREATE POLICY "Finance reads finance settings" ON public.workspace_finance_settings FOR SELECT TO authenticated
  USING (public.is_finance(workspace_id));
CREATE POLICY "Owner updates finance settings" ON public.workspace_finance_settings FOR UPDATE TO authenticated
  USING (public.is_owner(workspace_id)) WITH CHECK (public.is_owner(workspace_id));

CREATE POLICY "Members read closures" ON public.closures FOR SELECT TO authenticated
  USING (public.is_member(workspace_id));
CREATE POLICY "Office adds closures" ON public.closures FOR INSERT TO authenticated
  WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office updates closures" ON public.closures FOR UPDATE TO authenticated
  USING (public.is_office(workspace_id)) WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office deletes closures" ON public.closures FOR DELETE TO authenticated
  USING (public.is_office(workspace_id));

CREATE OR REPLACE FUNCTION public.write_audit()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _ws uuid; _row jsonb;
BEGIN
  _row := to_jsonb(COALESCE(NEW, OLD));
  IF TG_TABLE_NAME = 'workspaces' THEN _ws := (_row->>'id')::uuid;
  ELSE _ws := (_row->>'workspace_id')::uuid; END IF;
  INSERT INTO public.audit_log(workspace_id, actor_user_id, action, table_name, row_id, before, after)
  VALUES (_ws, auth.uid(), lower(TG_OP), TG_TABLE_NAME, COALESCE(_row->>'id', _row->>'workspace_id'),
    CASE WHEN TG_OP IN ('UPDATE','DELETE') THEN to_jsonb(OLD) END,
    CASE WHEN TG_OP IN ('INSERT','UPDATE') THEN to_jsonb(NEW) END);
  RETURN COALESCE(NEW, OLD);
END $$;

CREATE TRIGGER audit_workspace_settings AFTER INSERT OR UPDATE OR DELETE ON public.workspace_settings
  FOR EACH ROW EXECUTE FUNCTION public.write_audit();
CREATE TRIGGER audit_workspace_finance_settings AFTER INSERT OR UPDATE OR DELETE ON public.workspace_finance_settings
  FOR EACH ROW EXECUTE FUNCTION public.write_audit();
CREATE TRIGGER audit_closures AFTER INSERT OR UPDATE OR DELETE ON public.closures
  FOR EACH ROW EXECUTE FUNCTION public.write_audit();

CREATE OR REPLACE FUNCTION public.create_workspace_defaults()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.workspace_settings(workspace_id) VALUES (NEW.id) ON CONFLICT DO NOTHING;
  INSERT INTO public.workspace_finance_settings(workspace_id) VALUES (NEW.id) ON CONFLICT DO NOTHING;
  RETURN NEW;
END $$;
REVOKE EXECUTE ON FUNCTION public.create_workspace_defaults() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER workspace_defaults AFTER INSERT ON public.workspaces
  FOR EACH ROW EXECUTE FUNCTION public.create_workspace_defaults();

INSERT INTO public.workspace_settings(workspace_id) SELECT id FROM public.workspaces ON CONFLICT DO NOTHING;
INSERT INTO public.workspace_finance_settings(workspace_id) SELECT id FROM public.workspaces ON CONFLICT DO NOTHING;
UPDATE public.workspaces SET code_prefix = 'FZ' WHERE code_prefix = 'TB';