CREATE TABLE public.morning_briefs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  for_date date NOT NULL,
  since timestamptz NOT NULL,
  today jsonb NOT NULL DEFAULT '{}'::jsonb,
  changes jsonb NOT NULL DEFAULT '[]'::jsonb,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  summary text NOT NULL DEFAULT '',
  model text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (workspace_id, user_id, for_date)
);
GRANT SELECT, INSERT, UPDATE ON public.morning_briefs TO authenticated;
GRANT ALL ON public.morning_briefs TO service_role;
ALTER TABLE public.morning_briefs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own brief or owner reads" ON public.morning_briefs FOR SELECT TO authenticated
  USING ((user_id = auth.uid() AND public.is_office(workspace_id)) OR public.is_owner(workspace_id));
CREATE POLICY "Office writes own brief" ON public.morning_briefs FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() AND public.is_office(workspace_id));
CREATE POLICY "Office updates own brief" ON public.morning_briefs FOR UPDATE TO authenticated
  USING (user_id = auth.uid() AND public.is_office(workspace_id))
  WITH CHECK (user_id = auth.uid() AND public.is_office(workspace_id));
CREATE INDEX morning_briefs_user_idx ON public.morning_briefs (user_id, for_date DESC);
CREATE TRIGGER audit_morning_briefs AFTER INSERT OR UPDATE OR DELETE ON public.morning_briefs FOR EACH ROW EXECUTE FUNCTION public.write_audit();