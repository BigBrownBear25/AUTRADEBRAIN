CREATE TYPE public.message_kind AS ENUM ('message','problem','inspection','system');
CREATE TYPE public.message_speaker AS ENUM ('client','owner','foreman');
CREATE TYPE public.attachment_kind AS ENUM ('photo','audio','file');

CREATE TABLE public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL,
  author_user_id uuid,
  kind public.message_kind NOT NULL DEFAULT 'message',
  speaker public.message_speaker,
  body text NOT NULL DEFAULT '',
  task_id uuid REFERENCES public.tasks(id) ON DELETE SET NULL,
  reply_to_id uuid REFERENCES public.messages(id) ON DELETE SET NULL,
  mentions uuid[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);
CREATE INDEX messages_job_idx ON public.messages(job_id, created_at);
GRANT SELECT, INSERT, UPDATE ON public.messages TO authenticated;
GRANT ALL ON public.messages TO service_role;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Job readers read messages" ON public.messages FOR SELECT TO authenticated USING (public.is_job_reader(job_id));
CREATE POLICY "Job readers add own messages" ON public.messages FOR INSERT TO authenticated
  WITH CHECK (public.is_job_reader(job_id) AND author_user_id = auth.uid() AND deleted_at IS NULL
    AND (kind IN ('message','problem') OR public.is_office(workspace_id)));
CREATE POLICY "Authors and office delete messages" ON public.messages FOR UPDATE TO authenticated
  USING (public.is_job_reader(job_id) AND (author_user_id = auth.uid() OR public.is_office(workspace_id)))
  WITH CHECK (public.is_job_reader(job_id));

CREATE OR REPLACE FUNCTION public.message_before_write() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  SELECT workspace_id INTO NEW.workspace_id FROM public.jobs WHERE id = NEW.job_id;
  IF NEW.workspace_id IS NULL THEN RAISE EXCEPTION 'Unknown job'; END IF;
  IF TG_OP = 'INSERT' THEN
    IF NEW.task_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.tasks t WHERE t.id = NEW.task_id AND t.job_id = NEW.job_id) THEN RAISE EXCEPTION 'Task is on another job'; END IF;
    IF NEW.reply_to_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.messages m WHERE m.id = NEW.reply_to_id AND m.job_id = NEW.job_id) THEN RAISE EXCEPTION 'Reply is on another job'; END IF;
    NEW.created_at := now();
  ELSE
    -- Only soft delete: everything else stays as written.
    IF (to_jsonb(NEW) - 'deleted_at') IS DISTINCT FROM (to_jsonb(OLD) - 'deleted_at') OR NEW.deleted_at IS NULL OR OLD.deleted_at IS NOT NULL THEN
      RAISE EXCEPTION 'Messages can only be deleted';
    END IF;
    NEW.deleted_at := now();
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER messages_before_write BEFORE INSERT OR UPDATE ON public.messages FOR EACH ROW EXECUTE FUNCTION public.message_before_write();
CREATE TRIGGER audit_messages AFTER INSERT OR UPDATE OR DELETE ON public.messages FOR EACH ROW EXECUTE FUNCTION public.write_audit();

CREATE TABLE public.attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL,
  message_id uuid REFERENCES public.messages(id) ON DELETE CASCADE,
  kind public.attachment_kind NOT NULL,
  storage_path text NOT NULL,
  mime text,
  size bigint,
  duration_s numeric,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX attachments_job_idx ON public.attachments(job_id);
GRANT SELECT, INSERT ON public.attachments TO authenticated;
GRANT ALL ON public.attachments TO service_role;
ALTER TABLE public.attachments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Job readers read attachments" ON public.attachments FOR SELECT TO authenticated USING (public.is_job_reader(job_id));
CREATE POLICY "Job readers add own attachments" ON public.attachments FOR INSERT TO authenticated
  WITH CHECK (public.is_job_reader(job_id) AND created_by = auth.uid());
CREATE OR REPLACE FUNCTION public.attachment_before_write() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  SELECT workspace_id INTO NEW.workspace_id FROM public.jobs WHERE id = NEW.job_id;
  IF NEW.workspace_id IS NULL THEN RAISE EXCEPTION 'Unknown job'; END IF;
  IF split_part(NEW.storage_path, '/', 1) <> NEW.workspace_id::text OR split_part(NEW.storage_path, '/', 2) <> NEW.job_id::text THEN
    RAISE EXCEPTION 'File path must be workspace/job/file';
  END IF;
  IF NEW.message_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.messages m WHERE m.id = NEW.message_id AND m.job_id = NEW.job_id) THEN RAISE EXCEPTION 'Message is on another job'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER attachments_before_write BEFORE INSERT OR UPDATE ON public.attachments FOR EACH ROW EXECUTE FUNCTION public.attachment_before_write();
CREATE TRIGGER audit_attachments AFTER INSERT OR UPDATE OR DELETE ON public.attachments FOR EACH ROW EXECUTE FUNCTION public.write_audit();

CREATE TABLE public.message_reads (
  user_id uuid NOT NULL,
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL,
  last_read_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, job_id)
);
GRANT SELECT, INSERT, UPDATE ON public.message_reads TO authenticated;
GRANT ALL ON public.message_reads TO service_role;
ALTER TABLE public.message_reads ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own read markers" ON public.message_reads FOR SELECT TO authenticated USING (user_id = auth.uid() AND public.is_job_reader(job_id));
CREATE POLICY "Set own read markers" ON public.message_reads FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid() AND public.is_job_reader(job_id));
CREATE POLICY "Move own read markers" ON public.message_reads FOR UPDATE TO authenticated USING (user_id = auth.uid() AND public.is_job_reader(job_id)) WITH CHECK (user_id = auth.uid());
CREATE TRIGGER message_reads_ws BEFORE INSERT OR UPDATE ON public.message_reads FOR EACH ROW EXECUTE FUNCTION public.job_child_workspace();
CREATE TRIGGER audit_message_reads AFTER INSERT OR UPDATE OR DELETE ON public.message_reads FOR EACH ROW EXECUTE FUNCTION public.write_audit();

-- People who can read a job (office + assigned crew with an account): who can be notified and author names.
CREATE OR REPLACE FUNCTION public.job_people(_job_id uuid)
RETURNS TABLE(user_id uuid, name text, role public.app_role)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT DISTINCT ON (m.user_id) m.user_id, COALESCE(c.name, split_part(m.invited_email, '@', 1), initcap(m.role::text)), m.role
  FROM public.jobs j
  JOIN public.memberships m ON m.workspace_id = j.workspace_id AND m.status = 'active' AND m.user_id IS NOT NULL
  LEFT JOIN public.crew_members c ON c.id = m.crew_member_id
  WHERE j.id = _job_id AND public.is_job_reader(_job_id)
    AND (m.role IN ('owner','office') OR EXISTS (SELECT 1 FROM public.assignments a WHERE a.job_id = j.id AND a.crew_member_id = m.crew_member_id))
  ORDER BY m.user_id
$$;
REVOKE EXECUTE ON FUNCTION public.job_people(uuid) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.job_people(uuid) TO authenticated;

-- Fix storage policies: compare against the object's path, not the job's name.
DROP POLICY IF EXISTS "Job readers upload job files" ON storage.objects;
DROP POLICY IF EXISTS "Office deletes job files" ON storage.objects;
CREATE POLICY "Job readers upload job files" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'job-files' AND public.is_job_reader(public.job_id_from_path(objects.name))
    AND split_part(objects.name, '/', 1) = (SELECT j.workspace_id::text FROM public.jobs j WHERE j.id = public.job_id_from_path(objects.name)));
CREATE POLICY "Office deletes job files" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'job-files' AND EXISTS (SELECT 1 FROM public.jobs j WHERE j.id = public.job_id_from_path(objects.name) AND public.is_office(j.workspace_id)));

ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;