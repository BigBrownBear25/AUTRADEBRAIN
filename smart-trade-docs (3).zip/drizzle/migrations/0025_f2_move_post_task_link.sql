CREATE OR REPLACE FUNCTION private.move_brain_post(_message_id uuid, _to_job uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _m public.messages; _to public.jobs; _paths jsonb := '[]'::jsonb; _a record; _new text; _fb public.capture_feedback; _pids uuid[] := '{}'; _tids uuid[] := '{}'; _u uuid;
BEGIN
  SELECT * INTO _m FROM public.messages WHERE id = _message_id;
  IF _m.id IS NULL OR NOT private.is_job_reader(_m.job_id) THEN RAISE EXCEPTION 'Post not found'; END IF;
  IF _m.via IS DISTINCT FROM 'brain_bar' THEN RAISE EXCEPTION 'Only Brain bar posts can be moved'; END IF;
  IF _m.created_at < now() - interval '7 days' THEN RAISE EXCEPTION 'Posts can only be moved for 7 days'; END IF;
  IF NOT (_m.author_user_id = auth.uid() OR private.is_office(_m.workspace_id)) THEN RAISE EXCEPTION 'Only the author or the office can move this post'; END IF;
  SELECT * INTO _to FROM public.jobs WHERE id = _to_job;
  IF _to.id IS NULL OR _to.workspace_id <> _m.workspace_id OR NOT private.is_job_reader(_to.id) THEN RAISE EXCEPTION 'That job isn''t available to you'; END IF;
  IF _to.id = _m.job_id THEN RAISE EXCEPTION 'It''s already on that job'; END IF;

  PERFORM set_config('app.move_reason', 'moved: wrong job', true);
  SELECT * INTO _fb FROM public.capture_feedback WHERE message_id = _m.id LIMIT 1;
  IF _fb.id IS NOT NULL THEN _pids := _fb.proposal_ids; END IF;
  SELECT coalesce(array_agg((p.undo->>'delete_task')::uuid) FILTER (WHERE p.undo ? 'delete_task'), '{}') INTO _tids
    FROM public.proposals p WHERE p.id = ANY(_pids) AND p.workspace_id = _m.workspace_id;
  IF _m.task_id IS NOT NULL THEN _tids := _tids || _m.task_id; END IF;

  UPDATE public.messages SET job_id = _to.id, reply_to_id = NULL WHERE id = _m.id;
  FOR _a IN SELECT id, storage_path FROM public.attachments WHERE message_id = _m.id LOOP
    _new := _m.workspace_id::text || '/' || _to.id::text || '/' || substr(_a.storage_path, length(split_part(_a.storage_path, '/', 1)) + length(split_part(_a.storage_path, '/', 2)) + 3);
    UPDATE public.attachments SET job_id = _to.id, storage_path = _new WHERE id = _a.id;
    _paths := _paths || jsonb_build_object('from', _a.storage_path, 'to', _new);
  END LOOP;
  UPDATE public.tasks SET job_id = _to.id WHERE id = ANY(_tids) AND workspace_id = _m.workspace_id;
  UPDATE public.proposals SET job_id = _to.id WHERE id = ANY(_pids) AND workspace_id = _m.workspace_id;
  UPDATE public.capture_feedback SET moved = true, chosen_job_id = _to.id WHERE message_id = _m.id;
  FOR _u IN SELECT user_id FROM public.memberships WHERE workspace_id = _m.workspace_id AND status = 'active' AND role IN ('owner','office') AND user_id IS NOT NULL LOOP
    INSERT INTO public.notifications(workspace_id, user_id, kind, level, title, body, job_id)
    VALUES (_m.workspace_id, _u, 'post_moved', 'info', 'Brain bar post moved to ' || _to.code, left(_m.body, 300), _to.id);
  END LOOP;
  PERFORM set_config('app.move_reason', '', true);
  RETURN jsonb_build_object('job_id', _to.id, 'code', _to.code, 'paths', _paths);
END $$;