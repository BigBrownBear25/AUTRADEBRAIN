CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;

ALTER TABLE public.brain_settings ADD COLUMN IF NOT EXISTS last_overnight_on date, ADD COLUMN IF NOT EXISTS last_lookahead_on date;

-- Last Needs attention flags per job, so the watcher only reports new or worsened items
CREATE TABLE public.brain_job_flags (
  job_id uuid PRIMARY KEY REFERENCES public.jobs(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  flags jsonb NOT NULL DEFAULT '[]',
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.brain_job_flags TO authenticated;
GRANT ALL ON public.brain_job_flags TO service_role;
ALTER TABLE public.brain_job_flags ENABLE ROW LEVEL SECURITY;
CREATE POLICY brain_job_flags_read ON public.brain_job_flags FOR SELECT TO authenticated USING (public.is_office(workspace_id));
CREATE TRIGGER brain_job_flags_ws BEFORE INSERT OR UPDATE ON public.brain_job_flags FOR EACH ROW EXECUTE FUNCTION public.job_child_workspace();
CREATE TRIGGER audit_brain_job_flags AFTER INSERT OR UPDATE OR DELETE ON public.brain_job_flags FOR EACH ROW EXECUTE FUNCTION public.write_audit();

-- Weekly look-ahead reports
CREATE TABLE public.brain_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('lookahead')),
  for_date date NOT NULL,
  summary text NOT NULL DEFAULT '',
  data jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (workspace_id, kind, for_date)
);
GRANT SELECT ON public.brain_reports TO authenticated;
GRANT ALL ON public.brain_reports TO service_role;
ALTER TABLE public.brain_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY brain_reports_read ON public.brain_reports FOR SELECT TO authenticated USING (public.is_office(workspace_id));
CREATE TRIGGER audit_brain_reports AFTER INSERT OR UPDATE OR DELETE ON public.brain_reports FOR EACH ROW EXECUTE FUNCTION public.write_audit();

-- Token the scheduled calls present; never exposed through the API
CREATE TABLE IF NOT EXISTS private.app_tokens (name text PRIMARY KEY, value text NOT NULL);
REVOKE ALL ON private.app_tokens FROM PUBLIC, anon, authenticated;

-- Server-only check of the scheduled-call token
CREATE OR REPLACE FUNCTION public.check_cron_token(_t text) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = private, public AS $$
  SELECT EXISTS (SELECT 1 FROM private.app_tokens WHERE name = 'cron' AND value = _t AND length(_t) >= 32)
$$;
REVOKE EXECUTE ON FUNCTION public.check_cron_token(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.check_cron_token(text) TO service_role;