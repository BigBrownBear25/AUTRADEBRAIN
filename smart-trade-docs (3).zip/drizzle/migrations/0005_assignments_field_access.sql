CREATE TABLE public.assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL,
  crew_member_id uuid NOT NULL REFERENCES public.crew_members(id) ON DELETE CASCADE,
  date date NOT NULL,
  start_time time NOT NULL,
  end_time time NOT NULL,
  is_lead boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT assignments_time_order CHECK (end_time > start_time)
);
CREATE INDEX assignments_job_idx ON public.assignments(job_id, date);
CREATE INDEX assignments_crew_idx ON public.assignments(crew_member_id, date);

CREATE OR REPLACE FUNCTION public.assignment_before_write()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  SELECT workspace_id INTO NEW.workspace_id FROM public.jobs WHERE id = NEW.job_id;
  IF NEW.workspace_id IS NULL THEN RAISE EXCEPTION 'Unknown job'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.crew_members c WHERE c.id = NEW.crew_member_id AND c.workspace_id = NEW.workspace_id) THEN
    RAISE EXCEPTION 'Crew member belongs to another workspace';
  END IF;
  RETURN NEW;
END $$;
REVOKE EXECUTE ON FUNCTION public.assignment_before_write() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER assignments_before_write BEFORE INSERT OR UPDATE ON public.assignments
  FOR EACH ROW EXECUTE FUNCTION public.assignment_before_write();

CREATE OR REPLACE FUNCTION public.is_assigned_to_job(_job_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.assignments a
    JOIN public.memberships m ON m.crew_member_id = a.crew_member_id AND m.workspace_id = a.workspace_id
    WHERE a.job_id = _job_id AND m.user_id = auth.uid() AND m.status = 'active')
$$;
CREATE OR REPLACE FUNCTION public.is_job_reader(_job_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.jobs j WHERE j.id = _job_id AND public.is_office(j.workspace_id))
      OR public.is_assigned_to_job(_job_id)
$$;
CREATE OR REPLACE FUNCTION public.is_foreman_on_job(_job_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.is_assigned_to_job(_job_id) AND EXISTS (
    SELECT 1 FROM public.jobs j JOIN public.memberships m ON m.workspace_id = j.workspace_id
    WHERE j.id = _job_id AND m.user_id = auth.uid() AND m.status = 'active' AND m.role = 'foreman')
$$;
REVOKE EXECUTE ON FUNCTION public.is_assigned_to_job(uuid), public.is_foreman_on_job(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_assigned_to_job(uuid), public.is_foreman_on_job(uuid) TO authenticated;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.assignments TO authenticated;
GRANT ALL ON public.assignments TO service_role;
ALTER TABLE public.assignments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Office reads assignments" ON public.assignments FOR SELECT TO authenticated
  USING (public.is_office(workspace_id));
CREATE POLICY "Field reads assignments on their jobs" ON public.assignments FOR SELECT TO authenticated
  USING (public.is_assigned_to_job(job_id));
CREATE POLICY "Office adds assignments" ON public.assignments FOR INSERT TO authenticated
  WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office updates assignments" ON public.assignments FOR UPDATE TO authenticated
  USING (public.is_office(workspace_id)) WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office deletes assignments" ON public.assignments FOR DELETE TO authenticated
  USING (public.is_office(workspace_id));
CREATE TRIGGER audit_assignments AFTER INSERT OR UPDATE OR DELETE ON public.assignments
  FOR EACH ROW EXECUTE FUNCTION public.write_audit();

-- Rule 4: split job read policies into office vs assigned field user.
DROP POLICY "Job readers read jobs" ON public.jobs;
DROP POLICY "Job readers read tasks" ON public.tasks;
DROP POLICY "Job readers read materials" ON public.materials;
DROP POLICY "Job readers read dependencies" ON public.dependencies;
CREATE POLICY "Office reads jobs" ON public.jobs FOR SELECT TO authenticated USING (public.is_office(workspace_id));
CREATE POLICY "Assigned field users read jobs" ON public.jobs FOR SELECT TO authenticated USING (public.is_assigned_to_job(id));
CREATE POLICY "Office reads tasks" ON public.tasks FOR SELECT TO authenticated USING (public.is_office(workspace_id));
CREATE POLICY "Assigned field users read tasks" ON public.tasks FOR SELECT TO authenticated USING (public.is_assigned_to_job(job_id));
CREATE POLICY "Office reads materials" ON public.materials FOR SELECT TO authenticated USING (public.is_office(workspace_id));
CREATE POLICY "Assigned field users read materials" ON public.materials FOR SELECT TO authenticated USING (public.is_assigned_to_job(job_id));
CREATE POLICY "Office reads dependencies" ON public.dependencies FOR SELECT TO authenticated USING (public.is_office(workspace_id));
CREATE POLICY "Assigned field users read dependencies" ON public.dependencies FOR SELECT TO authenticated USING (public.is_assigned_to_job(job_id));

-- Rule 9
CREATE POLICY "Field ticks tasks on their jobs" ON public.tasks FOR UPDATE TO authenticated
  USING (public.is_assigned_to_job(job_id)) WITH CHECK (public.is_assigned_to_job(job_id));
CREATE POLICY "Foremen mark materials delivered" ON public.materials FOR UPDATE TO authenticated
  USING (public.is_foreman_on_job(job_id)) WITH CHECK (public.is_foreman_on_job(job_id) AND status = 'delivered');

CREATE OR REPLACE FUNCTION public.field_update_guard()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NULL OR public.is_office(OLD.workspace_id) THEN RETURN NEW; END IF;
  IF TG_TABLE_NAME = 'tasks' THEN
    IF (to_jsonb(NEW) - ARRAY['done','done_by','done_at']) IS DISTINCT FROM (to_jsonb(OLD) - ARRAY['done','done_by','done_at']) THEN
      RAISE EXCEPTION 'Field users can only tick tasks done';
    END IF;
  ELSIF TG_TABLE_NAME = 'materials' THEN
    IF (to_jsonb(NEW) - 'status') IS DISTINCT FROM (to_jsonb(OLD) - 'status') OR NEW.status <> 'delivered' THEN
      RAISE EXCEPTION 'Foremen can only mark materials delivered';
    END IF;
  END IF;
  RETURN NEW;
END $$;
REVOKE EXECUTE ON FUNCTION public.field_update_guard() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER tasks_field_guard BEFORE UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.field_update_guard();
CREATE TRIGGER materials_field_guard BEFORE UPDATE ON public.materials FOR EACH ROW EXECUTE FUNCTION public.field_update_guard();

-- Rule 6
CREATE OR REPLACE FUNCTION public.crew_mates(_job_id uuid)
RETURNS TABLE (crew_member_id uuid, name text, role public.crew_role, phone text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT DISTINCT c.id, c.name, c.role, c.phone
  FROM public.assignments a JOIN public.crew_members c ON c.id = a.crew_member_id
  WHERE a.job_id = _job_id AND public.is_job_reader(_job_id)
  ORDER BY c.name
$$;
REVOKE EXECUTE ON FUNCTION public.crew_mates(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.crew_mates(uuid) TO authenticated;

-- Rule 10: job-files paths are workspace_id/job_id/file
CREATE OR REPLACE FUNCTION public.job_id_from_path(_name text)
RETURNS uuid LANGUAGE plpgsql IMMUTABLE SET search_path = public AS $$
BEGIN
  RETURN split_part(_name, '/', 2)::uuid;
EXCEPTION WHEN others THEN RETURN NULL;
END $$;
CREATE POLICY "Job readers read job files" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'job-files' AND public.is_job_reader(public.job_id_from_path(name)));
CREATE POLICY "Job readers upload job files" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'job-files' AND public.is_job_reader(public.job_id_from_path(name))
    AND split_part(name, '/', 1) = (SELECT j.workspace_id::text FROM public.jobs j WHERE j.id = public.job_id_from_path(name)));
CREATE POLICY "Office deletes job files" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'job-files' AND EXISTS (SELECT 1 FROM public.jobs j WHERE j.id = public.job_id_from_path(name) AND public.is_office(j.workspace_id)));