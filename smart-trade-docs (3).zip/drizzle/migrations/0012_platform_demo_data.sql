ALTER TABLE public.workspaces ADD COLUMN demo_data boolean NOT NULL DEFAULT false;
ALTER TABLE public.jobs ADD COLUMN is_demo boolean NOT NULL DEFAULT false;
ALTER TABLE public.crew_members ADD COLUMN is_demo boolean NOT NULL DEFAULT false;

-- Owner-only switch. On: adds clearly labelled sample crew, jobs and bookings. Off: removes only those rows.
CREATE OR REPLACE FUNCTION public.set_demo_data(_ws uuid, _on boolean)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE c1 uuid; c2 uuid; c3 uuid; c4 uuid; j1 uuid; j2 uuid; d date := current_date;
BEGIN
  IF NOT public.is_owner(_ws) THEN RAISE EXCEPTION 'Only the owner can change demo data'; END IF;
  DELETE FROM public.jobs WHERE workspace_id = _ws AND is_demo;
  DELETE FROM public.crew_members WHERE workspace_id = _ws AND is_demo;
  UPDATE public.workspaces SET demo_data = _on WHERE id = _ws;
  IF NOT _on THEN RETURN; END IF;

  INSERT INTO public.crew_members (workspace_id, name, role, base_suburb, is_demo) VALUES (_ws, 'Demo — Sam Foreman', 'foreman', 'Wodonga VIC', true) RETURNING id INTO c1;
  INSERT INTO public.crew_members (workspace_id, name, role, base_suburb, is_demo) VALUES (_ws, 'Demo — Alex Installer', 'installer', 'Albury NSW', true) RETURNING id INTO c2;
  INSERT INTO public.crew_members (workspace_id, name, role, base_suburb, is_demo) VALUES (_ws, 'Demo — Jo Installer', 'installer', 'Wangaratta VIC', true) RETURNING id INTO c3;
  INSERT INTO public.crew_members (workspace_id, name, role, base_suburb, is_demo) VALUES (_ws, 'Demo — Riley Apprentice', 'apprentice', 'Wodonga VIC', true) RETURNING id INTO c4;

  INSERT INTO public.jobs (workspace_id, name, sector, status, suburb, address, flooring, area_m2, duration_value, duration_unit, crew_size, start_date, start_time, is_demo)
    VALUES (_ws, 'Demo — Smith kitchen & hallway', 'domestic', 'scheduled', 'Wodonga VIC', '12 High St', 'Engineered oak', 42, 2, 'days', 2, d + 1, '07:00', true) RETURNING id INTO j1;
  INSERT INTO public.jobs (workspace_id, name, sector, status, suburb, address, flooring, area_m2, duration_value, duration_unit, crew_size, start_date, start_time, is_demo)
    VALUES (_ws, 'Demo — Albury clinic vinyl', 'commercial', 'scheduled', 'Albury NSW', '4 Dean St', 'Sheet vinyl', 180, 3, 'days', 3, d + 3, '07:00', true) RETURNING id INTO j2;
  INSERT INTO public.jobs (workspace_id, name, sector, status, suburb, flooring, area_m2, duration_value, duration_unit, crew_size, due_by, is_demo)
    VALUES (_ws, 'Demo — Beechworth carpet', 'domestic', 'ready', 'Beechworth VIC', 'Carpet', 65, 1, 'days', 2, d + 14, true);
  INSERT INTO public.jobs (workspace_id, name, sector, status, suburb, flooring, area_m2, duration_value, duration_unit, crew_size, is_demo)
    VALUES (_ws, 'Demo — Wangaratta school hall', 'commercial', 'quoted', 'Wangaratta VIC', 'Sports vinyl', 400, 5, 'days', 4, true);

  INSERT INTO public.assignments (job_id, crew_member_id, date, start_time, end_time, is_lead) VALUES
    (j1, c1, d + 1, '07:00', '15:30', true), (j1, c4, d + 1, '07:00', '15:30', false),
    (j1, c1, d + 2, '07:00', '15:30', true), (j1, c4, d + 2, '07:00', '15:30', false),
    (j2, c2, d + 3, '07:00', '15:30', true), (j2, c3, d + 3, '07:00', '15:30', false),
    (j2, c2, d + 4, '07:00', '15:30', true), (j2, c3, d + 4, '07:00', '15:30', false),
    (j2, c2, d + 5, '07:00', '15:30', true), (j2, c3, d + 5, '07:00', '15:30', false);
END $$;
REVOKE EXECUTE ON FUNCTION public.set_demo_data(uuid, boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.set_demo_data(uuid, boolean) TO authenticated;