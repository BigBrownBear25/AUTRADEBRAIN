CREATE OR REPLACE FUNCTION private.seed_brain_defaults(_ws uuid) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.brain_settings(workspace_id) VALUES (_ws) ON CONFLICT DO NOTHING;
  INSERT INTO public.ai_config(workspace_id, function, model, max_tokens, max_tool_rounds) VALUES
    (_ws,'capture','anthropic/claude-sonnet-5',3000,4),
    (_ws,'ask','anthropic/claude-sonnet-5',4000,8),
    (_ws,'brief','anthropic/claude-sonnet-5',2000,0),
    (_ws,'summary','anthropic/claude-sonnet-5',4000,0),
    (_ws,'guidance','anthropic/claude-sonnet-5',4000,0),
    (_ws,'drafting','anthropic/claude-sonnet-5',4000,4),
    (_ws,'documents','anthropic/claude-sonnet-5',6000,0),
    (_ws,'lookahead','anthropic/claude-sonnet-5',3000,0),
    (_ws,'watcher','anthropic/claude-sonnet-5',2000,4),
    (_ws,'closeout','anthropic/claude-sonnet-5',3000,0),
    (_ws,'email_sort','anthropic/claude-haiku-4-5',2000,2),
    (_ws,'photo_tag','anthropic/claude-haiku-4-5',1500,0)
  ON CONFLICT DO NOTHING;
END $$;
REVOKE ALL ON FUNCTION private.seed_brain_defaults(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION private.seed_brain_defaults(uuid) TO service_role;
DO $$ DECLARE w record; BEGIN FOR w IN SELECT id FROM public.workspaces LOOP PERFORM private.seed_brain_defaults(w.id); END LOOP; END $$;