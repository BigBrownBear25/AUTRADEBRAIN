CREATE OR REPLACE FUNCTION private.mark_assignment_time(_assignment_id uuid, _which text)
RETURNS timestamptz LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _a public.assignments; _now timestamptz := now(); _today date; _office boolean;
BEGIN
  SELECT * INTO _a FROM public.assignments WHERE id = _assignment_id;
  IF _a.id IS NULL THEN RAISE EXCEPTION 'Booking not found'; END IF;
  _office := private.is_office(_a.workspace_id);
  IF NOT (_office OR _a.crew_member_id IN (SELECT private.my_crew_member_ids())) THEN
    RAISE EXCEPTION 'You can only start or finish your own bookings'; END IF;
  IF NOT _office THEN
    SELECT (_now AT TIME ZONE coalesce(w.timezone, 'Australia/Melbourne'))::date INTO _today FROM public.workspaces w WHERE w.id = _a.workspace_id;
    IF _a.date <> _today THEN
      RAISE EXCEPTION 'You can only start or finish today''s booking. Ask the office to correct other days.'; END IF;
  END IF;
  IF _which = 'start' THEN
    UPDATE public.assignments SET actual_start = _now, actual_end = NULL WHERE id = _assignment_id;
  ELSIF _which = 'finish' THEN
    IF _a.actual_start IS NULL THEN RAISE EXCEPTION 'Tap Start before Finish'; END IF;
    UPDATE public.assignments SET actual_end = _now WHERE id = _assignment_id;
  ELSIF _which = 'clear' THEN
    UPDATE public.assignments SET actual_start = NULL, actual_end = NULL WHERE id = _assignment_id;
  ELSE RAISE EXCEPTION 'Unknown action'; END IF;
  RETURN _now;
END $$;

-- Office corrects any booking's actual times (either may be null to clear it).
CREATE OR REPLACE FUNCTION private.correct_assignment_time(_assignment_id uuid, _start timestamptz, _end timestamptz)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _a public.assignments;
BEGIN
  SELECT * INTO _a FROM public.assignments WHERE id = _assignment_id;
  IF _a.id IS NULL THEN RAISE EXCEPTION 'Booking not found'; END IF;
  IF NOT private.is_office(_a.workspace_id) THEN RAISE EXCEPTION 'Only the office can correct booking times'; END IF;
  IF _end IS NOT NULL AND _start IS NULL THEN RAISE EXCEPTION 'Add a start time before a finish time'; END IF;
  IF _end IS NOT NULL AND _end < _start THEN RAISE EXCEPTION 'Finish must be after start'; END IF;
  UPDATE public.assignments SET actual_start = _start, actual_end = _end WHERE id = _assignment_id;
END $$;
REVOKE ALL ON FUNCTION private.correct_assignment_time(uuid, timestamptz, timestamptz) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION private.correct_assignment_time(uuid, timestamptz, timestamptz) TO authenticated, service_role;
CREATE OR REPLACE FUNCTION public.correct_assignment_time(_assignment_id uuid, _start timestamptz, _end timestamptz)
RETURNS void LANGUAGE sql SECURITY INVOKER SET search_path = public AS $$ SELECT private.correct_assignment_time(_assignment_id, _start, _end) $$;
REVOKE ALL ON FUNCTION public.correct_assignment_time(uuid, timestamptz, timestamptz) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.correct_assignment_time(uuid, timestamptz, timestamptz) TO authenticated, service_role;