-- Section 13: suppliers, catalogue items, prices (finance only), companion rules; catalogue links on materials.
CREATE TABLE public.suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  name text NOT NULL,
  account_no text, rep_name text, rep_phone text, rep_email text, orders_email text,
  lead_time_days integer CHECK (lead_time_days IS NULL OR lead_time_days >= 0),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.suppliers TO authenticated;
GRANT ALL ON public.suppliers TO service_role;
ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Office reads suppliers" ON public.suppliers FOR SELECT TO authenticated USING (public.is_office(workspace_id));
CREATE POLICY "Office adds suppliers" ON public.suppliers FOR INSERT TO authenticated WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office edits suppliers" ON public.suppliers FOR UPDATE TO authenticated USING (public.is_office(workspace_id)) WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office deletes suppliers" ON public.suppliers FOR DELETE TO authenticated USING (public.is_office(workspace_id));
CREATE TRIGGER audit_suppliers AFTER INSERT OR UPDATE OR DELETE ON public.suppliers FOR EACH ROW EXECUTE FUNCTION public.write_audit();

CREATE TABLE public.catalogue_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  supplier_id uuid REFERENCES public.suppliers(id) ON DELETE SET NULL,
  supplier_code text,
  name text NOT NULL,
  brand text, range text, colour text,
  category text NOT NULL DEFAULT 'other' CHECK (category IN ('carpet','sheet vinyl','lvt and hybrid','laminate','engineered timber','solid timber','tiles','underlay','adhesive','levelling and prep','trims and accessories','consumables','other')),
  unit text NOT NULL DEFAULT 'each' CHECK (unit IN ('m²','linear metre','box','roll','each','bag','pail','litre')),
  pack_size numeric CHECK (pack_size IS NULL OR pack_size > 0),
  coverage numeric CHECK (coverage IS NULL OR coverage > 0),
  coverage_basis text,
  waste_pct numeric CHECK (waste_pct IS NULL OR (waste_pct >= 0 AND waste_pct <= 100)),
  stocked boolean NOT NULL DEFAULT false,
  lead_time_days integer CHECK (lead_time_days IS NULL OR lead_time_days >= 0),
  spec_url text, install_url text, sds_url text, warranty_url text,
  hazard_tags text[] NOT NULL DEFAULT '{}',
  active boolean NOT NULL DEFAULT true,
  source text NOT NULL DEFAULT 'manual' CHECK (source IN ('import','reference','job','manual')),
  reference_item_id uuid,
  import_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX catalogue_items_ws_idx ON public.catalogue_items (workspace_id, category);
CREATE UNIQUE INDEX catalogue_items_supplier_code ON public.catalogue_items (workspace_id, supplier_id, supplier_code) WHERE supplier_id IS NOT NULL AND supplier_code IS NOT NULL;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.catalogue_items TO authenticated;
GRANT ALL ON public.catalogue_items TO service_role;
ALTER TABLE public.catalogue_items ENABLE ROW LEVEL SECURITY;
-- Office only. Field users get the few safe columns for their own jobs through job_catalogue_items().
CREATE POLICY "Office reads catalogue" ON public.catalogue_items FOR SELECT TO authenticated USING (public.is_office(workspace_id));
CREATE POLICY "Office adds catalogue items" ON public.catalogue_items FOR INSERT TO authenticated WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office edits catalogue items" ON public.catalogue_items FOR UPDATE TO authenticated USING (public.is_office(workspace_id)) WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office deletes catalogue items" ON public.catalogue_items FOR DELETE TO authenticated USING (public.is_office(workspace_id));
CREATE TRIGGER audit_catalogue_items AFTER INSERT OR UPDATE OR DELETE ON public.catalogue_items FOR EACH ROW EXECUTE FUNCTION public.write_audit();

CREATE TABLE public.catalogue_prices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id uuid NOT NULL REFERENCES public.catalogue_items(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL,
  cost numeric CHECK (cost IS NULL OR cost >= 0),
  sell numeric CHECK (sell IS NULL OR sell >= 0),
  markup_pct numeric,
  effective_from date NOT NULL DEFAULT current_date,
  import_id uuid,
  created_by uuid DEFAULT auth.uid(),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX catalogue_prices_item_idx ON public.catalogue_prices (item_id, effective_from DESC, created_at DESC);
-- Price history: finance adds new rows; nobody edits or deletes them from the app.
GRANT SELECT, INSERT ON public.catalogue_prices TO authenticated;
GRANT ALL ON public.catalogue_prices TO service_role;
ALTER TABLE public.catalogue_prices ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Finance reads prices" ON public.catalogue_prices FOR SELECT TO authenticated USING (public.is_finance(workspace_id));
CREATE POLICY "Finance adds prices" ON public.catalogue_prices FOR INSERT TO authenticated WITH CHECK (public.is_finance(workspace_id));

CREATE OR REPLACE FUNCTION public.catalogue_child_workspace()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  SELECT workspace_id INTO NEW.workspace_id FROM public.catalogue_items WHERE id = NEW.item_id;
  IF NEW.workspace_id IS NULL THEN RAISE EXCEPTION 'Unknown catalogue item'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER catalogue_prices_ws BEFORE INSERT OR UPDATE ON public.catalogue_prices FOR EACH ROW EXECUTE FUNCTION public.catalogue_child_workspace();
CREATE TRIGGER audit_catalogue_prices AFTER INSERT OR UPDATE OR DELETE ON public.catalogue_prices FOR EACH ROW EXECUTE FUNCTION public.write_audit();

CREATE TABLE public.companion_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  when_category text NOT NULL,
  add_category text NOT NULL,
  default_item_id uuid REFERENCES public.catalogue_items(id) ON DELETE SET NULL,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.companion_rules TO authenticated;
GRANT ALL ON public.companion_rules TO service_role;
ALTER TABLE public.companion_rules ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Office reads companion rules" ON public.companion_rules FOR SELECT TO authenticated USING (public.is_office(workspace_id));
CREATE POLICY "Office adds companion rules" ON public.companion_rules FOR INSERT TO authenticated WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office edits companion rules" ON public.companion_rules FOR UPDATE TO authenticated USING (public.is_office(workspace_id)) WITH CHECK (public.is_office(workspace_id));
CREATE POLICY "Office deletes companion rules" ON public.companion_rules FOR DELETE TO authenticated USING (public.is_office(workspace_id));
CREATE TRIGGER audit_companion_rules AFTER INSERT OR UPDATE OR DELETE ON public.companion_rules FOR EACH ROW EXECUTE FUNCTION public.write_audit();

-- Links between rows must stay inside one workspace.
CREATE OR REPLACE FUNCTION public.catalogue_links_same_ws()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _r jsonb := to_jsonb(NEW);
BEGIN
  IF _r ? 'supplier_id' AND NEW.supplier_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.suppliers s WHERE s.id = NEW.supplier_id AND s.workspace_id = NEW.workspace_id) THEN
    RAISE EXCEPTION 'Supplier belongs to another workspace'; END IF;
  IF _r ? 'catalogue_item_id' AND (_r->>'catalogue_item_id') IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.catalogue_items c WHERE c.id = (_r->>'catalogue_item_id')::uuid AND c.workspace_id = NEW.workspace_id) THEN
    RAISE EXCEPTION 'Catalogue item belongs to another workspace'; END IF;
  IF _r ? 'default_item_id' AND (_r->>'default_item_id') IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.catalogue_items c WHERE c.id = (_r->>'default_item_id')::uuid AND c.workspace_id = NEW.workspace_id) THEN
    RAISE EXCEPTION 'Catalogue item belongs to another workspace'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER catalogue_items_links BEFORE INSERT OR UPDATE ON public.catalogue_items FOR EACH ROW EXECUTE FUNCTION public.catalogue_links_same_ws();
CREATE TRIGGER companion_rules_links BEFORE INSERT OR UPDATE ON public.companion_rules FOR EACH ROW EXECUTE FUNCTION public.catalogue_links_same_ws();

-- Materials: optional catalogue link; free text still works.
ALTER TABLE public.materials
  ADD COLUMN catalogue_item_id uuid REFERENCES public.catalogue_items(id) ON DELETE SET NULL,
  ADD COLUMN supplier_id uuid REFERENCES public.suppliers(id) ON DELETE SET NULL,
  ADD COLUMN calc jsonb,
  ADD COLUMN order_by_date date,
  ADD COLUMN ordered_at timestamptz,
  ADD COLUMN order_list_id uuid;
COMMENT ON COLUMN public.materials.order_list_id IS 'order_lists arrives in M3; no foreign key until then';
-- materials_ws (job_child_workspace) runs first alphabetically, so workspace_id is set before this check.
CREATE TRIGGER materials_zz_links BEFORE INSERT OR UPDATE ON public.materials FOR EACH ROW EXECUTE FUNCTION public.catalogue_links_same_ws();

-- Waste defaults by category (section 13), changeable in Settings.
ALTER TABLE public.workspace_settings ADD COLUMN waste_defaults jsonb NOT NULL
  DEFAULT '{"carpet": 10, "lvt and hybrid": 8, "laminate": 8, "tiles": 10, "sheet vinyl": 10}'::jsonb;

-- Field users: name, colour, unit, coverage and links for catalogue items on a job they can read. No prices, no supplier detail.
CREATE OR REPLACE FUNCTION private.job_catalogue_items(_job_id uuid)
RETURNS TABLE(id uuid, name text, colour text, unit text, pack_size numeric, coverage numeric, coverage_basis text,
  spec_url text, install_url text, sds_url text, warranty_url text, hazard_tags text[])
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT c.id, c.name, c.colour, c.unit, c.pack_size, c.coverage, c.coverage_basis, c.spec_url, c.install_url, c.sds_url, c.warranty_url, c.hazard_tags
  FROM public.catalogue_items c
  WHERE private.is_job_reader(_job_id)
    AND c.id IN (SELECT m.catalogue_item_id FROM public.materials m WHERE m.job_id = _job_id)
$$;
REVOKE ALL ON FUNCTION private.job_catalogue_items(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION private.job_catalogue_items(uuid) TO authenticated;
CREATE OR REPLACE FUNCTION public.job_catalogue_items(_job_id uuid)
RETURNS TABLE(id uuid, name text, colour text, unit text, pack_size numeric, coverage numeric, coverage_basis text,
  spec_url text, install_url text, sds_url text, warranty_url text, hazard_tags text[])
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$ SELECT * FROM private.job_catalogue_items(_job_id) $$;
REVOKE ALL ON FUNCTION public.job_catalogue_items(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.job_catalogue_items(uuid) TO authenticated;