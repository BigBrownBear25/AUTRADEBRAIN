-- Jobs: builder PM phone and client phone
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS builder_pm_phone text, ADD COLUMN IF NOT EXISTS client_phone text;

-- Finance: variation margin
ALTER TABLE public.workspace_finance_settings ADD COLUMN IF NOT EXISTS variation_margin_pct numeric(5,2);

-- Assignments: actual start and finish from the field app
ALTER TABLE public.assignments ADD COLUMN IF NOT EXISTS actual_start timestamptz, ADD COLUMN IF NOT EXISTS actual_end timestamptz;

-- Attachments: video plus Brain fields
ALTER TYPE public.attachment_kind ADD VALUE IF NOT EXISTS 'video';
ALTER TABLE public.attachments
  ADD COLUMN IF NOT EXISTS transcript text,
  ADD COLUMN IF NOT EXISTS ai_tags text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS ai_readings jsonb,
  ADD COLUMN IF NOT EXISTS frame_paths text[] NOT NULL DEFAULT '{}';

-- Audit log: move reason, set only by the write_audit trigger from a transaction setting
ALTER TABLE public.audit_log ADD COLUMN IF NOT EXISTS reason text
  CHECK (reason IS NULL OR reason IN ('builder_delay','weather','crew_away','materials','client_request','other'));

CREATE OR REPLACE FUNCTION public.write_audit()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _ws uuid; _row jsonb; _reason text;
BEGIN
  _row := to_jsonb(COALESCE(NEW, OLD));
  IF TG_TABLE_NAME = 'workspaces' THEN _ws := (_row->>'id')::uuid;
  ELSE _ws := (_row->>'workspace_id')::uuid; END IF;
  _reason := nullif(current_setting('app.move_reason', true), '');
  IF _reason IS NOT NULL AND _reason NOT IN ('builder_delay','weather','crew_away','materials','client_request','other') THEN _reason := NULL; END IF;
  INSERT INTO public.audit_log(workspace_id, actor_user_id, action, table_name, row_id, before, after, reason)
  VALUES (_ws, auth.uid(), lower(TG_OP), TG_TABLE_NAME, _row->>'id',
    CASE WHEN TG_OP IN ('UPDATE','DELETE') THEN to_jsonb(OLD) END,
    CASE WHEN TG_OP IN ('INSERT','UPDATE') THEN to_jsonb(NEW) END, _reason);
  RETURN COALESCE(NEW, OLD);
END $$;
REVOKE EXECUTE ON FUNCTION public.write_audit() FROM PUBLIC, anon, authenticated;

-- place_job: optional move reason; keeps actual start/finish on bookings that survive the move
DROP FUNCTION IF EXISTS public.place_job(uuid, jsonb, date, time, public.job_status, boolean);
CREATE FUNCTION public.place_job(
  _job_id uuid, _rows jsonb, _start_date date, _start_time time, _status public.job_status,
  _ignore_lock boolean DEFAULT false, _reason text DEFAULT NULL
) RETURNS void LANGUAGE plpgsql SECURITY INVOKER SET search_path = public AS $$
DECLARE _ws uuid; _locked boolean;
BEGIN
  SELECT workspace_id, locked INTO _ws, _locked FROM public.jobs WHERE id = _job_id;
  IF _ws IS NULL OR NOT public.is_office(_ws) THEN RAISE EXCEPTION 'Only office users can place jobs'; END IF;
  IF _locked AND NOT _ignore_lock THEN RAISE EXCEPTION 'This job is locked. Unlock it to move it.'; END IF;
  IF _reason IS NOT NULL AND _reason NOT IN ('builder_delay','weather','crew_away','materials','client_request','other') THEN
    RAISE EXCEPTION 'Unknown move reason'; END IF;
  PERFORM set_config('app.move_reason', COALESCE(_reason, ''), true);
  CREATE TEMP TABLE IF NOT EXISTS _kept_actuals (id uuid PRIMARY KEY, actual_start timestamptz, actual_end timestamptz) ON COMMIT DROP;
  DELETE FROM _kept_actuals;
  INSERT INTO _kept_actuals SELECT id, actual_start, actual_end FROM public.assignments
    WHERE job_id = _job_id AND (actual_start IS NOT NULL OR actual_end IS NOT NULL);
  DELETE FROM public.assignments WHERE job_id = _job_id;
  INSERT INTO public.assignments (id, job_id, workspace_id, crew_member_id, date, start_time, end_time, is_lead, actual_start, actual_end)
  SELECT x.id, _job_id, _ws, x.crew_member_id, x.date, x.start_time, x.end_time, x.is_lead, k.actual_start, k.actual_end
  FROM (SELECT COALESCE((r->>'id')::uuid, gen_random_uuid()) AS id, (r->>'crew_member_id')::uuid AS crew_member_id,
               (r->>'date')::date AS date, (r->>'start_time')::time AS start_time, (r->>'end_time')::time AS end_time,
               COALESCE((r->>'is_lead')::boolean, false) AS is_lead
        FROM jsonb_array_elements(COALESCE(_rows, '[]'::jsonb)) r) x
  LEFT JOIN _kept_actuals k ON k.id = x.id;
  UPDATE public.jobs SET start_date = _start_date, start_time = _start_time, status = _status
  WHERE id = _job_id AND (start_date IS DISTINCT FROM _start_date OR start_time IS DISTINCT FROM _start_time OR status IS DISTINCT FROM _status);
  PERFORM set_config('app.move_reason', '', true);
END $$;
REVOKE EXECUTE ON FUNCTION public.place_job(uuid, jsonb, date, time, public.job_status, boolean, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.place_job(uuid, jsonb, date, time, public.job_status, boolean, text) TO authenticated;

-- Field Start / Finish: a crew member stamps only their own booking, only on its day
CREATE OR REPLACE FUNCTION private.mark_assignment_time(_assignment_id uuid, _which text)
RETURNS timestamptz LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _a public.assignments; _now timestamptz := now();
BEGIN
  SELECT * INTO _a FROM public.assignments WHERE id = _assignment_id;
  IF _a.id IS NULL THEN RAISE EXCEPTION 'Booking not found'; END IF;
  IF NOT (_a.crew_member_id IN (SELECT private.my_crew_member_ids()) OR private.is_office(_a.workspace_id)) THEN
    RAISE EXCEPTION 'You can only start or finish your own bookings'; END IF;
  IF _which = 'start' THEN
    UPDATE public.assignments SET actual_start = _now, actual_end = NULL WHERE id = _assignment_id;
  ELSIF _which = 'finish' THEN
    IF _a.actual_start IS NULL THEN RAISE EXCEPTION 'Tap Start before Finish'; END IF;
    UPDATE public.assignments SET actual_end = _now WHERE id = _assignment_id;
  ELSIF _which = 'clear' THEN
    UPDATE public.assignments SET actual_start = NULL, actual_end = NULL WHERE id = _assignment_id;
  ELSE RAISE EXCEPTION 'Unknown action'; END IF;
  RETURN _now;
END $$;
REVOKE ALL ON FUNCTION private.mark_assignment_time(uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION private.mark_assignment_time(uuid, text) TO authenticated, service_role;
CREATE OR REPLACE FUNCTION public.mark_assignment_time(_assignment_id uuid, _which text)
RETURNS timestamptz LANGUAGE sql SECURITY INVOKER SET search_path = public AS $$ SELECT private.mark_assignment_time(_assignment_id, _which) $$;
REVOKE ALL ON FUNCTION public.mark_assignment_time(uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.mark_assignment_time(uuid, text) TO authenticated, service_role;