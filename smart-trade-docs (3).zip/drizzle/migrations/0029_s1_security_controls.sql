-- Two-factor counts only for 12 hours after the code was entered (spec section 14 rule 2).
CREATE OR REPLACE FUNCTION private.has_aal2()
RETURNS boolean LANGUAGE sql STABLE SET search_path TO 'public' AS $$
  SELECT coalesce(auth.jwt()->>'aal','') = 'aal2' AND EXISTS (
    SELECT 1 FROM jsonb_array_elements(coalesce(auth.jwt()->'amr', '[]'::jsonb)) a
    WHERE a->>'method' IN ('totp','phone','webauthn','mfa/totp','mfa/phone','mfa/webauthn')
      AND (a->>'timestamp')::bigint > extract(epoch FROM now())::bigint - 43200)
$$;

-- Activity log: rows from finance tables only for finance users.
DROP POLICY IF EXISTS "Owner reads audit log" ON public.audit_log;
CREATE POLICY "Owner reads audit log" ON public.audit_log FOR SELECT TO authenticated
  USING (workspace_id IS NOT NULL AND private.is_owner(workspace_id)
    AND (table_name NOT IN ('job_finance','crew_rates','material_costs','workspace_finance_settings') OR private.is_finance(workspace_id)));

-- Access reviews: who reviewed the member list and when.
CREATE TABLE public.access_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  reviewed_by uuid NOT NULL DEFAULT auth.uid(),
  reviewed_at timestamptz NOT NULL DEFAULT now(),
  member_count integer NOT NULL DEFAULT 0,
  notes text
);
GRANT SELECT, INSERT ON public.access_reviews TO authenticated;
GRANT ALL ON public.access_reviews TO service_role;
ALTER TABLE public.access_reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owner reads access reviews" ON public.access_reviews FOR SELECT TO authenticated USING (public.is_owner(workspace_id));
CREATE POLICY "Owner records access review" ON public.access_reviews FOR INSERT TO authenticated
  WITH CHECK (public.is_owner(workspace_id) AND reviewed_by = auth.uid());
CREATE TRIGGER audit_access_reviews AFTER INSERT OR UPDATE OR DELETE ON public.access_reviews FOR EACH ROW EXECUTE FUNCTION public.write_audit();

-- Security events (owner signed a member out of every device). Written only by sign_out_member.
CREATE TABLE public.security_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  actor_user_id uuid,
  target_user_id uuid,
  kind text NOT NULL,
  at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.security_events TO authenticated;
GRANT ALL ON public.security_events TO service_role;
ALTER TABLE public.security_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owner reads security events" ON public.security_events FOR SELECT TO authenticated USING (public.is_owner(workspace_id));
CREATE TRIGGER audit_security_events AFTER INSERT OR UPDATE OR DELETE ON public.security_events FOR EACH ROW EXECUTE FUNCTION public.write_audit();

-- People and access: every member with last sign-in and two-factor status. Owner only.
CREATE OR REPLACE FUNCTION private.member_access(_ws uuid)
RETURNS TABLE(membership_id uuid, user_id uuid, role public.app_role, status public.membership_status, email text,
  crew_member_id uuid, crew_name text, last_sign_in_at timestamptz, two_factor boolean)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT private.is_owner(_ws) THEN RAISE EXCEPTION 'Only the owner can review access'; END IF;
  RETURN QUERY
  SELECT m.id, m.user_id, m.role, m.status, coalesce(u.email::text, m.invited_email), m.crew_member_id, c.name,
    u.last_sign_in_at,
    EXISTS (SELECT 1 FROM auth.mfa_factors f WHERE f.user_id = m.user_id AND f.status = 'verified')
  FROM public.memberships m
  LEFT JOIN auth.users u ON u.id = m.user_id
  LEFT JOIN public.crew_members c ON c.id = m.crew_member_id
  WHERE m.workspace_id = _ws AND m.status <> 'removed'
  ORDER BY m.role, coalesce(c.name, u.email::text, m.invited_email);
END $$;
REVOKE ALL ON FUNCTION private.member_access(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION private.member_access(uuid) TO authenticated;
CREATE OR REPLACE FUNCTION public.member_access(_ws uuid)
RETURNS TABLE(membership_id uuid, user_id uuid, role public.app_role, status public.membership_status, email text,
  crew_member_id uuid, crew_name text, last_sign_in_at timestamptz, two_factor boolean)
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$ SELECT * FROM private.member_access(_ws) $$;
REVOKE ALL ON FUNCTION public.member_access(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.member_access(uuid) TO authenticated;

-- Owner signs a member out of every device: ends all their sessions (access tokens lapse within the hour).
CREATE OR REPLACE FUNCTION private.sign_out_member(_ws uuid, _user uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT private.is_owner(_ws) THEN RAISE EXCEPTION 'Only the owner can sign people out'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.memberships WHERE workspace_id = _ws AND user_id = _user AND status <> 'removed') THEN
    RAISE EXCEPTION 'That person isn''t in this workspace'; END IF;
  DELETE FROM auth.sessions WHERE user_id = _user;
  INSERT INTO public.security_events(workspace_id, actor_user_id, target_user_id, kind) VALUES (_ws, auth.uid(), _user, 'signed_out_everywhere');
END $$;
REVOKE ALL ON FUNCTION private.sign_out_member(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION private.sign_out_member(uuid, uuid) TO authenticated;
CREATE OR REPLACE FUNCTION public.sign_out_member(_ws uuid, _user uuid)
RETURNS void LANGUAGE sql SECURITY INVOKER SET search_path = public AS $$ SELECT private.sign_out_member(_ws, _user) $$;
REVOKE ALL ON FUNCTION public.sign_out_member(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.sign_out_member(uuid, uuid) TO authenticated;