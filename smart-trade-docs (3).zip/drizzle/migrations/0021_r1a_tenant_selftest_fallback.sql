CREATE OR REPLACE FUNCTION public.selftest_proposal_tenant() RETURNS TABLE(test text, passed boolean)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE _ws uuid; _own uuid; _foreign uuid;
BEGIN
  SELECT w.id INTO _ws FROM public.workspaces w WHERE EXISTS (SELECT 1 FROM public.crew_members c WHERE c.workspace_id = w.id) LIMIT 1;
  IF _ws IS NULL THEN RETURN QUERY SELECT 'needs a workspace with crew'::text, false; RETURN; END IF;
  SELECT id INTO _own FROM public.crew_members WHERE workspace_id = _ws LIMIT 1;
  -- a real crew member from another workspace when one exists, otherwise an id that is not in this workspace
  SELECT id INTO _foreign FROM public.crew_members WHERE workspace_id <> _ws LIMIT 1;
  _foreign := COALESCE(_foreign, gen_random_uuid());
  RETURN QUERY VALUES
    ('rows naming another workspace crew member are refused', NOT private.proposal_tenant_ok(_ws, NULL, 'place', jsonb_build_object('rows', jsonb_build_array(jsonb_build_object('crew_member_id', _foreign))))),
    ('mixed rows (one foreign) are refused', NOT private.proposal_tenant_ok(_ws, NULL, 'swap', jsonb_build_object('rows', jsonb_build_array(jsonb_build_object('crew_member_id', _own), jsonb_build_object('crew_member_id', _foreign))))),
    ('ticket for another workspace crew member is refused', NOT private.proposal_tenant_ok(_ws, NULL, 'update_ticket', jsonb_build_object('crew_member_id', _foreign, 'ticket_type', 'x'))),
    ('leave for another workspace crew member is refused', NOT private.proposal_tenant_ok(_ws, NULL, 'leave_request', jsonb_build_object('crew_member_id', _foreign))),
    ('task owner from another workspace is refused', NOT private.proposal_tenant_ok(_ws, NULL, 'add_task', jsonb_build_object('label','x','owner_crew_member_id', _foreign))),
    ('own crew member is allowed', private.proposal_tenant_ok(_ws, NULL, 'place', jsonb_build_object('rows', jsonb_build_array(jsonb_build_object('crew_member_id', _own))))),
    ('undo naming another workspace crew member is refused', NOT private.undo_tenant_ok(_ws, NULL, jsonb_build_object('rows', jsonb_build_array(jsonb_build_object('crew_member_id', _foreign))))),
    ('real other-workspace crew member was used', EXISTS (SELECT 1 FROM public.crew_members WHERE id = _foreign));
END $$;