# Trade Brain — project brief

Oct 11, 2026 · @Geddy

## Summary

Trade Brain replaces the office whiteboard, the phone and the email chain with one place where every job lives and a scheduling agent that sees the whole pipeline. Elliot's flooring business in Wodonga (around 30 installers, domestic and commercial) is user zero. Trade Brain is conceived as a subscription (SaaS) product for trade businesses that schedule crews across many sites, with Elliot's business as the first customer and design partner.

The goal: get Elliot's 4 am scheduling down from about two hours to minutes, and absorb most of the change that now arrives as 80 phone calls a day, before it reaches him.

Three things make it different from job-management software:

- **Scheduling is the core, not an add-on.** Every job carries its rules (skills, tickets, crew size, deadlines, site access), so the schedule is checked against them all the time.
- **The job stream is the single record.** Everything about a job, from the first call or email through the site walk, photos, plans, SWMS, variations and sign-off, sits in one stream.
- **The agent acts ahead of Elliot.** When something changes, Trade Brain works out what it knocks on, proposes a fix, and asks Elliot to approve rather than to solve.

## The problem

The whole schedule lives on one whiteboard in Elliot's office, and only Elliot can rebuild it when it breaks. That holds while the business is small. It is what is wearing him down as it grows.

**A typical day today**

| Time | What happens | Why it hurts |
| --- | --- | --- |
| 4 am | Elliot arrives and builds the day and week on the whiteboard, across commercial and residential | Up to two hours. Every rule (who can do what, who holds which ticket, who is on leave, which site is ready) is in his head |
| 10 am | The phone starts: another trade isn't ready to hand over, a job has grown, a client wants a change | Each call can knock on to several other jobs. He re-plans by hand, on the board, while still on the phone |
| All day | About 80 calls | Constant interruption; decisions made from memory, not from the full picture |
| All day | Photos and variation details arrive by email; admin forward them to the builder's project manager for approval | Approvals wait in inboxes. Nobody can see what has been asked, approved or is holding a job up |

**What is actually broken**

- The schedule exists in one place, in one person's head and on one board. Nobody else can see it, check it or change it safely.
- Job information is scattered across phones, inboxes, text messages and memory. Site walk notes, photos and plans are hard to find when they matter.
- Change is handled one phone call at a time. Nothing works out the knock-on effects across the pipeline.
- Variations and approvals move by forwarded email, so they are slow and easy to lose.
- As the business grows, all of this grows with it, and it all lands on Elliot.

## Vision and principles

Elliot opens Trade Brain at 4 am and the week is already planned against every rule he would have applied himself. When the 10 am call comes, the change is logged once, and Trade Brain has already shown him what it affects and how to fix it.

1. **Scheduling first.** Every other feature exists to feed the schedule better information or to act on it. If a feature doesn't help the schedule or the people on site, it waits.
2. **One job stream, one source of truth.** Every call, email, photo, plan, note, document and decision belongs to a job and lives in its stream. Nothing important lives only in an inbox or a head.
3. **The agent proposes, a person approves.** Trade Brain suggests schedule changes, drafts SWMS and briefs, and prepares variations. It never moves a booked crew, sends anything to a client or builder, or changes a safety document without a person approving.
4. **People only see their own work.** Installers and subcontractors see the jobs they are assigned to and nothing else. They never see another crew's or contractor's jobs, clients, sites or schedule.
5. **Finance stays light and stays in the office.** Trade Brain tracks what scheduling needs: quoted or not, approved or not, value at a glance. Pricing, margins and costs stay with the office and accounting system, and installers and subcontractors never see them.
6. **Built for the site, not the desk.** Phone first, one hand, gloves, poor signal. Voice and photos count as much as typing.
7. **Safety is built in.** Tickets, hazards and SWMS are rules the schedule checks, not paperwork done afterwards.
8. **SaaS from day one.** Trade Brain is a multi-business subscription product. Elliot is the first customer, but nothing is built only for him: each business gets its own workspace, and trade-specific lists are settings.

## Who uses it and what they see

Access is set per job, and the system enforces it rather than hiding things on screen. A person who isn't on a job can't get to its data at all.

| Role | Uses Trade Brain to | Sees | Never sees |
| --- | --- | --- | --- |
| Owner / master scheduler (Elliot) | Plan and re-plan the pipeline, approve agent suggestions, approve variations and SWMS | Everything: all jobs, all crew, leave, availability, job value and status | Nothing is hidden |
| Office and admin | Take enquiries, log calls and emails, chase approvals and materials, manage leave | All jobs and crew; finance only if the owner allows it | Finance unless granted |
| Foreman / team leader | Run their jobs on site, sign crew on, update progress, raise problems and variations | Full detail of the jobs they lead, and their own crew's schedule on those jobs | Other jobs, other crews, any pricing |
| Installer and apprentice | See their day, get there, follow the brief and SWMS, post updates, voice notes and photos, tick tasks, request leave | Only jobs they are assigned to, for the days assigned; the people on the same job | Other installers' jobs, subcontractors, clients of other jobs, any pricing |
| Subcontractor | Same as an installer, for jobs subcontracted to them | Only their assigned jobs; nothing about Elliot's own crew beyond the shared job | Other subcontractors, Elliot's other jobs, any pricing beyond their own agreed rate |
| Builder's project manager / site manager | Report readiness, receive and approve variations, see progress on their jobs | A shared view of their own jobs: dates, progress, variations awaiting them, handover status | Anything about other builders' jobs or Elliot's crew schedule |
| Client (domestic) | Join the site walk, confirm access and selections, sign off | Their job's key dates, what they agreed, sign-off | Everything else |

**Rules this sets**

- An installer's schedule view shows their own bookings only. Other people's jobs show as nothing, not as a greyed-out block.
- Messages, files and voice notes belong to a job, so they inherit its access. A message to a job never reaches someone who isn't on it.
- Other people's leave shows to installers only as "away" when it affects a shared job, never as the type of leave.
- Removing someone from a job removes their access to it straight away; they keep a record of their own hours.

## The job stream

Every job has one stream: a timeline of everything that has happened on it, with the current facts pinned at the top. Anyone on the job sees the same stream, filtered to what their role is allowed to see.

**Stages**

1. **Enquiry.** Created from a call, email, web form or forwarded message. Trade Brain pulls out the client, site, scope and dates and asks for what's missing.
2. **Site walk.** Audio, video and photos from the client, owner or foreman, captured on a phone. Trade Brain transcribes them and turns them into scope, measurements, subfloor condition, access, hazards, client wants and open questions.
3. **Quoted.** The quote is noted as sent and its value recorded for the office. Pencilled dates are optional.
4. **Ready to schedule.** Accepted, with its rules set: skills, crew size, duration, tickets, hazards, must-finish-by date (hard or preferred), site access windows, and what it depends on (for example, the builder's handover or the slab moisture test).
5. **Scheduled.** Dates and crew are booked. The brief, SWMS, materials and travel are ready.
6. **On site.** Daily sign-on, progress, tasks, photos, problems, variations and the job chat.
7. **Handover and sign-off.** Checklist, photos, client or builder sign-off, defects list.
8. **Closed.** Everything stays searchable as the job record.

**What a stream holds**

| Kind | Examples | Comes from |
| --- | --- | --- |
| Conversations | Call notes, emails and attachments, texts, job chat with task threads | Phone, inbox forwarding, the app |
| Site capture | Walk-through audio and video, voice notes, photos, moisture and level readings | Phone camera and microphone |
| Drawings | Site plans, floor plans, set-out diagrams, builder's drawings | Upload or email; read by the agent |
| Job rules | Skills, tickets, crew size, duration, deadlines, access windows, dependencies, priority | Office, agent suggestions |
| Documents | Project brief, install guidance, SWMS, checklists, handover pack | Drafted by the agent, approved by a person |
| Decisions | Variations, schedule changes, approvals, who approved and when | Workflow in the app |
| Materials | Lines, quantities, status (to order, ordered, delivered) | Office, supplier confirmations |

The pinned summary at the top answers: what is it, where, when, who, what's blocking it, and what's waiting on someone. It's written by Trade Brain and checked by a person.

## Scheduling engine

This is the part that is killing Elliot, so it ships first and gets the most care. It replaces the whiteboard with a board that knows every job's rules and every person's availability.

**The master board and overview**

- **Board:** crew in rows (grouped foremen, installers, apprentices, subcontractors), working days in columns, jobs as bars. Leave, closures and public holidays are shown on the board.
- **Time frames:** week, two weeks, month, quarter or custom dates, on the board and on the overview.
- **Overview:** jobs in range, crew-days booked against crew-days available after leave, open crew spots, work booked, the unscheduled backlog, urgent issues, daily capacity, a timeline of jobs, skill demand against capacity, and the priority mix.
- **Forward availability:** free crew-days by week for the whole crew, each role and each skill, after bookings, leave and closures. Elliot can see there's room before he promises a date.

**Job rules the schedule enforces**

| Rule | How it's applied |
| --- | --- |
| Skills | Main skill plus supporting skills; at least half the crew must hold the main skill |
| Tickets | White Card, WWCC, asbestos and silica awareness, first aid; checked against expiry on the job's dates |
| Crew make-up | Crew size, a foreman on 3+ person jobs, a first aider on site |
| Time | Duration in hours or working days (weekends optional for each business), start and finish times, site access windows (after hours, school terms, closed days) |
| Deadlines | Must-finish-by date, hard or preferred |
| Dependencies | Waits on another trade's handover, a test result, a materials delivery or an approval |
| Availability | Bookings, approved leave, closures; requested leave as a warning |
| Travel | Drive time from each person's base, leave-by times, overnight stays for distant jobs |
| Priority | Importance (key, standard, minor) × urgency (critical, soon, flexible) gives P1 to P4; due dates raise it automatically |

**Doing the scheduling**

- **Drag and drop:** drag a job, or a card from the to-schedule tray, onto a day. While dragging, every cell shows whether it fits, fits with warnings or clashes, and why. Drop on a crew member to move dates; drop on someone else to swap them in. Every change can be undone. On a phone, tap a card then tap a day.
- **Find a slot:** the earliest dates where a qualified crew is free, before any hard deadline. If nothing fits, it says why (for example, "no foreman holds silica awareness").
- **Suggest a plan:** schedules the whole backlog in priority order, taking each earlier pick into account. It's only a preview until approved.
- **Lock:** pin a job or a crew member so the agent never moves them.
- **Split crews and part days:** a job can change crew partway through, bookings can be half days or set hours (some jobs take an hour), and Saturday and Sunday can be working days. The prototype couldn't do this; the real build needs it.
- **What-if:** try a change on a copy of the schedule and compare it with the live one before committing.

**Leave and resources**

- Leave types (annual, sick, training, RDO, unavailable), requested by installers and approved by the office, with a clash warning if the person is booked.
- Business closures and public holidays for NSW and Victoria, both of which apply on the border.
- Subcontractor availability windows and their own ticket records.

## The Trade Brain agent

The agent knows the whole pipeline, every job's rules and every person's availability. Its job is to catch a change early, work out what it knocks on, and hand Elliot a fix to approve instead of a problem to solve.

&#91;embedded content: how a change is handled · 6 steps, 1 decision\]

Elliot's part is the diamond. Everything before it is the agent's work, and nothing changes on site until he approves.

**When something changes**

A change can be a builder's PM saying the site won't be ready, a foreman reporting the subfloor is worse than expected, an installer calling in sick, a delivery slipping or a client changing a selection. Trade Brain then:

1. **Logs it once** against the job, from wherever it came in: a call note, email, text, voice note or the app.
2. **Works out the impact:** which jobs, people, deadlines and dependencies move, and which hard deadlines are now at risk.
3. **Proposes fixes,** usually two or three, each with its trade-off. For example: "Push FZ-1046 two days and move Kyle and Jack to the library job; both still finish before their hard dates. Or keep FZ-1046 and bring in a subcontractor for the library."
4. **Alerts Elliot** once, with the change, the impact and the options. It doesn't send a stream of notifications.
5. **Applies the option Elliot picks,** then tells the affected crew, builder or client, using messages Elliot has approved or set rules for.

**It also watches for things before they become calls**

- A ticket expires before a booked job ends.
- Materials aren't delivered and the job starts in 48 hours.
- A dependency hasn't been confirmed by its due date (for example, "has the builder confirmed handover for Monday?").
- Leave has been requested over a booked job.
- A crew member is double-booked or over-travelled this week.
- A job is running over its days, based on the foreman's updates.

**What it reads and writes**

- **Reads:** emails, call notes, voice notes, site walk audio and video, photos, site plans and drawings, the job rules, the schedule, leave and tickets.
- **Writes, for a person to approve:** project briefs, install guidance, SWMS, pre-start and handover checklists, variation requests, measured quantities from plans, client and builder updates, and the 4 am draft schedule.
- **Learns from history:** how long each job type really takes, which builders tend to run late, and which crews work well together. It uses this to make better suggestions over time.

**Limits on what it can do**

| The agent can, on its own | The agent needs approval to |
| --- | --- |
| Log, summarise and file anything that comes in | Change a booked job's dates or crew |
| Draft documents, messages and plans | Send anything to a client, builder or subcontractor |
| Flag risks and clashes | Approve or submit a variation |
| Hold a tentative slot for a P1 job | Issue or change a SWMS |
| Suggest a schedule on a copy | Override a lock, a hard deadline or a ticket rule |

Every action it takes is logged with the reason, what it was based on, and who approved it.

## Variations and approvals

A variation goes from the site to the builder's PM in one step, and everyone can see where it's up to. Today it goes from the installer to Elliot to admin by email, then to the PM.

1. **Raised on site:** the foreman or installer takes photos, records a voice note ("subfloor dips 12 mm over 3 m in bedroom 2, needs levelling") and taps Raise variation.
2. **Drafted by Trade Brain:** it writes the variation in the builder's expected format, with the description, reason, photos, measurements, extra time and materials, and its effect on the schedule.
3. **Checked by the office:** Elliot or admin adjusts it and adds the price. The price is office-only, so the installer who raised it doesn't see it.
4. **Sent to the PM:** through a link the PM can open without an account. They see the photos and details and can approve, reject or ask a question.
5. **Tracked:** the status shows on the job (waiting, approved, rejected, query), with reminders if it's waiting too long and an alert if the job can't go ahead without it.
6. **Approved:** the job's scope, materials, duration and schedule update, with Trade Brain proposing the schedule change. The approval is kept as a record with who, when and what.

The same flow is used for other approvals: client selections and sign-off, SWMS sign-off, builder handover confirmation and schedule changes the agent proposes.

## Safety

Safety documents are drafted from what's actually known about the site and approved before anyone starts. Safety rules are also scheduling rules, so a crew without the right tickets can't be booked by mistake.

- **SWMS per job:** Trade Brain starts from the business's approved SWMS templates for each high-risk activity (asbestos in older buildings, silica dust from grinding, epoxy and solvents, work near live services) and fills in the site's hazards from the walk and the plans. A competent person approves it, and it's versioned.
- **Sign-on:** each crew member signs on to the SWMS and the pre-start checklist on their phone before work starts, and again if it changes.
- **Tickets and inductions:** expiry dates are tracked. Expiring tickets are flagged 45 days out and before any booked job. Site-specific inductions are logged against the job.
- **Hazard controls:** standard controls attached to each hazard type (old floor removal, occupied sites, vulnerable occupants, sanding, epoxy, grinding, heat welding, after-hours work, stairs, heavy rolls).
- **Stop-work and incidents:** one tap to raise a hazard or incident, which alerts the office and the foreman with photos and location.
- **Records:** who was on site, when, under which SWMS version, kept with the job.

Open question: which SWMS templates and formats Elliot's builders require, and who in the business is the approved signatory.

## Field app and communications

Installers get a phone app that answers "where am I going, what am I doing, and what do I need to know" without a call to Elliot.

**For installers and foremen**

- **My day:** today's job, leave-by time from home, directions, who's on the crew, the next task, and what's changed since yesterday.
- **Brief, guidance and SWMS** for the job, with SWMS sign-on.
- **Job chat:** one channel per job, with task threads, replies, problem flags and @-mentions.
- **Voice notes and photos:** recorded in the app, transcribed and filed to the job; usable for progress updates, problems and variations.
- **Tasks and checklists:** tick tasks off, add photos as evidence, complete handover checklists.
- **Leave requests and their own tickets.**
- **Works offline:** saves on the phone and syncs when signal returns, since rural sites often have none.

**Communication rules**

- Real notifications (push, with SMS as a fallback) for things that need action: schedule changes, @-mentions, approvals. A quiet digest for the rest.
- Builders and clients reply by email or SMS link; their replies land in the job stream without needing an account.
- Fewer calls by design: the office and the agent answer "where, when, who" through the app, so the phone is kept for real exceptions.
- Every message carries its job, so nothing gets lost in a personal inbox or text thread.

## Integrations and data

Trade Brain connects to the tools the business already uses rather than replacing them, starting with the ones that cause most of the phone calls and emails.

| Integration | Why | When |
| --- | --- | --- |
| Email (Outlook or Google) | A job inbox address; forwarded emails and attachments file to the right job | Phase 1 |
| Phone and SMS | Call logging with notes, SMS updates and replies, an SMS fallback for alerts | Phase 2 |
| Calendar | Crew and office see bookings in their own calendar (only their own jobs) | Phase 2 |
| Accounting (Xero or MYOB) | Job and variation value passed for invoicing; Trade Brain doesn't keep the books | Phase 3 |
| Suppliers | Order confirmations and delivery dates update the materials status | Phase 3 |
| Builders' platforms | Read site readiness and post variations where builders use their own systems | Later, case by case |
| Payroll and leave | Bring in approved leave and hours | Later |

**Data**

- Hosted in Australia. Each business's data is kept separate, and access is checked per job on the server.
- Audio, video and photos are stored with the job. Files are compressed on the phone where possible and kept full size where needed for evidence.
- Full audit log of changes, approvals and agent actions.
- Records kept in line with WHS and contract record requirements (to be confirmed), with a full export per job.
- The business owns its data: export all of it at any time.

## Out of scope

- **Accounting:** invoicing, payments, payroll, detailed job costing and margin reporting stay in the accounting system. Trade Brain holds only the value and status the office needs to plan.
- **Quoting and estimating tools:** quotes are recorded, not built. Reading measurements off plans to help a quote is a later option.
- **Fully automatic changes:** the agent never commits schedule, safety or external communication changes without a person.
- **A full CRM or marketing.**
- **Other trades' scheduling:** Trade Brain tracks dependencies on other trades but doesn't schedule them.

## Phased roadmap

Scheduling ships first because it's what is costing Elliot most. Each later phase starts only when the one before has met its gate in real use.

&#91;embedded content: roadmap · 4 phases, each with a gate\]

Phase lengths will be set after the discovery workshops; the gates are the commitments, not the dates.

Every feature, from the prototype and new, with the phase it lands in: Feature coverage

## Technical approach and feasibility

Everything in this brief can be built with tools available today. Most of it is standard software. Three areas need extra care: the scheduling solver, reading site plans, and logging phone calls.

**How it fits together**

- **One app for office and field:** one web app built in Lovable on Supabase (Sydney region), wrapped with Capacitor as an iPhone and Android app.
- **A database that enforces access per job on the server,** so an installer's phone never receives another crew's jobs or any pricing.
- **A scheduling engine of tested scheduling rules**, written in TypeScript, with a dedicated solver service added only if Phase 2's re-planning needs it. It applies every rule, finds slots, builds plans and works out the knock-on effects of a change. It gives the same answer every time and can say why.
- **Claude, through the API, as the agent's reasoning layer:** it reads emails, transcripts, photos and plans, turns them into job updates and solver inputs, explains the solver's options in plain English, and drafts briefs, SWMS, variations and messages.
- **Supporting services:** speech-to-text for voice notes and site walks, maps routing for drive times, push and SMS for alerts, and a job email address that files what it receives.

The key design choice: Claude doesn't do the scheduling maths. The rules engine does that, and Claude handles the language, documents and judgement around it. Splitting it this way keeps the schedule reliable and the agent's suggestions explainable.

**What's easy and what's hard**

| Capability | Can it be built? | Difficulty | Watch out for |
| --- | --- | --- | --- |
| Board, overview, drag and drop, leave, per-job access | Yes | Standard | Mostly design work; the prototype already proves it |
| Find a slot, suggest a plan, re-planning on change | Yes | The hardest core piece | Phase 1 uses the prototype's proven rules, which suit a crew of about 30; live re-planning in Phase 2 may need a hosted solver service. Elliot's rules must be captured fully |
| Split crews and part days | Yes | Medium | Touches every rule; design the data for it from day one |
| Agent alerts with options | Yes | Medium | Only as good as the rules and how current the job data is |
| Email intake and summaries | Yes | Standard | A person confirms before anything reaches the schedule |
| Voice notes and transcription | Yes | Standard | Site noise and trade terms cause errors; keep the audio with the transcript |
| Video site walks | Yes | Medium | Large files: upload on Wi-Fi; Claude reads the transcript and sampled frames |
| SWMS, briefs and checklists | Yes | Standard | Drafted from approved templates; the business stays legally responsible and a competent person signs |
| Variations by link to PMs | Yes | Standard | None significant |
| Offline field app | Yes | Medium to hard | Changes made offline by two people need careful merging |
| Reading site plans and drawings | Partly | Hard | Good at rooms, labels, notes and rough areas; not reliable for measured quantities, so a person checks every figure |
| Call logging | Partly | Depends on the phone system | Simple with a business VoIP system, hard from personal mobiles. Recording calls has consent rules in NSW and Victoria, so get advice first; quick voice notes after a call are the safe start |
| Builders' own platforms | Depends | Varies | Only where the platform allows outside access |
| Learning from history | Yes, gradually | Medium | Needs months of real jobs; starts as simple averages |

**What it takes**

- The prototype is not the base. It runs as a single page inside Claude. Trade Brain needs its own codebase, logins, hosting and phone app. The prototype's rules, fit checks, priority formula and screens carry across as the specification.
- Ged builds Phase 1 in Lovable without a developer, following the Phase 1 build spec. Its safeguards are the access checks and the rules test page built into the app. An outside security review is worth paying for before a second business joins.
- Running costs (hosting, AI usage, transcription, SMS, maps) scale with use and are priced in Phase 0.

Build document for Lovable: Trade Brain — Phase 1 build spec (Lovable)

## From user zero to other businesses

Elliot's business is user zero. Trade Brain is built around his work first, and is offered to other businesses only once it has met his gates and the success measures have held.

**Why Elliot first**

- Real jobs, a real crew of around 30, and daily use from day one.
- A problem that is clear and measurable: two hours at 4 am and 80 calls a day.
- Honest, fast feedback from someone who knows the trade and the region.

**Built as SaaS from the start**

Only Elliot is onboarded at first, but nothing should need rebuilding to add a second business.

- Each business's data is kept separate from Phase 1.
- Trade-specific lists are settings, not code: skills, tickets, hazards and their controls, leave types, job types, checklists and SWMS templates.
- Nothing about Elliot's business is hard-coded, including his depot, builders and pricing.
- The access model (owner, office, foreman, installer, subcontractor, builder, client) works for any trade that sends crews to sites.

**The path out**

1. **Prove it with Elliot** through Phases 1 and 2, measured against his baseline.
2. **Test with three to five similar businesses** in nearby trades and regions (for example flooring, tiling, painting, plastering, joinery): interviews first, then trials in a demo workspace and then their own.
3. **Go ahead only if** they would pay for it, can set it up in about a day, and see results like Elliot's.
4. **SaaS launch:** self-serve sign-up, billing, onboarding and support, as set out in the SaaS model below.

**To agree with Elliot before the build starts**

- Who owns the software and its intellectual property, and what Elliot gets as the design partner (for example free use, a discount or a share).
- That his business data stays his and is never visible to another business.
- Whether his business can be named as a case study.
- A short written agreement covering these points, checked by a lawyer.

## SaaS model

Trade Brain is one cloud service that many trade businesses subscribe to, each in its own private workspace. Elliot's business is the first workspace. The plan below separates what Phase 1 needs from what must exist before a second business signs up.

**What SaaS means for the build**

| Area | In Phase 1, for Elliot | Before the second business signs up |
| --- | --- | --- |
| Workspaces | Each business is a separate workspace; access checked per business and per job on the server | Isolation tested and an external security review |
| Configuration | Skills, tickets, hazards, leave types, job types, depots and holidays are workspace settings | Starter templates per trade (flooring, tiling, painting and so on) |
| Accounts and roles | Owner, office, foreman, installer, subcontractor, builder, client; two-factor sign-in for office users | Self-serve invites; single sign-on for larger customers |
| Onboarding | Crew and jobs loaded by the team | Sign-up, a setup wizard, import from spreadsheets, a demo workspace |
| Billing | None while Elliot is design partner | Subscriptions, plans, trials and invoices |
| AI usage | Measured per workspace | An allowance in each plan, with fair-use limits |
| Support and reliability | A direct line to the team | Help centre, in-app support, status page and an uptime target |
| Releases | Continuous, to one customer | Feature flags, release notes and staged rollouts |
| Data and compliance | Hosted in Australia, backups, audit log, full export | Terms, privacy policy, a Privacy Act (APP) review and data processing terms |
| Integrations | Job email address | Public API; accounting and calendar connectors set up in the app |

**Pricing options to test (not decided)**

| Model | How it works | Suits | Watch out for |
| --- | --- | --- | --- |
| Per business, by crew size | One monthly fee set by the number of field staff | Owners who want one predictable bill | Size bands must feel fair at the edges |
| Per office user, field users included | Pay for schedulers and admin; installers free or nominal | Getting 30 installers on without a big bill | Revenue depends on office headcount |
| Per active field user | Pay for each person scheduled that month | Seasonal crews | Owners may leave casuals off to save money, which breaks the schedule |

Many tools charge per user ([Fergus does](https://fergus.com/llm-info/)). Trade Brain only works if every installer and subcontractor is in it, so pricing should never make leaving someone out the cheaper choice. SMS, extra transcription and the builder portal could be add-ons.

**What to prove with Elliot before launch**

- **Cost to serve** per workspace per month (hosting, Claude usage, transcription, maps, SMS), measured through Phases 1 and 2 and kept well below the planned price.
- **Setup time** for a new business, aiming for about a day.
- **Daily use** by the scheduler and the crew, the best early sign that customers will stay.

## Where Trade Brain fits among existing tools

Trade Brain can't win on “scheduling with AI” alone, because the big job-management tools now have AI too. It can be different by going deep where they are thin: crews working to builders' programmes, where the schedule keeps changing.

**What the market already offers (October 2026)**

| Tool | Built around | AI and scheduling today |
| --- | --- | --- |
| [ServiceM8](https://www.usecarly.com/blog/servicem8-ai/) | Small service businesses and job cards | Writing helper, quoting assistant, auto-invoice and an AI phone receptionist; each is started by a person. Also offers a connection that lets Claude or ChatGPT work in a ServiceM8 account |
| [Fergus](https://fergus.com/llm-info/) | Trade businesses from sole traders to 30+ staff | AI assistant in the office and in the field (voice), a visual schedule board, and a confirmation step before anything changes |
| [Simpro and AroFlo](https://www.simprogroup.com/company/press/simpro-group-unveils-lightning) (Simpro Group) | Larger service and project contractors | Lightning AI platform, launched May 2026: pre-dispatch briefings, voice-to-notes and job summaries, with more than 20 agents on its roadmap. An [AI scheduler](https://www.usecarly.com/blog/simpro-ai/) that matches technicians by location, skills, certifications and availability has been rolling out since July 2026 |
| [RFMS (Cyncly Flooring Go)](https://www.cyncly.com/products/cyncly-flooring-suite/flooring-go) | Flooring retailers, as a business system | Installation crew scheduling tied to orders and stock, with work orders sent to crews' phones |

**Where Trade Brain is different**

1. **Built for crews on other people's programmes.** Multi-day jobs for crews of two to six, waiting on a builder's handover, a slab test, a delivery or an access window. Dependencies are part of every schedule check, not a note on the job.
2. **The whole pipeline re-plans, not one job.** A change is traced across every job it touches, and Elliot gets options with their trade-offs, respecting locks and hard deadlines.
3. **From first conversation to builder sign-off.** Site walk audio and video, plans, SWMS, and variations approved by the builder's PM from a link. Most tools leave the subcontractor-to-builder loop to email.
4. **Schedule first, finance light.** It works alongside the accounting system rather than trying to replace it.
5. **Need-to-know by design.** Installers and subcontractors see only their own jobs and never any pricing.
6. **Shaped by a working operator's rules,** including tickets, hazards and NSW and Victorian rules on the border.

**Honest limits**

- Any single feature can be copied, and the incumbents are moving fast. A lasting edge would come from depth in one niche (finishing trades subcontracting to builders), a library of trade rules and templates, real job-duration data, and builders' PMs getting used to approving through it.
- Selling is harder than building. Incumbents already have customers, accountants and integrations.
- One real option is to build Trade Brain as a scheduling brain on top of a business's existing job system, through its API, instead of replacing it. Decide this in Phase 0.

**How to test it:** ask Elliot and five similar businesses why they still schedule on a whiteboard when these tools exist. If the answer is “they don't handle crews, builders and constant change”, that is the gap. If it's “never got around to it”, the gap is smaller than it looks.

## Success measures

The numbers below are for Elliot's business and are measured against a two-week baseline taken before go-live. The targets are first guesses to agree with Elliot.

| Measure | Today | Target after 3 months |
| --- | --- | --- |
| Time spent on daily scheduling | About 2 hours from 4 am | Under 30 minutes, reviewing a draft |
| Phone calls per day | About 80 | Halved |
| Variation approval time (raised to approved) | To be measured | Under 2 working days |
| Changes logged in Trade Brain rather than only by phone | None | 90% |
| Double bookings or ticket clashes reaching site | To be measured | Zero |
| Installers who start each day from the app, not a call | None | 90% |
| Agent suggestions accepted as offered or lightly edited | Not applicable | 70% |

The real test is Elliot's own answer to: can someone else run tomorrow's schedule if he's away?

## Risks and open questions

**Risks**

| Risk | What we do about it |
| --- | --- |
| Elliot doesn't trust the agent's plan and goes back to the whiteboard | Start with suggestions he edits, show the reasons behind every suggestion, and let him lock anything; measure how many he accepts |
| Installers won't use another app | One screen for "my day", voice-first, works offline; the app replaces calls they'd otherwise have to make |
| The rules are incomplete, so suggestions are wrong | Capture Elliot's rules in workshops before build; every override he makes is a prompt to add a rule |
| Builders won't use another portal | No login for PMs: approve from an email or SMS link |
| A privacy slip shows one contractor's work to another | Access enforced on the server per job, with tests for every role; the prototype's client-side picker is not used in the real build |
| Data from calls and emails is messy | The agent drafts and a person confirms; nothing goes onto the schedule from an email without review |

**Open questions for Elliot**

- [ ] Which builders and PMs are involved most often, and how do they want variations sent?
- [ ] How many subcontractors are used, and are any regular enough to treat like crew?
- [ ] Who besides Elliot should be able to change the schedule (an operations coordinator, foremen)?
- [ ] What rules does he apply in his head that aren't written down (who works well together, which builders always run late)?
- [ ] Which phone system and email does the office use?
- [ ] Which SWMS templates and checklists are in use now?
- [ ] Has the ownership and design-partner agreement been settled with Elliot (see From user zero to other businesses)?

## What the prototype already shows

The Floorzy prototype, built on 9 October 2026 with example data (30 installers, 19 jobs, 8 leave records), shows most of the scheduling engine and job file working. It's a reference for the real build, not something to scale up. The Feature coverage tab maps every prototype feature to a phase.

| Area | In the prototype | Needed for Trade Brain |
| --- | --- | --- |
| Master board and overview | Week to quarter and custom ranges, capacity, timeline, skills demand, priority mix | Locks, what-if copies, split crews, part days, subcontractors |
| Rule-checked drag and drop | Fit colours from skills, tickets, availability, leave, due date, drive time; undo | Dependencies on other trades and approvals, access windows |
| Find a slot, Suggest a plan | Working | The agent re-planning live when something changes |
| Priorities | P1 to P4 from importance × urgency, due-date escalation | No change |
| Leave and availability | Requests, approvals, closures, forward availability by role and skill | Public holidays, payroll link |
| Job file | Overview, chat with task threads, inspection, guidance, safety, travel | First-contact intake from email and calls, plans and video, variations workflow |
| Voice notes | Recorded and replayed; text summarised by Claude | Transcription, video, offline capture |
| AI documents | Inspection summary and install guidance | SWMS, briefs, checklists, variations, the 4 am draft schedule |
| Privacy | Pricing held in an office-only store | Per-job access for installers and subcontractors, enforced with real logins |
| Sharing | claude.ai accounts; outside users read-only | Its own logins, phone app, SMS and push |

The biggest gap between the two is access: in Trade Brain, people only ever receive the jobs they're on. The second is the agent acting on change as it arrives, rather than on request.
