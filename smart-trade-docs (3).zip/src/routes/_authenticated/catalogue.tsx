import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Plus } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PagePlaceholder } from "@/components/PagePlaceholder";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { ItemForm, type ItemDraft } from "@/components/catalogue/ItemForm";
import { catalogueQuery, pricesQuery, suppliersQuery, type CatalogueItem, type Supplier } from "@/lib/catalogue";
import { isFinanceQuery } from "@/lib/crew";
import { CATEGORIES, CATEGORY_LABEL } from "@/lib/rules/materials";

const desc = "Your products and suppliers: search, filters, links, lead times and (finance) price history.";

export const Route = createFileRoute("/_authenticated/catalogue")({
  head: () => ({
    meta: [
      { title: "Catalogue — Trade Brain" },
      { name: "description", content: desc },
      { property: "og:title", content: "Catalogue — Trade Brain" },
      { property: "og:description", content: desc },
    ],
  }),
  component: Page,
});

const sel = "h-10 rounded-md border bg-background px-2 text-sm";

function Page() {
  const { membership } = Route.useRouteContext();
  const ws = membership.workspaceId;
  return (
    <PagePlaceholder title="Catalogue" description={desc}>
      <Tabs defaultValue="items" className="mt-4">
        <TabsList><TabsTrigger value="items">Items</TabsTrigger><TabsTrigger value="suppliers">Suppliers</TabsTrigger></TabsList>
        <TabsContent value="items"><Items ws={ws} /></TabsContent>
        <TabsContent value="suppliers"><Suppliers ws={ws} /></TabsContent>
      </Tabs>
    </PagePlaceholder>
  );
}

function Items({ ws }: { ws: string }) {
  const qc = useQueryClient();
  const items = useQuery(catalogueQuery(ws));
  const sups = useQuery(suppliersQuery(ws));
  const [q, setQ] = useState("");
  const [f, setF] = useState({ category: "", supplier: "", stock: "", active: "active" });
  const [open, setOpen] = useState<CatalogueItem | null>(null);
  const [adding, setAdding] = useState(false);
  const supName = useMemo(() => new Map((sups.data ?? []).map((s) => [s.id, s.name])), [sups.data]);
  const list = (items.data ?? []).filter((i) => {
    const t = q.trim().toLowerCase();
    if (t && ![i.name, i.brand, i.range, i.colour, i.supplier_code, supName.get(i.supplier_id ?? "")].some((x) => x?.toLowerCase().includes(t))) return false;
    if (f.category && i.category !== f.category) return false;
    if (f.supplier && i.supplier_id !== f.supplier) return false;
    if (f.stock === "stocked" && !i.stocked) return false;
    if (f.stock === "order" && i.stocked) return false;
    if (f.active === "active" && !i.active) return false;
    if (f.active === "inactive" && i.active) return false;
    return true;
  });
  const saved = () => { qc.invalidateQueries({ queryKey: ["catalogue_items", ws] }); setAdding(false); setOpen(null); };

  return (
    <div className="space-y-3 pt-3">
      <div className="flex flex-wrap gap-2">
        <Input className="min-w-56 flex-1" placeholder="Search name, brand, colour, code" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search catalogue" />
        <select aria-label="Category" className={sel} value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>
          <option value="">All categories</option>{CATEGORIES.map((c) => <option key={c} value={c}>{CATEGORY_LABEL[c]}</option>)}
        </select>
        <select aria-label="Supplier" className={sel} value={f.supplier} onChange={(e) => setF({ ...f, supplier: e.target.value })}>
          <option value="">All suppliers</option>{(sups.data ?? []).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
        <select aria-label="Stocked or order in" className={sel} value={f.stock} onChange={(e) => setF({ ...f, stock: e.target.value })}>
          <option value="">Stocked and order in</option><option value="stocked">Stocked</option><option value="order">Order in</option>
        </select>
        <select aria-label="Active" className={sel} value={f.active} onChange={(e) => setF({ ...f, active: e.target.value })}>
          <option value="active">Active</option><option value="inactive">Inactive</option><option value="">All</option>
        </select>
        <Button onClick={() => setAdding(true)}><Plus className="h-4 w-4" /> Add item</Button>
      </div>
      <ul className="divide-y rounded-md border bg-card">
        {list.map((i) => (
          <li key={i.id}>
            <button className="flex w-full flex-wrap items-baseline justify-between gap-2 px-3 py-2 text-left text-sm hover:bg-muted" onClick={() => setOpen(i)}>
              <span><span className="font-medium">{i.name}</span>{i.colour && <span className="text-muted-foreground"> · {i.colour}</span>}{!i.active && <span className="text-muted-foreground"> · inactive</span>}</span>
              <span className="text-xs text-muted-foreground">{CATEGORY_LABEL[i.category as keyof typeof CATEGORY_LABEL] ?? i.category} · {supName.get(i.supplier_id ?? "") ?? "No supplier"} · {i.stocked ? "Stocked" : i.lead_time_days != null ? `Order in, ${i.lead_time_days} working days` : "Order in"}</span>
            </button>
          </li>
        ))}
        {!list.length && <li className="px-3 py-4 text-sm text-muted-foreground">{items.isLoading ? "Loading…" : items.data?.length ? "Nothing matches." : "No items yet. Add one by hand, or from a job's materials."}</li>}
      </ul>
      <Sheet open={adding || !!open} onOpenChange={(o) => { if (!o) { setAdding(false); setOpen(null); } }}>
        <SheetContent className="w-full overflow-y-auto sm:max-w-xl">
          <SheetHeader><SheetTitle>{open ? open.name : "Add item"}</SheetTitle></SheetHeader>
          <div className="mt-4 space-y-6">
            {open && <ItemDetails ws={ws} item={open} supplier={supName.get(open.supplier_id ?? "")} />}
            <ItemForm key={open?.id ?? "new"} ws={ws} item={(open ?? { name: "" }) as ItemDraft} suppliers={sups.data ?? []} onSaved={saved} />
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}

function ItemDetails({ ws, item, supplier }: { ws: string; item: CatalogueItem; supplier: string | undefined }) {
  const { data: finance } = useQuery(isFinanceQuery(ws));
  const links = [["Spec sheet", item.spec_url], ["Installation guide", item.install_url], ["Safety data sheet", item.sds_url], ["Warranty", item.warranty_url]].filter(([, u]) => u) as [string, string][];
  return (
    <div className="space-y-4 text-sm">
      <dl className="grid grid-cols-2 gap-x-4 gap-y-1">
        <dt className="text-muted-foreground">Supplier</dt><dd>{supplier ?? "—"}{item.supplier_code && <span className="font-mono"> · {item.supplier_code}</span>}</dd>
        <dt className="text-muted-foreground">Brand / range</dt><dd>{[item.brand, item.range].filter(Boolean).join(" · ") || "—"}</dd>
        <dt className="text-muted-foreground">Unit</dt><dd>{item.unit}{item.pack_size ? ` · ${item.pack_size}` : ""}</dd>
        <dt className="text-muted-foreground">Coverage</dt><dd>{item.coverage ?? "—"}</dd>
        <dt className="text-muted-foreground">Hazards</dt><dd>{item.hazard_tags.join(", ") || "—"}</dd>
      </dl>
      {links.length > 0 && <div className="flex flex-wrap gap-3">{links.map(([l, u]) => <a key={l} href={u} target="_blank" rel="noreferrer" className="text-primary underline">{l}</a>)}</div>}
      {finance && <PriceHistory itemId={item.id} />}
    </div>
  );
}

/** Finance only: the database refuses price rows to anyone else. Prices are ex GST and never edited, only added. */
function PriceHistory({ itemId }: { itemId: string }) {
  const qc = useQueryClient();
  const { data = [] } = useQuery(pricesQuery(itemId));
  const [p, setP] = useState({ cost: "", sell: "", from: new Date().toISOString().slice(0, 10) });
  const add = async () => {
    if (p.cost === "" && p.sell === "") return;
    const cost = p.cost === "" ? null : Number(p.cost); const sell = p.sell === "" ? null : Number(p.sell);
    const markup = cost && sell ? Math.round(((sell - cost) / cost) * 1000) / 10 : null;
    const { error } = await supabase.from("catalogue_prices").insert({ item_id: itemId, workspace_id: "00000000-0000-0000-0000-000000000000", cost, sell, markup_pct: markup, effective_from: p.from });
    if (error) { toast.error(error.message); return; }
    setP({ ...p, cost: "", sell: "" });
    qc.invalidateQueries({ queryKey: ["catalogue_prices", itemId] });
  };
  return (
    <div className="space-y-2">
      <p className="font-medium">Price history (ex GST)</p>
      <ul className="divide-y rounded-md border">
        {data.map((r) => (
          <li key={r.id} className="flex justify-between px-3 py-1.5">
            <span>From {r.effective_from}{r.import_id ? " · import" : ""}</span>
            <span className="font-mono">cost {r.cost ?? "—"} · sell {r.sell ?? "—"}{r.markup_pct != null ? ` · ${r.markup_pct}%` : ""}</span>
          </li>
        ))}
        {!data.length && <li className="px-3 py-2 text-muted-foreground">No prices yet.</li>}
      </ul>
      <div className="flex flex-wrap gap-2">
        <Input className="w-28" type="number" min={0} step="0.01" placeholder="Cost $" value={p.cost} onChange={(e) => setP({ ...p, cost: e.target.value })} aria-label="Cost" />
        <Input className="w-28" type="number" min={0} step="0.01" placeholder="Sell $" value={p.sell} onChange={(e) => setP({ ...p, sell: e.target.value })} aria-label="Sell" />
        <Input className="w-40" type="date" value={p.from} onChange={(e) => setP({ ...p, from: e.target.value })} aria-label="Effective from" />
        <Button variant="outline" onClick={add}>Add price</Button>
      </div>
    </div>
  );
}

function Suppliers({ ws }: { ws: string }) {
  const qc = useQueryClient();
  const { data = [] } = useQuery(suppliersQuery(ws));
  const blank = { name: "", account_no: "", rep_name: "", rep_phone: "", rep_email: "", orders_email: "", lead_time_days: "", notes: "" };
  const [edit, setEdit] = useState<(typeof blank & { id?: string }) | null>(null);
  const save = async () => {
    if (!edit?.name.trim()) { toast.error("Give the supplier a name"); return; }
    const row = { workspace_id: ws, name: edit.name.trim(), account_no: edit.account_no || null, rep_name: edit.rep_name || null, rep_phone: edit.rep_phone || null,
      rep_email: edit.rep_email || null, orders_email: edit.orders_email || null, lead_time_days: edit.lead_time_days === "" ? null : Number(edit.lead_time_days), notes: edit.notes || null };
    const { error } = edit.id ? await supabase.from("suppliers").update(row).eq("id", edit.id) : await supabase.from("suppliers").insert(row);
    if (error) { toast.error(error.message); return; }
    setEdit(null); qc.invalidateQueries({ queryKey: ["suppliers", ws] });
  };
  const open = (s: Supplier) => setEdit({ id: s.id, name: s.name, account_no: s.account_no ?? "", rep_name: s.rep_name ?? "", rep_phone: s.rep_phone ?? "",
    rep_email: s.rep_email ?? "", orders_email: s.orders_email ?? "", lead_time_days: s.lead_time_days == null ? "" : String(s.lead_time_days), notes: s.notes ?? "" });
  const F = (k: keyof typeof blank, label: string, type = "text") => (
    <label className="grid gap-1 text-sm">{label}<Input type={type} value={edit![k]} onChange={(e) => setEdit({ ...edit!, [k]: e.target.value })} /></label>
  );
  return (
    <div className="space-y-3 pt-3">
      <div className="flex justify-end"><Button onClick={() => setEdit(blank)}><Plus className="h-4 w-4" /> Add supplier</Button></div>
      <ul className="divide-y rounded-md border bg-card">
        {data.map((s) => (
          <li key={s.id}><button className="flex w-full flex-wrap justify-between gap-2 px-3 py-2 text-left text-sm hover:bg-muted" onClick={() => open(s)}>
            <span className="font-medium">{s.name}</span>
            <span className="text-xs text-muted-foreground">{[s.rep_name, s.orders_email, s.lead_time_days != null ? `${s.lead_time_days} working days` : null].filter(Boolean).join(" · ")}</span>
          </button></li>
        ))}
        {!data.length && <li className="px-3 py-4 text-sm text-muted-foreground">No suppliers yet.</li>}
      </ul>
      <Sheet open={!!edit} onOpenChange={(o) => !o && setEdit(null)}>
        <SheetContent className="w-full overflow-y-auto sm:max-w-lg">
          <SheetHeader><SheetTitle>{edit?.id ? edit.name : "Add supplier"}</SheetTitle></SheetHeader>
          {edit && (
            <div className="mt-4 grid gap-3">
              {F("name", "Name")}{F("account_no", "Account number")}{F("rep_name", "Rep name")}{F("rep_phone", "Rep phone", "tel")}
              {F("rep_email", "Rep email", "email")}{F("orders_email", "Ordering email", "email")}{F("lead_time_days", "Usual lead time (working days)", "number")}{F("notes", "Notes")}
              <div className="flex justify-end"><Button onClick={save}>Save supplier</Button></div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
