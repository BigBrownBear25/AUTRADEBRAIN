import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useMemo, useState } from "react";
import { Plus, Search } from "lucide-react";
import { PagePlaceholder } from "@/components/PagePlaceholder";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { JobCard } from "@/components/jobs/JobCard";
import { JobSheet } from "@/components/jobs/JobSheet";
import { jobsQuery, type JobListItem, type JobStatus } from "@/lib/jobs";
import { comparePriority } from "@/lib/rules/priority";
import { todayIso } from "@/lib/rules/ticket-expiry";

const desc = "Every job in the workspace, with filters, priority sorting and search.";

export const Route = createFileRoute("/_authenticated/jobs")({
  head: () => ({
    meta: [
      { title: "Jobs — Trade Brain" },
      { name: "description", content: desc },
      { property: "og:title", content: "Jobs — Trade Brain" },
      { property: "og:description", content: desc },
    ],
  }),
  validateSearch: (s: Record<string, unknown>): { job?: string; proposal?: string } => ({
    ...(typeof s["job"] === "string" ? { job: s["job"] } : {}),
    ...(typeof s["proposal"] === "string" ? { proposal: s["proposal"] } : {}),
  }),
  component: Page,
});

const FILTERS: { key: string; label: string; statuses?: JobStatus[] }[] = [
  { key: "to-schedule", label: "To schedule", statuses: ["ready"] },
  { key: "scheduled", label: "Scheduled", statuses: ["scheduled", "on site"] },
  { key: "quoted", label: "Quoted", statuses: ["enquiry", "quoted"] },
  { key: "complete", label: "Complete", statuses: ["complete", "closed"] },
  { key: "all", label: "All" },
];

function Page() {
  const { membership } = Route.useRouteContext();
  const { data: jobs = [], isLoading } = useQuery(jobsQuery(membership.workspaceId));
  const [filter, setFilter] = useState("to-schedule");
  const [sort, setSort] = useState<"priority" | "date">("priority");
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<JobListItem | null>(null);

  const counts = useMemo(() => Object.fromEntries(FILTERS.map((f) => [f.key, f.statuses ? jobs.filter((j) => f.statuses!.includes(j.status)).length : jobs.length])), [jobs]);

  const shown = useMemo(() => {
    const f = FILTERS.find((x) => x.key === filter)!;
    const needle = q.trim().toLowerCase();
    const list = jobs.filter((j) =>
      (!f.statuses || f.statuses.includes(j.status)) &&
      (!needle || [j.code, j.name, j.suburb, j.client_name, j.builder_company, j.flooring, j.address].some((v) => v?.toLowerCase().includes(needle))),
    );
    const today = todayIso();
    const d = (x: string | null) => x ?? "9999-12-31";
    return [...list].sort(sort === "priority" ? comparePriority(today) : (a, b) => d(a.start_date).localeCompare(d(b.start_date)) || d(a.due_by).localeCompare(d(b.due_by)));
  }, [jobs, filter, q, sort]);

  const openFor = (j: JobListItem | null) => { setEditing(j); setOpen(true); };
  const { job: jobParam, proposal: proposalParam } = Route.useSearch();
  const navigate = useNavigate();
  const [prefill, setPrefill] = useState<Record<string, unknown> | null>(null);
  // Edit on a non-scheduling Brain proposal: open the job form with the proposed values filled in.
  useEffect(() => {
    if (!proposalParam) { setPrefill(null); return; }
    void supabase.from("proposals").select("kind, job_id, payload").eq("id", proposalParam).maybeSingle().then(({ data }) => {
      if (!data) return;
      const pl = (data.payload ?? {}) as Record<string, unknown>;
      setPrefill(data.kind === "update_job" ? ((pl["fields"] ?? {}) as Record<string, unknown>) : pl);
      if (!data.job_id) { setEditing(null); setOpen(true); }
    });
  }, [proposalParam]);
  useEffect(() => {
    if (!jobParam || isLoading) return;
    const j = jobs.find((x) => x.id === jobParam);
    if (j) openFor(j);
    else { toast.error("That job isn't available to you."); void navigate({ to: "/" }); }
  }, [jobParam, jobs, isLoading]);

  return (
    <PagePlaceholder title="Jobs" description={desc}>
      <div className="mt-6 flex flex-col gap-3 lg:flex-row lg:items-center">
        <div className="flex flex-wrap gap-1 rounded-md border bg-card p-1">
          {FILTERS.map((f) => (
            <button key={f.key} onClick={() => setFilter(f.key)}
              className={`min-h-10 rounded-sm px-3 font-heading text-sm font-medium uppercase tracking-wide ${filter === f.key ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted"}`}>
              {f.label} <span className="ml-1 font-mono text-xs opacity-75">{counts[f.key]}</span>
            </button>
          ))}
        </div>
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search code, name, suburb, client, builder" className="h-11 pl-9" />
        </div>
        <select value={sort} onChange={(e) => setSort(e.target.value as "priority" | "date")} className="h-11 rounded-md border bg-background px-3 text-sm" aria-label="Sort">
          <option value="priority">Sort by priority</option>
          <option value="date">Sort by date</option>
        </select>
        <Button className="h-11" onClick={() => openFor(null)}><Plus className="h-4 w-4" /> New job</Button>
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {isLoading && <p className="text-sm text-muted-foreground">Loading jobs…</p>}
        {!isLoading && shown.length === 0 && (
          <div className="chalk-grid col-span-full grid min-h-48 place-items-center rounded-md border bg-card p-6 text-center text-muted-foreground">
            {jobs.length === 0 ? "No jobs yet. Add your first job." : "No jobs match."}
          </div>
        )}
        {shown.map((j) => <JobCard key={j.id} job={j} onOpen={() => openFor(j)} />)}
      </div>

      <JobSheet workspaceId={membership.workspaceId} job={editing} open={open} onOpenChange={(o) => { setOpen(o); if (!o) setPrefill(null); }} prefill={prefill} />
    </PagePlaceholder>
  );
}
