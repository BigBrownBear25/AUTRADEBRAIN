import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Plus } from "lucide-react";
import { LeavePanel } from "@/components/leave/LeavePanel";
import { PagePlaceholder } from "@/components/PagePlaceholder";
import { Button } from "@/components/ui/button";
import { TicketChip } from "@/components/crew/TicketChip";
import { PersonSheet } from "@/components/crew/PersonSheet";
import { crewQuery, crewRoleLabel, type CrewWithTickets } from "@/lib/crew";

const desc = "People, skills and tickets, plus leave requests, closures and forward availability.";

export const Route = createFileRoute("/_authenticated/crew")({
  head: () => ({
    meta: [
      { title: "Crew — Trade Brain" },
      { name: "description", content: desc },
      { property: "og:title", content: "Crew — Trade Brain" },
      { property: "og:description", content: desc },
    ],
  }),
  component: Page,
});

function Page() {
  const { membership } = Route.useRouteContext();
  const { data: crew = [], isLoading } = useQuery(crewQuery(membership.workspaceId));
  const [editing, setEditing] = useState<CrewWithTickets | null>(null);
  const [open, setOpen] = useState(false);
  const openFor = (p: CrewWithTickets | null) => { setEditing(p); setOpen(true); };

  return (
    <PagePlaceholder title="Crew" description={desc}>
      <div className="mt-6 flex items-center justify-between">
        <h2 className="text-xl font-semibold uppercase">People</h2>
        <Button className="h-11" onClick={() => openFor(null)}><Plus className="h-4 w-4" /> Add person</Button>
      </div>

      <div className="mt-3 overflow-x-auto rounded-md border bg-card">
        <table className="w-full min-w-[820px] text-sm">
          <thead className="border-b bg-muted/50 text-left font-heading uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-3 py-2">Name</th><th className="px-3 py-2">Role</th><th className="px-3 py-2">Base</th>
              <th className="px-3 py-2">Skills</th><th className="px-3 py-2">Tickets</th><th className="px-3 py-2">Bookings</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {isLoading && <tr><td colSpan={6} className="px-3 py-6 text-muted-foreground">Loading…</td></tr>}
            {!isLoading && crew.length === 0 && (
              <tr><td colSpan={6} className="px-3 py-6 text-muted-foreground">No people yet. Add your first crew member.</td></tr>
            )}
            {crew.map((p) => (
              <tr key={p.id} onClick={() => openFor(p)} className={`cursor-pointer hover:bg-muted/40 ${p.active ? "" : "opacity-50"}`}>
                <td className="px-3 py-2 font-medium">
                  {p.name}
                  {p.is_subcontractor && <span className="block text-xs text-muted-foreground">Sub · {p.company_name ?? "—"}</span>}
                </td>
                <td className="px-3 py-2">{crewRoleLabel[p.role]}</td>
                <td className="px-3 py-2">{p.base_suburb ?? "—"}</td>
                <td className="px-3 py-2 text-xs text-muted-foreground">{(p.skills ?? []).join(", ") || "—"}</td>
                <td className="px-3 py-2">
                  <div className="flex flex-wrap gap-1">
                    {p.crew_tickets.length === 0 ? "—" : p.crew_tickets.map((t) => <TicketChip key={t.id} type={t.ticket_type} expiresOn={t.expires_on} />)}
                  </div>
                </td>
                <td className="px-3 py-2 text-muted-foreground">—</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">Tickets: green current, amber expires within 45 days, red expired. Bookings fill in once assignments are built.</p>

      <section className="mt-10">
        <h2 className="text-xl font-semibold uppercase">Leave &amp; availability</h2>
        <div className="mt-3"><LeavePanel workspaceId={membership.workspaceId} /></div>
      </section>

      <PersonSheet workspaceId={membership.workspaceId} person={editing} open={open} onOpenChange={setOpen} />
    </PagePlaceholder>
  );
}
