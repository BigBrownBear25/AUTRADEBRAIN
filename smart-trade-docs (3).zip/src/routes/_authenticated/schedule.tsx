import { createFileRoute, getRouteApi } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { ScheduleBoard } from "@/components/schedule/ScheduleBoard";
import { JobSheet } from "@/components/jobs/JobSheet";
import type { Job } from "@/lib/jobs";

const desc = "Crew in rows, working days in columns, with every booking, closure and double-booking.";
const auth = getRouteApi("/_authenticated");

export const Route = createFileRoute("/_authenticated/schedule")({
  head: () => ({
    meta: [
      { title: "Schedule — Trade Brain" },
      { name: "description", content: desc },
      { property: "og:title", content: "Schedule — Trade Brain" },
      { property: "og:description", content: desc },
    ],
  }),
  validateSearch: (s: Record<string, unknown>): { place?: string; proposal?: string } => ({
    ...(typeof s["place"] === "string" ? { place: s["place"] } : {}),
    ...(typeof s["proposal"] === "string" ? { proposal: s["proposal"] } : {}),
  }),
  component: Page,
});

function Page() {
  const { membership } = auth.useRouteContext();
  const { place, proposal } = Route.useSearch();
  const [job, setJob] = useState<Job | null>(null);
  const [open, setOpen] = useState(false);
  const openJob = async (id: string) => {
    const { data, error } = await supabase.from("jobs").select("*").eq("id", id).single();
    if (error) { toast.error(error.message); return; }
    setJob(data); setOpen(true);
  };
  return (
    <div className="mx-auto max-w-[1600px] px-4 py-6 md:py-8">
      <h1 className="text-3xl font-bold uppercase">Schedule</h1>
      <p className="mb-4 text-sm text-muted-foreground">{desc}</p>
      <ScheduleBoard workspaceId={membership.workspaceId} mode="office" onOpenJob={openJob} initialPlace={place} initialProposal={proposal} />
      <JobSheet workspaceId={membership.workspaceId} job={job} open={open} onOpenChange={setOpen} />
    </div>
  );
}
