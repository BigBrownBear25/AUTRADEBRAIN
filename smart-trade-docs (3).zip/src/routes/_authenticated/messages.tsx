import { createFileRoute, getRouteApi, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { pinBrain, unpinBrain } from "@/lib/brain-pin";
import { AlertTriangle, AtSign } from "lucide-react";
import { JobChat } from "@/components/chat/JobChat";
import { inboxQuery, useMessagesLive, useUserId } from "@/lib/chat";
import { modeForRole } from "@/lib/session";
import { UnfiledEmail } from "@/components/email/UnfiledEmail";

const desc = "Every job chat you can see, unread first, with problems and mentions flagged.";
const auth = getRouteApi("/_authenticated");

export const Route = createFileRoute("/_authenticated/messages")({
  validateSearch: (s: Record<string, unknown>): { job?: string } => (typeof s["job"] === "string" ? { job: s["job"] } : {}),
  head: () => ({
    meta: [
      { title: "Messages — Trade Brain" },
      { name: "description", content: desc },
      { property: "og:title", content: "Messages — Trade Brain" },
      { property: "og:description", content: desc },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Page,
});

function Page() {
  const { membership } = auth.useRouteContext();
  const { job } = Route.useSearch();
  const me = useUserId();
  useMessagesLive(null);
  const { data: inbox = [], isLoading } = useQuery(inboxQuery(me));
  const open = inbox.find((c) => c.jobId === job);
  const office = modeForRole(membership.role) === "office";
  // Job chat pins the Brain bar to that job.
  useEffect(() => {
    if (!open) return undefined;
    pinBrain({ id: open.jobId, code: open.code, name: open.name });
    return () => unpinBrain(open.jobId);
  }, [open?.jobId]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-6">
      <h1 className="font-heading text-3xl font-semibold uppercase tracking-wide">Messages</h1>
      <p className="mb-4 text-sm text-muted-foreground">{desc}</p>
      {office && !job && <UnfiledEmail workspaceId={membership.workspaceId} />}
      <div className="grid gap-4 md:grid-cols-[320px_1fr]">
        <ul className={`divide-y rounded-md border bg-card ${job ? "hidden md:block" : ""}`}>
          {isLoading && <li className="p-3 text-sm text-muted-foreground">Loading…</li>}
          {!isLoading && inbox.length === 0 && <li className="p-3 text-sm text-muted-foreground">No messages on your jobs yet.</li>}
          {inbox.map((c) => (
            <li key={c.jobId}>
              <Link to="/messages" search={{ job: c.jobId }} className={`block p-3 hover:bg-muted/50 ${c.jobId === job ? "bg-muted" : ""}`}>
                <div className="flex items-center gap-2">
                  <span className={`h-3 w-1 rounded-sm ${c.sector === "commercial" ? "bg-commercial" : "bg-domestic"}`} />
                  <span className="font-mono text-xs">{c.code}</span>
                  <span className={`flex-1 truncate text-sm ${c.unread ? "font-semibold" : ""}`}>{c.name}</span>
                  {c.mention && <span title="@ you" className="text-primary"><AtSign className="h-4 w-4" /></span>}
                  {c.problem && <span title="Problem" className="text-clash"><AlertTriangle className="h-4 w-4" /></span>}
                  {c.unread > 0 && <span className="rounded-full bg-primary px-1.5 text-xs text-primary-foreground">{c.unread}</span>}
                </div>
                <p className="mt-1 truncate text-xs text-muted-foreground">
                  {c.last.tasks?.label && <span>#{c.last.tasks.label} · </span>}
                  {c.last.deleted_at ? "Message deleted" : c.last.body || "Attachment"}
                </p>
              </Link>
            </li>
          ))}
        </ul>
        <div className={job ? "" : "hidden md:block"}>
          {job ? (
            <div>
              <div className="mb-2 flex items-center gap-2">
                <Link to="/messages" className="text-sm text-primary md:hidden">← All messages</Link>
                <h2 className="font-heading text-xl font-semibold uppercase">{open ? <><span className="font-mono text-base">{open.code}</span> · {open.name}</> : "Job chat"}</h2>
              </div>
              <JobChat workspaceId={membership.workspaceId} jobId={job} office={office} />
            </div>
          ) : <p className="rounded-md border bg-card p-6 text-sm text-muted-foreground">Pick a job to open its chat.</p>}
        </div>
      </div>
    </div>
  );
}
