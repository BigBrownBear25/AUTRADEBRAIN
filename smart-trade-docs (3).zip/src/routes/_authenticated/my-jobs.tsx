import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { pinBrain, unpinBrain } from "@/lib/brain-pin";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Phone } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PagePlaceholder } from "@/components/PagePlaceholder";
import { Checkbox } from "@/components/ui/checkbox";
import { crewRoleLabel } from "@/lib/crew";
import { crewMatesQuery, hm } from "@/lib/assignments";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { JobChat } from "@/components/chat/JobChat";
import { SafetyTab, TravelTab } from "@/components/jobs/JobFileTabs";
import { InspectionTab, GuidanceTab } from "@/components/jobs/AiTabs";
import { jobChildrenQuery, type Job } from "@/lib/jobs";

const desc = "The jobs you're assigned to, with tasks, safety and crew.";

export const Route = createFileRoute("/_authenticated/my-jobs")({
  head: () => ({
    meta: [
      { title: "My jobs — Trade Brain" },
      { name: "description", content: desc },
      { property: "og:title", content: "My jobs — Trade Brain" },
      { property: "og:description", content: desc },
    ],
  }),
  validateSearch: (s: Record<string, unknown>): { job?: string; tab?: string } => ({
    ...(typeof s["job"] === "string" ? { job: s["job"] } : {}),
    ...(typeof s["tab"] === "string" ? { tab: s["tab"] } : {}),
  }),
  component: Page,
});

/** Row-level security returns only jobs the person holds an assignment on. */
function Page() {
  const { membership } = Route.useRouteContext();
  const { job: openId, tab } = Route.useSearch();
  const { data: jobs = [], isLoading } = useQuery({
    queryKey: ["my-jobs"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("jobs")
        .select("*, assignments(id, date, start_time, end_time, crew_member_id), tasks(id, label, done, sort)")
        .order("start_date", { nullsFirst: false });
      if (error) throw error;
      return data;
    },
  });
  const open = jobs.find((j) => j.id === openId);
  const navigate = useNavigate();
  useEffect(() => {
    if (open) { pinBrain(open); return () => unpinBrain(open.id); } return undefined;
  }, [open?.id]);
  useEffect(() => {
    if (openId && !isLoading && !open) { toast.error("That job isn't available to you."); void navigate({ to: "/" }); }
  }, [openId, isLoading, open]);

  if (openId) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-4">
        <Link to="/my-jobs" className="text-sm text-primary">← My jobs</Link>
        {!open ? <p className="mt-4 text-sm text-muted-foreground">{isLoading ? "Loading…" : "This job isn't on your list any more."}</p> : (
          <>
            <p className="mt-2 font-mono text-sm text-muted-foreground">{open.code}</p>
            <h1 className="font-heading text-2xl font-semibold uppercase">{open.name}</h1>
            <p className="text-sm text-muted-foreground">{[open.address, open.suburb].filter(Boolean).join(", ")}</p>
            <Tabs defaultValue={tab ?? "overview"} className="mt-3">
              <TabsList className="grid h-auto w-full grid-cols-3 sm:grid-cols-6">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="chat">Job chat</TabsTrigger>
                <TabsTrigger value="materials">Materials</TabsTrigger>
                <TabsTrigger value="safety">Safety</TabsTrigger>
                <TabsTrigger value="travel">Travel</TabsTrigger>
                <TabsTrigger value="deps">Depend.</TabsTrigger>
                <TabsTrigger value="inspection">Inspection</TabsTrigger>
                <TabsTrigger value="guidance">Guidance</TabsTrigger>
              </TabsList>
              <TabsContent value="overview"><MyJob job={open} /></TabsContent>
              <TabsContent value="chat"><div className="pt-2"><JobChat workspaceId={membership.workspaceId} jobId={open.id} office={false} /></div></TabsContent>
              <TabsContent value="materials"><FieldMaterials jobId={open.id} foreman={membership.role === "foreman"} /></TabsContent>
              <TabsContent value="safety"><SafetyTab workspaceId={membership.workspaceId} job={open as unknown as Job} /></TabsContent>
              <TabsContent value="travel"><TravelTab workspaceId={membership.workspaceId} job={open as unknown as Job} /></TabsContent>
              <TabsContent value="deps"><FieldDeps jobId={open.id} /></TabsContent>
              <TabsContent value="inspection"><InspectionTab workspaceId={membership.workspaceId} jobId={open.id} canEdit={membership.role === "foreman"} /></TabsContent>
              <TabsContent value="guidance"><GuidanceTab jobId={open.id} canEdit={membership.role === "foreman"} /></TabsContent>
            </Tabs>
          </>
        )}
      </div>
    );
  }

  return (
    <PagePlaceholder title="My jobs" description={isLoading ? "Loading…" : jobs.length ? desc : "You're not booked on any jobs yet."}>
      <ul className="mt-6 space-y-3">
        {jobs.map((j) => {
          const days = j.assignments.map((a) => a.date).sort();
          const done = j.tasks.filter((t) => t.done).length;
          return (
            <li key={j.id}>
              <Link to="/my-jobs" search={{ job: j.id }} className={`block rounded-md border border-l-4 bg-card p-4 hover:bg-muted/40 ${j.sector === "commercial" ? "border-l-commercial" : "border-l-domestic"}`}>
                <p className="font-mono text-xs text-muted-foreground">{j.code}</p>
                <p className="font-heading text-lg font-semibold uppercase">{j.name}</p>
                <p className="text-sm text-muted-foreground">{j.suburb}{days[0] && ` · ${new Date(`${days[0]}T00:00:00`).toLocaleDateString("en-AU", { weekday: "short", day: "numeric", month: "short" })}`}{days.length > 1 && ` + ${days.length - 1} more day${days.length > 2 ? "s" : ""}`}</p>
                <p className="mt-1 text-xs text-muted-foreground">Tasks {done}/{j.tasks.length}</p>
              </Link>
            </li>
          );
        })}
      </ul>
    </PagePlaceholder>
  );
}

function FieldMaterials({ jobId, foreman }: { jobId: string; foreman: boolean }) {
  const qc = useQueryClient();
  const { data } = useQuery(jobChildrenQuery(jobId));
  const mats = data?.materials ?? [];
  const deliver = async (id: string) => {
    const { error } = await supabase.from("materials").update({ status: "delivered" }).eq("id", id);
    if (error) toast.error(error.message); else qc.invalidateQueries({ queryKey: ["job_children", jobId] });
  };
  if (!mats.length) return <p className="pt-4 text-sm text-muted-foreground">No materials listed.</p>;
  return (
    <ul className="mt-2 divide-y rounded-md border bg-card">
      {mats.map((m) => (
        <li key={m.id} className="flex items-center gap-2 px-3 py-2 text-sm">
          <span className="flex-1">{m.item}{m.qty != null && <span className="text-muted-foreground"> · {m.qty} {m.unit}</span>}</span>
          <span className={`rounded-sm px-1.5 text-xs ${m.status === "delivered" ? "bg-fit-soft text-fit" : "bg-muted"}`}>{m.status}</span>
          {foreman && m.status !== "delivered" && <button className="min-h-9 rounded-md border px-2 text-xs" onClick={() => deliver(m.id)}>Mark delivered</button>}
        </li>
      ))}
    </ul>
  );
}

function FieldDeps({ jobId }: { jobId: string }) {
  const { data } = useQuery(jobChildrenQuery(jobId));
  const deps = data?.dependencies ?? [];
  if (!deps.length) return <p className="pt-4 text-sm text-muted-foreground">Nothing this job is waiting on.</p>;
  return (
    <ul className="mt-2 divide-y rounded-md border bg-card">
      {deps.map((d) => (
        <li key={d.id} className="px-3 py-2 text-sm">
          <p>{d.description}{d.blocks_start && <span className="ml-1 text-xs text-clash">blocks start</span>}</p>
          <p className="text-xs text-muted-foreground">{d.kind}{d.party && ` · ${d.party}`}{d.due_date && ` · due ${d.due_date}`} · {d.status}</p>
        </li>
      ))}
    </ul>
  );
}

type J = {
  id: string; code: string; name: string; suburb: string | null; sector: string; safety_notes: string | null; unique_notes: string | null;
  assignments: { id: string; date: string; start_time: string; end_time: string }[];
  tasks: { id: string; label: string; done: boolean; sort: number }[];
};

function MyJob({ job }: { job: J }) {
  const qc = useQueryClient();
  const { data: mates = [] } = useQuery(crewMatesQuery(job.id));
  // Crew mates' leave arrives only as "Away" + date — never the type or note.
  const { data: away = [] } = useQuery({
    queryKey: ["away_days", job.id],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("away_days", { _job_id: job.id });
      if (error) throw error;
      return data ?? [];
    },
  });
  const tick = async (id: string, done: boolean) => {
    const { error } = await supabase.from("tasks").update({ done }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["my-jobs"] });
  };
  const days = [...job.assignments].sort((a, b) => (a.date + a.start_time).localeCompare(b.date + b.start_time));

  return (
    <article className="mt-2 rounded-md border bg-card p-4">
      {job.unique_notes && <p className="mb-3 whitespace-pre-wrap text-sm"><span className="font-semibold">What makes this job different: </span>{job.unique_notes}</p>}

      <div className="mt-3 grid gap-4 md:grid-cols-3">
        <section>
          <h3 className="text-sm font-semibold">Your days</h3>
          <ul className="mt-1 space-y-0.5 text-sm">
            {days.map((a) => (
              <li key={a.id}>{new Date(`${a.date}T00:00:00`).toLocaleDateString("en-AU", { weekday: "short", day: "numeric", month: "short" })} <span className="font-mono text-xs">{hm(a.start_time)}–{hm(a.end_time)}</span></li>
            ))}
          </ul>
        </section>
        <section>
          <h3 className="text-sm font-semibold">Crew on this job</h3>
          <ul className="mt-1 space-y-1 text-sm">
            {mates.map((m) => (
              <li key={m.crew_member_id} className="flex items-center justify-between gap-2">
                <span>{m.name} <span className="text-muted-foreground">· {crewRoleLabel[m.role]}</span>
                  {away.filter((a) => a.crew_member_id === m.crew_member_id).length > 0 && (
                    <span className="ml-1 rounded-sm bg-muted px-1 text-xs">Away {away.filter((a) => a.crew_member_id === m.crew_member_id).map((a) => new Date(`${a.date}T00:00:00`).toLocaleDateString("en-AU", { day: "numeric", month: "short" })).join(", ")}</span>
                  )}
                </span>
                {m.phone && <a href={`tel:${m.phone}`} className="inline-flex min-h-9 items-center gap-1 text-primary"><Phone className="h-4 w-4" />Call</a>}
              </li>
            ))}
          </ul>
        </section>
        <section>
          <h3 className="text-sm font-semibold">Tasks</h3>
          <ul className="mt-1 space-y-1 text-sm">
            {[...job.tasks].sort((a, b) => a.sort - b.sort).map((t) => (
              <li key={t.id}><label className="flex min-h-9 items-center gap-2"><Checkbox checked={t.done} onCheckedChange={(c) => tick(t.id, !!c)} />{t.label}</label></li>
            ))}
          </ul>
        </section>
      </div>
      {job.safety_notes && <p className="mt-3 rounded-sm bg-muted p-2 text-sm"><span className="font-semibold">Safety: </span>{job.safety_notes}</p>}
    </article>
  );
}
