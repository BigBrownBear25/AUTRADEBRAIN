import { createFileRoute, getRouteApi, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ScheduleBoard } from "@/components/schedule/ScheduleBoard";
import { crewQuery } from "@/lib/crew";
import { hm } from "@/lib/assignments";
import { leaveQuery } from "@/lib/leave";
import { addDays } from "@/lib/rules/board";
import { todayIso } from "@/lib/rules/ticket-expiry";

const desc = "Where you're booked over the coming days and weeks.";
const auth = getRouteApi("/_authenticated");

export const Route = createFileRoute("/_authenticated/my-schedule")({
  head: () => ({
    meta: [
      { title: "My schedule — Trade Brain" },
      { name: "description", content: desc },
      { property: "og:title", content: "My schedule — Trade Brain" },
      { property: "og:description", content: desc },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Page,
});

const dmy = (d: string) => new Date(`${d}T00:00:00`).toLocaleDateString("en-AU", { weekday: "short", day: "numeric", month: "short" });

/** Field view: a day list on phones, the board (own row only) on wider screens. */
function Page() {
  const { membership } = auth.useRouteContext();
  const navigate = useNavigate();
  const ws = membership.workspaceId;
  const today = todayIso();
  const { data: crew = [] } = useQuery(crewQuery(ws));
  const me = crew[0];
  const { data: rows = [] } = useQuery({
    queryKey: ["my-schedule-list", me?.id, today],
    enabled: !!me,
    queryFn: async () => {
      const { data, error } = await supabase.from("assignments")
        .select("id, date, start_time, end_time, job_id, jobs(code, name, suburb, sector)")
        .eq("crew_member_id", me!.id).gte("date", today).lte("date", addDays(today, 41)).order("date").order("start_time");
      if (error) throw error;
      return data;
    },
  });
  const { data: leave = [] } = useQuery(leaveQuery(ws));
  const myLeave = leave.filter((l) => l.crew_member_id === me?.id && l.status !== "declined" && l.to_date >= today);
  const dates = [...new Set([...rows.map((r) => r.date)])];

  return (
    <div className="mx-auto max-w-[1600px] px-4 py-6 md:py-8">
      <h1 className="font-heading text-3xl font-semibold uppercase">My schedule</h1>
      <p className="mb-4 text-sm text-muted-foreground">{desc}</p>

      <div className="space-y-3 md:hidden">
        {myLeave.map((l) => (
          <div key={l.id} className={`rounded-md p-3 text-sm hatch-leave ${l.status === "requested" ? "border border-dashed border-muted-foreground" : ""}`}>
            <span className="rounded-sm bg-card px-1 font-medium">{l.type} {l.status === "requested" ? "(requested)" : ""} · {dmy(l.from_date)}{l.to_date !== l.from_date && ` – ${dmy(l.to_date)}`}</span>
          </div>
        ))}
        {!me ? <p className="text-sm text-muted-foreground">Your account isn't linked to a crew record yet.</p>
          : dates.length === 0 ? <p className="rounded-md border bg-card p-4 text-sm text-muted-foreground">Nothing booked in the next six weeks.</p>
          : dates.map((d) => (
            <section key={d} className="rounded-md border bg-card">
              <h2 className={`border-b px-3 py-2 text-sm font-semibold ${d === today ? "text-primary" : ""}`}>{d === today ? "Today · " : ""}{dmy(d)}</h2>
              <ul>
                {rows.filter((r) => r.date === d).map((r) => r.jobs && (
                  <li key={r.id}>
                    <Link to="/my-jobs" search={{ job: r.job_id }} className="flex min-h-12 items-center gap-2 px-3 py-2 text-sm">
                      <span className={`h-6 w-1 rounded-sm ${r.jobs.sector === "commercial" ? "bg-commercial" : "bg-domestic"}`} />
                      <span className="flex-1"><span className="font-mono text-xs">{r.jobs.code}</span> {r.jobs.name}<span className="block text-xs text-muted-foreground">{r.jobs.suburb}</span></span>
                      <span className="font-mono text-xs">{hm(r.start_time)}–{hm(r.end_time)}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </section>
          ))}
      </div>

      <div className="hidden md:block">
        <ScheduleBoard workspaceId={ws} mode="field" onOpenJob={(id) => navigate({ to: "/my-jobs", search: { job: id } })} />
      </div>
    </div>
  );
}
