import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { BookOpen, ClipboardList, ExternalLink, FileText, MessageSquare, ShieldAlert } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { TicketChip } from "@/components/crew/TicketChip";
import { MyLeave } from "@/components/leave/MyLeave";
import { crewQuery, crewRoleLabel } from "@/lib/crew";
import { hm } from "@/lib/assignments";
import { getDriveTimes } from "@/lib/drive-times.functions";
import { leaveBy } from "@/lib/rules/travel";
import { todayIso } from "@/lib/rules/ticket-expiry";
import { StartFinish } from "@/components/field/StartFinish";

const desc = "Today's job, when to leave, directions and your next task.";

export const Route = createFileRoute("/_authenticated/my-day")({
  head: () => ({
    meta: [
      { title: "My day — Trade Brain" },
      { name: "description", content: desc },
      { property: "og:title", content: "My day — Trade Brain" },
      { property: "og:description", content: desc },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Page,
});

const dmy = (d: string) => new Date(`${d}T00:00:00`).toLocaleDateString("en-AU", { weekday: "short", day: "numeric", month: "short" });
const mins = (m: number) => (m >= 60 ? `${Math.floor(m / 60)} h ${m % 60} min` : `${m} min`);

function Page() {
  const { membership } = Route.useRouteContext();
  const ws = membership.workspaceId;
  const today = todayIso();
  // For field users the database returns only their own crew record, assignments and jobs.
  const { data: crew = [] } = useQuery(crewQuery(ws));
  const me = crew[0];
  const { data: settings } = useQuery({
    queryKey: ["workspace_settings", ws, "myday"],
    queryFn: async () => (await supabase.from("workspace_settings").select("unload_buffer_min, day_start").eq("workspace_id", ws).single()).data,
  });
  const { data: rows = [] } = useQuery({
    queryKey: ["my-day", me?.id, today],
    enabled: !!me,
    queryFn: async () => {
      const { data, error } = await supabase.from("assignments")
        .select("id, date, start_time, end_time, actual_start, actual_end, job_id, jobs(id, code, name, address, suburb, sector, tasks(id, label, done, sort))")
        .eq("crew_member_id", me!.id).gte("date", today).order("date").order("start_time").limit(40);
      if (error) throw error;
      return data;
    },
  });
  const todays = rows.filter((r) => r.date === today);
  const coming = rows.filter((r) => r.date > today).slice(0, 6);

  return (
    <div className="mx-auto max-w-3xl space-y-5 px-4 py-6">
      <div>
        <h1 className="font-heading text-3xl font-semibold uppercase tracking-wide">My day</h1>
        <p className="text-sm text-muted-foreground">{dmy(today)}{me && ` · ${me.name}`}</p>
      </div>

      {!me ? (
        <p className="rounded-md border bg-card p-5 text-sm text-muted-foreground">Your account isn't linked to a crew record yet. Ask the office.</p>
      ) : todays.length === 0 ? (
        <div className="chalk-grid grid min-h-32 place-items-center rounded-md border bg-card p-6 text-center">
          <p className="font-heading text-xl uppercase tracking-wide text-muted-foreground">Nothing booked today</p>
        </div>
      ) : todays.map((a) => a.jobs && (
        <TodayCard key={a.id} me={me.id} start={hm(a.start_time)} end={hm(a.end_time)} job={a.jobs} buffer={settings?.unload_buffer_min ?? 10} assignmentId={a.id} actualStart={a.actual_start} actualEnd={a.actual_end} />
      ))}

      {me && (
        <section className="rounded-md border bg-card p-5">
          <h2 className="font-heading text-xl font-semibold uppercase">Coming up</h2>
          {coming.length === 0 ? <p className="mt-2 text-sm text-muted-foreground">Nothing else booked yet.</p> : (
            <ul className="mt-2 divide-y">
              {coming.map((a) => a.jobs && (
                <li key={a.id}>
                  <Link to="/my-jobs" search={{ job: a.job_id }} className="flex min-h-11 items-center gap-2 py-2 text-sm">
                    <span className={`h-4 w-1 rounded-sm ${a.jobs.sector === "commercial" ? "bg-commercial" : "bg-domestic"}`} />
                    <span className="w-28 shrink-0">{dmy(a.date)}</span>
                    <span className="flex-1 truncate"><span className="font-mono text-xs">{a.jobs.code}</span> {a.jobs.name}</span>
                    <span className="font-mono text-xs text-muted-foreground">{hm(a.start_time)}</span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>
      )}

      {me && <MyLeave workspaceId={ws} crewMemberId={me.id} />}

      {me && (
        <section className="rounded-md border bg-card p-5">
          <h2 className="font-heading text-xl font-semibold uppercase">My details</h2>
          <div className="mt-3 space-y-2 text-sm">
            <p><span className="font-medium">{me.name}</span> · {crewRoleLabel[me.role]}{me.base_suburb && ` · ${me.base_suburb}`}</p>
            <div className="flex flex-wrap gap-1">
              {me.crew_tickets.length === 0 ? <span className="text-muted-foreground">No tickets recorded.</span> : me.crew_tickets.map((t) => <TicketChip key={t.id} type={t.ticket_type} expiresOn={t.expires_on} />)}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}

type TodayJob = { id: string; code: string; name: string; address: string | null; suburb: string | null; sector: string; tasks: { id: string; label: string; done: boolean; sort: number }[] };

function TodayCard({ me, start, end, job, buffer, assignmentId, actualStart, actualEnd }: { me: string; start: string; end: string; job: TodayJob; buffer: number; assignmentId: string; actualStart: string | null; actualEnd: string | null }) {
  const fetchDrive = useServerFn(getDriveTimes);
  const { data: drive, isLoading } = useQuery({
    queryKey: ["drive", job.id, job.address, job.suburb],
    queryFn: () => fetchDrive({ data: { jobId: job.id } }),
    staleTime: 10 * 60_000,
  });
  const leg = drive?.legs.find((l) => l.crewMemberId === me);
  const site = [job.address, job.suburb].filter(Boolean).join(", ");
  const next = [...job.tasks].sort((a, b) => a.sort - b.sort).find((t) => !t.done);
  const quick = [
    { label: "Open job", icon: FileText, tab: "overview" },
    { label: "Safety", icon: ShieldAlert, tab: "safety" },
    { label: "Guidance", icon: BookOpen, tab: "guidance" },
    { label: "Inspection", icon: ClipboardList, tab: "inspection" },
  ];
  return (
    <section className={`rounded-md border border-l-4 bg-card p-5 ${job.sector === "commercial" ? "border-l-commercial" : "border-l-domestic"}`}>
      <p className="font-mono text-sm text-muted-foreground">{job.code}</p>
      <h2 className="font-heading text-2xl font-semibold uppercase">{job.name}</h2>
      <p className="text-sm text-muted-foreground">{site || "No site address yet"}</p>

      <div className="mt-4 grid grid-cols-3 gap-2 text-center">
        <div className="rounded-md bg-muted p-2"><p className="text-xs uppercase text-muted-foreground">Leave by</p><p className="font-mono text-xl font-semibold">{leg?.minutes != null ? leaveBy(start, leg.minutes, buffer) : "—"}</p></div>
        <div className="rounded-md bg-muted p-2"><p className="text-xs uppercase text-muted-foreground">Drive</p><p className="font-mono text-xl font-semibold">{leg?.minutes != null ? mins(leg.minutes) : isLoading ? "…" : "—"}</p></div>
        <div className="rounded-md bg-muted p-2"><p className="text-xs uppercase text-muted-foreground">On site</p><p className="font-mono text-xl font-semibold">{start}–{end}</p></div>
      </div>
      <StartFinish assignmentId={assignmentId} actualStart={actualStart} actualEnd={actualEnd} />
      {!isLoading && leg?.minutes == null && <p className="mt-2 text-xs text-muted-foreground">{leg?.error ?? "Add your home base with the office to see when to leave."}</p>}

      {site && (
        <Button asChild className="mt-3 h-11 w-full">
          <a href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${site}, Australia`)}`} target="_blank" rel="noreferrer">Directions <ExternalLink className="ml-1 h-4 w-4" /></a>
        </Button>
      )}

      <div className="mt-4 rounded-md border p-3">
        <p className="text-xs uppercase text-muted-foreground">Next task</p>
        <p className="text-sm font-medium">{next ? next.label : "All tasks done"}</p>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-5">
        {quick.map((q) => (
          <Button key={q.label} asChild variant="outline" className="h-14 flex-col gap-0.5 text-xs">
            <Link to="/my-jobs" search={{ job: job.id, tab: q.tab }}><q.icon className="h-4 w-4" />{q.label}</Link>
          </Button>
        ))}
        <Button asChild variant="outline" className="h-14 flex-col gap-0.5 text-xs">
          <Link to="/messages" search={{ job: job.id }}><MessageSquare className="h-4 w-4" />Job chat</Link>
        </Button>
      </div>
    </section>
  );
}
