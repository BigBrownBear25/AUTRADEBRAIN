import { createFileRoute, getRouteApi } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { CheckCircle2, XCircle } from "lucide-react";
import { PagePlaceholder } from "@/components/PagePlaceholder";
import { Button } from "@/components/ui/button";
import { AI_TESTS } from "@/lib/ai-tests";
import { resizeForAi } from "@/lib/resize-image";
import { runAiTest, type AiTestResult } from "@/lib/ai-test.functions";

const desc = "Runs saved Brain examples through the live AI and checks the answers, including privacy checks.";
const auth = getRouteApi("/_authenticated");

export const Route = createFileRoute("/_authenticated/ai-test")({
  head: () => ({
    meta: [
      { title: "AI test — Trade Brain" },
      { name: "description", content: desc },
      { property: "og:title", content: "AI test — Trade Brain" },
      { property: "og:description", content: desc },
    ],
  }),
  component: Page,
});

function Page() {
  const { membership } = auth.useRouteContext();
  const run = useServerFn(runAiTest);
  const [res, setRes] = useState<Record<string, AiTestResult>>({});
  const [busy, setBusy] = useState(false);
  async function all() {
    setBusy(true); setRes({});
    for (const t of AI_TESTS) {
      try { const image = t.image ? (await resizeForAi(await (await fetch(t.image)).blob())).data : undefined; const r = await run({ data: { workspaceId: membership.workspaceId, id: t.id, ...(image ? { image } : {}) } }); setRes((p) => ({ ...p, [t.id]: r })); }
      catch (e) { setRes((p) => ({ ...p, [t.id]: { id: t.id, pass: false, got: (e as Error).message, ms: 0 } })); }
    }
    setBusy(false);
  }
  const done = Object.values(res); const passed = done.filter((r) => r.pass).length;
  return (
    <PagePlaceholder title="AI test" description={desc}>
      <div className="mt-4 flex items-center gap-3">
        <Button onClick={all} disabled={busy}>{busy ? `Running ${done.length + 1} of ${AI_TESTS.length}…` : "Run all tests"}</Button>
        {done.length > 0 && <span className={`font-heading text-xl font-semibold uppercase ${passed === done.length ? "text-fit" : "text-clash"}`}>{passed} of {done.length} passed</span>}
      </div>
      <FeedbackRates ws={membership.workspaceId} />
      <p className="mt-2 text-xs text-muted-foreground">Uses real AI credit (about 25 short requests). Email and document examples are added when those features are built.</p>
      <div className="mt-4 space-y-2">
        {AI_TESTS.map((t) => { const r = res[t.id]; return (
          <div key={t.id} className="rounded-md border bg-card p-3 text-sm">
            <div className="flex items-start gap-2">
              {r ? (r.pass ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-fit" /> : <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-clash" />) : <span className="mt-0.5 h-4 w-4 shrink-0 rounded-full border" />}
              <div className="min-w-0">
                <p><span className="text-xs uppercase text-muted-foreground">{t.group === "photo" ? "Photo" : t.group === "capture" ? "Brain bar" : t.group === "match" ? (t.asField ? "Matching · installer" : "Matching") : t.asField ? "Ask · privacy" : "Ask"}</span> {t.input}</p>
                {t.expect && <p className="text-xs text-muted-foreground">Expected: {t.expect}{r ? ` · got ${r.got}` : ""}</p>}
                {t.image && <img src={t.image} alt={t.input} loading="lazy" width={64} height={64} className="mt-1 h-16 w-16 rounded-sm object-cover" />}
                {r && (t.group === "match" || t.group === "photo") && r.note && <p className="mt-1 text-xs text-muted-foreground">{r.note}</p>}
                {r && t.group === "ask" && <p className="mt-1 whitespace-pre-wrap text-xs text-muted-foreground">{r.note ? `${r.note} — ` : ""}{r.got}</p>}
              </div>
            </div>
          </div>
        ); })}
      </div>
    </PagePlaceholder>
  );
}

/** How often people changed the Brain bar's job match, and how often a post was later moved (capture_feedback). */
function FeedbackRates({ ws }: { ws: string }) {
  const { data } = useQuery({
    queryKey: ["capture_feedback", ws, "rates"],
    queryFn: async () => (await supabase.from("capture_feedback").select("changed, moved, preselected_job_id").eq("workspace_id", ws).gte("created_at", new Date(Date.now() - 30 * 86_400_000).toISOString()).limit(5000)).data ?? [],
  });
  const n = data?.length ?? 0;
  const pre = (data ?? []).filter((r) => r.preselected_job_id);
  const pct = (a: number, b: number) => (b ? `${Math.round((a / b) * 100)}%` : "—");
  return (
    <div className="mt-4 grid gap-2 sm:grid-cols-3">
      <div className="rounded-md border bg-card p-3"><p className="text-xs uppercase text-muted-foreground">Brain bar posts (30 days)</p><p className="font-heading text-2xl font-semibold">{n}</p></div>
      <div className="rounded-md border bg-card p-3"><p className="text-xs uppercase text-muted-foreground">Match changed by the person</p><p className="font-heading text-2xl font-semibold">{pct(pre.filter((r) => r.changed).length, pre.length)}</p><p className="text-xs text-muted-foreground">of {pre.length} with a job picked for them</p></div>
      <div className="rounded-md border bg-card p-3"><p className="text-xs uppercase text-muted-foreground">Later moved to another job</p><p className="font-heading text-2xl font-semibold">{pct((data ?? []).filter((r) => r.moved).length, n)}</p></div>
    </div>
  );
}
