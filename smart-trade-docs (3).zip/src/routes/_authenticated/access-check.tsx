import { createFileRoute, getRouteApi } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { PagePlaceholder } from "@/components/PagePlaceholder";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { runAccessCheck, type AccessReport } from "@/lib/access-check.functions";

const desc = "See exactly what each account can read, checked through the same access rules the app uses.";
const auth = getRouteApi("/_authenticated");

export const Route = createFileRoute("/_authenticated/access-check")({
  head: () => ({
    meta: [
      { title: "Access check — Trade Brain" },
      { name: "description", content: desc },
      { property: "og:title", content: "Access check — Trade Brain" },
      { property: "og:description", content: desc },
    ],
  }),
  component: Page,
});

function List({ items, none = "Nothing" }: { items: string[]; none?: string }) {
  if (!items.length) return <span className="text-muted-foreground">{none}</span>;
  return <ul className="space-y-0.5">{items.map((i) => <li key={i}>{i}</li>)}</ul>;
}

function Page() {
  const { membership } = auth.useRouteContext();
  const run = useServerFn(runAccessCheck);
  const [extra, setExtra] = useState("");
  const [busy, setBusy] = useState(false);
  const [rows, setRows] = useState<AccessReport[] | null>(null);

  const go = async () => {
    setBusy(true);
    try {
      setRows(await run({ data: { workspaceId: membership.workspaceId, extraEmails: extra.split(/[\s,]+/) } }));
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <PagePlaceholder title="Access check" description={desc}>
      <div className="mt-6 space-y-4">
        <div className="flex flex-col gap-3 rounded-md border bg-card p-4 md:flex-row md:items-end">
          <div className="flex-1 space-y-1.5">
            <Label>Extra accounts to test (e.g. the Outsider), comma separated</Label>
            <Input value={extra} onChange={(e) => setExtra(e.target.value)} placeholder="outsider@example.com" />
          </div>
          <Button onClick={go} disabled={busy}>{busy ? "Checking…" : "Run check"}</Button>
        </div>
        <p className="text-sm text-muted-foreground">Every member of {membership.workspaceName} is tested. Only rows from this workspace are listed, so an outsider should show nothing. Accounts are checked without two-factor, so owner and office accounts should also see nothing.</p>
        {rows && (
          <div className="overflow-x-auto rounded-md border bg-card">
            <table className="w-full text-left text-sm">
              <thead className="border-b bg-muted/50">
                <tr>{["Account", "Jobs", "People (full record)", "Crew mates", "Bookings", "Finance rows", "Leave", "Other", "Platform (section 12)"].map((h) => <th key={h} className="px-3 py-2 font-semibold">{h}</th>)}</tr>
              </thead>
              <tbody className="divide-y align-top">
                {rows.map((r) => {
                  const fin = Object.values(r.finance).reduce((a, b) => a + b, 0);
                  return (
                    <tr key={r.email}>
                      <td className="px-3 py-2"><p className="font-medium">{r.email}</p><p className="text-xs text-muted-foreground">{r.role}</p>{r.level && <p className="text-xs text-muted-foreground">Signed in at {r.level}</p>}{r.error && <p className="text-xs text-clash">{r.error}</p>}</td>
                      <td className="px-3 py-2 font-mono text-xs"><List items={r.jobs} /></td>
                      <td className="px-3 py-2"><List items={r.people} /></td>
                      <td className="px-3 py-2"><List items={r.crewMates} /></td>
                      <td className="px-3 py-2">{r.assignments}</td>
                      <td className={`px-3 py-2 ${fin && !["owner", "office"].includes(r.role) ? "font-semibold text-clash" : ""}`}>
                        {fin === 0 ? <span className="text-muted-foreground">None</span> : (
                          <ul className="text-xs">{Object.entries(r.finance).map(([k, v]) => <li key={k}>{k}: {v}</li>)}</ul>
                        )}
                      </td>
                      <td className="px-3 py-2 text-xs text-muted-foreground">{r.leave}</td>
                      <td className="px-3 py-2 text-xs"><ul>{Object.entries(r.other).map(([k, v]) => <li key={k}>{k}: {v}</li>)}</ul></td>
                      <td className="px-3 py-2 text-xs">{r.platform && (
                        <ul>{Object.entries(r.platform).map(([k, v]) => {
                          const bad = (typeof v === "number" && v > 0) || v === "ALLOWED";
                          return <li key={k} className={bad ? "font-semibold text-clash" : ""}>{k.replace(/_/g, " ")}: {String(v)}</li>;
                        })}</ul>
                      )}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </PagePlaceholder>
  );
}
