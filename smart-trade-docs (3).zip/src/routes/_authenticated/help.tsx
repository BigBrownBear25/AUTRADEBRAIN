import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/PagePlaceholder";
import { officeNav, fieldNav } from "@/lib/nav";
import { modeForRole } from "@/lib/session";

const desc = "What's where: a sentence or two on each area of Trade Brain.";

export const Route = createFileRoute("/_authenticated/help")({
  head: () => ({
    meta: [
      { title: "What's where — Trade Brain" },
      { name: "description", content: desc },
      { property: "og:title", content: "What's where — Trade Brain" },
      { property: "og:description", content: desc },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: HelpPage,
});

const JOB_FILE = [
  ["Overview", "Dates, crew, tasks, and what makes this job different."],
  ["Chat", "Messages, problems, photos and voice notes for everyone on the job. Filed emails appear here too."],
  ["Materials and Depend.", "What's ordered and delivered, and what has to happen before you can start."],
  ["Safety and Travel", "Tickets against crew, hazards with controls, drive times and when to leave."],
  ["Inspection and Guidance", "Walkthrough notes with a Claude summary, and a Claude crew brief. Always check against the manufacturer's instructions."],
] as const;

const OFFICE_EXTRA = [
  ["Unfiled email", "On Messages. Emails without a job code wait here with Claude's suggested job, for you to file, ignore or turn into an enquiry."],
  ["Settings", "Working week, hours, skills, tickets, hazards, leave types, closures, team and invites. The owner also sees demo data, usage and data export."],
] as const;

function List({ title, items }: { title: string; items: { label: string; help: string; icon?: React.ComponentType<{ className?: string }> }[] }) {
  return (
    <section className="rounded-md border bg-card p-5">
      <h2 className="font-heading text-xl font-semibold uppercase">{title}</h2>
      <ul className="mt-3 space-y-3">
        {items.map((n) => (
          <li key={n.label} className="flex gap-3">
            {n.icon ? <n.icon className="mt-0.5 h-5 w-5 shrink-0 text-primary" /> : <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />}
            <div>
              <p className="font-medium">{n.label}</p>
              <p className="text-sm text-muted-foreground">{n.help}</p>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}

function HelpPage() {
  const { membership } = Route.useRouteContext();
  const office = modeForRole(membership.role) === "office";
  const toItems = (xs: readonly (readonly [string, string])[]) => xs.map(([label, help]) => ({ label, help }));
  return (
    <PagePlaceholder title="What's where" description={desc}>
      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <List title="Your screens" items={office ? officeNav : fieldNav} />
        <List title="Inside a job" items={toItems(JOB_FILE)} />
        {office && <List title="Also for the office" items={toItems(OFFICE_EXTRA)} />}
      </div>
    </PagePlaceholder>
  );
}
