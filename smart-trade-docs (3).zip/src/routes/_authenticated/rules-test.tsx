import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import { CheckCircle2, XCircle } from "lucide-react";
import { PagePlaceholder } from "@/components/PagePlaceholder";
import { runScenarios } from "@/lib/rules/scenarios";
import { todayIso } from "@/lib/rules/ticket-expiry";

const desc = "Runs every scheduling rule scenario from the spec on built-in sample data.";

export const Route = createFileRoute("/_authenticated/rules-test")({
  head: () => ({
    meta: [
      { title: "Rules test — Trade Brain" },
      { name: "description", content: desc },
      { property: "og:title", content: "Rules test — Trade Brain" },
      { property: "og:description", content: desc },
    ],
  }),
  component: Page,
});

function Page() {
  const results = useMemo(() => runScenarios(todayIso()), []);
  const passed = results.filter((r) => r.pass).length;
  return (
    <PagePlaceholder title="Rules test" description={desc}>
      <p className={`mt-4 font-heading text-xl font-semibold uppercase ${passed === results.length ? "text-fit" : "text-clash"}`}>
        {passed} of {results.length} passed
      </p>
      <div className="mt-4 space-y-3">
        {results.map((r) => (
          <article key={r.name} className={`rounded-md border border-l-4 bg-card p-4 ${r.pass ? "border-l-fit" : "border-l-clash"}`}>
            <div className="flex items-start gap-2">
              {r.pass ? <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-fit" /> : <XCircle className="mt-0.5 h-5 w-5 shrink-0 text-clash" />}
              <div className="min-w-0">
                <p className="font-medium">{r.name}</p>
                <p className="text-sm"><span className="text-muted-foreground">Expected: </span>{r.expected}</p>
                <p className="text-sm"><span className="text-muted-foreground">Actual: </span>{r.actual}</p>
              </div>
              <span className={`ml-auto shrink-0 rounded-sm px-2 py-0.5 text-xs font-bold uppercase ${r.pass ? "bg-fit-soft text-fit" : "bg-clash-soft text-clash"}`}>{r.pass ? "Pass" : "Fail"}</span>
            </div>
          </article>
        ))}
      </div>
    </PagePlaceholder>
  );
}
