import { useMemo, useState } from "react";
import { MATERIAL_ATTENTION_COLS, flattenMaterial } from "@/lib/materials-attention";
import { AccessReviewReminder } from "@/components/settings/SecuritySettings";
import { createFileRoute, getRouteApi, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SuggestPlanButton } from "@/components/schedule/SuggestPlan";
import { CapacityTotals } from "@/components/schedule/CapacityTotals";
import { MorningBrief } from "@/components/overview/MorningBrief";
import { DraftPlan, LookAhead } from "@/components/brain/DraftPlan";
import { hm } from "@/lib/assignments";
import { isFinanceQuery } from "@/lib/crew";
import { jobEndDate } from "@/lib/jobs";
import { leaveQuery, useDaysOff } from "@/lib/leave";
import { toRuleJob, useSchedulingData } from "@/lib/scheduling";
import { addDays, frameRange, shiftAnchor, type Frame } from "@/lib/rules/board";
import { skillDemand } from "@/lib/rules/capacity";
import { dailyCapacity, forwardAvailability, jobCost, margin, rangeCapacity, type CapLeave, type WeekCell } from "@/lib/rules/availability";
import { needsAttention, type Flag } from "@/lib/rules/attention";
import { comparePriority, priorityOf } from "@/lib/rules/priority";
import { todayIso } from "@/lib/rules/ticket-expiry";
import { jobDays, workingDays } from "@/lib/rules/working-days";

const desc = "Headline figures, daily crew capacity, needs attention and jobs waiting to be scheduled.";
const auth = getRouteApi("/_authenticated");

export const Route = createFileRoute("/_authenticated/overview")({
  head: () => ({
    meta: [
      { title: "Overview — Trade Brain" },
      { name: "description", content: desc },
      { property: "og:title", content: "Overview — Trade Brain" },
      { property: "og:description", content: desc },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Page,
});

const FRAMES: { v: Frame; label: string }[] = [
  { v: "week", label: "Week" }, { v: "2weeks", label: "2 weeks" }, { v: "month", label: "Month" }, { v: "quarter", label: "Quarter" }, { v: "custom", label: "Custom" },
];
const WEEKS = 8;
const f1 = (n: number) => (Math.round(n * 10) / 10).toLocaleString("en-AU");
const money = (n: number) => n.toLocaleString("en-AU", { style: "currency", currency: "AUD", maximumFractionDigits: 0 });
const dmy = (d: string) => new Date(`${d}T00:00:00`).toLocaleDateString("en-AU", { day: "numeric", month: "short" });
const ACTIVE = new Set(["enquiry", "quoted", "ready", "scheduled", "on site"]);

function Page() {
  const { membership } = auth.useRouteContext();
  const ws = membership.workspaceId;
  const today = todayIso();
  const [frame, setFrame] = useState<Frame>("2weeks");
  const [anchor, setAnchor] = useState(today);
  const [custom, setCustom] = useState({ from: today, to: addDays(today, 13) });
  const range = frameRange(frame, anchor, custom);
  const fetchTo = range.to > addDays(today, WEEKS * 7 + 7) ? range.to : addDays(today, WEEKS * 7 + 7);
  const fetchFrom = range.from < today ? range.from : today;

  const sched = useSchedulingData(ws);
  const settings = useQuery({
    queryKey: ["workspace_settings", ws, "board"],
    queryFn: async () => {
      const { data, error } = await supabase.from("workspace_settings")
        .select("working_days, day_start, morning_end, day_end, skills, hazards, ticket_rules, avg_kmh, holiday_states").eq("workspace_id", ws).single();
      if (error) throw error;
      return data;
    },
  });
  const people = useQuery({
    queryKey: ["board-people", ws],
    queryFn: async () => {
      const { data, error } = await supabase.from("crew_members")
        .select("id, name, role, is_subcontractor, base_suburb, base_lat, base_lng, skills, crew_tickets(ticket_type, expires_on)")
        .eq("workspace_id", ws).eq("active", true).order("sort").order("name");
      if (error) throw error;
      return data;
    },
  });
  const rows = useQuery({
    queryKey: ["board-assignments", ws, "overview", fetchFrom, fetchTo],
    queryFn: async () => {
      const { data, error } = await supabase.from("assignments").select("job_id, crew_member_id, date, start_time, end_time")
        .eq("workspace_id", ws).gte("date", fetchFrom).lte("date", fetchTo);
      if (error) throw error;
      return data;
    },
  });
  const closures = useDaysOff(ws, settings.data?.holiday_states);
  const leaveRows = useQuery(leaveQuery(ws));
  const extras = useQuery({
    queryKey: ["overview-extras", ws],
    queryFn: async () => {
      const [m, t] = await Promise.all([
        supabase.from("materials").select(MATERIAL_ATTENTION_COLS).eq("workspace_id", ws),
        supabase.from("tasks").select("job_id, label, due_date, done").eq("workspace_id", ws),
      ]);
      if (m.error) throw m.error;
      if (t.error) throw t.error;
      return { materials: m.data.map(flattenMaterial), tasks: t.data };
    },
  });
  const finance = useQuery(isFinanceQuery(ws)).data === true;
  const fin = useQuery({
    queryKey: ["overview-finance", ws],
    enabled: finance,
    queryFn: async () => {
      const [q, r, mc, s] = await Promise.all([
        supabase.from("job_finance").select("job_id, quote_value").eq("workspace_id", ws),
        supabase.from("crew_rates").select("crew_member_id, day_rate").eq("workspace_id", ws),
        supabase.from("material_costs").select("material_id, unit_cost").eq("workspace_id", ws),
        supabase.from("workspace_finance_settings").select("default_day_rate").eq("workspace_id", ws).maybeSingle(),
      ]);
      for (const x of [q, r, mc, s]) if (x.error) throw x.error;
      return {
        quotes: new Map((q.data ?? []).map((x) => [x.job_id, x.quote_value == null ? null : Number(x.quote_value)])),
        rates: new Map((r.data ?? []).map((x) => [x.crew_member_id, Number(x.day_rate)])),
        unitCost: new Map((mc.data ?? []).map((x) => [x.material_id, Number(x.unit_cost)])),
        defaultRate: Number(s.data?.default_day_rate ?? 0),
      };
    },
  });

  const [openCell, setOpenCell] = useState<{ label: string; cell: WeekCell } | null>(null);

  const model = useMemo(() => {
    if (!settings.data || !people.data || !rows.data || !closures || !leaveRows.data) return null;
    const s = settings.data;
    const week = { workingDays: s.working_days, closures };
    const hours = { dayStart: hm(s.day_start), dayEnd: hm(s.day_end) };
    const ids = people.data.map((p) => p.id);
    const idSet = new Set(ids);
    const bookings = rows.data.filter((r) => idSet.has(r.crew_member_id)).map((r) => ({ crew_member_id: r.crew_member_id, job_id: r.job_id, date: r.date, start: hm(r.start_time), end: hm(r.end_time) }));
    const leave: CapLeave[] = leaveRows.data.filter((l) => l.status !== "declined").map((l) => ({ crew_member_id: l.crew_member_id, from: l.from_date, to: l.to_date, status: l.status === "approved" ? "approved" : "requested" }));
    const days = workingDays(range.from, range.to, week);
    const cap = rangeCapacity(ids, days, hours, leave, bookings);
    const daily = dailyCapacity(ids, days, hours, leave, bookings);
    const dayH = (Number(hours.dayEnd.slice(0, 2)) * 60 + Number(hours.dayEnd.slice(3)) - Number(hours.dayStart.slice(0, 2)) * 60 - Number(hours.dayStart.slice(3))) / 60;

    const groups: { label: string; ids: string[] }[] = [
      { label: "Whole crew", ids },
      { label: "Foremen", ids: people.data.filter((p) => !p.is_subcontractor && p.role === "foreman").map((p) => p.id) },
      { label: "Installers", ids: people.data.filter((p) => !p.is_subcontractor && p.role === "installer").map((p) => p.id) },
      { label: "Apprentices", ids: people.data.filter((p) => !p.is_subcontractor && p.role === "apprentice").map((p) => p.id) },
      { label: "Subcontractors", ids: people.data.filter((p) => p.is_subcontractor).map((p) => p.id) },
      ...(s.skills ?? []).map((k) => ({ label: k, ids: people.data!.filter((p) => (p.skills ?? []).includes(k)).map((p) => p.id) })),
    ].filter((g) => g.ids.length);
    const forward = groups.map((g) => ({ label: g.label, cells: forwardAvailability(g.ids, today, WEEKS, week, hours, leave, bookings) }));

    // Skills demand in range: crew-days needed by jobs (main skill) in range vs crew-days available of holders.
    const demand = (s.skills ?? []).map((k) => {
      const needed = bookings.filter((b) => days.includes(b.date) && sched?.jobMap.get(b.job_id)?.main_skill === k)
        .reduce((a, b) => a + (Number(b.end.slice(0, 2)) * 60 + Number(b.end.slice(3)) - Number(b.start.slice(0, 2)) * 60 - Number(b.start.slice(3))) / 60, 0) / (dayH || 1);
      const unplaced = (sched?.jobs ?? []).filter((j) => j.main_skill === k && !j.start_date && ACTIVE.has(j.status) && j.due_by && j.due_by >= range.from && j.due_by <= range.to)
        .reduce((a, j) => a + j.crew_size * (j.duration_unit === "days" ? Number(j.duration_value) : Number(j.duration_value) / (dayH || 1)), 0);
      const holders = people.data!.filter((p) => (p.skills ?? []).includes(k)).map((p) => p.id);
      const avail = rangeCapacity(holders, days, hours, leave, []).availableCrewDays;
      return { skill: k, needed: needed + unplaced, avail, ...skillDemand(needed + unplaced, avail) };
    });
    return { s, week, days, cap, daily, forward, demand, bookings, dayH };
  }, [settings.data, people.data, rows.data, closures, leaveRows.data, range.from, range.to, today, sched]);

  const jobs = sched?.jobs ?? [];
  const toSchedule = jobs.filter((j) => !j.locked && (j.status === "ready" || (!j.start_date && ACTIVE.has(j.status)))).sort(comparePriority(today));
  const attention = useMemo(() => {
    if (!sched || !extras.data) return [];
    return jobs.filter((j) => ACTIVE.has(j.status)).map((j) => {
      const rj = toRuleJob(j);
      const ctx = sched.ctxFor(rj);
      const flags = needsAttention({
        job: rj, ctx, crew: ctx.jobCrew,
        materials: extras.data.materials.filter((m) => m.job_id === j.id),
        tasks: extras.data.tasks.filter((t) => t.job_id === j.id),
      });
      return { job: j, flags };
    }).filter((x) => x.flags.length).sort((a, b) => b.flags.filter((x) => x.level === "red").length - a.flags.filter((x) => x.level === "red").length);
  }, [sched, extras.data, jobs]);

  const inRange = jobs.filter((j) => j.start_date && j.start_date <= range.to && (jobEndDate(j) ?? j.start_date) >= range.from).sort((a, b) => a.start_date!.localeCompare(b.start_date!));
  const mix = [1, 2, 3, 4].map((p) => ({ p, n: jobs.filter((j) => ACTIVE.has(j.status) && priorityOf(j, today) === p).length }));

  const financeFig = useMemo(() => {
    if (!finance || !fin.data || !model || !extras.data) return null;
    let booked = 0, cost = 0, quoted = 0;
    for (const j of inRange) {
      const q = fin.data.quotes.get(j.id) ?? null;
      const crew = [...new Set(model.bookings.filter((b) => b.job_id === j.id).map((b) => b.crew_member_id))];
      const nDays = jobDays(j.start_date!, { value: Number(j.duration_value), unit: j.duration_unit }, model.week).length;
      const mats = extras.data.materials.filter((m) => m.job_id === j.id).reduce((a, m) => a + (fin.data!.unitCost.get(m.id) ?? 0) * Number(m.qty ?? 0), 0);
      const c = jobCost({ days: nDays, crewDayRates: crew.map((id) => fin.data!.rates.get(id) ?? fin.data!.defaultRate), openSpots: Math.max(0, j.crew_size - crew.length), defaultDayRate: fin.data.defaultRate, travel: 0, accommodation: 0, materials: mats });
      if (q != null) { booked += q; quoted += q; cost += c.total; }
    }
    return { booked, margin: margin(quoted, cost) };
  }, [finance, fin.data, model, extras.data, inRange]);

  const crit = attention.reduce((a, x) => a + (x.flags.some((f) => f.level === "red") ? 1 : 0), 0);
  const maxDay = Math.max(1, ...(model?.daily.map((d) => Math.max(d.availableHours, d.bookedHours)) ?? [1]));

  return (
    <div className="mx-auto max-w-7xl space-y-5 px-4 py-6">
      <AccessReviewReminder membership={membership} />
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-heading text-3xl font-semibold uppercase tracking-wide">Overview</h1>
          <p className="text-sm text-muted-foreground">{desc}</p>
        </div>
        <SuggestPlanButton workspaceId={ws} />
      </div>
      <DraftPlan workspaceId={ws} />
      <MorningBrief workspaceId={ws} />
      <LookAhead workspaceId={ws} />

      {/* Time frame control — same ranges as the Schedule board */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex flex-wrap rounded-md border bg-card p-0.5">
          {FRAMES.map((x) => (
            <button key={x.v} onClick={() => setFrame(x.v)} className={`min-h-9 rounded-sm px-3 text-sm ${frame === x.v ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>{x.label}</button>
          ))}
        </div>
        <Button variant="outline" size="icon" aria-label="Earlier" onClick={() => setAnchor(shiftAnchor(frame, anchor, -1, custom))}><ChevronLeft className="h-4 w-4" /></Button>
        <Button variant="outline" onClick={() => setAnchor(today)}>Today</Button>
        <Button variant="outline" size="icon" aria-label="Later" onClick={() => setAnchor(shiftAnchor(frame, anchor, 1, custom))}><ChevronRight className="h-4 w-4" /></Button>
        {frame === "custom" ? (
          <div className="flex items-center gap-1">
            <Input type="date" className="w-40" value={custom.from} onChange={(e) => setCustom({ ...custom, from: e.target.value })} />
            <span className="text-muted-foreground">to</span>
            <Input type="date" className="w-40" value={custom.to} min={custom.from} onChange={(e) => setCustom({ ...custom, to: e.target.value })} />
          </div>
        ) : <p className="text-sm font-medium">{dmy(range.from)} – {dmy(range.to)}</p>}
      </div>

      {!model ? <p className="text-sm text-muted-foreground">Loading…</p> : (
        <>
          <CapacityTotals cap={model.cap} label="Whole crew" />

          {/* Headline figures */}
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-6">
            <Stat label="Free crew-days" value={f1(model.cap.freeCrewDays)} tone={model.cap.freeHours < 0 ? "clash" : undefined} />
            <Stat label="Booked" value={`${model.cap.availableHours > 0 ? Math.round((model.cap.bookedHours / model.cap.availableHours) * 100) : 0}%`} />
            <Stat label="Jobs in range" value={String(inRange.length)} />
            <Stat label="To schedule" value={String(toSchedule.length)} />
            <Stat label="Need attention" value={String(attention.length)} tone={crit ? "clash" : attention.length ? "warn" : undefined} />
            {financeFig && <Stat label="Work booked" value={money(financeFig.booked)} />}
            {financeFig && <Stat label="Margin" value={financeFig.margin.margin == null ? "—" : `${Math.round(financeFig.margin.margin * 100)}%`} tone={financeFig.margin.level === "red" ? "clash" : financeFig.margin.level === "amber" ? "warn" : undefined} hint="Labour and materials; travel not yet included" />}
          </div>

          {/* Daily crew capacity */}
          <Panel title="Crew capacity by day">
            {model.daily.length === 0 ? <Empty>No working days in this range.</Empty> : (
              <div className="flex h-40 items-end gap-1 overflow-x-auto pb-6">
                {model.daily.map((d) => (
                  <div key={d.date} className="relative flex h-full min-w-6 flex-1 flex-col justify-end" title={`${dmy(d.date)}: ${f1(d.bookedCrewDays)} of ${f1(d.availableCrewDays)} crew-days booked`}>
                    <div className="relative w-full rounded-t-sm bg-muted" style={{ height: `${(d.availableHours / maxDay) * 100}%` }}>
                      <div className={`absolute bottom-0 w-full rounded-t-sm ${d.bookedHours > d.availableHours ? "bg-clash" : "bg-primary"}`} style={{ height: `${d.availableHours ? Math.min(100, (d.bookedHours / d.availableHours) * 100) : d.bookedHours ? 100 : 0}%` }} />
                    </div>
                    <span className={`absolute -bottom-5 left-0 right-0 text-center text-[10px] ${d.date === today ? "font-semibold text-primary" : "text-muted-foreground"}`}>{new Date(`${d.date}T00:00:00`).getDate()}</span>
                  </div>
                ))}
              </div>
            )}
            <p className="text-xs text-muted-foreground">Grey = available, blue = booked. Closures and approved leave are already taken off.</p>
          </Panel>

          <div className="grid gap-5 lg:grid-cols-2">
            <Panel title="Needs attention">
              {attention.length === 0 ? <Empty>Nothing needs attention.</Empty> : (
                <ul className="divide-y">
                  {attention.slice(0, 12).map(({ job, flags }) => (
                    <li key={job.id} className="py-2">
                      <Link to="/jobs" className="text-sm font-medium hover:underline"><span className="font-mono">{job.code}</span> {job.name}</Link>
                      <div className="mt-1 flex flex-wrap gap-1">{flags.map((fl, i) => <FlagChip key={i} f={fl} />)}</div>
                    </li>
                  ))}
                </ul>
              )}
            </Panel>
            <Panel title="To schedule" action={<SuggestPlanButton workspaceId={ws} size="sm" />}>
              {toSchedule.length === 0 ? <Empty>Every job has dates.</Empty> : (
                <ul className="divide-y">
                  {toSchedule.slice(0, 10).map((j) => (
                    <li key={j.id} className="flex items-center gap-2 py-2">
                      <span className="rounded-sm bg-muted px-1.5 font-mono text-xs">P{priorityOf(j, today)}</span>
                      <span className={`h-3 w-1 rounded-sm ${j.sector === "commercial" ? "bg-commercial" : "bg-domestic"}`} />
                      <span className="flex-1 truncate text-sm"><span className="font-mono">{j.code}</span> {j.name}{j.due_by && <span className="text-muted-foreground"> · due {dmy(j.due_by)}</span>}</span>
                      <Button asChild size="sm" variant="outline"><Link to="/schedule" search={{ place: j.id }}>Place</Link></Button>
                    </li>
                  ))}
                </ul>
              )}
            </Panel>
          </div>

          <Panel title="Job timeline">
            {inRange.length === 0 ? <Empty>No jobs in this range.</Empty> : (
              <div className="space-y-1">
                {inRange.map((j) => {
                  const end = jobEndDate(j) ?? j.start_date!;
                  const i0 = Math.max(0, model.days.findIndex((d) => d >= j.start_date!));
                  let i1 = model.days.length - 1; for (let i = model.days.length - 1; i >= 0; i--) if (model.days[i]! <= end) { i1 = i; break; }
                  const n = model.days.length || 1;
                  return (
                    <div key={j.id} className="grid items-center gap-2" style={{ gridTemplateColumns: "180px 1fr" }}>
                      <span className="truncate text-xs"><span className="font-mono">{j.code}</span> {j.name}</span>
                      <div className="relative h-5 rounded-sm bg-muted/50">
                        <div className={`absolute h-full rounded-sm ${j.sector === "commercial" ? "bg-commercial" : "bg-domestic"}`} style={{ left: `${(i0 / n) * 100}%`, width: `${(Math.max(1, i1 - i0 + 1) / n) * 100}%` }} title={`${dmy(j.start_date!)} – ${dmy(end)}`} />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Panel>

          <Panel title={`Forward availability — free crew-days, next ${WEEKS} weeks`}>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr><th className="py-1 pr-2 text-left font-medium text-muted-foreground">Group</th>{model.forward[0]?.cells.map((c) => <th key={c.weekStart} className="px-1 py-1 text-right font-medium text-muted-foreground">{dmy(c.weekStart)}</th>)}</tr></thead>
                <tbody>
                  {model.forward.map((g) => (
                    <tr key={g.label} className="border-t">
                      <td className="py-1 pr-2">{g.label}</td>
                      {g.cells.map((c) => (
                        <td key={c.weekStart} className="px-1 py-1 text-right">
                          <button onClick={() => setOpenCell({ label: g.label, cell: c })} className={`min-h-8 w-full rounded-sm px-1 font-mono ${c.freeCrewDays < 0 ? "bg-clash-soft text-clash" : c.freeCrewDays < 1 ? "bg-warn-soft" : "hover:bg-muted"}`}>{f1(c.freeCrewDays)}</button>
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {openCell && (
              <div className="mt-3 rounded-md border p-3 text-sm">
                <div className="mb-2 flex items-center justify-between"><b>{openCell.label} · week of {dmy(openCell.cell.weekStart)}</b><Button size="sm" variant="ghost" onClick={() => setOpenCell(null)}>Close</Button></div>
                {([["Free all week", openCell.cell.free], ["Partly free", openCell.cell.partly], ["Not free", openCell.cell.notFree]] as const).map(([t, list]) => (
                  <p key={t}><span className="text-muted-foreground">{t}:</span> {list.length ? list.map((id) => people.data?.find((p) => p.id === id)?.name).join(", ") : "nobody"}</p>
                ))}
              </div>
            )}
          </Panel>

          <div className="grid gap-5 lg:grid-cols-2">
            <Panel title="Skills demand">
              {model.demand.length === 0 ? <Empty>No skills set up.</Empty> : (
                <ul className="space-y-2">
                  {model.demand.map((d) => (
                    <li key={d.skill}>
                      <div className="flex justify-between text-sm"><span>{d.skill}</span><span className={d.level === "short" ? "text-clash" : d.level === "tight" ? "text-warn" : "text-muted-foreground"}>{f1(d.needed)} of {f1(d.avail)} crew-days{d.level !== "ok" && ` · ${d.level}`}</span></div>
                      <div className="h-1.5 overflow-hidden rounded-full bg-muted"><div className={`h-full ${d.level === "short" ? "bg-clash" : d.level === "tight" ? "bg-warn" : "bg-fit"}`} style={{ width: `${Math.min(100, (Number.isFinite(d.ratio) ? d.ratio : 1) * 100)}%` }} /></div>
                    </li>
                  ))}
                </ul>
              )}
            </Panel>
            <Panel title="Priority mix">
              <div className="grid grid-cols-4 gap-2">
                {mix.map((m) => <div key={m.p} className="rounded-md border p-3 text-center"><p className="font-mono text-xs text-muted-foreground">P{m.p}</p><p className="font-heading text-2xl font-semibold">{m.n}</p></div>)}
              </div>
              <p className="mt-2 text-xs text-muted-foreground">Open jobs, from enquiry to on site.</p>
            </Panel>
          </div>
        </>
      )}
    </div>
  );
}

function Stat({ label, value, tone, hint }: { label: string; value: string; tone?: "clash" | "warn" | undefined; hint?: string }) {
  return (
    <div className="rounded-md border bg-card p-3" title={hint}>
      <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className={`font-heading text-2xl font-semibold ${tone === "clash" ? "text-clash" : tone === "warn" ? "text-warn" : ""}`}>{value}</p>
    </div>
  );
}
function Panel({ title, action, children }: { title: string; action?: React.ReactNode; children: React.ReactNode }) {
  return (
    <section className="rounded-md border bg-card p-4">
      <div className="mb-3 flex items-center justify-between gap-2"><h2 className="font-heading text-lg font-semibold uppercase tracking-wide">{title}</h2>{action}</div>
      {children}
    </section>
  );
}
const Empty = ({ children }: { children: React.ReactNode }) => <p className="text-sm text-muted-foreground">{children}</p>;
const FlagChip = ({ f }: { f: Flag }) => <span className={`rounded-sm px-1.5 py-0.5 text-xs ${f.level === "red" ? "bg-clash-soft text-clash" : "bg-warn-soft text-warn"}`}>{f.text}</span>;
