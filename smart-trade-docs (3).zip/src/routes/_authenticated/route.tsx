import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { loadMembership, modeForRole, requiresTwoFactor } from "@/lib/session";
import { officeNav, fieldNav } from "@/lib/nav";
import { checkSession, endSession } from "@/lib/session-guard";

const OFFICE_ONLY = ["/settings", "/access-check", "/rules-test", "/ai-test", ...officeNav.map((n) => n.to).filter((p) => p !== "/messages")];
const FIELD_ONLY = fieldNav.map((n) => n.to).filter((p) => p !== "/messages");

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async ({ location }) => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/auth" });

    const membership = await loadMembership(data.user.id);
    if (!membership) throw redirect({ to: "/no-workspace" });

    if (requiresTwoFactor(membership.role)) {
      const { data: aal } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
      if (aal?.currentLevel !== "aal2") throw redirect({ to: "/two-factor" });
    }

    // Session limits (spec section 14): office 60 min idle / 12 h; field 30 days.
    const ended = await checkSession(requiresTwoFactor(membership.role));
    if (ended) { await endSession(ended); throw redirect({ to: "/auth" }); }

    const mode = modeForRole(membership.role);
    const path = location.pathname;
    if (mode === "field" && OFFICE_ONLY.some((p) => path.startsWith(p))) throw redirect({ to: "/my-day" });
    if ((path.startsWith("/access-check") || path.startsWith("/rules-test") || path.startsWith("/ai-test")) && membership.role !== "owner") throw redirect({ to: "/overview" });
    if (mode === "office" && FIELD_ONLY.some((p) => path.startsWith(p))) throw redirect({ to: "/overview" });

    return { user: data.user, membership, mode };
  },
  component: () => (
    <AppShell>
      <Outlet />
    </AppShell>
  ),
});
