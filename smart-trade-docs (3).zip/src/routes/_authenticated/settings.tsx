import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/PagePlaceholder";
import { TeamInvites } from "@/components/TeamInvites";
import { BrainSettings } from "@/components/settings/BrainSettings";
import { ActivityLog, PeopleAccess } from "@/components/settings/SecuritySettings";
import { MaterialsSettings } from "@/components/settings/MaterialsSettings";
import { MoistureSettings } from "@/components/settings/MoistureSettings";
import { PlatformSettings } from "@/components/settings/PlatformSettings";
import { WorkspaceDetails, WorkspaceSettings, FinanceSettings, Closures } from "@/components/settings/SettingsForms";

const desc = "Working week, standard hours, skills, tickets, hazards, leave types, depot and team.";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({
    meta: [
      { title: "Settings — Trade Brain" },
      { name: "description", content: desc },
      { property: "og:title", content: "Settings — Trade Brain" },
      { property: "og:description", content: desc },
    ],
  }),
  component: Page,
});

function Page() {
  // Field roles never reach this page: the _authenticated layout redirects them to My day.
  const { membership } = Route.useRouteContext();
  return (
    <PagePlaceholder title="Settings" description={desc}>
      <div className="mt-6 space-y-6">
        <WorkspaceDetails membership={membership} />
        <WorkspaceSettings membership={membership} />
        <FinanceSettings membership={membership} />
        <Closures membership={membership} />
        <MaterialsSettings membership={membership} />
        <MoistureSettings ws={membership.workspaceId} />
        <TeamInvites membership={membership} />
        <div id="people-and-access"><PeopleAccess membership={membership} /></div>
        <ActivityLog membership={membership} />
        <BrainSettings membership={membership} />
        <PlatformSettings membership={membership} />
      </div>
    </PagePlaceholder>
  );
}
