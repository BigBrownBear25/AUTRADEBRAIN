import { createFileRoute, Link, Outlet } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { adminWhoAmI } from "@/lib/admin.functions";

/** Platform admin area. Not linked from the app; every request is checked on the server, anything else is "Not found". */
export const Route = createFileRoute("/admin")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Not found — Trade Brain" },
      { name: "description", content: "Trade Brain platform administration." },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Trade Brain" },
      { property: "og:description", content: "Trade Brain platform administration." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AdminShell,
});

export function NotFoundBlock() {
  return (
    <div className="grid min-h-screen place-items-center bg-background px-4">
      <div className="text-center">
        <h1 className="font-heading text-4xl font-semibold uppercase">Not found</h1>
        <p className="mt-2 text-sm text-muted-foreground">There's nothing at this address.</p>
        <Link to="/" className="mt-4 inline-block text-sm underline">Go home</Link>
      </div>
    </div>
  );
}

function AdminShell() {
  const who = useServerFn(adminWhoAmI);
  const q = useQuery({ queryKey: ["admin-who"], queryFn: () => who(), retry: false, refetchInterval: 5 * 60_000 });
  if (q.isLoading) return <div className="p-6 text-sm text-muted-foreground">…</div>;
  if (q.error || !q.data) return <NotFoundBlock />;
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-nav text-nav-foreground">
        <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3">
          <Link to="/admin" className="font-heading text-xl font-semibold uppercase">Trade Brain · Platform</Link>
          <span className="text-xs opacity-75">{q.data.role} · health only, never workspace content</span>
          <Link to="/overview" className="ml-auto text-sm underline">Back to the app</Link>
        </div>
      </header>
      <main className="mx-auto max-w-7xl px-4 py-6"><Outlet /></main>
    </div>
  );
}
