import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { adminSetBilling, adminSetFlag, adminWorkspace } from "@/lib/admin.functions";
import { FN_LABEL, KILLABLE, flagName } from "@/lib/platform/flags";
import { bytes, when } from "./admin.index";
import { NotFoundBlock } from "./admin";

export const Route = createFileRoute("/admin/workspaces/$id")({ component: WorkspacePage });

const STATUSES = ["trial", "active", "past_due", "paused", "cancelled"];

function WorkspacePage() {
  const { id } = Route.useParams();
  const qc = useQueryClient();
  const get = useServerFn(adminWorkspace), setFlag = useServerFn(adminSetFlag), setBilling = useServerFn(adminSetBilling);
  const q = useQuery({ queryKey: ["admin-ws", id], queryFn: () => get({ data: { id } }), retry: false });
  const [b, setB] = useState({ plan: "trial", status: "trial", seats: 0, price: 0, notes: "" });
  useEffect(() => { if (q.data) setB(q.data.billing); }, [q.data]);

  if (q.error) return <NotFoundBlock />;
  if (!q.data) return <p className="text-sm text-muted-foreground">Loading…</p>;
  const w = q.data;
  const state = (fn: string) => {
    const mine = w.flags.find((f) => f.workspace_id === id && f.flag === flagName(fn));
    const all = w.flags.find((f) => f.workspace_id === null && f.flag === flagName(fn));
    return { off: mine ? !mine.enabled : false, everyoneOff: all ? !all.enabled : false };
  };
  async function toggle(fn: string, enabled: boolean) {
    const reason = enabled ? "" : window.prompt(`Switch ${FN_LABEL[fn] ?? fn} off for ${w.name}. Reason?`) ?? "";
    if (!enabled && !reason) return;
    try { await setFlag({ data: { workspaceId: id, fn, enabled, reason } }); qc.invalidateQueries({ queryKey: ["admin-ws", id] }); toast.success("Saved"); }
    catch (e) { toast.error((e as Error).message); }
  }
  async function save() {
    try { await setBilling({ data: { workspaceId: id, ...b } }); qc.invalidateQueries({ queryKey: ["admin-ws", id] }); toast.success("Saved"); }
    catch (e) { toast.error((e as Error).message); }
  }

  return (
    <div className="space-y-6">
      <div>
        <Link to="/admin" className="text-sm underline">← All workspaces</Link>
        <h1 className="mt-1 font-heading text-3xl font-semibold uppercase">{w.name}</h1>
        <p className="text-sm text-muted-foreground">Owner {w.owner} · since {when(w.created_at)} · last activity {when(w.lastActivity)}</p>
        <p className="text-xs text-muted-foreground">Health only. Jobs, chat, files, finance and people's details are not shown here.</p>
      </div>

      <section className="grid gap-4 md:grid-cols-2">
        <div className="rounded-md border bg-card p-4">
          <h2 className="font-heading text-xl font-semibold uppercase">Plan</h2>
          <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
            <label className="space-y-1">Plan<Input value={b.plan} onChange={(e) => setB({ ...b, plan: e.target.value })} /></label>
            <label className="space-y-1">Status
              <select className="h-10 w-full rounded-md border bg-background px-2" value={b.status} onChange={(e) => setB({ ...b, status: e.target.value })}>
                {STATUSES.map((s) => <option key={s} value={s}>{s.replace("_", " ")}</option>)}
              </select>
            </label>
            <label className="space-y-1">Seats<Input type="number" value={b.seats} onChange={(e) => setB({ ...b, seats: Number(e.target.value) })} /></label>
            <label className="space-y-1">Price (AUD / month)<Input type="number" value={b.price} onChange={(e) => setB({ ...b, price: Number(e.target.value) })} /></label>
            <label className="col-span-2 space-y-1">Notes<Textarea value={b.notes} onChange={(e) => setB({ ...b, notes: e.target.value })} /></label>
          </div>
          <Button className="mt-3" size="sm" onClick={save}>Save</Button>
        </div>
        <div className="rounded-md border bg-card p-4 text-sm">
          <h2 className="font-heading text-xl font-semibold uppercase">Usage this month</h2>
          <p className="mt-2">SMS {w.sms} · Email {w.email} · Storage {bytes(w.storageBytes)}</p>
          <h3 className="mt-3 font-semibold">AI spend by function</h3>
          {Object.keys(w.spend).length === 0 ? <p className="text-muted-foreground">None.</p> : (
            <ul>{Object.entries(w.spend).map(([k, v]) => <li key={k}>{FN_LABEL[k] ?? k}: ${v.toFixed(2)}</li>)}</ul>
          )}
        </div>
      </section>

      <section className="rounded-md border bg-card p-4">
        <h2 className="font-heading text-xl font-semibold uppercase">Users</h2>
        <table className="mt-2 w-full text-left text-sm">
          <thead className="text-xs uppercase text-muted-foreground"><tr><th className="py-1">Name</th><th>Role</th><th>Last sign-in</th></tr></thead>
          <tbody className="divide-y">{w.users.map((u, i) => <tr key={i}><td className="py-1.5">{u.name}</td><td>{u.role}</td><td>{when(u.lastSignIn)}</td></tr>)}</tbody>
        </table>
      </section>

      <section className="rounded-md border bg-card p-4">
        <h2 className="font-heading text-xl font-semibold uppercase">Brain switches for this workspace</h2>
        <ul className="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {["all", ...KILLABLE].map((fn) => {
            const s = state(fn);
            return (
              <li key={fn} className="flex items-center justify-between rounded border px-3 py-2 text-sm">
                <span className={s.off || s.everyoneOff ? "font-medium text-clash" : ""}>{fn === "all" ? "Whole Brain" : FN_LABEL[fn] ?? fn}{s.everyoneOff && <span className="ml-1 text-xs">(off for everyone)</span>}</span>
                <Switch checked={!s.off} onCheckedChange={(v) => toggle(fn, v)} aria-label={`${fn} on`} />
              </li>
            );
          })}
        </ul>
      </section>

      <section className="rounded-md border bg-card p-4">
        <h2 className="font-heading text-xl font-semibold uppercase">Recent errors</h2>
        {w.errors.length === 0 ? <p className="mt-2 text-sm text-muted-foreground">None.</p> : (
          <ul className="mt-2 divide-y text-sm">{w.errors.map((r, i) => <li key={i} className="py-1.5"><span className="font-mono text-xs">{when(r.at)}</span> · {r.fn} · {r.message}</li>)}</ul>
        )}
      </section>

      <section className="rounded-md border bg-card p-4">
        <h2 className="font-heading text-xl font-semibold uppercase">Platform audit</h2>
        <ul className="mt-2 divide-y text-sm">
          {w.audit.map((a) => <li key={a.id} className="py-1.5"><span className="font-mono text-xs">{when(a.at)}</span> · {a.admin} · <span className="font-medium">{a.action}</span> {Object.keys(a.detail as object ?? {}).length ? <span className="text-xs text-muted-foreground">{JSON.stringify(a.detail)}</span> : null}</li>)}
        </ul>
      </section>
    </div>
  );
}
