import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Switch } from "@/components/ui/switch";
import { adminDashboard, adminErrors, adminPlatformFlags, adminSetFlag, adminWorkspaces } from "@/lib/admin.functions";
import { jobHealth, JOB_LABEL } from "@/lib/rules/job-health";
import { FN_LABEL, KILLABLE, flagName } from "@/lib/platform/flags";

export const Route = createFileRoute("/admin/")({ component: Dashboard });

export const bytes = (n: number) => (n > 1e9 ? `${(n / 1e9).toFixed(1)} GB` : n > 1e6 ? `${(n / 1e6).toFixed(1)} MB` : `${Math.round(n / 1e3)} KB`);
export const when = (s: string | null) => (s ? new Date(s).toLocaleString("en-AU", { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" }) : "—");

function Stat({ label, value, red }: { label: string; value: string | number; red?: boolean }) {
  return (
    <div className={`rounded-md border bg-card px-4 py-3 ${red ? "border-clash" : ""}`}>
      <div className="text-xs uppercase text-muted-foreground">{label}</div>
      <div className={`font-heading text-3xl font-semibold ${red ? "text-clash" : ""}`}>{value}</div>
    </div>
  );
}

function Dashboard() {
  const qc = useQueryClient();
  const dash = useServerFn(adminDashboard), list = useServerFn(adminWorkspaces), errs = useServerFn(adminErrors), pf = useServerFn(adminPlatformFlags), setFlag = useServerFn(adminSetFlag);
  const d = useQuery({ queryKey: ["admin-dash"], queryFn: () => dash() });
  const w = useQuery({ queryKey: ["admin-ws"], queryFn: () => list() });
  const e = useQuery({ queryKey: ["admin-errors"], queryFn: () => errs() });
  const f = useQuery({ queryKey: ["admin-pflags"], queryFn: () => pf() });

  if (d.error) return <p className="text-sm text-clash">{(d.error as Error).message}</p>;
  if (!d.data) return <p className="text-sm text-muted-foreground">Loading…</p>;
  const x = d.data;
  const jobs = ["watcher", "overnight", "email_intake"];
  const off = (fn: string) => (f.data ?? []).some((r) => r.flag === flagName(fn) && !r.enabled);

  async function toggle(fn: string, enabled: boolean) {
    const reason = enabled ? "" : window.prompt(`Switch ${FN_LABEL[fn] ?? fn} off for everyone. Reason?`) ?? "";
    if (!enabled && !reason) return;
    try { await setFlag({ data: { workspaceId: null, fn, enabled, reason } }); qc.invalidateQueries({ queryKey: ["admin-pflags"] }); toast.success("Saved"); }
    catch (err) { toast.error((err as Error).message); }
  }

  return (
    <div className="space-y-6">
      <section className="grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-6">
        <Stat label="Workspaces" value={x.workspaces} />
        {Object.entries(x.byStatus).map(([k, v]) => <Stat key={k} label={k.replace("_", " ")} value={v} red={k === "past_due"} />)}
        <Stat label="Active today" value={x.activeToday} />
        <Stat label="Active this week" value={x.activeWeek} />
        <Stat label="Jobs this month" value={x.jobsThisMonth} />
        <Stat label="AI spend this month" value={`$${x.aiSpendAud.toFixed(2)}`} />
        <Stat label="SMS this month" value={x.sms} />
        <Stat label="Email this month" value={x.email} />
        <Stat label="Storage used" value={bytes(x.storageBytes)} />
        <Stat label="Errors (24 h)" value={x.errors24h} red={x.errors24h > 0} />
      </section>

      <section className="rounded-md border bg-card p-4">
        <h2 className="font-heading text-xl font-semibold uppercase">Background work</h2>
        <ul className="mt-2 divide-y text-sm">
          {jobs.map((j) => {
            const r = x.jobRuns.find((y) => y.job === j);
            const h = jobHealth(r, j);
            return (
              <li key={j} className="flex flex-wrap items-center gap-3 py-2">
                <span className={`h-2.5 w-2.5 rounded-full ${h.late ? "bg-clash" : "bg-fit"}`} />
                <span className="w-36 font-medium">{JOB_LABEL[j] ?? j}</span>
                <span className={h.late ? "text-clash" : "text-muted-foreground"}>Last success {when(r?.last_ok_at ?? null)}{h.reason ? ` · ${h.reason}` : ""}</span>
              </li>
            );
          })}
        </ul>
      </section>

      <section className="rounded-md border bg-card p-4">
        <h2 className="font-heading text-xl font-semibold uppercase">Workspaces</h2>
        <div className="mt-2 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b text-xs uppercase text-muted-foreground">
              <tr>{["Workspace", "Owner", "Plan", "Status", "Seats", "Price", "People", "Last activity", "AI this month", "Storage"].map((h) => <th key={h} className="px-2 py-2">{h}</th>)}</tr>
            </thead>
            <tbody className="divide-y">
              {(w.data ?? []).map((r) => (
                <tr key={r.id}>
                  <td className="px-2 py-2"><Link to="/admin/workspaces/$id" params={{ id: r.id }} className="font-medium underline">{r.name}</Link></td>
                  <td className="px-2 py-2">{r.owner}</td>
                  <td className="px-2 py-2">{r.plan}</td>
                  <td className={`px-2 py-2 ${r.status === "past_due" ? "text-clash" : ""}`}>{r.status.replace("_", " ")}</td>
                  <td className="px-2 py-2">{r.seats}</td>
                  <td className="px-2 py-2">${r.price.toFixed(2)}</td>
                  <td className="px-2 py-2">{r.people}</td>
                  <td className="px-2 py-2">{when(r.lastActivity)}</td>
                  <td className="px-2 py-2">${r.aiSpendAud.toFixed(2)}</td>
                  <td className="px-2 py-2">{bytes(r.storageBytes)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="rounded-md border bg-card p-4">
        <h2 className="font-heading text-xl font-semibold uppercase">Kill switches — everyone</h2>
        <p className="text-sm text-muted-foreground">Turning one off stops that Brain function in every workspace with a clear message. Everything else keeps working.</p>
        <ul className="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {["all", ...KILLABLE].map((fn) => (
            <li key={fn} className="flex items-center justify-between rounded border px-3 py-2 text-sm">
              <span className={off(fn) ? "font-medium text-clash" : ""}>{fn === "all" ? "Whole Brain" : FN_LABEL[fn] ?? fn}</span>
              <Switch checked={!off(fn)} onCheckedChange={(v) => toggle(fn, v)} aria-label={`${fn} on`} />
            </li>
          ))}
        </ul>
      </section>

      <section className="rounded-md border bg-card p-4">
        <h2 className="font-heading text-xl font-semibold uppercase">Errors in the last 24 hours</h2>
        {(e.data ?? []).length === 0 ? <p className="mt-2 text-sm text-muted-foreground">None.</p> : (
          <ul className="mt-2 divide-y text-sm">
            {e.data!.map((r) => <li key={r.id} className="py-1.5"><span className="font-mono text-xs">{when(r.at)}</span> · <span className="font-medium">{r.fn}</span> · {r.message}{r.workspace_id ? <> · <Link to="/admin/workspaces/$id" params={{ id: r.workspace_id }} className="underline">workspace</Link></> : null}</li>)}
          </ul>
        )}
      </section>
    </div>
  );
}
