import { createFileRoute, redirect, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { AuthCard } from "@/components/AuthCard";
import { Button } from "@/components/ui/button";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";

export const Route = createFileRoute("/two-factor")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Two-factor sign-in — Trade Brain" },
      { name: "description", content: "Confirm your sign-in with an authenticator app." },
      { property: "og:title", content: "Two-factor sign-in — Trade Brain" },
      { property: "og:description", content: "Confirm your sign-in with an authenticator app." },
    ],
  }),
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/auth" });
  },
  component: TwoFactorPage,
});

type Enroll = { factorId: string; qr: string; secret: string };

function TwoFactorPage() {
  const navigate = useNavigate();
  const [factorId, setFactorId] = useState<string | null>(null);
  const [enroll, setEnroll] = useState<Enroll | null>(null);
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      const { data, error } = await supabase.auth.mfa.listFactors();
      if (error) { toast.error(error.message); return; }
      const verified = data.totp.find((f) => f.status === "verified");
      if (verified) return setFactorId(verified.id);
      // Clear half-finished enrolments, then start a fresh one.
      for (const f of data.all.filter((f) => f.status === "unverified")) {
        await supabase.auth.mfa.unenroll({ factorId: f.id });
      }
      const res = await supabase.auth.mfa.enroll({ factorType: "totp", friendlyName: "Authenticator app" });
      if (res.error) { toast.error(res.error.message); return; }
      setFactorId(res.data.id);
      setEnroll({ factorId: res.data.id, qr: res.data.totp.qr_code, secret: res.data.totp.secret });
    })();
  }, []);

  const verify = async (e: FormEvent) => {
    e.preventDefault();
    if (!factorId) return;
    setBusy(true);
    const { error } = await supabase.auth.mfa.challengeAndVerify({ factorId, code });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    navigate({ to: "/", replace: true });
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };

  return (
    <AuthCard
      title="Two-factor sign-in"
      subtitle={enroll ? "Owner and office accounts need an authenticator app. Scan this code with Google Authenticator, Microsoft Authenticator or 1Password." : "Enter the 6-digit code from your authenticator app."}
    >
      {enroll && (
        <div className="mb-4 flex flex-col items-center gap-2">
          <img src={enroll.qr} alt="Authenticator QR code" className="h-44 w-44 rounded-sm bg-white p-2" />
          <p className="text-center text-xs text-muted-foreground">
            Can't scan? Enter this key: <span className="font-mono break-all">{enroll.secret}</span>
          </p>
        </div>
      )}
      <form onSubmit={verify} className="space-y-4">
        <InputOTP maxLength={6} value={code} onChange={setCode} autoFocus>
          <InputOTPGroup>
            {[0, 1, 2, 3, 4, 5].map((i) => <InputOTPSlot key={i} index={i} className="h-12 w-12 text-lg" />)}
          </InputOTPGroup>
        </InputOTP>
        <Button type="submit" className="h-11 w-full" disabled={busy || !factorId || code.length !== 6}>Confirm</Button>
      </form>
      <button className="mt-4 text-sm text-primary underline" onClick={signOut}>Sign out</button>
    </AuthCard>
  );
}
