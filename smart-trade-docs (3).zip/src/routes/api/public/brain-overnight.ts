import { createFileRoute } from "@tanstack/react-router";

/** Scheduled every 15 minutes; each workspace runs its 03:30 draft and Monday 03:45 look-ahead once in local time. */
export const Route = createFileRoute("/api/public/brain-overnight")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { cronAllowed } = await import("@/lib/brain/cron.server");
        const { recordJobRun } = await import("@/lib/brain/job-runs.server");
        if (!(await cronAllowed(request))) return new Response("Forbidden", { status: 403 });
        const { runOvernight } = await import("@/lib/brain/watch.server");
        try { const ran = await runOvernight(); await recordJobRun("overnight"); return Response.json({ ok: true, ran }); }
        catch (e) { console.error("brain-overnight", e); await recordJobRun("overnight", e); return Response.json({ ok: false }, { status: 500 }); }
      },
    },
  },
});
