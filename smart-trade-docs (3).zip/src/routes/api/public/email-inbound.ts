import { createFileRoute } from "@tanstack/react-router";

/**
 * email-inbound: the email provider (Postmark inbound JSON or SendGrid Inbound Parse) posts here
 * with ?token=INBOUND_EMAIL_TOKEN. The workspace is picked from the "+key" on the recipient address.
 * A job code in the subject files the email straight onto that job; otherwise it waits, unfiled,
 * with Claude's suggested job.
 */
type Parsed = { from: string; to: string[]; subject: string; text: string; files: { name: string; mime: string; data: Uint8Array }[] };

function safeEqual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
const b64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
const stripHtml = (h: string) => h.replace(/<style[\s\S]*?<\/style>/gi, "").replace(/<br\s*\/?>|<\/p>/gi, "\n").replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&");

async function parse(request: Request): Promise<Parsed> {
  const type = request.headers.get("content-type") ?? "";
  if (type.includes("application/json")) {
    const p = (await request.json()) as any;
    const to = [p.OriginalRecipient, p.To, ...(p.ToFull ?? []).map((t: any) => t.Email), ...(p.CcFull ?? []).map((t: any) => t.Email), ...(p.ToFull ?? []).map((t: any) => t.MailboxHash ? `+${t.MailboxHash}@` : "")].filter(Boolean);
    return {
      from: p.FromFull?.Email ?? p.From ?? "", to, subject: p.Subject ?? "",
      text: p.TextBody || stripHtml(p.HtmlBody ?? ""),
      files: (p.Attachments ?? []).map((a: any) => ({ name: a.Name, mime: a.ContentType ?? "application/octet-stream", data: b64(a.Content ?? "") })),
    };
  }
  const f = await request.formData();
  const files: Parsed["files"] = [];
  for (const [, v] of f.entries()) if (typeof v !== "string") files.push({ name: v.name, mime: v.type || "application/octet-stream", data: new Uint8Array(await v.arrayBuffer()) });
  const s = (k: string) => (typeof f.get(k) === "string" ? (f.get(k) as string) : "");
  return { from: s("from"), to: [s("to"), s("cc"), s("envelope")], subject: s("subject"), text: s("text") || stripHtml(s("html")), files };
}

export const Route = createFileRoute("/api/public/email-inbound")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = process.env["INBOUND_EMAIL_TOKEN"];
        const token = new URL(request.url).searchParams.get("token") ?? "";
        if (!secret || !safeEqual(token, secret)) return new Response("Forbidden", { status: 403 });
        const { recordJobRun } = await import("@/lib/brain/job-runs.server");
        try {
          const res = await handle(request);
          await recordJobRun("email_intake", res.status >= 500 ? new Error(`Intake answered ${res.status}: ${await res.clone().text()}`) : undefined);
          return res;
        } catch (e) {
          console.error("email-inbound", e); await recordJobRun("email_intake", e);
          return new Response("Intake failed", { status: 500 });
        }
      },
    },
  },
});

async function handle(request: Request): Promise<Response> {
        let mail: Parsed;
        try { mail = await parse(request); } catch { return new Response("Bad payload", { status: 400 }); }

        const keys = mail.to.join(" ").toLowerCase().match(/\+([a-z0-9]{6,20})@/g)?.map((k) => k.slice(1, -1)) ?? [];
        if (!keys.length) return new Response("No workspace key on the address", { status: 200 });

        const { supabaseAdmin: admin } = await import("@/integrations/supabase/client.server");
        const intake = await import("@/lib/email-intake.server");
        const { data: ws } = await admin.from("workspaces").select("id, code_prefix").in("inbound_key", keys).limit(1).maybeSingle();
        // Answer 200 so the provider doesn't retry for an unknown address.
        if (!ws) return new Response("Unknown address", { status: 200 });

        const { data: row, error } = await admin.from("inbound_emails").insert({
          workspace_id: ws.id, from_address: mail.from.slice(0, 300), subject: mail.subject.slice(0, 500), body_text: mail.text.slice(0, 50000),
        }).select("id").single();
        if (error || !row) return new Response("Couldn't store", { status: 500 });

        const files: { name: string; mime: string; size: number; path: string }[] = [];
        for (const file of mail.files.slice(0, 10)) {
          if (file.data.byteLength > 15 * 1024 * 1024) continue;
          const name = (file.name || "file").replace(/[^\w.\-]+/g, "_").slice(0, 120);
          const path = `${ws.id}/inbox/${row.id}/${name}`;
          const { error: upErr } = await admin.storage.from("job-files").upload(path, file.data, { contentType: file.mime, upsert: true });
          if (!upErr) files.push({ name, mime: file.mime, size: file.data.byteLength, path });
        }
        if (files.length) await admin.from("inbound_emails").update({ files }).eq("id", row.id);
        await admin.from("usage_events").insert({ workspace_id: ws.id, kind: "email", units: 1, detail: "inbound" });

        const code = intake.codeInSubject(mail.subject, ws.code_prefix);
        if (code) {
          const { data: job } = await admin.from("jobs").select("id").eq("workspace_id", ws.id).ilike("code", code).maybeSingle();
          if (job) {
            await intake.fileToJob(admin, row.id, job.id, null);
            return Response.json({ ok: true, filed: true });
          }
        }
        const suggestion = await intake.suggestJob(admin, ws.id, mail);
        if (suggestion) await admin.from("inbound_emails").update({ ai_suggestion: suggestion }).eq("id", row.id);
        return Response.json({ ok: true, filed: false });
}
