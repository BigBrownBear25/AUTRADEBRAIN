import { createFileRoute } from "@tanstack/react-router";

/** Scheduled every minute. Only callers presenting the stored scheduler token get in. */
export const Route = createFileRoute("/api/public/brain-watch")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { cronAllowed } = await import("@/lib/brain/cron.server");
        const { recordJobRun } = await import("@/lib/brain/job-runs.server");
        if (!(await cronAllowed(request))) return new Response("Forbidden", { status: 403 });
        const { runWatcher } = await import("@/lib/brain/watch.server");
        try {
          const processed = await runWatcher();
          const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
          await supabaseAdmin.rpc("brain_watch_sleep");
          await recordJobRun("watcher");
          return Response.json({ ok: true, workspaces: Object.keys(processed).length });
        }
        catch (e) { console.error("brain-watch", e); await recordJobRun("watcher", e); return Response.json({ ok: false }, { status: 500 }); }
      },
    },
  },
});
