import { createFileRoute } from "@tanstack/react-router";

/** Ask Trade Brain: streams the answer as newline-delimited JSON. Runs with the caller's own sign-in. */
export const Route = createFileRoute("/api/brain-ask")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { userClientFromRequest } = await import("@/lib/brain/user-client.server");
        const who = await userClientFromRequest(request);
        if (!who) return new Response(JSON.stringify({ error: "Sign in first" }), { status: 401 });
        let body: { thread_id?: string; text?: string };
        try { body = await request.json(); } catch { return new Response("Bad request", { status: 400 }); }
        const text = String(body.text ?? "").trim();
        const thread = /^[0-9a-f-]{36}$/i.test(body.thread_id ?? "") ? body.thread_id! : crypto.randomUUID();
        if (!text || text.length > 4000) return new Response(JSON.stringify({ error: "Ask something (up to 4,000 characters)." }), { status: 400 });

        const { personContext, runBrain } = await import("@/lib/brain/runner.server");
        let ctx;
        try { ctx = await personContext(who.sb, who.userId, "ask"); } catch (e) { return new Response(JSON.stringify({ error: (e as Error).message }), { status: 403 }); }
        const { data: hist } = await who.sb.from("ask_messages").select("role, content").eq("user_id", who.userId).eq("thread_id", thread).order("created_at").limit(20);
        await who.sb.from("ask_messages").insert({ workspace_id: ctx.ws, user_id: who.userId, thread_id: thread, role: "user", content: text });

        const enc = new TextEncoder();
        const stream = new ReadableStream({
          async start(ctrl) {
            const send = (o: unknown) => ctrl.enqueue(enc.encode(JSON.stringify(o) + "\n"));
            send({ t: "thread", v: thread });
            try {
              const { askTask } = await import("@/lib/brain/runner.server");
              const task = askTask(ctx.office);
              const r = await runBrain(ctx, {
                fn: "ask", feature: "ask", task, input: text,
                history: (hist ?? []).map((h) => ({ role: h.role === "brain" ? "assistant" as const : "user" as const, content: h.content })),
                onText: (t) => send({ t: "text", v: t }),
              });
              const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
              await supabaseAdmin.from("ask_messages").insert({ workspace_id: ctx.ws, user_id: who.userId, thread_id: thread, role: "brain", content: r.text || "(no answer)", tool_calls: r.toolCalls as never, proposal_ids: r.proposalIds });
              send({ t: "done", proposalIds: r.proposalIds, text: r.text });
            } catch (e) {
              send({ t: "error", v: (e as Error).message });
            }
            ctrl.close();
          },
        });
        return new Response(stream, { headers: { "Content-Type": "application/x-ndjson", "Cache-Control": "no-store" } });
      },
    },
  },
});
