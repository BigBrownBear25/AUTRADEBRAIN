import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { AuthCard } from "@/components/AuthCard";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/no-workspace")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "No workspace yet — Trade Brain" },
      { name: "description", content: "Your account isn't part of a Trade Brain workspace yet." },
      { property: "og:title", content: "No workspace yet — Trade Brain" },
      { property: "og:description", content: "Your account isn't part of a Trade Brain workspace yet." },
    ],
  }),
  component: Page,
});

function Page() {
  const navigate = useNavigate();
  return (
    <AuthCard title="No workspace yet" subtitle="Your account isn't part of a workspace. Ask your boss to invite this email address, then sign in again.">
      <div className="flex gap-2">
        <Button className="h-11" onClick={() => navigate({ to: "/", replace: true })}>Check again</Button>
        <Button variant="outline" className="h-11" onClick={async () => { await supabase.auth.signOut(); navigate({ to: "/auth", replace: true }); }}>Sign out</Button>
      </div>
    </AuthCard>
  );
}
