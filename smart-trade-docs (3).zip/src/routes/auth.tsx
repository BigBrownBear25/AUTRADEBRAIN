import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { AuthCard } from "@/components/AuthCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — Trade Brain" },
      { name: "description", content: "Sign in to Trade Brain. Accounts are by invite from your office." },
      { property: "og:title", content: "Sign in — Trade Brain" },
      { property: "og:description", content: "Sign in to Trade Brain. Accounts are by invite from your office." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const done = () => navigate({ to: "/", replace: true });

  return (
    <AuthCard title="Welcome" subtitle="Scheduling and job records for trade crews.">
      <Tabs defaultValue="password">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="password">Password</TabsTrigger>
          <TabsTrigger value="code">Email code</TabsTrigger>
          <TabsTrigger value="signup">New account</TabsTrigger>
        </TabsList>
        <TabsContent value="password"><PasswordForm onDone={done} /></TabsContent>
        <TabsContent value="code"><CodeForm onDone={done} /></TabsContent>
        <TabsContent value="signup"><SignUpForm /></TabsContent>
      </Tabs>
    </AuthCard>
  );
}

function PasswordForm({ onDone }: { onDone: () => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    onDone();
  };
  return (
    <form onSubmit={submit} className="space-y-4 pt-2">
      <Field label="Email"><Input type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
      <Field label="Password"><Input type="password" required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} /></Field>
      <Button type="submit" className="h-11 w-full" disabled={busy}>Sign in</Button>
    </form>
  );
}

function CodeForm({ onDone }: { onDone: () => void }) {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);

  const send = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.signInWithOtp({ email, options: { shouldCreateUser: false } });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    setSent(true);
    toast.success("We've emailed you a 6-digit code.");
  };

  const verify = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.verifyOtp({ email, token: code, type: "email" });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    onDone();
  };

  if (!sent) {
    return (
      <form onSubmit={send} className="space-y-4 pt-2">
        <Field label="Email"><Input type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
        <Button type="submit" className="h-11 w-full" disabled={busy}>Email me a code</Button>
      </form>
    );
  }
  return (
    <form onSubmit={verify} className="space-y-4 pt-2">
      <p className="text-sm text-muted-foreground">Enter the 6-digit code sent to {email}.</p>
      <InputOTP maxLength={6} value={code} onChange={setCode} autoFocus>
        <InputOTPGroup>
          {[0, 1, 2, 3, 4, 5].map((i) => <InputOTPSlot key={i} index={i} className="h-12 w-12 text-lg" />)}
        </InputOTPGroup>
      </InputOTP>
      <Button type="submit" className="h-11 w-full" disabled={busy || code.length !== 6}>Sign in</Button>
      <button type="button" className="text-sm text-primary underline" onClick={() => { setSent(false); setCode(""); }}>
        Use a different email
      </button>
    </form>
  );
}

function SignUpForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [sentTo, setSentTo] = useState<string | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (password.length < 12) { toast.error("Use at least 12 characters for your password."); return; }
    setBusy(true);
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { emailRedirectTo: window.location.origin },
    });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    setSentTo(email);
  };

  if (sentTo) {
    return (
      <p className="pt-4 text-sm">
        Check <strong>{sentTo}</strong> to confirm your email, then sign in here.
      </p>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-4 pt-2">
      <p className="rounded-sm bg-muted p-3 text-sm">Trade Brain is invite-only for now. Ask your office for an invite.</p>
      <Field label="Email"><Input type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
      <Field label="Password"><Input type="password" required minLength={12} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} /></Field>
      <p className="text-xs text-muted-foreground">At least 12 characters. Passwords found in known data leaks are refused. Use the same email your invite was sent to. You'll join that workspace when you first sign in.</p>
      <Button type="submit" className="h-11 w-full" disabled={busy}>Create account</Button>
    </form>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
    </div>
  );
}
