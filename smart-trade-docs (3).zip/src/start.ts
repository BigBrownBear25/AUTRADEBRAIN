import { createStart, createCsrfMiddleware, createMiddleware } from "@tanstack/react-start";

import { renderErrorPage } from "./lib/error-page";
import { attachSupabaseAuth } from "@/integrations/supabase/auth-attacher";

const errorMiddleware = createMiddleware().server(async ({ next }) => {
  try {
    return await next();
  } catch (error) {
    if (error != null && typeof error === "object" && "statusCode" in error) {
      throw error;
    }
    console.error(error);
    try { const { recordError } = await import("./lib/platform/errors.server"); await recordError("request", error); } catch { /* logging must not break the page */ }
    return new Response(renderErrorPage(), {
      status: 500,
      headers: { "content-type": "text/html; charset=utf-8" },
    });
  }
});

/** Every server function error is logged to error_events (function, workspace, scrubbed message), then re-thrown unchanged. */
const errorEventsMiddleware = createMiddleware({ type: "function" }).server(async ({ next, serverFnMeta }) => {
  try {
    return await next();
  } catch (error) {
    if (!(error instanceof Response)) {
      const { recordError, workspaceForBearer } = await import("./lib/platform/errors.server");
      const { getRequest } = await import("@tanstack/react-start/server");
      let ws: string | null = null;
      try { ws = await workspaceForBearer(getRequest().headers.get("authorization")); } catch { /* no request */ }
      await recordError(serverFnMeta?.name ?? "server function", error, ws);
    }
    throw error;
  }
});

/**
 * Security headers on every response (spec section 14, prompt S1). The CSP allows only this origin, the backend
 * (database, files, sign-in, live updates) and Google Fonts. Lovable's editor preview frames the app, so on preview
 * hosts frame-ancestors allows Lovable and the CSP is report-only; the published app gets the full policy.
 */
const securityHeadersMiddleware = createMiddleware().server(async ({ next, request }) => {
  const result = await next();
  const res = (result instanceof Response ? result : (result as { response?: Response }).response) as Response | undefined;
  if (!res) return result;
  const host = new URL(request.url).hostname;
  const preview = host === "localhost" || host.startsWith("id-preview--") || host.endsWith(".lovableproject.com") || host.endsWith(".lovable.dev");
  const backend = (process.env["SUPABASE_URL"] ?? import.meta.env["VITE_SUPABASE_URL"] ?? "").replace(/\/$/, "");
  const backendWs = backend.replace(/^https:/, "wss:");
  const frame = preview ? "'self' https://lovable.dev https://*.lovable.dev https://*.lovable.app https://*.lovableproject.com" : "'none'";
  const csp = [
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline'",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com data:",
    `img-src 'self' data: blob: ${backend}`,
    `media-src 'self' blob: ${backend}`,
    `connect-src 'self' ${backend} ${backendWs}`,
    "worker-src 'self'",
    "manifest-src 'self'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    `frame-ancestors ${frame}`,
  ].join("; ");
  const set = (h: Headers) => {
    h.set(preview ? "Content-Security-Policy-Report-Only" : "Content-Security-Policy", csp);
    if (preview) h.set("Content-Security-Policy", `frame-ancestors ${frame}`);
    else h.set("X-Frame-Options", "DENY");
    h.set("Strict-Transport-Security", "max-age=63072000; includeSubDomains");
    h.set("X-Content-Type-Options", "nosniff");
    h.set("Referrer-Policy", "strict-origin-when-cross-origin");
    h.set("Permissions-Policy", "camera=(self), microphone=(self), geolocation=(self), payment=(), usb=()");
  };
  try { set(res.headers); return result; } catch {
    const copy = new Response(res.body, res); set(copy.headers);
    return result instanceof Response ? copy : { ...(result as object), response: copy } as typeof result;
  }
});

// Start installs this automatically when src/start.ts is absent; defining the
// file opts out, so re-add it explicitly to keep server functions protected
// from cross-site requests.
const csrfMiddleware = createCsrfMiddleware({
  filter: (ctx) => ctx.handlerType === "serverFn",
});

export const startInstance = createStart(() => ({
  functionMiddleware: [attachSupabaseAuth, errorEventsMiddleware],
  requestMiddleware: [securityHeadersMiddleware, errorMiddleware, csrfMiddleware],
}));
