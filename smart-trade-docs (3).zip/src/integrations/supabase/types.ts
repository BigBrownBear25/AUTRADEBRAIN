export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      access_reviews: {
        Row: {
          id: string
          member_count: number
          notes: string | null
          reviewed_at: string
          reviewed_by: string
          workspace_id: string
        }
        Insert: {
          id?: string
          member_count?: number
          notes?: string | null
          reviewed_at?: string
          reviewed_by?: string
          workspace_id: string
        }
        Update: {
          id?: string
          member_count?: number
          notes?: string | null
          reviewed_at?: string
          reviewed_by?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "access_reviews_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_config: {
        Row: {
          function: string
          max_tokens: number
          max_tool_rounds: number
          model: string
          workspace_id: string
        }
        Insert: {
          function: string
          max_tokens?: number
          max_tool_rounds?: number
          model: string
          workspace_id: string
        }
        Update: {
          function?: string
          max_tokens?: number
          max_tool_rounds?: number
          model?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_config_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_runs: {
        Row: {
          at: string
          cost_aud: number
          error: string | null
          function: string
          id: string
          input_tokens: number
          model: string
          ms: number
          ok: boolean
          output_tokens: number
          tool_calls: Json
          user_id: string | null
          workspace_id: string
        }
        Insert: {
          at?: string
          cost_aud?: number
          error?: string | null
          function: string
          id?: string
          input_tokens?: number
          model: string
          ms?: number
          ok?: boolean
          output_tokens?: number
          tool_calls?: Json
          user_id?: string | null
          workspace_id: string
        }
        Update: {
          at?: string
          cost_aud?: number
          error?: string | null
          function?: string
          id?: string
          input_tokens?: number
          model?: string
          ms?: number
          ok?: boolean
          output_tokens?: number
          tool_calls?: Json
          user_id?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_runs_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      ask_messages: {
        Row: {
          content: string
          created_at: string
          id: string
          proposal_ids: string[]
          role: string
          thread_id: string
          tool_calls: Json
          user_id: string
          workspace_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          proposal_ids?: string[]
          role: string
          thread_id: string
          tool_calls?: Json
          user_id: string
          workspace_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          proposal_ids?: string[]
          role?: string
          thread_id?: string
          tool_calls?: Json
          user_id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ask_messages_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      assignments: {
        Row: {
          actual_end: string | null
          actual_start: string | null
          created_at: string
          crew_member_id: string
          date: string
          end_time: string
          id: string
          is_lead: boolean
          job_id: string
          start_time: string
          workspace_id: string
        }
        Insert: {
          actual_end?: string | null
          actual_start?: string | null
          created_at?: string
          crew_member_id: string
          date: string
          end_time: string
          id?: string
          is_lead?: boolean
          job_id: string
          start_time: string
          workspace_id: string
        }
        Update: {
          actual_end?: string | null
          actual_start?: string | null
          created_at?: string
          crew_member_id?: string
          date?: string
          end_time?: string
          id?: string
          is_lead?: boolean
          job_id?: string
          start_time?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "assignments_crew_member_id_fkey"
            columns: ["crew_member_id"]
            isOneToOne: false
            referencedRelation: "crew_members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "assignments_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      attachments: {
        Row: {
          ai_readings: Json | null
          ai_tags: string[]
          created_at: string
          created_by: string | null
          duration_s: number | null
          frame_paths: string[]
          id: string
          job_id: string
          kind: Database["public"]["Enums"]["attachment_kind"]
          message_id: string | null
          mime: string | null
          size: number | null
          storage_path: string
          transcript: string | null
          workspace_id: string
        }
        Insert: {
          ai_readings?: Json | null
          ai_tags?: string[]
          created_at?: string
          created_by?: string | null
          duration_s?: number | null
          frame_paths?: string[]
          id?: string
          job_id: string
          kind: Database["public"]["Enums"]["attachment_kind"]
          message_id?: string | null
          mime?: string | null
          size?: number | null
          storage_path: string
          transcript?: string | null
          workspace_id: string
        }
        Update: {
          ai_readings?: Json | null
          ai_tags?: string[]
          created_at?: string
          created_by?: string | null
          duration_s?: number | null
          frame_paths?: string[]
          id?: string
          job_id?: string
          kind?: Database["public"]["Enums"]["attachment_kind"]
          message_id?: string | null
          mime?: string | null
          size?: number | null
          storage_path?: string
          transcript?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "attachments_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attachments_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_log: {
        Row: {
          action: string
          actor_user_id: string | null
          after: Json | null
          at: string
          before: Json | null
          id: number
          reason: string | null
          row_id: string | null
          table_name: string
          workspace_id: string | null
        }
        Insert: {
          action: string
          actor_user_id?: string | null
          after?: Json | null
          at?: string
          before?: Json | null
          id?: never
          reason?: string | null
          row_id?: string | null
          table_name: string
          workspace_id?: string | null
        }
        Update: {
          action?: string
          actor_user_id?: string | null
          after?: Json | null
          at?: string
          before?: Json | null
          id?: never
          reason?: string | null
          row_id?: string | null
          table_name?: string
          workspace_id?: string | null
        }
        Relationships: []
      }
      brain_events: {
        Row: {
          at: string
          crew_member_id: string | null
          id: number
          job_id: string | null
          kind: string
          processed_at: string | null
          row_id: string | null
          table_name: string
          workspace_id: string
        }
        Insert: {
          at?: string
          crew_member_id?: string | null
          id?: never
          job_id?: string | null
          kind: string
          processed_at?: string | null
          row_id?: string | null
          table_name: string
          workspace_id: string
        }
        Update: {
          at?: string
          crew_member_id?: string | null
          id?: never
          job_id?: string | null
          kind?: string
          processed_at?: string | null
          row_id?: string | null
          table_name?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "brain_events_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      brain_job_flags: {
        Row: {
          flags: Json
          job_id: string
          updated_at: string
          workspace_id: string
        }
        Insert: {
          flags?: Json
          job_id: string
          updated_at?: string
          workspace_id: string
        }
        Update: {
          flags?: Json
          job_id?: string
          updated_at?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "brain_job_flags_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: true
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "brain_job_flags_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      brain_reports: {
        Row: {
          created_at: string
          data: Json
          for_date: string
          id: string
          kind: string
          summary: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          data?: Json
          for_date: string
          id?: string
          kind: string
          summary?: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          data?: Json
          for_date?: string
          id?: string
          kind?: string
          summary?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "brain_reports_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      brain_settings: {
        Row: {
          features: Json
          last_lookahead_on: string | null
          last_overnight_on: string | null
          monthly_ai_budget: number
          quiet_from: string
          quiet_to: string
          sms_auto_reminders: boolean
          sms_templates: Json
          timezone: string
          updated_at: string
          variation_price_to_builder: boolean
          workspace_id: string
        }
        Insert: {
          features?: Json
          last_lookahead_on?: string | null
          last_overnight_on?: string | null
          monthly_ai_budget?: number
          quiet_from?: string
          quiet_to?: string
          sms_auto_reminders?: boolean
          sms_templates?: Json
          timezone?: string
          updated_at?: string
          variation_price_to_builder?: boolean
          workspace_id: string
        }
        Update: {
          features?: Json
          last_lookahead_on?: string | null
          last_overnight_on?: string | null
          monthly_ai_budget?: number
          quiet_from?: string
          quiet_to?: string
          sms_auto_reminders?: boolean
          sms_templates?: Json
          timezone?: string
          updated_at?: string
          variation_price_to_builder?: boolean
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "brain_settings_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: true
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      call_logs: {
        Row: {
          actions: Json
          at: string
          audio_attachment_id: string | null
          contact_name: string
          contact_role: string
          direction: string
          id: string
          job_id: string | null
          logged_by: string | null
          summary: string
          transcript: string | null
          workspace_id: string
        }
        Insert: {
          actions?: Json
          at?: string
          audio_attachment_id?: string | null
          contact_name?: string
          contact_role?: string
          direction?: string
          id?: string
          job_id?: string | null
          logged_by?: string | null
          summary?: string
          transcript?: string | null
          workspace_id: string
        }
        Update: {
          actions?: Json
          at?: string
          audio_attachment_id?: string | null
          contact_name?: string
          contact_role?: string
          direction?: string
          id?: string
          job_id?: string | null
          logged_by?: string | null
          summary?: string
          transcript?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "call_logs_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "call_logs_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      capture_feedback: {
        Row: {
          candidates: Json
          changed: boolean
          chosen_job_id: string | null
          created_at: string
          id: string
          input: string
          message_id: string | null
          moved: boolean
          no_job: string | null
          preselected_job_id: string | null
          proposal_ids: string[]
          user_id: string
          workspace_id: string
        }
        Insert: {
          candidates?: Json
          changed?: boolean
          chosen_job_id?: string | null
          created_at?: string
          id?: string
          input: string
          message_id?: string | null
          moved?: boolean
          no_job?: string | null
          preselected_job_id?: string | null
          proposal_ids?: string[]
          user_id: string
          workspace_id: string
        }
        Update: {
          candidates?: Json
          changed?: boolean
          chosen_job_id?: string | null
          created_at?: string
          id?: string
          input?: string
          message_id?: string | null
          moved?: boolean
          no_job?: string | null
          preselected_job_id?: string | null
          proposal_ids?: string[]
          user_id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "capture_feedback_chosen_job_id_fkey"
            columns: ["chosen_job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "capture_feedback_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "capture_feedback_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      catalogue_items: {
        Row: {
          active: boolean
          brand: string | null
          category: string
          colour: string | null
          coverage: number | null
          coverage_basis: string | null
          created_at: string
          hazard_tags: string[]
          id: string
          import_id: string | null
          install_url: string | null
          lead_time_days: number | null
          name: string
          pack_size: number | null
          range: string | null
          reference_item_id: string | null
          sds_url: string | null
          source: string
          spec_url: string | null
          stocked: boolean
          supplier_code: string | null
          supplier_id: string | null
          unit: string
          updated_at: string
          warranty_url: string | null
          waste_pct: number | null
          workspace_id: string
        }
        Insert: {
          active?: boolean
          brand?: string | null
          category?: string
          colour?: string | null
          coverage?: number | null
          coverage_basis?: string | null
          created_at?: string
          hazard_tags?: string[]
          id?: string
          import_id?: string | null
          install_url?: string | null
          lead_time_days?: number | null
          name: string
          pack_size?: number | null
          range?: string | null
          reference_item_id?: string | null
          sds_url?: string | null
          source?: string
          spec_url?: string | null
          stocked?: boolean
          supplier_code?: string | null
          supplier_id?: string | null
          unit?: string
          updated_at?: string
          warranty_url?: string | null
          waste_pct?: number | null
          workspace_id: string
        }
        Update: {
          active?: boolean
          brand?: string | null
          category?: string
          colour?: string | null
          coverage?: number | null
          coverage_basis?: string | null
          created_at?: string
          hazard_tags?: string[]
          id?: string
          import_id?: string | null
          install_url?: string | null
          lead_time_days?: number | null
          name?: string
          pack_size?: number | null
          range?: string | null
          reference_item_id?: string | null
          sds_url?: string | null
          source?: string
          spec_url?: string | null
          stocked?: boolean
          supplier_code?: string | null
          supplier_id?: string | null
          unit?: string
          updated_at?: string
          warranty_url?: string | null
          waste_pct?: number | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "catalogue_items_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "catalogue_items_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      catalogue_prices: {
        Row: {
          cost: number | null
          created_at: string
          created_by: string | null
          effective_from: string
          id: string
          import_id: string | null
          item_id: string
          markup_pct: number | null
          sell: number | null
          workspace_id: string
        }
        Insert: {
          cost?: number | null
          created_at?: string
          created_by?: string | null
          effective_from?: string
          id?: string
          import_id?: string | null
          item_id: string
          markup_pct?: number | null
          sell?: number | null
          workspace_id: string
        }
        Update: {
          cost?: number | null
          created_at?: string
          created_by?: string | null
          effective_from?: string
          id?: string
          import_id?: string | null
          item_id?: string
          markup_pct?: number | null
          sell?: number | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "catalogue_prices_item_id_fkey"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "catalogue_items"
            referencedColumns: ["id"]
          },
        ]
      }
      closures: {
        Row: {
          created_at: string
          from_date: string
          id: string
          kind: string
          name: string
          state: string | null
          to_date: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          from_date: string
          id?: string
          kind?: string
          name: string
          state?: string | null
          to_date: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          from_date?: string
          id?: string
          kind?: string
          name?: string
          state?: string | null
          to_date?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "closures_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      companion_rules: {
        Row: {
          add_category: string
          created_at: string
          default_item_id: string | null
          id: string
          note: string | null
          when_category: string
          workspace_id: string
        }
        Insert: {
          add_category: string
          created_at?: string
          default_item_id?: string | null
          id?: string
          note?: string | null
          when_category: string
          workspace_id: string
        }
        Update: {
          add_category?: string
          created_at?: string
          default_item_id?: string | null
          id?: string
          note?: string | null
          when_category?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "companion_rules_default_item_id_fkey"
            columns: ["default_item_id"]
            isOneToOne: false
            referencedRelation: "catalogue_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "companion_rules_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      crew_members: {
        Row: {
          active: boolean
          base_lat: number | null
          base_lng: number | null
          base_suburb: string | null
          company_name: string | null
          created_at: string
          email: string | null
          id: string
          is_demo: boolean
          is_subcontractor: boolean
          name: string
          phone: string | null
          role: Database["public"]["Enums"]["crew_role"]
          skills: string[] | null
          sort: number
          workspace_id: string
        }
        Insert: {
          active?: boolean
          base_lat?: number | null
          base_lng?: number | null
          base_suburb?: string | null
          company_name?: string | null
          created_at?: string
          email?: string | null
          id?: string
          is_demo?: boolean
          is_subcontractor?: boolean
          name: string
          phone?: string | null
          role?: Database["public"]["Enums"]["crew_role"]
          skills?: string[] | null
          sort?: number
          workspace_id: string
        }
        Update: {
          active?: boolean
          base_lat?: number | null
          base_lng?: number | null
          base_suburb?: string | null
          company_name?: string | null
          created_at?: string
          email?: string | null
          id?: string
          is_demo?: boolean
          is_subcontractor?: boolean
          name?: string
          phone?: string | null
          role?: Database["public"]["Enums"]["crew_role"]
          skills?: string[] | null
          sort?: number
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "crew_members_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      crew_rates: {
        Row: {
          crew_member_id: string
          day_rate: number
          workspace_id: string
        }
        Insert: {
          crew_member_id: string
          day_rate: number
          workspace_id: string
        }
        Update: {
          crew_member_id?: string
          day_rate?: number
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "crew_rates_crew_member_id_fkey"
            columns: ["crew_member_id"]
            isOneToOne: true
            referencedRelation: "crew_members"
            referencedColumns: ["id"]
          },
        ]
      }
      crew_tickets: {
        Row: {
          crew_member_id: string
          evidence_path: string | null
          expires_on: string | null
          id: string
          ticket_type: string
          workspace_id: string
        }
        Insert: {
          crew_member_id: string
          evidence_path?: string | null
          expires_on?: string | null
          id?: string
          ticket_type: string
          workspace_id: string
        }
        Update: {
          crew_member_id?: string
          evidence_path?: string | null
          expires_on?: string | null
          id?: string
          ticket_type?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "crew_tickets_crew_member_id_fkey"
            columns: ["crew_member_id"]
            isOneToOne: false
            referencedRelation: "crew_members"
            referencedColumns: ["id"]
          },
        ]
      }
      dependencies: {
        Row: {
          blocks_start: boolean
          created_at: string
          description: string
          due_date: string | null
          id: string
          job_id: string
          kind: Database["public"]["Enums"]["dependency_kind"]
          party: string | null
          status: Database["public"]["Enums"]["dependency_status"]
          workspace_id: string
        }
        Insert: {
          blocks_start?: boolean
          created_at?: string
          description: string
          due_date?: string | null
          id?: string
          job_id: string
          kind?: Database["public"]["Enums"]["dependency_kind"]
          party?: string | null
          status?: Database["public"]["Enums"]["dependency_status"]
          workspace_id: string
        }
        Update: {
          blocks_start?: boolean
          created_at?: string
          description?: string
          due_date?: string | null
          id?: string
          job_id?: string
          kind?: Database["public"]["Enums"]["dependency_kind"]
          party?: string | null
          status?: Database["public"]["Enums"]["dependency_status"]
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "dependencies_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      drive_cache: {
        Row: {
          fetched_at: string
          from_key: string
          km: number
          minutes: number
          to_key: string
          workspace_id: string
        }
        Insert: {
          fetched_at?: string
          from_key: string
          km: number
          minutes: number
          to_key: string
          workspace_id: string
        }
        Update: {
          fetched_at?: string
          from_key?: string
          km?: number
          minutes?: number
          to_key?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "drive_cache_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      error_events: {
        Row: {
          at: string
          fn: string
          id: number
          message: string
          workspace_id: string | null
        }
        Insert: {
          at?: string
          fn: string
          id?: number
          message: string
          workspace_id?: string | null
        }
        Update: {
          at?: string
          fn?: string
          id?: number
          message?: string
          workspace_id?: string | null
        }
        Relationships: []
      }
      inbound_emails: {
        Row: {
          ai_suggestion: Json | null
          body_text: string
          filed_at: string | null
          filed_by: string | null
          files: Json
          from_address: string
          id: string
          job_id: string | null
          message_id: string | null
          received_at: string
          status: Database["public"]["Enums"]["inbound_status"]
          subject: string
          workspace_id: string
        }
        Insert: {
          ai_suggestion?: Json | null
          body_text?: string
          filed_at?: string | null
          filed_by?: string | null
          files?: Json
          from_address?: string
          id?: string
          job_id?: string | null
          message_id?: string | null
          received_at?: string
          status?: Database["public"]["Enums"]["inbound_status"]
          subject?: string
          workspace_id: string
        }
        Update: {
          ai_suggestion?: Json | null
          body_text?: string
          filed_at?: string | null
          filed_by?: string | null
          files?: Json
          from_address?: string
          id?: string
          job_id?: string | null
          message_id?: string | null
          received_at?: string
          status?: Database["public"]["Enums"]["inbound_status"]
          subject?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "inbound_emails_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "inbound_emails_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "inbound_emails_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      job_finance: {
        Row: {
          job_id: string
          notes: string | null
          quote_value: number | null
          workspace_id: string
        }
        Insert: {
          job_id: string
          notes?: string | null
          quote_value?: number | null
          workspace_id: string
        }
        Update: {
          job_id?: string
          notes?: string | null
          quote_value?: number | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "job_finance_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: true
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      job_runs: {
        Row: {
          job: string
          last_error: string | null
          last_error_at: string | null
          last_ok_at: string | null
        }
        Insert: {
          job: string
          last_error?: string | null
          last_error_at?: string | null
          last_ok_at?: string | null
        }
        Update: {
          job?: string
          last_error?: string | null
          last_error_at?: string | null
          last_ok_at?: string | null
        }
        Relationships: []
      }
      jobs: {
        Row: {
          access_window: Json
          address: string | null
          area_m2: number | null
          builder_company: string | null
          builder_pm_email: string | null
          builder_pm_name: string | null
          builder_pm_phone: string | null
          client_contact: string | null
          client_name: string | null
          client_phone: string | null
          code: string
          created_at: string
          crew_size: number
          due_by: string | null
          due_hard: boolean
          duration_unit: Database["public"]["Enums"]["duration_unit"]
          duration_value: number
          extra_tickets: string[]
          flooring: string | null
          guidance: Json | null
          hazards: string[]
          id: string
          importance: Database["public"]["Enums"]["job_importance"]
          inspection_summary: Json | null
          is_demo: boolean
          job_type: string | null
          lat: number | null
          lng: number | null
          locked: boolean
          main_skill: string | null
          name: string
          other_skills: string[]
          safety_notes: string | null
          sector: Database["public"]["Enums"]["job_sector"]
          start_date: string | null
          start_time: string | null
          status: Database["public"]["Enums"]["job_status"]
          suburb: string | null
          unique_notes: string | null
          updated_at: string
          urgency: Database["public"]["Enums"]["job_urgency"]
          workspace_id: string
        }
        Insert: {
          access_window?: Json
          address?: string | null
          area_m2?: number | null
          builder_company?: string | null
          builder_pm_email?: string | null
          builder_pm_name?: string | null
          builder_pm_phone?: string | null
          client_contact?: string | null
          client_name?: string | null
          client_phone?: string | null
          code?: string
          created_at?: string
          crew_size?: number
          due_by?: string | null
          due_hard?: boolean
          duration_unit?: Database["public"]["Enums"]["duration_unit"]
          duration_value?: number
          extra_tickets?: string[]
          flooring?: string | null
          guidance?: Json | null
          hazards?: string[]
          id?: string
          importance?: Database["public"]["Enums"]["job_importance"]
          inspection_summary?: Json | null
          is_demo?: boolean
          job_type?: string | null
          lat?: number | null
          lng?: number | null
          locked?: boolean
          main_skill?: string | null
          name: string
          other_skills?: string[]
          safety_notes?: string | null
          sector?: Database["public"]["Enums"]["job_sector"]
          start_date?: string | null
          start_time?: string | null
          status?: Database["public"]["Enums"]["job_status"]
          suburb?: string | null
          unique_notes?: string | null
          updated_at?: string
          urgency?: Database["public"]["Enums"]["job_urgency"]
          workspace_id: string
        }
        Update: {
          access_window?: Json
          address?: string | null
          area_m2?: number | null
          builder_company?: string | null
          builder_pm_email?: string | null
          builder_pm_name?: string | null
          builder_pm_phone?: string | null
          client_contact?: string | null
          client_name?: string | null
          client_phone?: string | null
          code?: string
          created_at?: string
          crew_size?: number
          due_by?: string | null
          due_hard?: boolean
          duration_unit?: Database["public"]["Enums"]["duration_unit"]
          duration_value?: number
          extra_tickets?: string[]
          flooring?: string | null
          guidance?: Json | null
          hazards?: string[]
          id?: string
          importance?: Database["public"]["Enums"]["job_importance"]
          inspection_summary?: Json | null
          is_demo?: boolean
          job_type?: string | null
          lat?: number | null
          lng?: number | null
          locked?: boolean
          main_skill?: string | null
          name?: string
          other_skills?: string[]
          safety_notes?: string | null
          sector?: Database["public"]["Enums"]["job_sector"]
          start_date?: string | null
          start_time?: string | null
          status?: Database["public"]["Enums"]["job_status"]
          suburb?: string | null
          unique_notes?: string | null
          updated_at?: string
          urgency?: Database["public"]["Enums"]["job_urgency"]
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "jobs_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      leave: {
        Row: {
          created_at: string
          crew_member_id: string
          decided_at: string | null
          decided_by: string | null
          end_time: string | null
          from_date: string
          id: string
          note: string | null
          start_time: string | null
          status: Database["public"]["Enums"]["leave_status"]
          to_date: string
          type: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          crew_member_id: string
          decided_at?: string | null
          decided_by?: string | null
          end_time?: string | null
          from_date: string
          id?: string
          note?: string | null
          start_time?: string | null
          status?: Database["public"]["Enums"]["leave_status"]
          to_date: string
          type: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          crew_member_id?: string
          decided_at?: string | null
          decided_by?: string | null
          end_time?: string | null
          from_date?: string
          id?: string
          note?: string | null
          start_time?: string | null
          status?: Database["public"]["Enums"]["leave_status"]
          to_date?: string
          type?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "leave_crew_member_id_fkey"
            columns: ["crew_member_id"]
            isOneToOne: false
            referencedRelation: "crew_members"
            referencedColumns: ["id"]
          },
        ]
      }
      material_costs: {
        Row: {
          material_id: string
          unit_cost: number
          workspace_id: string
        }
        Insert: {
          material_id: string
          unit_cost: number
          workspace_id: string
        }
        Update: {
          material_id?: string
          unit_cost?: number
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "material_costs_material_id_fkey"
            columns: ["material_id"]
            isOneToOne: true
            referencedRelation: "materials"
            referencedColumns: ["id"]
          },
        ]
      }
      materials: {
        Row: {
          calc: Json | null
          catalogue_item_id: string | null
          id: string
          item: string
          job_id: string
          order_by_date: string | null
          order_list_id: string | null
          ordered_at: string | null
          qty: number | null
          sort: number
          status: Database["public"]["Enums"]["material_status"]
          supplier_id: string | null
          unit: string | null
          workspace_id: string
        }
        Insert: {
          calc?: Json | null
          catalogue_item_id?: string | null
          id?: string
          item: string
          job_id: string
          order_by_date?: string | null
          order_list_id?: string | null
          ordered_at?: string | null
          qty?: number | null
          sort?: number
          status?: Database["public"]["Enums"]["material_status"]
          supplier_id?: string | null
          unit?: string | null
          workspace_id: string
        }
        Update: {
          calc?: Json | null
          catalogue_item_id?: string | null
          id?: string
          item?: string
          job_id?: string
          order_by_date?: string | null
          order_list_id?: string | null
          ordered_at?: string | null
          qty?: number | null
          sort?: number
          status?: Database["public"]["Enums"]["material_status"]
          supplier_id?: string | null
          unit?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "materials_catalogue_item_id_fkey"
            columns: ["catalogue_item_id"]
            isOneToOne: false
            referencedRelation: "catalogue_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "materials_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "materials_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
        ]
      }
      memberships: {
        Row: {
          created_at: string
          crew_member_id: string | null
          id: string
          invited_by: string | null
          invited_email: string | null
          last_selected_at: string | null
          role: Database["public"]["Enums"]["app_role"]
          status: Database["public"]["Enums"]["membership_status"]
          user_id: string | null
          workspace_id: string
        }
        Insert: {
          created_at?: string
          crew_member_id?: string | null
          id?: string
          invited_by?: string | null
          invited_email?: string | null
          last_selected_at?: string | null
          role: Database["public"]["Enums"]["app_role"]
          status?: Database["public"]["Enums"]["membership_status"]
          user_id?: string | null
          workspace_id: string
        }
        Update: {
          created_at?: string
          crew_member_id?: string | null
          id?: string
          invited_by?: string | null
          invited_email?: string | null
          last_selected_at?: string | null
          role?: Database["public"]["Enums"]["app_role"]
          status?: Database["public"]["Enums"]["membership_status"]
          user_id?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "memberships_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      message_reads: {
        Row: {
          job_id: string
          last_read_at: string
          user_id: string
          workspace_id: string
        }
        Insert: {
          job_id: string
          last_read_at?: string
          user_id: string
          workspace_id: string
        }
        Update: {
          job_id?: string
          last_read_at?: string
          user_id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "message_reads_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          author_user_id: string | null
          body: string
          created_at: string
          deleted_at: string | null
          id: string
          job_id: string
          kind: Database["public"]["Enums"]["message_kind"]
          mentions: string[]
          reply_to_id: string | null
          speaker: Database["public"]["Enums"]["message_speaker"] | null
          task_id: string | null
          via: string | null
          workspace_id: string
        }
        Insert: {
          author_user_id?: string | null
          body?: string
          created_at?: string
          deleted_at?: string | null
          id?: string
          job_id: string
          kind?: Database["public"]["Enums"]["message_kind"]
          mentions?: string[]
          reply_to_id?: string | null
          speaker?: Database["public"]["Enums"]["message_speaker"] | null
          task_id?: string | null
          via?: string | null
          workspace_id: string
        }
        Update: {
          author_user_id?: string | null
          body?: string
          created_at?: string
          deleted_at?: string | null
          id?: string
          job_id?: string
          kind?: Database["public"]["Enums"]["message_kind"]
          mentions?: string[]
          reply_to_id?: string | null
          speaker?: Database["public"]["Enums"]["message_speaker"] | null
          task_id?: string | null
          via?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_reply_to_id_fkey"
            columns: ["reply_to_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      morning_briefs: {
        Row: {
          changes: Json
          created_at: string
          for_date: string
          id: string
          items: Json
          model: string | null
          since: string
          summary: string
          today: Json
          user_id: string
          workspace_id: string
        }
        Insert: {
          changes?: Json
          created_at?: string
          for_date: string
          id?: string
          items?: Json
          model?: string | null
          since: string
          summary?: string
          today?: Json
          user_id: string
          workspace_id: string
        }
        Update: {
          changes?: Json
          created_at?: string
          for_date?: string
          id?: string
          items?: Json
          model?: string | null
          since?: string
          summary?: string
          today?: Json
          user_id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "morning_briefs_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          body: string
          created_at: string
          id: string
          job_id: string | null
          kind: string
          level: string
          proposal_id: string | null
          pushed_at: string | null
          read_at: string | null
          title: string
          user_id: string
          workspace_id: string
        }
        Insert: {
          body?: string
          created_at?: string
          id?: string
          job_id?: string | null
          kind: string
          level?: string
          proposal_id?: string | null
          pushed_at?: string | null
          read_at?: string | null
          title: string
          user_id: string
          workspace_id: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          job_id?: string | null
          kind?: string
          level?: string
          proposal_id?: string | null
          pushed_at?: string | null
          read_at?: string | null
          title?: string
          user_id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notifications_proposal_id_fkey"
            columns: ["proposal_id"]
            isOneToOne: false
            referencedRelation: "proposals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notifications_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      platform_admins: {
        Row: {
          created_at: string
          last_seen_at: string | null
          role: string
          user_id: string
        }
        Insert: {
          created_at?: string
          last_seen_at?: string | null
          role?: string
          user_id: string
        }
        Update: {
          created_at?: string
          last_seen_at?: string | null
          role?: string
          user_id?: string
        }
        Relationships: []
      }
      platform_audit: {
        Row: {
          action: string
          admin_user_id: string | null
          at: string
          detail: Json
          id: number
          workspace_id: string | null
        }
        Insert: {
          action: string
          admin_user_id?: string | null
          at?: string
          detail?: Json
          id?: number
          workspace_id?: string | null
        }
        Update: {
          action?: string
          admin_user_id?: string | null
          at?: string
          detail?: Json
          id?: number
          workspace_id?: string | null
        }
        Relationships: []
      }
      proposals: {
        Row: {
          created_at: string
          created_by: string | null
          created_by_brain: boolean
          decided_at: string | null
          decided_by: string | null
          dedupe_key: string | null
          dismiss_reason: string | null
          expires_at: string | null
          explanation: string
          fit: Json | null
          group_id: string | null
          group_label: string | null
          id: string
          job_id: string | null
          kind: Database["public"]["Enums"]["proposal_kind"]
          level: string
          payload: Json
          result: Json | null
          source: Database["public"]["Enums"]["proposal_source"]
          status: Database["public"]["Enums"]["proposal_status"]
          title: string
          undo: Json | null
          workspace_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          created_by_brain?: boolean
          decided_at?: string | null
          decided_by?: string | null
          dedupe_key?: string | null
          dismiss_reason?: string | null
          expires_at?: string | null
          explanation?: string
          fit?: Json | null
          group_id?: string | null
          group_label?: string | null
          id?: string
          job_id?: string | null
          kind: Database["public"]["Enums"]["proposal_kind"]
          level?: string
          payload?: Json
          result?: Json | null
          source: Database["public"]["Enums"]["proposal_source"]
          status?: Database["public"]["Enums"]["proposal_status"]
          title?: string
          undo?: Json | null
          workspace_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          created_by_brain?: boolean
          decided_at?: string | null
          decided_by?: string | null
          dedupe_key?: string | null
          dismiss_reason?: string | null
          expires_at?: string | null
          explanation?: string
          fit?: Json | null
          group_id?: string | null
          group_label?: string | null
          id?: string
          job_id?: string | null
          kind?: Database["public"]["Enums"]["proposal_kind"]
          level?: string
          payload?: Json
          result?: Json | null
          source?: Database["public"]["Enums"]["proposal_source"]
          status?: Database["public"]["Enums"]["proposal_status"]
          title?: string
          undo?: Json | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "proposals_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "proposals_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      public_holidays: {
        Row: {
          date: string
          id: string
          name: string
          state: string
        }
        Insert: {
          date: string
          id?: string
          name: string
          state: string
        }
        Update: {
          date?: string
          id?: string
          name?: string
          state?: string
        }
        Relationships: []
      }
      push_subscriptions: {
        Row: {
          auth: string
          created_at: string
          device_label: string | null
          endpoint: string
          id: string
          p256dh: string
          user_id: string
        }
        Insert: {
          auth: string
          created_at?: string
          device_label?: string | null
          endpoint: string
          id?: string
          p256dh: string
          user_id: string
        }
        Update: {
          auth?: string
          created_at?: string
          device_label?: string | null
          endpoint?: string
          id?: string
          p256dh?: string
          user_id?: string
        }
        Relationships: []
      }
      security_events: {
        Row: {
          actor_user_id: string | null
          at: string
          id: string
          kind: string
          target_user_id: string | null
          workspace_id: string
        }
        Insert: {
          actor_user_id?: string | null
          at?: string
          id?: string
          kind: string
          target_user_id?: string | null
          workspace_id: string
        }
        Update: {
          actor_user_id?: string | null
          at?: string
          id?: string
          kind?: string
          target_user_id?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "security_events_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      suppliers: {
        Row: {
          account_no: string | null
          created_at: string
          id: string
          lead_time_days: number | null
          name: string
          notes: string | null
          orders_email: string | null
          rep_email: string | null
          rep_name: string | null
          rep_phone: string | null
          workspace_id: string
        }
        Insert: {
          account_no?: string | null
          created_at?: string
          id?: string
          lead_time_days?: number | null
          name: string
          notes?: string | null
          orders_email?: string | null
          rep_email?: string | null
          rep_name?: string | null
          rep_phone?: string | null
          workspace_id: string
        }
        Update: {
          account_no?: string | null
          created_at?: string
          id?: string
          lead_time_days?: number | null
          name?: string
          notes?: string | null
          orders_email?: string | null
          rep_email?: string | null
          rep_name?: string | null
          rep_phone?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "suppliers_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      tasks: {
        Row: {
          done: boolean
          done_at: string | null
          done_by: string | null
          due_date: string | null
          id: string
          job_id: string
          label: string
          owner_crew_member_id: string | null
          sort: number
          workspace_id: string
        }
        Insert: {
          done?: boolean
          done_at?: string | null
          done_by?: string | null
          due_date?: string | null
          id?: string
          job_id: string
          label: string
          owner_crew_member_id?: string | null
          sort?: number
          workspace_id: string
        }
        Update: {
          done?: boolean
          done_at?: string | null
          done_by?: string | null
          due_date?: string | null
          id?: string
          job_id?: string
          label?: string
          owner_crew_member_id?: string | null
          sort?: number
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tasks_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_owner_crew_member_id_fkey"
            columns: ["owner_crew_member_id"]
            isOneToOne: false
            referencedRelation: "crew_members"
            referencedColumns: ["id"]
          },
        ]
      }
      usage_events: {
        Row: {
          at: string
          detail: string | null
          id: string
          kind: string
          units: number
          workspace_id: string
        }
        Insert: {
          at?: string
          detail?: string | null
          id?: string
          kind: string
          units?: number
          workspace_id: string
        }
        Update: {
          at?: string
          detail?: string | null
          id?: string
          kind?: string
          units?: number
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "usage_events_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      workspace_billing: {
        Row: {
          notes: string
          plan: string
          price_aud: number
          seats: number
          status: string
          updated_at: string
          workspace_id: string
        }
        Insert: {
          notes?: string
          plan?: string
          price_aud?: number
          seats?: number
          status?: string
          updated_at?: string
          workspace_id: string
        }
        Update: {
          notes?: string
          plan?: string
          price_aud?: number
          seats?: number
          status?: string
          updated_at?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "workspace_billing_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: true
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      workspace_finance_settings: {
        Row: {
          accommodation_rate: number
          default_day_rate: number
          km_rate: number
          variation_margin_pct: number | null
          workspace_id: string
        }
        Insert: {
          accommodation_rate?: number
          default_day_rate?: number
          km_rate?: number
          variation_margin_pct?: number | null
          workspace_id: string
        }
        Update: {
          accommodation_rate?: number
          default_day_rate?: number
          km_rate?: number
          variation_margin_pct?: number | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "workspace_finance_settings_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: true
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      workspace_flags: {
        Row: {
          enabled: boolean
          flag: string
          id: string
          reason: string | null
          updated_at: string
          updated_by: string | null
          workspace_id: string | null
        }
        Insert: {
          enabled?: boolean
          flag: string
          id?: string
          reason?: string | null
          updated_at?: string
          updated_by?: string | null
          workspace_id?: string | null
        }
        Update: {
          enabled?: boolean
          flag?: string
          id?: string
          reason?: string | null
          updated_at?: string
          updated_by?: string | null
          workspace_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "workspace_flags_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      workspace_settings: {
        Row: {
          avg_kmh: number
          day_end: string
          day_start: string
          hazards: Json
          holiday_states: string[]
          job_types: string[]
          leave_types: string[]
          moisture_limits: Json
          morning_end: string
          overnight_minutes: number
          skills: string[]
          ticket_rules: Json
          ticket_types: Json
          unload_buffer_min: number
          waste_defaults: Json
          working_days: number[]
          workspace_id: string
        }
        Insert: {
          avg_kmh?: number
          day_end?: string
          day_start?: string
          hazards?: Json
          holiday_states?: string[]
          job_types?: string[]
          leave_types?: string[]
          moisture_limits?: Json
          morning_end?: string
          overnight_minutes?: number
          skills?: string[]
          ticket_rules?: Json
          ticket_types?: Json
          unload_buffer_min?: number
          waste_defaults?: Json
          working_days?: number[]
          workspace_id: string
        }
        Update: {
          avg_kmh?: number
          day_end?: string
          day_start?: string
          hazards?: Json
          holiday_states?: string[]
          job_types?: string[]
          leave_types?: string[]
          moisture_limits?: Json
          morning_end?: string
          overnight_minutes?: number
          skills?: string[]
          ticket_rules?: Json
          ticket_types?: Json
          unload_buffer_min?: number
          waste_defaults?: Json
          working_days?: number[]
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "workspace_settings_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: true
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      workspaces: {
        Row: {
          code_prefix: string
          created_at: string
          demo_data: boolean
          depot_lat: number | null
          depot_lng: number | null
          depot_name: string | null
          finance_visible_to_office: boolean
          id: string
          inbound_key: string
          name: string
          next_job_number: number
          timezone: string
        }
        Insert: {
          code_prefix?: string
          created_at?: string
          demo_data?: boolean
          depot_lat?: number | null
          depot_lng?: number | null
          depot_name?: string | null
          finance_visible_to_office?: boolean
          id?: string
          inbound_key?: string
          name: string
          next_job_number?: number
          timezone?: string
        }
        Update: {
          code_prefix?: string
          created_at?: string
          demo_data?: boolean
          depot_lat?: number | null
          depot_lng?: number | null
          depot_name?: string | null
          finance_visible_to_office?: boolean
          id?: string
          inbound_key?: string
          name?: string
          next_job_number?: number
          timezone?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      accept_pending_invites: { Args: never; Returns: number }
      apply_proposal: {
        Args: { _anyway?: boolean; _id: string; _payload?: Json }
        Returns: Json
      }
      away_days: {
        Args: { _job_id: string }
        Returns: {
          crew_member_id: string
          date: string
        }[]
      }
      background_health: {
        Args: never
        Returns: {
          job: string
          last_ok_at: string
          late: boolean
        }[]
      }
      brain_watch_sleep: { Args: never; Returns: undefined }
      check_cron_token: { Args: { _t: string }; Returns: boolean }
      correct_assignment_time: {
        Args: { _assignment_id: string; _end: string; _start: string }
        Returns: undefined
      }
      crew_mates: {
        Args: { _job_id: string }
        Returns: {
          crew_member_id: string
          name: string
          phone: string
          role: Database["public"]["Enums"]["crew_role"]
        }[]
      }
      dismiss_proposal: {
        Args: { _id: string; _reason?: string }
        Returns: undefined
      }
      has_workspace_role: {
        Args: { _roles: Database["public"]["Enums"]["app_role"][]; _ws: string }
        Returns: boolean
      }
      is_assigned_to_job: { Args: { _job_id: string }; Returns: boolean }
      is_finance: { Args: { _ws: string }; Returns: boolean }
      is_foreman_on_job: { Args: { _job_id: string }; Returns: boolean }
      is_job_reader: { Args: { _job_id: string }; Returns: boolean }
      is_member: { Args: { _ws: string }; Returns: boolean }
      is_office: { Args: { _ws: string }; Returns: boolean }
      is_owner: { Args: { _ws: string }; Returns: boolean }
      job_catalogue_items: {
        Args: { _job_id: string }
        Returns: {
          colour: string
          coverage: number
          coverage_basis: string
          hazard_tags: string[]
          id: string
          install_url: string
          name: string
          pack_size: number
          sds_url: string
          spec_url: string
          unit: string
          warranty_url: string
        }[]
      }
      job_id_from_path: { Args: { _name: string }; Returns: string }
      job_people: {
        Args: { _job_id: string }
        Returns: {
          name: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }[]
      }
      link_membership_crew: {
        Args: { _crew_member_id: string; _membership_id: string }
        Returns: undefined
      }
      mark_assignment_time: {
        Args: { _assignment_id: string; _which: string }
        Returns: string
      }
      member_access: {
        Args: { _ws: string }
        Returns: {
          crew_member_id: string
          crew_name: string
          email: string
          last_sign_in_at: string
          membership_id: string
          role: Database["public"]["Enums"]["app_role"]
          status: Database["public"]["Enums"]["membership_status"]
          two_factor: boolean
          user_id: string
        }[]
      }
      move_brain_post: {
        Args: { _message_id: string; _to_job: string }
        Returns: Json
      }
      my_crew_member_ids: { Args: never; Returns: string[] }
      place_job: {
        Args: {
          _ignore_lock?: boolean
          _job_id: string
          _reason?: string
          _rows: Json
          _start_date: string
          _start_time: string
          _status: Database["public"]["Enums"]["job_status"]
        }
        Returns: undefined
      }
      select_workspace: { Args: { _ws: string }; Returns: undefined }
      selftest_proposal_tenant: {
        Args: never
        Returns: {
          passed: boolean
          test: string
        }[]
      }
      set_demo_data: { Args: { _on: boolean; _ws: string }; Returns: undefined }
      set_job_ai: {
        Args: { _field: string; _job_id: string; _value: Json }
        Returns: undefined
      }
      sign_out_member: {
        Args: { _user: string; _ws: string }
        Returns: undefined
      }
      storage_by_workspace: {
        Args: never
        Returns: {
          bytes: number
          workspace_id: string
        }[]
      }
      undo_proposal: { Args: { _id: string }; Returns: undefined }
    }
    Enums: {
      app_role:
        | "owner"
        | "office"
        | "foreman"
        | "installer"
        | "apprentice"
        | "subcontractor"
      attachment_kind: "photo" | "audio" | "file" | "video"
      crew_role: "foreman" | "installer" | "apprentice"
      dependency_kind:
        | "trade handover"
        | "test result"
        | "delivery"
        | "approval"
        | "other"
      dependency_status: "pending" | "confirmed" | "failed"
      duration_unit: "hours" | "days"
      inbound_status: "unfiled" | "filed" | "ignored"
      job_importance: "key" | "standard" | "minor"
      job_sector: "domestic" | "commercial"
      job_status:
        | "enquiry"
        | "quoted"
        | "ready"
        | "scheduled"
        | "on site"
        | "complete"
        | "closed"
      job_urgency: "critical" | "soon" | "flexible"
      leave_status: "requested" | "approved" | "declined"
      material_status: "to order" | "ordered" | "delivered"
      membership_status: "invited" | "active" | "removed"
      message_kind: "message" | "problem" | "inspection" | "system"
      message_speaker: "client" | "owner" | "foreman" | "email"
      proposal_kind:
        | "place"
        | "move"
        | "swap"
        | "add_person"
        | "remove_person"
        | "create_job"
        | "update_job"
        | "add_task"
        | "add_dependency"
        | "update_dependency"
        | "mark_delivered"
        | "update_ticket"
        | "leave_request"
        | "log_call"
        | "send_email"
        | "send_sms"
      proposal_source:
        | "brief"
        | "watcher"
        | "overnight"
        | "capture"
        | "ask"
        | "email"
        | "photo"
        | "document"
        | "variation"
      proposal_status:
        | "open"
        | "applied"
        | "dismissed"
        | "expired"
        | "superseded"
        | "undone"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "owner",
        "office",
        "foreman",
        "installer",
        "apprentice",
        "subcontractor",
      ],
      attachment_kind: ["photo", "audio", "file", "video"],
      crew_role: ["foreman", "installer", "apprentice"],
      dependency_kind: [
        "trade handover",
        "test result",
        "delivery",
        "approval",
        "other",
      ],
      dependency_status: ["pending", "confirmed", "failed"],
      duration_unit: ["hours", "days"],
      inbound_status: ["unfiled", "filed", "ignored"],
      job_importance: ["key", "standard", "minor"],
      job_sector: ["domestic", "commercial"],
      job_status: [
        "enquiry",
        "quoted",
        "ready",
        "scheduled",
        "on site",
        "complete",
        "closed",
      ],
      job_urgency: ["critical", "soon", "flexible"],
      leave_status: ["requested", "approved", "declined"],
      material_status: ["to order", "ordered", "delivered"],
      membership_status: ["invited", "active", "removed"],
      message_kind: ["message", "problem", "inspection", "system"],
      message_speaker: ["client", "owner", "foreman", "email"],
      proposal_kind: [
        "place",
        "move",
        "swap",
        "add_person",
        "remove_person",
        "create_job",
        "update_job",
        "add_task",
        "add_dependency",
        "update_dependency",
        "mark_delivered",
        "update_ticket",
        "leave_request",
        "log_call",
        "send_email",
        "send_sms",
      ],
      proposal_source: [
        "brief",
        "watcher",
        "overnight",
        "capture",
        "ask",
        "email",
        "photo",
        "document",
        "variation",
      ],
      proposal_status: [
        "open",
        "applied",
        "dismissed",
        "expired",
        "superseded",
        "undone",
      ],
    },
  },
} as const
