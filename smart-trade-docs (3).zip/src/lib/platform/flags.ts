/** Kill switches (spec section 12). Browser-safe list; checks live in flags.server.ts. */
import { BRAIN_FUNCTIONS } from "@/lib/ai-config";

export const KILLABLE: string[] = [...new Set([...BRAIN_FUNCTIONS, "email_match", "overnight"])];
export const FN_LABEL: Record<string, string> = {
  capture: "Brain bar", ask: "Ask", brief: "Morning brief", summary: "Inspection summary", guidance: "Install guidance", drafting: "Drafting",
  documents: "Documents", lookahead: "Look-ahead", watcher: "Watcher", closeout: "Close-outs", email_sort: "Sorting emails",
  email_match: "Matching emails", photo_tag: "Tagging photos", overnight: "Overnight draft",
};
export const flagName = (fn: string) => `brain:${fn}`;
