/** Server errors → error_events (spec section 12): workspace, function and a scrubbed message. Never customer content. */

/** Strips quoted text, key=value details, emails and long numbers so no customer content is kept. */
export function scrubMessage(m: string): string {
  return m
    .replace(/"[^"]*"|'[^']*'|“[^”]*”/g, "\"…\"")
    .replace(/\(([^)]*)\)=\([^)]*\)/g, "($1)=(…)")
    .replace(/[\w.+-]+@[\w-]+\.[\w.]+/g, "[email]")
    .replace(/\b\d{6,}\b/g, "[number]")
    .replace(/\s+/g, " ")
    .slice(0, 300);
}

export async function recordError(fn: string, err: unknown, ws?: string | null) {
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const raw = err instanceof Error ? err.message : typeof err === "string" ? err : "Unknown error";
    await supabaseAdmin.from("error_events").insert({ workspace_id: ws ?? null, fn: fn.slice(0, 120), message: scrubMessage(raw) });
  } catch (e) { console.error("error_events", (e as Error).message); }
}

/** Workspace for the bearer on a request (unverified decode is fine: this only labels an error log row). */
export async function workspaceForBearer(auth: string | null): Promise<string | null> {
  try {
    const tok = auth?.replace(/^Bearer\s+/i, "");
    if (!tok || tok.split(".").length !== 3) return null;
    const sub = JSON.parse(atob(tok.split(".")[1]!.replace(/-/g, "+").replace(/_/g, "/")))?.sub;
    if (!sub) return null;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data } = await supabaseAdmin.from("memberships").select("workspace_id").eq("user_id", sub).eq("status", "active")
      .order("last_selected_at", { ascending: false, nullsFirst: false }).limit(1).maybeSingle();
    return data?.workspace_id ?? null;
  } catch { return null; }
}
