/** Every Brain function checks these before running: a platform-wide switch and the workspace's own. Server-only. */
import { FN_LABEL, flagName } from "./flags";

export class SwitchedOff extends Error { status = 503; }

/** Throws a clear message when the function (or the whole Brain) is switched off for this workspace or everyone. */
export async function assertBrainOn(ws: string, fn: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin.from("workspace_flags").select("workspace_id, flag, enabled")
    .in("flag", [flagName(fn), flagName("all")]).eq("enabled", false).or(`workspace_id.is.null,workspace_id.eq.${ws}`);
  if (data?.length) {
    const everyone = data.some((f) => f.workspace_id === null);
    throw new SwitchedOff(`${FN_LABEL[fn] ?? "This Brain feature"} is switched off for now${everyone ? "" : " for this business"} by Trade Brain support. Everything else keeps working.`);
  }
}

/** Non-throwing version for background loops. */
export async function brainOn(ws: string, fn: string) {
  try { await assertBrainOn(ws, fn); return true; } catch { return false; }
}
