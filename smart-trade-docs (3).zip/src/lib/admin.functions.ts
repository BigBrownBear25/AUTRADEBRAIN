/**
 * Platform admin area (spec section 12). Admins see how a workspace is doing, never what's in it:
 * no jobs, chat, files, finance or people's details. Every call is checked here on the server:
 * in platform_admins, signed in with two-factor, and active in the last 30 minutes — otherwise "Not found".
 * Every admin action writes platform_audit.
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { KILLABLE, flagName } from "@/lib/platform/flags";

const IDLE_MS = 30 * 60_000;
const isId = (s: unknown) => typeof s === "string" && /^[0-9a-f-]{36}$/i.test(s);

type Claims = { aal?: string; amr?: { method: string; timestamp: number }[] };

async function adminGate(userId: string, claims: unknown) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const c = (claims ?? {}) as Claims;
  const { data: a } = await supabaseAdmin.from("platform_admins").select("user_id, role, last_seen_at").eq("user_id", userId).maybeSingle();
  const lastAuth = Math.max(0, ...(c.amr ?? []).map((x) => Number(x.timestamp) * 1000));
  const lastSeen = a?.last_seen_at ? Date.parse(a.last_seen_at) : 0;
  const now = Date.now();
  // Active = signed in (or used the admin area) within the last 30 minutes.
  // and two-factor entered within the last 12 hours (spec section 14 rule 2).
  const { mfaAt, OFFICE_TOTAL_MS } = await import("./rules/sessions");
  const mfa = mfaAt(c.amr);
  if (!a || c.aal !== "aal2" || now - Math.max(lastAuth, lastSeen) > IDLE_MS || mfa == null || now - mfa > OFFICE_TOTAL_MS) throw new Error("Not found");
  await supabaseAdmin.from("platform_admins").update({ last_seen_at: new Date(now).toISOString() }).eq("user_id", userId);
  const audit = async (action: string, workspace_id: string | null, detail: Record<string, unknown> = {}) => {
    const { error } = await supabaseAdmin.from("platform_audit").insert({ admin_user_id: userId, action, workspace_id, detail: detail as never });
    if (error) throw new Error("Couldn't record the admin action, so it was stopped.");
  };
  return { sb: supabaseAdmin, role: a.role, audit };
}

const monthStart = () => { const d = new Date(); return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1)).toISOString(); };
const dayAgo = (n: number) => new Date(Date.now() - n * 86_400_000).toISOString();

async function allUsers(sb: Awaited<ReturnType<typeof adminGate>>["sb"]) {
  const out: { id: string; email: string | undefined; last_sign_in_at: string | null | undefined; name: string | undefined }[] = [];
  for (let page = 1; page <= 20; page++) {
    const { data } = await sb.auth.admin.listUsers({ page, perPage: 1000 });
    const users = data?.users ?? [];
    out.push(...users.map((u) => ({ id: u.id, email: u.email, last_sign_in_at: u.last_sign_in_at, name: (u.user_metadata?.["full_name"] ?? u.user_metadata?.["name"]) as string | undefined })));
    if (users.length < 1000) break;
  }
  return out;
}

/** Quick yes/no for the /admin shell: anything but a pass shows "Not found". */
export const adminWhoAmI = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const g = await adminGate(context.userId, context.claims);
    return { role: g.role };
  });

export const adminDashboard = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { sb, audit } = await adminGate(context.userId, context.claims);
    await audit("view_dashboard", null);
    const m = monthStart();
    const [ws, bill, jobs, ai, usage, errs, runs, storage, act1, act7] = await Promise.all([
      sb.from("workspaces").select("id", { count: "exact", head: true }),
      sb.from("workspace_billing").select("status"),
      sb.from("jobs").select("id", { count: "exact", head: true }).gte("created_at", m).eq("is_demo", false),
      sb.from("ai_runs").select("cost_aud").gte("at", m),
      sb.from("usage_events").select("kind, units").gte("at", m).in("kind", ["sms", "email"]),
      sb.from("error_events").select("id", { count: "exact", head: true }).gte("at", dayAgo(1)),
      sb.from("job_runs").select("*"),
      sb.rpc("storage_by_workspace"),
      sb.from("audit_log").select("actor_user_id").gte("at", dayAgo(1)).not("actor_user_id", "is", null).limit(10000),
      sb.from("audit_log").select("actor_user_id").gte("at", dayAgo(7)).not("actor_user_id", "is", null).limit(10000),
    ]);
    const users = await allUsers(sb);
    const signedIn = (days: number) => users.filter((u) => u.last_sign_in_at && Date.parse(u.last_sign_in_at) > Date.now() - days * 86_400_000).map((u) => u.id);
    const active = (rows: { actor_user_id: string | null }[] | null, days: number) => new Set([...(rows ?? []).map((r) => r.actor_user_id!), ...signedIn(days)]).size;
    const byStatus: Record<string, number> = {};
    for (const b of bill.data ?? []) byStatus[b.status] = (byStatus[b.status] ?? 0) + 1;
    const sum = (k: string) => (usage.data ?? []).filter((u) => u.kind === k).reduce((a, u) => a + u.units, 0);
    return {
      workspaces: ws.count ?? 0, byStatus,
      activeToday: active(act1.data, 1), activeWeek: active(act7.data, 7),
      jobsThisMonth: jobs.count ?? 0,
      aiSpendAud: Math.round((ai.data ?? []).reduce((a, r) => a + Number(r.cost_aud), 0) * 100) / 100,
      sms: sum("sms"), email: sum("email"),
      storageBytes: (storage.data ?? []).reduce((a, r) => a + Number(r.bytes), 0),
      errors24h: errs.count ?? 0,
      jobRuns: runs.data ?? [],
    };
  });

export const adminWorkspaces = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { sb, audit } = await adminGate(context.userId, context.claims);
    await audit("list_workspaces", null);
    const m = monthStart();
    const [ws, bill, mem, ai, storage, last] = await Promise.all([
      sb.from("workspaces").select("id, name, created_at").order("name"),
      sb.from("workspace_billing").select("*"),
      sb.from("memberships").select("workspace_id, user_id, role").eq("status", "active"),
      sb.from("ai_runs").select("workspace_id, cost_aud").gte("at", m),
      sb.rpc("storage_by_workspace"),
      sb.from("audit_log").select("workspace_id, at").order("at", { ascending: false }).limit(5000),
    ]);
    const users = new Map((await allUsers(sb)).map((u) => [u.id, u]));
    return (ws.data ?? []).map((w) => {
      const b = (bill.data ?? []).find((x) => x.workspace_id === w.id);
      const mine = (mem.data ?? []).filter((x) => x.workspace_id === w.id);
      const owner = mine.find((x) => x.role === "owner");
      return {
        id: w.id, name: w.name, owner: owner?.user_id ? users.get(owner.user_id)?.email ?? "—" : "—",
        plan: b?.plan ?? "trial", status: b?.status ?? "trial", seats: b?.seats ?? 0, price: Number(b?.price_aud ?? 0),
        people: mine.length,
        lastActivity: (last.data ?? []).find((x) => x.workspace_id === w.id)?.at ?? null,
        aiSpendAud: Math.round((ai.data ?? []).filter((r) => r.workspace_id === w.id).reduce((a, r) => a + Number(r.cost_aud), 0) * 100) / 100,
        storageBytes: Number((storage.data ?? []).find((r) => r.workspace_id === w.id)?.bytes ?? 0),
      };
    });
  });

export const adminWorkspace = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => { if (!isId(d?.id)) throw new Error("Not found"); return d; })
  .handler(async ({ data, context }) => {
    const { sb, audit } = await adminGate(context.userId, context.claims);
    const ws = data.id;
    const { data: w } = await sb.from("workspaces").select("id, name, created_at").eq("id", ws).maybeSingle();
    if (!w) throw new Error("Not found");
    await audit("view_workspace", ws);
    const m = monthStart();
    const [bill, mem, ai, usage, storage, last, flags, paudit, errs] = await Promise.all([
      sb.from("workspace_billing").select("*").eq("workspace_id", ws).maybeSingle(),
      sb.from("memberships").select("user_id, role, crew_member_id").eq("workspace_id", ws).eq("status", "active"),
      sb.from("ai_runs").select("function, cost_aud").eq("workspace_id", ws).gte("at", m),
      sb.from("usage_events").select("kind, units").eq("workspace_id", ws).gte("at", m).in("kind", ["sms", "email"]),
      sb.rpc("storage_by_workspace"),
      sb.from("audit_log").select("at").eq("workspace_id", ws).order("at", { ascending: false }).limit(1).maybeSingle(),
      sb.from("workspace_flags").select("workspace_id, flag, enabled, reason, updated_at").or(`workspace_id.is.null,workspace_id.eq.${ws}`),
      sb.from("platform_audit").select("id, admin_user_id, action, detail, at").eq("workspace_id", ws).order("at", { ascending: false }).limit(100),
      sb.from("error_events").select("fn, message, at").eq("workspace_id", ws).order("at", { ascending: false }).limit(20),
    ]);
    const users = new Map((await allUsers(sb)).map((u) => [u.id, u]));
    const crewIds = (mem.data ?? []).map((x) => x.crew_member_id).filter(Boolean) as string[];
    const { data: crew } = crewIds.length ? await sb.from("crew_members").select("id, name").in("id", crewIds) : { data: [] as { id: string; name: string }[] };
    const crewName = new Map((crew ?? []).map((c) => [c.id, c.name]));
    const spend: Record<string, number> = {};
    for (const r of ai.data ?? []) spend[r.function] = Math.round(((spend[r.function] ?? 0) + Number(r.cost_aud)) * 100) / 100;
    const owner = (mem.data ?? []).find((x) => x.role === "owner");
    return {
      id: w.id, name: w.name, created_at: w.created_at,
      owner: owner?.user_id ? users.get(owner.user_id)?.email ?? "—" : "—",
      billing: { plan: bill.data?.plan ?? "trial", status: bill.data?.status ?? "trial", seats: bill.data?.seats ?? 0, price: Number(bill.data?.price_aud ?? 0), notes: bill.data?.notes ?? "" },
      lastActivity: last.data?.at ?? null,
      spend,
      sms: (usage.data ?? []).filter((u) => u.kind === "sms").reduce((a, u) => a + u.units, 0),
      email: (usage.data ?? []).filter((u) => u.kind === "email").reduce((a, u) => a + u.units, 0),
      storageBytes: Number((storage.data ?? []).find((r) => r.workspace_id === ws)?.bytes ?? 0),
      // Name, role and last sign-in only.
      users: (mem.data ?? []).map((x) => {
        const u = x.user_id ? users.get(x.user_id) : undefined;
        return { name: (x.crew_member_id ? crewName.get(x.crew_member_id) : undefined) ?? u?.name ?? "—", role: x.role, lastSignIn: u?.last_sign_in_at ?? null };
      }),
      flags: flags.data ?? [],
      audit: (paudit.data ?? []).map((a) => ({ ...a, admin: a.admin_user_id ? users.get(a.admin_user_id)?.email ?? "admin" : "system" })),
      errors: errs.data ?? [],
    };
  });

export const adminErrors = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { sb, audit } = await adminGate(context.userId, context.claims);
    await audit("view_errors", null);
    const { data } = await sb.from("error_events").select("id, workspace_id, fn, message, at").gte("at", dayAgo(1)).order("at", { ascending: false }).limit(200);
    return data ?? [];
  });

export const adminPlatformFlags = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { sb } = await adminGate(context.userId, context.claims);
    const { data } = await sb.from("workspace_flags").select("flag, enabled, reason, updated_at").is("workspace_id", null);
    return data ?? [];
  });

/** Switch a Brain function on or off for one workspace (workspaceId) or everyone (null). Superadmin only. */
export const adminSetFlag = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { workspaceId: string | null; fn: string; enabled: boolean; reason?: string }) => {
    if (d.workspaceId !== null && !isId(d.workspaceId)) throw new Error("Bad workspace");
    if (d.fn !== "all" && !KILLABLE.includes(d.fn)) throw new Error("Unknown Brain function");
    return { workspaceId: d.workspaceId, fn: d.fn, enabled: !!d.enabled, reason: String(d.reason ?? "").slice(0, 300) };
  })
  .handler(async ({ data, context }) => {
    const { sb, role, audit } = await adminGate(context.userId, context.claims);
    if (role !== "superadmin") throw new Error("Only the superadmin can change switches.");
    await audit(data.enabled ? "flag_on" : "flag_off", data.workspaceId, { flag: flagName(data.fn), scope: data.workspaceId ? "workspace" : "everyone", reason: data.reason });
    const flag = flagName(data.fn);
    let q = sb.from("workspace_flags").select("id").eq("flag", flag);
    q = data.workspaceId ? q.eq("workspace_id", data.workspaceId) : q.is("workspace_id", null);
    const { data: ex } = await q.maybeSingle();
    const row = { enabled: data.enabled, reason: data.reason || null, updated_by: context.userId, updated_at: new Date().toISOString() };
    const { error } = ex
      ? await sb.from("workspace_flags").update(row).eq("id", ex.id)
      : await sb.from("workspace_flags").insert({ ...row, workspace_id: data.workspaceId, flag });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Plan, status, seats, price and notes. Superadmin only. */
export const adminSetBilling = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { workspaceId: string; plan: string; status: string; seats: number; price: number; notes: string }) => {
    if (!isId(d.workspaceId)) throw new Error("Bad workspace");
    if (!["trial", "active", "past_due", "paused", "cancelled"].includes(d.status)) throw new Error("Bad status");
    return { workspaceId: d.workspaceId, plan: String(d.plan).slice(0, 40) || "trial", status: d.status, seats: Math.max(0, Math.round(Number(d.seats) || 0)), price: Math.max(0, Number(d.price) || 0), notes: String(d.notes ?? "").slice(0, 4000) };
  })
  .handler(async ({ data, context }) => {
    const { sb, role, audit } = await adminGate(context.userId, context.claims);
    if (role !== "superadmin") throw new Error("Only the superadmin can change billing.");
    const { data: before } = await sb.from("workspace_billing").select("plan, status, seats, price_aud").eq("workspace_id", data.workspaceId).maybeSingle();
    await audit("update_billing", data.workspaceId, { before, after: { plan: data.plan, status: data.status, seats: data.seats, price_aud: data.price }, notes_changed: true });
    const { error } = await sb.from("workspace_billing").upsert({ workspace_id: data.workspaceId, plan: data.plan, status: data.status, seats: data.seats, price_aud: data.price, notes: data.notes, updated_at: new Date().toISOString() });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
