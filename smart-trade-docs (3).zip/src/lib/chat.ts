import { useEffect, useState } from "react";
import { queryOptions, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type Message = Database["public"]["Tables"]["messages"]["Row"];
export type Attachment = Database["public"]["Tables"]["attachments"]["Row"];

export function useUserId() {
  const [id, setId] = useState<string | null>(null);
  useEffect(() => { supabase.auth.getUser().then(({ data }) => setId(data.user?.id ?? null)); }, []);
  return id;
}

export const jobMessagesQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["messages", jobId],
    queryFn: async () => {
      const [m, a] = await Promise.all([
        supabase.from("messages").select("*").eq("job_id", jobId).order("created_at").limit(500),
        supabase.from("attachments").select("*").eq("job_id", jobId),
      ]);
      if (m.error) throw m.error;
      if (a.error) throw a.error;
      return { messages: m.data, attachments: a.data };
    },
  });

export const jobPeopleQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["job_people", jobId],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("job_people", { _job_id: jobId });
      if (error) throw error;
      return data;
    },
  });

/** Inbox: every channel the caller can read (RLS decides), with unread, mentions and problems. */
export const inboxQuery = (userId: string | null) =>
  queryOptions({
    queryKey: ["inbox", userId],
    enabled: !!userId,
    queryFn: async () => {
      const [m, r] = await Promise.all([
        supabase.from("messages").select("id, job_id, author_user_id, kind, body, task_id, mentions, created_at, deleted_at, jobs(code, name, sector), tasks(label)")
          .order("created_at", { ascending: false }).limit(1000),
        supabase.from("message_reads").select("job_id, last_read_at"),
      ]);
      if (m.error) throw m.error;
      if (r.error) throw r.error;
      const reads = new Map(r.data.map((x) => [x.job_id, x.last_read_at]));
      const byJob = new Map<string, { jobId: string; code: string; name: string; sector: string; last: (typeof m.data)[number]; unread: number; mention: boolean; problem: boolean }>();
      for (const x of m.data) {
        if (!x.jobs) continue;
        let c = byJob.get(x.job_id);
        if (!c) { c = { jobId: x.job_id, code: x.jobs.code, name: x.jobs.name, sector: x.jobs.sector, last: x, unread: 0, mention: false, problem: false }; byJob.set(x.job_id, c); }
        const read = reads.get(x.job_id);
        const isUnread = x.author_user_id !== userId && !x.deleted_at && (!read || x.created_at > read);
        if (isUnread) { c.unread++; if (x.mentions.includes(userId!)) c.mention = true; if (x.kind === "problem") c.problem = true; }
      }
      return [...byJob.values()].sort((a, b) => (b.unread > 0 ? 1 : 0) - (a.unread > 0 ? 1 : 0) || b.last.created_at.localeCompare(a.last.created_at));
    },
  });

export async function markRead(jobId: string, userId: string) {
  await supabase.from("message_reads").upsert({ job_id: jobId, user_id: userId, workspace_id: "00000000-0000-0000-0000-000000000000", last_read_at: new Date().toISOString() });
}

/** Live updates: RLS on realtime means only job readers receive a job's changes. */
export function useMessagesLive(jobId: string | null) {
  const qc = useQueryClient();
  useEffect(() => {
    const ch = supabase.channel(`messages-${jobId ?? "all"}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "messages", ...(jobId ? { filter: `job_id=eq.${jobId}` } : {}) }, () => {
        if (jobId) qc.invalidateQueries({ queryKey: ["messages", jobId] });
        qc.invalidateQueries({ queryKey: ["inbox"] });
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [jobId, qc]);
}
