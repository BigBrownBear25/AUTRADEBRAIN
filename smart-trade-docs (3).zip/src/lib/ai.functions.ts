import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  AI_MODEL, SUMMARY_KEYS, GUIDANCE_KEYS, checkShape,
  type InspectionSummary, type InstallGuidance, type AiResult,
} from "./ai-config";

const callClaude = async (meta: import("./claude.server").CallMeta, s: string, u: string, keys: readonly string[]) => (await import("./claude.server")).callClaude(meta, s, u, schemaOf(keys));

const SUMMARY_SYSTEM =
  "You are helping a flooring business in regional Australia turn a site walkthrough into a clean record. Keep to what was said; do not invent measurements. Australian spelling, metric units, short plain items of at most 20 words.";
const GUIDANCE_SYSTEM =
  "You are a senior flooring installer in regional Victoria and NSW writing a short crew brief. Use only the facts given. Where something important is unknown, tell the crew what to check rather than guessing numbers. Plain trade language, Australian spelling, metric units, at most 25 words an item.";

const arr = { type: "array", items: { type: "string" } };
const schemaOf = (keys: readonly string[]) => ({
  type: "object", additionalProperties: false, required: [...keys],
  properties: Object.fromEntries(keys.map((k) => [k, arr])),
});

/**
 * Only non-finance job columns. Never add client contact, pricing, job_finance,
 * material_costs or rates here — this is everything Claude may see about the job.
 */
const JOB_COLS =
  "id, workspace_id, code, name, sector, address, suburb, flooring, area_m2, start_date, crew_size, main_skill, other_skills, hazards, unique_notes, safety_notes, inspection_summary";

function parse<T>(text: string, keys: readonly string[]): T {
  let obj: unknown;
  try { obj = JSON.parse(text.replace(/^```(json)?|```$/g, "").trim()); } catch { throw new Error("Claude's answer couldn't be used. Try again later."); }
  const ok = checkShape(obj, keys);
  if (!ok) throw new Error("Claude's answer couldn't be used. Try again later.");
  return ok as T;
}

async function readJob(sb: any, jobId: string) {
  const { data: ok } = await sb.rpc("is_job_reader", { _job_id: jobId });
  if (!ok) throw new Error("You can't open this job");
  const { data: job, error } = await sb.from("jobs").select(JOB_COLS).eq("id", jobId).single();
  if (error || !job) throw new Error("Job not found");
  return job;
}

async function save(sb: any, job: { id: string; workspace_id: string }, field: "inspection_summary" | "guidance", value: unknown, tokens: number) {
  const { error } = await sb.rpc("set_job_ai", { _job_id: job.id, _field: field, _value: value });
  if (error) throw new Error(error.message);
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  await supabaseAdmin.from("usage_events").insert({ workspace_id: job.workspace_id, kind: "ai", units: tokens, detail: field });
}

const validJob = (d: { jobId: string }) => {
  if (!/^[0-9a-f-]{36}$/i.test(d?.jobId)) throw new Error("Bad job id");
  return d;
};

/** ai-inspection-summary: job readers who may save (office, foreman on the job). */
export const aiInspectionSummary = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(validJob)
  .handler(async ({ data, context }) => {
    const sb = context.supabase;
    const job = await readJob(sb, data.jobId);
    const { data: notes } = await sb.from("messages").select("body, speaker")
      .eq("job_id", job.id).eq("kind", "inspection").is("deleted_at", null).order("created_at");
    const withText = (notes ?? []).filter((n) => n.body.trim());
    if (!withText.length) throw new Error("Add some inspection notes first.");
    const input = [
      `Job: ${job.name}`, `Flooring: ${job.flooring ?? "not given"}`, `Area: ${job.area_m2 ? `${job.area_m2} m²` : "not given"}`,
      `Sector: ${job.sector}`, `Suburb: ${job.suburb ?? "not given"}`, "", "Inspection notes:",
      ...withText.map((n) => `[${n.speaker ?? "office"}] ${n.body.trim()}`),
      "", `Reply with JSON only: {${SUMMARY_KEYS.join("[], ")}[]}. Use an empty list for anything not mentioned.`,
    ].join("\n");
    const { text, tokens } = await callClaude({ ws: job.workspace_id, userId: context.userId, fn: "summary", feature: "job_ai" }, SUMMARY_SYSTEM, input, SUMMARY_KEYS);
    const result: AiResult<InspectionSummary> = { data: parse(text, SUMMARY_KEYS), at: new Date().toISOString(), notes: withText.length, model: AI_MODEL };
    await save(sb, job, "inspection_summary", result, tokens);
    return result;
  });

/** ai-install-guidance: crew brief from the job, its inspection summary, hazards and crew. */
export const aiInstallGuidance = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(validJob)
  .handler(async ({ data, context }) => {
    const sb = context.supabase;
    const job = await readJob(sb, data.jobId);
    const [{ data: asg }, { data: mats }] = await Promise.all([
      sb.from("assignments").select("crew_member_id, date").eq("job_id", job.id),
      sb.from("materials").select("item, qty, unit, status").eq("job_id", job.id).order("sort"),
    ]);
    const ids = [...new Set((asg ?? []).map((a) => a.crew_member_id))];
    const days = new Set((asg ?? []).map((a) => a.date)).size;
    // Crew names, roles and skills only — read server-side because field users can't see each other's skills.
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: crew } = ids.length
      ? await supabaseAdmin.from("crew_members").select("name, role, skills").in("id", ids).eq("workspace_id", job.workspace_id)
      : { data: [] as { name: string; role: string; skills: string[] }[] };
    const summary = (job.inspection_summary as AiResult<InspectionSummary> | null)?.data;
    const list = (xs: string[] | null | undefined) => (xs?.length ? xs.join(", ") : "none given");
    const input = [
      `Job code: ${job.code}`, `Name: ${job.name}`, `Sector: ${job.sector}`,
      `Site: ${[job.address, job.suburb].filter(Boolean).join(", ") || "not given"}`,
      `Start date: ${job.start_date ?? "not set"}`, `Working days: ${days || "not scheduled"}`, `Crew size: ${job.crew_size ?? "not given"}`,
      `Area: ${job.area_m2 ? `${job.area_m2} m²` : "not given"}`, `Flooring: ${job.flooring ?? "not given"}`,
      `Skills: ${list([job.main_skill, ...(job.other_skills ?? [])].filter(Boolean) as string[])}`,
      `Hazards: ${list(job.hazards)}`, `Unique aspects: ${job.unique_notes || "none given"}`, `Safety notes: ${job.safety_notes || "none given"}`,
      "Materials:", ...((mats ?? []).length ? mats!.map((m) => `- ${m.item}, ${m.qty ?? "?"} ${m.unit ?? ""}, ${m.status}`) : ["- none listed"]),
      "Inspection summary:", summary ? JSON.stringify(summary) : "none yet",
      "Crew:", ...((crew ?? []).length ? crew!.map((c) => `- ${c.name}, ${c.role}, skills: ${list(c.skills)}`) : ["- not assigned yet"]),
      "", `Reply with JSON only: {${GUIDANCE_KEYS.join("[], ")}[]}, 3 to 6 items each.`,
    ].join("\n");
    const { text, tokens } = await callClaude({ ws: job.workspace_id, userId: context.userId, fn: "guidance", feature: "job_ai" }, GUIDANCE_SYSTEM, input, GUIDANCE_KEYS);
    const result: AiResult<InstallGuidance> = { data: parse(text, GUIDANCE_KEYS), at: new Date().toISOString(), notes: summary ? 1 : 0, model: AI_MODEL };
    await save(sb, job, "guidance", result, tokens);
    return result;
  });
