import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const MIMES = new Set(["image/jpeg", "image/png", "image/webp"]);

/**
 * Runs vision-tag on a photo the caller just uploaded. The browser sends a copy resized to at most 1,600 px.
 * Only the uploader, on a job they can read, and only once per photo.
 */
export const tagPhoto = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { attachmentId: string; data: string; mime: string }) => {
    const data = String(d.data ?? "");
    if (data.length > 4_000_000) throw new Error("Photo too large to read");
    if (!MIMES.has(String(d.mime))) throw new Error("Unsupported photo type");
    return { attachmentId: String(d.attachmentId), data, mime: String(d.mime) };
  })
  .handler(async ({ data, context }) => {
    // As the caller: RLS shows the attachment only to job readers.
    const { data: att } = await context.supabase.from("attachments").select("id, job_id, kind, created_by").eq("id", data.attachmentId).maybeSingle();
    if (!att || att.kind !== "photo" || att.created_by !== context.userId) throw new Error("You can only read your own photos");
    const { visionTag } = await import("./vision.server");
    try { return await visionTag(att.id, { data: data.data, mime: data.mime }); }
    catch (e) { return { tags: [] as string[], actions: [] as string[], error: (e as Error).message }; }
  });
