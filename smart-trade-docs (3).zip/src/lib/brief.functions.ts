/**
 * Morning brief (spec section 6 "Morning brief", section 8). Built with the caller's own sign-in so RLS decides
 * what they see; the rules work out items and fixes, Claude (fn "brief", via runBrain) only writes the summary.
 * One row per office user per day in morning_briefs.
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { BriefChange, BriefItem, BriefItemStatus, BriefToday } from "@/lib/rules/morning-brief";

export type BriefRow = {
  id: string; for_date: string; since: string; today: BriefToday; changes: BriefChange[]; items: BriefItem[];
  summary: string; model: string | null; created_at: string;
};

/** ISO instant for a local wall-clock time in a time zone. */
function zonedIso(date: string, time: string, tz: string): string {
  const guess = new Date(`${date}T${time}:00Z`);
  const off = new Intl.DateTimeFormat("en-AU", { timeZone: tz, timeZoneName: "longOffset" }).formatToParts(guess).find((p) => p.type === "timeZoneName")?.value ?? "GMT+10:00";
  const m = off.match(/GMT([+-])(\d{2}):?(\d{2})?/);
  const mins = m ? (m[1] === "-" ? -1 : 1) * (Number(m[2]) * 60 + Number(m[3] ?? 0)) : 600;
  return new Date(guess.getTime() - mins * 60_000).toISOString();
}

const SUMMARY_SCHEMA = { type: "object", additionalProperties: false, required: ["summary"], properties: { summary: { type: "string" } } };
const TASK = "You are the scheduling assistant for a flooring business in regional Australia, writing the scheduler's start-of-day brief. Use only the facts given. Do not add problems, people, jobs or numbers. Lead with what most needs sorting before 10 am. Plain, direct Australian English. Write the summary in at most 3 sentences. Give no money values.";

export const getMorningBrief = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { refresh?: boolean }) => ({ refresh: !!d?.refresh }))
  .handler(async ({ data, context }): Promise<BriefRow | null> => {
    const sb = context.supabase;
    const { personContext, runBrain, limits } = await import("./brain/runner.server");
    const ctx = await personContext(sb, context.userId, "brief");
    if (!ctx.office) throw new Error("The morning brief is for office users.");
    const ws = ctx.ws;
    const { localDate, localHm } = await import("./rules/brain-rules");
    const { data: bs } = await sb.from("brain_settings").select("timezone").eq("workspace_id", ws).maybeSingle();
    const tz = bs?.timezone ?? "Australia/Melbourne";
    const now = new Date();
    const today = localDate(now, tz);

    const { data: last } = await sb.from("morning_briefs").select("*").eq("workspace_id", ws).eq("user_id", context.userId).order("for_date", { ascending: false }).limit(2);
    const todays = (last ?? []).find((r) => r.for_date === today);
    // Built the first time each day after 3 am; before 3 am the latest brief stands.
    if (!data.refresh && (todays || (localHm(now, tz) < "03:00" && last?.[0]))) return (todays ?? last![0]) as unknown as BriefRow;

    const { buildSchedulingApi, loadSchedulingRaw } = await import("./scheduling-core");
    const { flagsFor, fixFor } = await import("./brain/watch.server");
    const { nextWorkingDays } = await import("./rules/working-days");
    const { addDays } = await import("./rules/board");
    const { rangeCapacity } = await import("./rules/availability");
    const { priorityOf } = await import("./rules/priority");
    const { hm } = await import("./assignments");
    const R = await import("./rules/morning-brief");

    const a = buildSchedulingApi(await loadSchedulingRaw(sb, ws, today));
    const prevBrief = (last ?? []).find((r) => r.for_date < today);
    let prev = addDays(today, -1);
    for (let i = 0; i < 10 && nextWorkingDays(prev, 1, a.week)[0] !== prev; i++) prev = addDays(prev, -1);
    const since = todays?.since ?? prevBrief?.created_at ?? zonedIso(prev, "17:00", tz);
    const name = (id: string) => a.people.find((p) => p.id === id)?.name ?? "Someone";

    // ---- Today strip ----
    const todayBk = a.bookingsRaw.filter((b) => b.date === today);
    const ids = a.people.map((p) => p.id);
    const capLeave = a.leave.filter((l) => l.status !== "declined").map((l) => ({ crew_member_id: l.crew_member_id, from: l.from_date, to: l.to_date, status: l.status === "approved" ? "approved" as const : "requested" as const }));
    const hours = { dayStart: hm(a.settings.day_start), dayEnd: hm(a.settings.day_end) };
    const cap = rangeCapacity(ids, [today], hours, capLeave, todayBk.map((b) => ({ crew_member_id: b.crew_member_id, job_id: b.job_id, date: b.date, start: hm(b.start_time), end: hm(b.end_time) })));
    const util = cap.availableHours > 0 ? Math.round((cap.bookedHours / cap.availableHours) * 100) : 0;
    const todayFacts: BriefToday = {
      crewWorking: new Set(todayBk.map((b) => b.crew_member_id)).size,
      jobsStarting: a.jobs.filter((j) => j.start_date === today).length,
      away: a.leave.filter((l) => l.status === "approved" && l.from_date <= today && today <= l.to_date).map((l) => ({ name: name(l.crew_member_id), type: l.type })),
      utilisationPct: util,
    };

    // ---- Since you last looked ----
    const in30 = addDays(today, 30);
    const [lv, jb, pr, filed, waiting, mats, deps, tix] = await Promise.all([
      sb.from("leave").select("id", { count: "exact", head: true }).eq("workspace_id", ws).or(`created_at.gte.${since},decided_at.gte.${since}`),
      sb.from("jobs").select("id, status").eq("workspace_id", ws).gte("created_at", since),
      sb.from("messages").select("id, job_id, author_user_id, created_at").eq("workspace_id", ws).eq("kind", "problem").is("deleted_at", null).gte("created_at", since),
      sb.from("inbound_emails").select("id", { count: "exact", head: true }).eq("workspace_id", ws).eq("status", "filed").gte("filed_at", since),
      sb.from("inbound_emails").select("id", { count: "exact", head: true }).eq("workspace_id", ws).eq("status", "unfiled"),
      sb.from("audit_log").select("id", { count: "exact", head: true }).eq("workspace_id", ws).eq("table_name", "materials").gte("at", since),
      sb.from("audit_log").select("id", { count: "exact", head: true }).eq("workspace_id", ws).eq("table_name", "dependencies").gte("at", since),
      sb.from("crew_tickets").select("id", { count: "exact", head: true }).eq("workspace_id", ws).gte("expires_on", today).lte("expires_on", in30),
    ]);
    const problems = pr.data ?? [];
    let unreplied = 0;
    if (problems.length) {
      const { data: later } = await sb.from("messages").select("job_id, author_user_id, created_at").eq("workspace_id", ws).in("job_id", [...new Set(problems.map((p) => p.job_id))]).is("deleted_at", null).gte("created_at", since);
      unreplied = problems.filter((p) => !(later ?? []).some((m) => m.job_id === p.job_id && m.created_at > p.created_at && m.author_user_id && m.author_user_id !== p.author_user_id)).length;
    }
    const newJobs = jb.data ?? [];
    const changes: BriefChange[] = [
      { kind: "leave", label: "Leave requested, approved or entered", count: lv.count ?? 0, to: "/crew" },
      { kind: "jobs", label: "New jobs", count: newJobs.filter((j) => j.status !== "enquiry").length, to: "/jobs" },
      { kind: "enquiries", label: "New enquiries", count: newJobs.filter((j) => j.status === "enquiry").length, to: "/jobs" },
      { kind: "problems", label: "Problems nobody has replied to", count: unreplied, to: "/messages" },
      { kind: "filed", label: "Emails filed to jobs", count: filed.count ?? 0, to: "/messages" },
      { kind: "unfiled", label: "Emails waiting in Unfiled", count: waiting.count ?? 0, to: "/messages" },
      { kind: "materials", label: "Material changes", count: mats.count ?? 0, to: "/jobs" },
      { kind: "dependencies", label: "Dependency changes", count: deps.count ?? 0, to: "/jobs" },
      { kind: "tickets", label: "Tickets expiring in 30 days", count: tix.count ?? 0, to: "/crew" },
    ];

    // ---- Sort first: Needs attention over the next 10 working days ----
    const window = nextWorkingDays(today, 10, a.week);
    const end = window[window.length - 1] ?? today;
    const jobIds = a.jobs.filter((j) => !["complete", "closed"].includes(j.status) &&
      ((j.start_date && j.start_date >= today && j.start_date <= end) || (!j.start_date && j.due_by && j.due_by <= end))).map((j) => j.id);
    const flags = await flagsFor(sb as never, a, jobIds);
    const all: (BriefItem & { flag: { level: "red" | "amber"; text: string } })[] = [];
    for (const [id, fl] of flags) {
      const j = a.jobMap.get(id)!; if (!fl.length) continue;
      const top = [...fl].sort((x, y) => (x.level === "red" ? 0 : 1) - (y.level === "red" ? 0 : 1))[0]!;
      all.push({ key: `${id}:${top.text.replace(/\d+/g, "#")}`, job_id: id, code: j.code, name: j.name, suburb: j.suburb ?? null, level: top.level,
        problem: top.text, reasons: fl.filter((f) => f !== top).map((f) => f.text), start: j.start_date ?? j.due_by ?? null,
        priority: priorityOf(j as never, today), fix: null, status: "open", flag: top });
    }
    const old = new Map(((todays?.items ?? []) as unknown as BriefItem[]).map((i) => [i.key, i]));
    const items: BriefItem[] = [];
    for (const it of R.rankBriefItems(all, 5)) {
      const { flag, ...rest } = it;
      const pid = await fixFor(sb as never, a, ws, it.job_id, flag, "brief", null, context.userId);
      let fix: BriefItem["fix"] = null;
      if (pid) { const { data: p } = await sb.from("proposals").select("title, status").eq("id", pid).single(); if (p) fix = { proposal_id: pid, title: p.title }; }
      items.push({ ...rest, fix, status: old.get(it.key)?.status ?? "open" });
    }

    // ---- Summary: Claude from the facts only, else the template ----
    const facts = JSON.stringify({ today: todayFacts, changes: changes.map(({ label, count }) => ({ label, count })),
      items: items.map((i) => ({ code: i.code, name: i.name, suburb: i.suburb, level: i.level, problem: i.problem, reasons: i.reasons, fix: i.fix?.title ?? null })) });
    let summary = R.briefTemplate(todayFacts, changes, items);
    let model: string | null = null;
    try {
      const lim = await limits(ws, context.userId);
      if (lim.state !== "paused" && lim.features["brief"] !== false) {
        items.forEach((i) => ctx.seen.codes.add(i.code));
        const r = await runBrain(ctx, { fn: "brief", feature: "brief", task: TASK, input: `The brief's facts:\n${(await import("./brain/checks")).untrusted("brief facts", facts)}`, schema: SUMMARY_SCHEMA, tools: [] });
        const s = R.capSentences(String((r.json as { summary?: string })?.summary ?? "").trim(), 3);
        if (s && !R.namesNotInFacts(s, facts, a.people.map((p) => p.name)).length) { summary = s; model = r.model; }
      }
    } catch (e) { console.error("brief summary", (e as Error).message); }

    const row = { workspace_id: ws, user_id: context.userId, for_date: today, since, today: todayFacts as never, changes: changes as never, items: items as never, summary, model };
    const { data: saved, error } = await sb.from("morning_briefs").upsert(row, { onConflict: "workspace_id,user_id,for_date" }).select("*").single();
    if (error) throw new Error(error.message);
    return saved as unknown as BriefRow;
  });

/** The user records what happened to an item on their own brief: applied, opened or dismissed. */
export const markBriefItem = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string; key: string; status: BriefItemStatus }) => {
    if (!/^[0-9a-f-]{36}$/i.test(d?.id ?? "") || typeof d?.key !== "string") throw new Error("Bad brief item");
    if (!["open", "applied", "opened", "dismissed"].includes(d.status)) throw new Error("Bad status");
    return d;
  })
  .handler(async ({ data, context }) => {
    const sb = context.supabase;
    const { data: b, error } = await sb.from("morning_briefs").select("items").eq("id", data.id).eq("user_id", context.userId).single();
    if (error || !b) throw new Error("Brief not found");
    const items = (b.items as unknown as BriefItem[]).map((i) => (i.key === data.key && !(data.status === "opened" && i.status !== "open") ? { ...i, status: data.status } : i));
    const { error: ue } = await sb.from("morning_briefs").update({ items: items as never }).eq("id", data.id).eq("user_id", context.userId);
    if (ue) throw new Error(ue.message);
    return { ok: true };
  });
