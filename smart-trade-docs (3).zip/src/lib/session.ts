import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type AppRole = Database["public"]["Enums"]["app_role"];
export type ViewMode = "office" | "field";

export const OFFICE_ROLES: AppRole[] = ["owner", "office"];
export const FIELD_ROLES: AppRole[] = ["foreman", "installer", "apprentice", "subcontractor"];

export const roleLabel: Record<AppRole, string> = {
  owner: "Owner",
  office: "Office",
  foreman: "Foreman",
  installer: "Installer",
  apprentice: "Apprentice",
  subcontractor: "Subcontractor",
};

export function modeForRole(role: AppRole): ViewMode {
  return OFFICE_ROLES.includes(role) ? "office" : "field";
}

/** Office roles must finish authenticator-app sign-in (AAL2). */
export function requiresTwoFactor(role: AppRole) {
  return OFFICE_ROLES.includes(role);
}

export type ActiveMembership = {
  id: string;
  role: AppRole;
  workspaceId: string;
  workspaceName: string;
};

/** Activates any invites for the signed-in email, then returns the user's active membership. */
export async function loadMembership(userId: string): Promise<ActiveMembership | null> {
  await supabase.rpc("accept_pending_invites");
  const { data, error } = await supabase
    .from("memberships")
    .select("id, role, workspace_id, last_selected_at, workspaces(name)")
    .eq("user_id", userId)
    .eq("status", "active")
    .order("last_selected_at", { ascending: false, nullsFirst: false })
    .order("created_at", { ascending: true });
  if (error) throw error;
  if (!data?.length) return null;
  // Same choice as the server's personContext: the workspace last picked in the switcher, else owner, else oldest.
  const m = data.find((r) => r.last_selected_at) ?? data.find((r) => r.role === "owner") ?? data[0]!;
  return {
    id: m.id,
    role: m.role,
    workspaceId: m.workspace_id,
    workspaceName: (m.workspaces as { name: string } | null)?.name ?? "Workspace",
  };
}

/** Every workspace the person is active in, for the account-menu switcher. */
export async function listMyWorkspaces(userId: string) {
  const { data } = await supabase.from("memberships").select("workspace_id, role, workspaces(name)").eq("user_id", userId).eq("status", "active").order("created_at");
  return (data ?? []).map((m) => ({ workspaceId: m.workspace_id, role: m.role, name: (m.workspaces as { name: string } | null)?.name ?? "Workspace" }));
}
