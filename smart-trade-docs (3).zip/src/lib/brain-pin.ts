/**
 * Brain bar context: the job the bar is pinned to (opened from a job file, job chat or job card),
 * and the jobs this person opened in the last 2 hours (a matching clue worth 10).
 * Browser-only state; read inside effects or useSyncExternalStore.
 */
import { useSyncExternalStore } from "react";

export type PinnedJob = { id: string; code: string; label: string };
let pinned: PinnedJob | null = null;
const subs = new Set<() => void>();
const emit = () => subs.forEach((f) => f());
const KEY = "tb-recent-jobs";
const TWO_HOURS = 2 * 60 * 60 * 1000;

export function pinBrain(job: { id: string; code: string; address?: string | null; suburb?: string | null; name?: string | null }) {
  const where = [job.address, job.suburb].filter(Boolean).join(", ") || job.name || "";
  pinned = { id: job.id, code: job.code, label: where };
  noteOpened(job.id);
  emit();
}
/** Unpins only if this job is still the pinned one (so closing an old sheet doesn't clear a newer pin). */
export function unpinBrain(id?: string) {
  if (!pinned || (id && pinned.id !== id)) return;
  pinned = null; emit();
}
export function usePinnedJob() {
  return useSyncExternalStore((f) => { subs.add(f); return () => subs.delete(f); }, () => pinned, () => null);
}

export function noteOpened(id: string) {
  try {
    const now = Date.now();
    const list = (JSON.parse(localStorage.getItem(KEY) ?? "[]") as { id: string; at: number }[]).filter((x) => x.id !== id && now - x.at < TWO_HOURS);
    localStorage.setItem(KEY, JSON.stringify([{ id, at: now }, ...list].slice(0, 20)));
  } catch { /* storage off */ }
}
export function recentJobIds(): string[] {
  try {
    const now = Date.now();
    return (JSON.parse(localStorage.getItem(KEY) ?? "[]") as { id: string; at: number }[]).filter((x) => now - x.at < TWO_HOURS).map((x) => x.id);
  } catch { return []; }
}
