import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Database } from "@/integrations/supabase/types";

export type AccessReport = {
  email: string;
  role: string;
  level?: string;
  error?: string;
  jobs: string[];
  people: string[];
  crewMates: string[];
  assignments: number;
  leave: string;
  finance: { job_finance: number; crew_rates: number; material_costs: number; workspace_finance_settings: number };
  other: { memberships: number; audit_log: number; workspace_settings: number };
  /** Section 12: what each account can reach of the platform admin tables. Everything should be 0 / refused / Not found. */
  platform?: { platform_admins: number; error_events: number; other_platform_audit: number; flag_write: string; billing_write: string; audit_change: string; admin_area: string };
};

/**
 * Owner-only. For each account, opens a short-lived session as that user and runs read-only
 * queries through row-level security, reporting only rows from the owner's own workspace.
 */
export const runAccessCheck = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { workspaceId: string; extraEmails: string[] }) => ({
    workspaceId: String(input.workspaceId),
    extraEmails: (input.extraEmails ?? []).map((e) => String(e).trim().toLowerCase()).filter(Boolean).slice(0, 10),
  }))
  .handler(async ({ data, context }): Promise<AccessReport[]> => {
    const { data: isOwner } = await context.supabase.rpc("is_owner", { _ws: data.workspaceId });
    if (!isOwner) throw new Error("Only the workspace owner can run the access check");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const ws = data.workspaceId;

    const { data: members, error: mErr } = await supabaseAdmin
      .from("memberships").select("user_id, role").eq("workspace_id", ws).eq("status", "active").not("user_id", "is", null);
    if (mErr) throw new Error(mErr.message);

    const accounts: { email: string; role: string }[] = [];
    for (const m of members ?? []) {
      const { data: u } = await supabaseAdmin.auth.admin.getUserById(m.user_id!);
      if (u.user?.email) accounts.push({ email: u.user.email.toLowerCase(), role: m.role });
    }
    for (const e of data.extraEmails) if (!accounts.some((a) => a.email === e)) accounts.push({ email: e, role: "not a member" });

    const url = process.env["SUPABASE_URL"]!;
    const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
    const reports: AccessReport[] = [];

    for (const acc of accounts) {
      const empty: AccessReport = {
        ...acc, jobs: [], people: [], crewMates: [], assignments: 0, leave: "None",
        finance: { job_finance: 0, crew_rates: 0, material_costs: 0, workspace_finance_settings: 0 },
        other: { memberships: 0, audit_log: 0, workspace_settings: 0 },
      };
      const link = await supabaseAdmin.auth.admin.generateLink({ type: "magiclink", email: acc.email });
      const tokenHash = link.data?.properties?.hashed_token;
      if (link.error || !tokenHash) { reports.push({ ...empty, error: "No account with this email" }); continue; }

      const as = createClient<Database>(url, key, {
        auth: { persistSession: false, autoRefreshToken: false, storage: undefined },
        global: { fetch: (input, init) => {
          const h = new Headers(init?.headers);
          if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
          h.set("apikey", key);
          return fetch(input, { ...init, headers: h });
        } },
      });
      const { error: vErr } = await as.auth.verifyOtp({ token_hash: tokenHash, type: "email" });
      if (vErr) { reports.push({ ...empty, error: vErr.message }); continue; }
      const { data: aal } = await as.auth.mfa.getAuthenticatorAssuranceLevel();
      empty.level = aal?.currentLevel === "aal2" ? "aal2 (two-factor done)" : "aal1 (no two-factor)";

      try {
        const count = async (table: "job_finance" | "crew_rates" | "material_costs" | "workspace_finance_settings" | "memberships" | "audit_log" | "workspace_settings" | "assignments") => {
          const { count: c } = await as.from(table).select("*", { count: "exact", head: true }).eq("workspace_id", ws);
          return c ?? 0;
        };
        const { data: jobs } = await as.from("jobs").select("id, code, name").eq("workspace_id", ws).order("code");
        const { data: lv } = await as.from("leave").select("type, crew_members(name)").eq("workspace_id", ws);
        const leaveText = (lv ?? []).length ? (lv ?? []).map((l) => `${(l.crew_members as { name: string } | null)?.name ?? "?"}: ${l.type}`).join("; ") : "None";
        const { data: people } = await as.from("crew_members").select("name").eq("workspace_id", ws).order("name");
        const mates = new Set<string>();
        for (const j of jobs ?? []) {
          const { data: cm } = await as.rpc("crew_mates", { _job_id: j.id });
          for (const p of cm ?? []) mates.add(`${p.name} (${j.code})`);
        }
        const refused = (r: { error: unknown; data?: unknown; count?: number | null }) => (r.error || !(Array.isArray(r.data) ? r.data.length : r.data) ? "refused" : "ALLOWED");
        const pa = await as.from("platform_admins").select("*", { count: "exact", head: true });
        const ee = await as.from("error_events").select("*", { count: "exact", head: true });
        const op = await as.from("platform_audit").select("*", { count: "exact", head: true }).or(`workspace_id.is.null,workspace_id.neq.${ws}`);
        const fw = await as.from("workspace_flags").insert({ workspace_id: ws, flag: "brain:access_check_probe", enabled: false }).select("id");
        if (!fw.error && fw.data?.length) await supabaseAdmin.from("workspace_flags").delete().in("id", fw.data.map((x) => x.id));
        const bw = await as.from("workspace_billing").update({ notes: "access check probe" }).eq("workspace_id", ws).select("workspace_id");
        const ac = await as.from("platform_audit").update({ action: "tampered" }).eq("workspace_id", ws).select("id");
        const { data: au } = await as.auth.getUser();
        const { data: isAdmin } = au.user ? await supabaseAdmin.from("platform_admins").select("user_id").eq("user_id", au.user.id).maybeSingle() : { data: null };
        const platform = {
          platform_admins: pa.count ?? 0, error_events: ee.count ?? 0, other_platform_audit: op.count ?? 0,
          flag_write: refused(fw), billing_write: refused(bw), audit_change: refused(ac),
          admin_area: isAdmin && aal?.currentLevel === "aal2" ? "Opens (platform admin with two-factor)" : "Not found",
        };
        reports.push({
          ...empty,
          platform,
          jobs: (jobs ?? []).map((j) => `${j.code} ${j.name}`),
          people: (people ?? []).map((p) => p.name),
          crewMates: [...mates],
          leave: leaveText,
          assignments: await count("assignments"),
          finance: {
            job_finance: await count("job_finance"),
            crew_rates: await count("crew_rates"),
            material_costs: await count("material_costs"),
            workspace_finance_settings: await count("workspace_finance_settings"),
          },
          other: { memberships: await count("memberships"), audit_log: await count("audit_log"), workspace_settings: await count("workspace_settings") },
        });
      } finally {
        await as.auth.signOut({ scope: "local" });
      }
    }
    return reports;
  });
