import { AI_MODEL } from "./ai-config";

const GATEWAY = "https://ai.gateway.lovable.dev/v1/messages";

export type CallMeta = { ws: string; userId: string | null; fn: "summary" | "guidance" | "email_match"; feature: string };

/**
 * One streamed Claude call; accumulates text server-side. Never retried.
 * Like runBrain: checks the feature switch and monthly budget first, and writes one ai_runs row.
 */
export async function callClaude(meta: CallMeta, system: string, user: string, schema: object, maxTokens = 4000) {
  if (!user?.trim()) throw new Error("I didn't catch that. Try again.");
  await (await import("./platform/flags.server")).assertBrainOn(meta.ws, meta.fn);
  const { limits } = await import("./brain/runner.server");
  const lim = await limits(meta.ws, null);
  if (lim.features[meta.feature] === false) throw new Error("This AI feature is switched off in Settings.");
  if (lim.state === "paused") throw new Error("The monthly AI budget is used up, so this is paused until next month.");
  const t0 = Date.now();
  let inTok = 0, outTok = 0, err: string | null = null;
  try {
    const r = await stream(system, user, schema, maxTokens);
    inTok = r.inTok; outTok = r.outTok;
    return { text: r.text, tokens: inTok + outTok };
  } catch (e) {
    err = (e as Error)?.message ?? "error";
    void import("./platform/errors.server").then((m) => m.recordError(`ai:${meta.fn}`, e, meta.ws));
    if ((e as { inTok?: number }).inTok) { inTok = (e as any).inTok; outTok = (e as any).outTok; }
    throw e;
  } finally {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { runCostAud } = await import("./brain/rates");
    await supabaseAdmin.from("ai_runs").insert({
      workspace_id: meta.ws, user_id: meta.userId, function: meta.fn, model: AI_MODEL, input_tokens: inTok, output_tokens: outTok,
      tool_calls: [] as never, ok: !err, error: err, ms: Date.now() - t0, cost_aud: runCostAud(AI_MODEL, inTok, outTok),
    });
  }
}

async function stream(system: string, user: string, schema: object, maxTokens: number) {
  const key = process.env["LOVABLE_API_KEY"];
  if (!key) throw new Error("The AI service isn't set up");
  const res = await fetch(GATEWAY, {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json", "X-Lovable-AIG-SDK": "fetch" },
    body: JSON.stringify({
      model: AI_MODEL, max_tokens: maxTokens, stream: true, system,
      messages: [{ role: "user", content: user.trim() }],
      output_config: { format: { type: "json_schema", schema } },
    }),
  });
  if (!res.ok || !res.body) {
    let msg = "";
    try { const j = await res.json(); msg = j?.error?.message ?? j?.message ?? ""; } catch { /* ignore */ }
    if (res.status === 402) throw new Error(msg || "AI credits have run out. Top up to keep using Claude features.");
    if (res.status === 429) throw new Error("Claude is busy right now. Try again in a minute.");
    if (res.status === 403) throw new Error(msg || "Claude refused access for this request.");
    throw new Error(msg || `Claude couldn't answer (${res.status}).`);
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "", text = "", stop = "", inTok = 0, outTok = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf("\n\n")) >= 0) {
      const frame = buf.slice(0, i); buf = buf.slice(i + 2);
      const line = frame.split("\n").find((l) => l.startsWith("data:"));
      if (!line) continue;
      let ev: any;
      try { ev = JSON.parse(line.slice(5).trim()); } catch { continue; }
      if (ev.type === "message_start") inTok = ev.message?.usage?.input_tokens ?? 0;
      else if (ev.type === "content_block_delta" && ev.delta?.type === "text_delta") text += ev.delta.text;
      else if (ev.type === "message_delta") { stop = ev.delta?.stop_reason ?? stop; outTok = ev.usage?.output_tokens ?? outTok; }
      else if (ev.type === "error") throw new Error(ev.error?.message ?? "Claude stopped with an error");
    }
  }
  if (stop === "refusal") throw Object.assign(new Error("Claude declined to answer this one."), { inTok, outTok });
  return { text, inTok, outTok };
}

