import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Links last 60 seconds, so someone removed from a job loses even already-open links within a minute. */
const TTL = 60;

/**
 * Issues short-lived links to job files. Paths are workspace_id/job_id/file.
 * Checks the caller is a job reader for each job before signing.
 */
export const getJobFileUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { path: string }) => ({ path: String(input.path) }))
  .handler(async ({ data, context }) => {
    const jobId = data.path.split("/")[1];
    if (!jobId) throw new Error("Bad file path");
    const { data: ok } = await context.supabase.rpc("is_job_reader", { _job_id: jobId });
    if (!ok) throw new Error("You don't have access to this file");
    const { data: signed, error } = await context.supabase.storage.from("job-files").createSignedUrl(data.path, TTL);
    if (error) throw new Error(error.message);
    return { url: signed.signedUrl };
  });

/** Same check, many files on one job at once (for a chat screen). */
export const getJobFileUrls = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { jobId: string; paths: string[] }) => ({ jobId: String(input.jobId), paths: (input.paths ?? []).map(String).slice(0, 100) }))
  .handler(async ({ data, context }) => {
    if (data.paths.some((p) => p.split("/")[1] !== data.jobId)) throw new Error("Files must belong to this job");
    const { data: ok } = await context.supabase.rpc("is_job_reader", { _job_id: data.jobId });
    if (!ok) throw new Error("You don't have access to this job");
    if (!data.paths.length) return {} as Record<string, string>;
    const { data: signed, error } = await context.supabase.storage.from("job-files").createSignedUrls(data.paths, TTL);
    if (error) throw new Error(error.message);
    return Object.fromEntries(signed.filter((s) => s.signedUrl && s.path).map((s) => [s.path!, s.signedUrl])) as Record<string, string>;
  });
