/**
 * Brain server functions for people: apply (with a fresh fit check), capture (Brain bar),
 * Ask, and the owner's AI test page. Every one runs with the caller's own sign-in.
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const isId = (s: unknown) => typeof s === "string" && /^[0-9a-f-]{36}$/i.test(s);
const brain = () => import("./brain/runner.server");
const toolsMod = () => import("./brain/tools.server");

function friendly(e: unknown): never {
  const m = (e as Error)?.message ?? "Something went wrong";
  throw new Error(m);
}

/** apply-proposal: re-runs fitCheck on today's data; a clash needs "Apply anyway" (office only). */
export const applyProposal = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string; anyway?: boolean; payload?: Record<string, unknown> | null }) => {
    if (!isId(d?.id)) throw new Error("Bad proposal id");
    return { id: d.id, anyway: !!d.anyway, payload: d.payload && typeof d.payload === "object" ? d.payload : null };
  })
  .handler(async ({ data, context }) => {
    const sb = context.supabase;
    const { data: p, error } = await sb.from("proposals").select("*").eq("id", data.id).single();
    if (error || !p) throw new Error("Proposal not found");
    const payload = (data.payload ?? p.payload) as Record<string, any>;
    if (p.job_id && ["place", "move", "swap", "add_person"].includes(p.kind) && Array.isArray(payload["rows"]) && payload["start_date"]) {
      const { personContext } = await brain();
      const ctx = await personContext(sb, context.userId, p.source);
      const { buildSchedulingApi, loadSchedulingRaw, toRuleJob } = await import("./scheduling-core");
      const { fitCheck } = await import("./rules/fit-check");
      const a = buildSchedulingApi(await loadSchedulingRaw(sb, ctx.ws, ctx.today));
      const j = a.jobMap.get(p.job_id);
      if (j) {
        const rj = toRuleJob(j);
        const base = a.ctxFor(rj);
        const c = { ...base, bookings: base.bookings.filter((b) => b.job_id !== p.job_id) };
        const ids = [...new Set((payload["rows"] as { crew_member_id: string }[]).map((r) => r.crew_member_id))];
        const fit = ids.map((id) => {
          const person = a.people.find((x) => x.id === id);
          return person ? { person: person.name, ...fitCheck(rj, { id: person.id, name: person.name, role: person.role, skills: person.skills ?? [], tickets: person.crew_tickets }, payload["start_date"], c) }
            : { person: "Unknown", level: "clash" as const, reasons: [{ level: "clash" as const, check: "Person", text: "No longer in the crew" }] };
        });
        if (fit.some((f) => f.level === "clash") && !data.anyway) return { applied: false as const, needsAnyway: true, fit };
      }
    }
    const { data: res, error: e2 } = await sb.rpc("apply_proposal", { _id: data.id, _anyway: data.anyway, _payload: (data.payload ?? null) as never });
    if (e2) throw new Error(e2.message);
    return { applied: true as const, needsAnyway: false, fit: null, result: res };
  });

/** brain-capture: "Here's what I understood" from Brain bar speech or text.
 * Claude only extracts clues (spec section 6 "Matching to the right job"); the matcher in
 * src/lib/rules/jobMatch.ts scores jobs and the person confirms.
 * Claude's structured output allows at most 16 nullable/union fields and rejects enums on type arrays,
 * so every field is a plain string/number/array with "" (or 0) meaning "not said"; normaliseCard turns those into null. */
const S = { type: "string" } as const;
const SA = { type: "array", items: S } as const;
const CLUE_KEYS = ["job_codes", "client_names", "builder_names", "streets", "suburbs", "lot_units", "job_words", "people", "dates", "flooring"] as const;
export const CAPTURE_SCHEMA = {
  type: "object", additionalProperties: false, required: ["kind", "summary", "urgency", "question", "clues", "fields"],
  properties: {
    kind: { type: "string", enum: ["message", "problem", "task", "variation", "leave", "enquiry", "call_log", "question"] },
    summary: S, question: S,
    urgency: { type: "string", enum: ["now", "today", "this_week", ""] },
    clues: { type: "object", additionalProperties: false, required: [...CLUE_KEYS], properties: Object.fromEntries(CLUE_KEYS.map((k) => [k, SA])) },
    fields: {
      type: "object", additionalProperties: false,
      required: ["name", "client_name", "client_phone", "builder_company", "builder_pm_name", "builder_pm_phone", "address", "suburb", "flooring", "area_m2", "sector", "contact_name", "contact_role", "direction", "leave_type", "from_date", "to_date", "note", "task_label"],
      properties: {
        name: S, client_name: S, client_phone: S, builder_company: S, builder_pm_name: S, builder_pm_phone: S,
        address: S, suburb: S, flooring: S, area_m2: { type: "number" },
        sector: { type: "string", enum: ["domestic", "commercial", ""] },
        contact_name: S, contact_role: { type: "string", enum: ["client", "builder", "supplier", "crew", "other", ""] },
        direction: { type: "string", enum: ["in", "out", ""] },
        leave_type: S, from_date: S, to_date: S, note: S, task_label: S,
      },
    },
  },
};

export type CaptureKind = "message" | "problem" | "task" | "variation" | "leave" | "enquiry" | "call_log" | "question";
export const JOB_KINDS: CaptureKind[] = ["message", "problem", "task", "variation"];
export type Candidate = {
  id: string; code: string; name: string; address: string | null; suburb: string | null; client_name: string | null; builder_company: string | null;
  next_day: string | null; crew: string[]; score: number; matchedOn: string[];
};
export type CaptureMatch = { how: "pinned" | "today" | "confident" | "ask" | "none"; candidates: Candidate[]; preselected: string | null; notice: string | null };
export type CaptureCard = {
  kind: CaptureKind; summary: string; question: string | null; urgency: "now" | "today" | "this_week" | null;
  clues: Record<(typeof CLUE_KEYS)[number], string[]>;
  fields: Record<string, any>;
  match: CaptureMatch | null;
  /** The person's pick: a job, or a no-job choice. */
  job_id: string | null; no_job: "enquiry" | "unfiled" | null;
  /** Leave for a named person: the matched crew (more than one = the person picks). */
  people?: { id: string; name: string; role: string | null; base_suburb: string | null }[];
  person_id?: string | null;
};

/** Crew in the workspace matching the name said, through the caller's own RLS. */
async function crewByName(sb: any, ws: string, said: string) {
  const { matchPeople } = await import("./rules/personMatch");
  const { data } = await sb.from("crew_members").select("id, name, role, base_suburb").eq("workspace_id", ws).eq("active", true);
  return matchPeople(said, (data ?? []) as { id: string; name: string; role: string | null; base_suburb: string | null }[]);
}

/** "" and 0 mean "not said" in the schema; the rest of the app expects null. */
const blank = (v: unknown) => (typeof v === "string" ? (v.trim() ? v.trim() : null) : v);
export function normaliseCard(c: any): CaptureCard {
  const f: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(c?.fields ?? {})) f[k] = k === "area_m2" ? (Number(v) > 0 ? Number(v) : null) : blank(v);
  const clues = Object.fromEntries(CLUE_KEYS.map((k) => [k, (Array.isArray(c?.clues?.[k]) ? c.clues[k] : []).map((x: unknown) => String(x ?? "").trim()).filter(Boolean).slice(0, 8)])) as CaptureCard["clues"];
  const kind = (["message", "problem", "task", "variation", "leave", "enquiry", "call_log", "question"].includes(c?.kind) ? c.kind : "message") as CaptureKind;
  const urgency = (blank(c?.urgency) as CaptureCard["urgency"]) ?? (kind === "problem" ? "today" : null);
  return { kind, summary: String(c?.summary ?? ""), question: blank(c?.question) as string | null, urgency, clues, fields: f, match: null, job_id: null, no_job: null };
}

export const captureTask = (office: boolean) =>
  "Sort what the person said into ONE card and pull out the clues they actually said. Do NOT decide which job it is; another step matches jobs. " +
  "kind: message (a note or update on a job), problem (something wrong on site), task (something to do on a job), variation (extra work or a change the builder/client should pay for)" +
  (office ? ", leave (a crew member away), enquiry (a new job), call_log (a phone call), question (asking the Brain something)." : ", leave (their own time off), question (asking the Brain something).") +
  " urgency only for problems: now, today or this_week. clues: job_codes exactly as heard, including spoken forms like \"F Z ten fifty-two\"; client_names; builder_names; streets (e.g. \"Kurrajong St\"); suburbs; lot_units (e.g. \"Lot 12\", \"Unit 3\"); job_words (other words naming the job); people (crew named); dates as YYYY-MM-DD (resolve \"tomorrow\", \"Thursday\" from today); flooring words. " +
  "Use empty lists and empty strings for anything not said. Fill fields only for enquiry, call_log, leave and task_label for tasks.";

const MATCH_COLS = "id, code, name, client_name, builder_company, address, suburb, status";

async function workspaceToday(sb: any, ws: string) {
  const { data } = await sb.from("workspaces").select("timezone").eq("id", ws).maybeSingle();
  return new Intl.DateTimeFormat("en-CA", { timeZone: data?.timezone ?? "Australia/Melbourne", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}

/** Scores the caller's visible jobs (RLS: field users only see their own) and builds the card's job panel. */
async function matchForCard(sb: any, ctx: { ws: string; office: boolean; crewIds: string[] }, card: CaptureCard, pinnedJobId: string | null, recent: string[]): Promise<CaptureMatch> {
  const { decideCapture } = await import("./rules/jobMatch");
  const today = await workspaceToday(sb, ctx.ws);
  const { data: jobs } = await sb.from("jobs").select(MATCH_COLS).eq("workspace_id", ctx.ws).limit(1000);
  const list = (jobs ?? []) as { id: string; code: string; name: string; client_name: string | null; builder_company: string | null; address: string | null; suburb: string | null; status: string }[];
  const from = new Date(Date.parse(today) - 30 * 86_400_000).toISOString().slice(0, 10);
  const { data: asg } = list.length ? await sb.from("assignments").select("job_id, crew_member_id, date").eq("workspace_id", ctx.ws).gte("date", from).limit(5000) : { data: [] };
  const rows = (asg ?? []) as { job_id: string; crew_member_id: string; date: string }[];
  const byJob = new Map<string, { dates: string[]; crew: string[] }>();
  for (const r of rows) { const b = byJob.get(r.job_id) ?? { dates: [], crew: [] }; b.dates.push(r.date); b.crew.push(r.crew_member_id); byJob.set(r.job_id, b); }

  const personIds = [...ctx.crewIds];
  if (ctx.office) for (const n of card.clues.people) { const m = await crewByName(sb, ctx.ws, n); if (m.kind === "one") personIds.push(m.person.id); }

  const view = async (ids: { id: string; score: number; matchedOn: string[] }[]): Promise<Candidate[]> => {
    const out: Candidate[] = [];
    for (const s of ids) {
      const j = list.find((x) => x.id === s.id); if (!j) continue;
      const b = byJob.get(j.id);
      const next = (b?.dates ?? []).filter((d) => d >= today).sort()[0] ?? null;
      let crew: string[] = [];
      if (ctx.office) {
        const cids = [...new Set(b?.crew ?? [])];
        if (cids.length) crew = ((await sb.from("crew_members").select("name").in("id", cids)).data ?? []).map((c: { name: string }) => c.name);
      } else crew = ((await sb.rpc("crew_mates", { _job_id: j.id })).data ?? []).map((c: { name: string }) => c.name);
      out.push({ id: j.id, code: j.code, name: j.name, address: j.address, suburb: j.suburb, client_name: j.client_name, builder_company: j.builder_company, next_day: next, crew, score: s.score, matchedOn: s.matchedOn });
    }
    return out;
  };

  const todays = [...new Set(rows.filter((r) => r.date === today && ctx.crewIds.includes(r.crew_member_id)).map((r) => r.job_id))];
  const d = decideCapture(list.map((j) => ({ ...j, booked_dates: byJob.get(j.id)?.dates ?? [], crew_ids: byJob.get(j.id)?.crew ?? [] })), card.clues,
    { office: ctx.office, personCrewIds: personIds, recentJobIds: recent, pinnedJobId, todaysJobIds: todays });
  return { how: d.how, candidates: await view(d.scored.map((c) => ({ id: c.jobId, score: c.score, matchedOn: c.matchedOn }))), preselected: d.preselected, notice: d.notice };
}

export const brainCapture = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { text: string; pinnedJobId?: string | null; recent?: string[] }) => {
    const text = String(d?.text ?? "").trim();
    if (!text) throw new Error("I didn't catch that. Try again.");
    if (text.length > 4000) throw new Error("That's too long — keep it under 4,000 characters.");
    return { text, pinnedJobId: isId(d?.pinnedJobId) ? d.pinnedJobId! : null, recent: (Array.isArray(d?.recent) ? d.recent : []).filter(isId).slice(0, 20) };
  })
  .handler(async ({ data, context }) => {
    try {
      const { personContext, runBrain } = await brain();
      const ctx = await personContext(context.supabase, context.userId, "capture");
      const r = await runBrain(ctx, { fn: "capture", feature: "capture", task: captureTask(ctx.office), input: data.text, schema: CAPTURE_SCHEMA, tools: [], cluesOnly: true });
      const card = normaliseCard(r.json);
      if (!ctx.office && (card.kind === "enquiry" || card.kind === "call_log")) card.kind = "message";
      if (card.kind === "leave" && ctx.office && (card.fields["contact_name"] || card.clues.people[0])) {
        const m = await crewByName(context.supabase, ctx.ws, String(card.fields["contact_name"] ?? card.clues.people[0]));
        if (m.kind === "none") throw new Error(m.message);
        if (m.kind === "one") { card.people = [m.person]; card.person_id = m.person.id; }
        else { card.people = m.people; card.person_id = null; }
      }
      if (JOB_KINDS.includes(card.kind) || card.kind === "call_log") {
        card.match = await matchForCard(context.supabase, ctx, card, data.pinnedJobId, data.recent);
        card.job_id = card.match.preselected;
      }
      return { card, office: ctx.office };
    } catch (e) { friendly(e); }
  });

/** Problem → the office and the job's foreman are told. */
async function notifyProblem(ws: string, jobId: string, code: string, body: string, urgent: boolean, author: string) {
  const { notify, officeUserIds } = await import("./brain/notify.server");
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: asg } = await supabaseAdmin.from("assignments").select("crew_member_id").eq("job_id", jobId);
  const crew = [...new Set((asg ?? []).map((a) => a.crew_member_id))];
  const { data: fm } = crew.length ? await supabaseAdmin.from("memberships").select("user_id").eq("workspace_id", ws).eq("status", "active").eq("role", "foreman").in("crew_member_id", crew) : { data: [] };
  const ids = [...(await officeUserIds(ws)), ...((fm ?? []).map((m) => m.user_id).filter(Boolean) as string[])].filter((u) => u !== author);
  if (ids.length) await notify({ ws, userIds: ids, kind: "problem", level: "red", title: `Problem on ${code}`, body: body.slice(0, 300), jobId, urgent });
}

/** Confirming a capture card posts to the chosen job (or the no-job choice) and records what happened. */
export const confirmCapture = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { card: CaptureCard; transcript?: string }) => {
    if (!d?.card?.kind) throw new Error("Nothing to confirm");
    return { card: d.card, transcript: String(d.transcript ?? "").slice(0, 8000) };
  })
  .handler(async ({ data, context }) => {
    const sb = context.supabase;
    const { personContext } = await brain();
    const { propose } = await toolsMod();
    const ctx = await personContext(sb, context.userId, "capture");
    const c = data.card; const f = c.fields ?? {};
    const said = (data.transcript || c.summary).trim();
    let messageId: string | null = null;
    let done = ctx.office ? "Saved as a proposal in the Brain feed" : "Sent to the office to approve";

    const needsJob = JOB_KINDS.includes(c.kind);
    let job: { id: string; code: string } | null = null;
    if (c.job_id) {
      if (!isId(c.job_id)) throw new Error("Bad job");
      const { data: j } = await sb.from("jobs").select("id, code, workspace_id").eq("id", c.job_id).maybeSingle();
      if (!j || j.workspace_id !== ctx.ws) throw new Error("That job isn't available to you.");
      job = { id: j.id, code: j.code };
    }
    if (needsJob && !job && !c.no_job) throw new Error("Pick a job, or choose No job.");
    if (c.no_job === "enquiry" && !ctx.office) throw new Error("Only the office can add enquiries");

    if (needsJob && job) {
      const urg = c.kind === "problem" && c.urgency ? `Urgency: ${{ now: "now", today: "today", this_week: "this week" }[c.urgency]}\n` : "";
      const head = c.kind === "variation" ? "Variation draft\n" : c.kind === "task" ? "Task\n" : "";
      const { data: m, error } = await sb.from("messages").insert({
        job_id: job.id, workspace_id: ctx.ws, author_user_id: context.userId, kind: c.kind === "problem" ? "problem" : "message", body: `${head}${urg}${said}`.slice(0, 8000), via: "brain_bar",
      }).select("id").single();
      if (error) throw new Error(error.message);
      messageId = m.id;
      if (c.kind === "task") await propose(ctx, { kind: "add_task", job_id: job.id, title: `Task: ${f["task_label"] ?? c.summary}`.slice(0, 200), explanation: c.summary, payload: { label: String(f["task_label"] ?? c.summary).slice(0, 200) } });
      if (c.kind === "problem") await notifyProblem(ctx.ws, job.id, job.code, said, c.urgency === "now", context.userId);
      done = `Posted in ${job.code} chat`;
    } else if (needsJob && c.no_job === "enquiry" || c.kind === "enquiry") {
      if (!ctx.office) throw new Error("Only the office can add enquiries");
      await propose(ctx, { kind: "create_job", title: `New enquiry: ${f["name"] ?? f["client_name"] ?? "unnamed"}`, explanation: c.summary,
        payload: { name: f["name"] ?? (f["client_name"] ? `${f["client_name"]} ${f["flooring"] ?? ""}`.trim() : "New enquiry"), client_name: f["client_name"], client_phone: f["client_phone"], builder_company: f["builder_company"], builder_pm_name: f["builder_pm_name"], builder_pm_phone: f["builder_pm_phone"], address: f["address"], suburb: f["suburb"], flooring: f["flooring"], area_m2: f["area_m2"], sector: f["sector"] ?? "domestic", unique_notes: f["note"] ?? said } });
    } else if (needsJob && c.no_job === "unfiled") {
      const { notify, officeUserIds } = await import("./brain/notify.server");
      await notify({ ws: ctx.ws, userIds: await officeUserIds(ctx.ws), kind: "unfiled_note", level: "info", title: "Unfiled Brain bar note", body: said.slice(0, 1000) });
      done = "Saved as an unfiled note for the office";
    } else if (c.kind === "call_log") {
      if (!ctx.office) throw new Error("Only the office can log calls");
      await propose(ctx, { kind: "log_call", job_id: job?.id ?? null, title: `Call with ${f["contact_name"] ?? "someone"}`, explanation: c.summary,
        payload: { contact_name: f["contact_name"] ?? "", contact_role: f["contact_role"] ?? "other", direction: f["direction"] ?? "in", summary: c.summary, transcript: data.transcript || null } });
    } else if (c.kind === "leave") {
      let crewId = ctx.crewIds[0];
      const who = f["contact_name"] ?? c.clues?.people?.[0];
      if (ctx.office && who) {
        const m = await crewByName(sb, ctx.ws, String(who));
        if (m.kind === "none") throw new Error(m.message);
        const hits = m.kind === "one" ? [m.person] : m.people;
        const picked = c.person_id ? hits.find((p) => p.id === c.person_id) : m.kind === "one" ? m.person : undefined;
        if (!picked) throw new Error(m.kind === "many" && !c.person_id ? "Pick who this is for." : `That person isn't called ${who}.`);
        crewId = picked.id;
      }
      if (!crewId || !f["from_date"]) throw new Error("Leave needs a person and a start date");
      await propose(ctx, { kind: "leave_request", title: `Leave ${f["from_date"]}${f["to_date"] && f["to_date"] !== f["from_date"] ? ` to ${f["to_date"]}` : ""}`, explanation: c.summary,
        payload: { crew_member_id: crewId, type: f["leave_type"] ?? "unavailable", from_date: f["from_date"], to_date: f["to_date"] ?? f["from_date"], note: f["note"] } });
    } else if (c.kind === "question") return { done: "question", proposalIds: [] as string[] };

    if (needsJob || c.kind === "call_log") {
      const pre = c.match?.preselected ?? null;
      const cands = (c.match?.candidates ?? []).slice(0, 5).map((x) => ({ job_id: x.id, code: x.code, score: Number(x.score) || 0, matched_on: (x.matchedOn ?? []).slice(0, 6) }));
      const { error: fe } = await sb.from("capture_feedback").insert({
        workspace_id: ctx.ws, user_id: context.userId, input: said.slice(0, 4000), candidates: cands as never,
        preselected_job_id: pre && isId(pre) ? pre : null, chosen_job_id: job?.id ?? null, no_job: job ? null : c.no_job,
        changed: (job?.id ?? null) !== pre, message_id: messageId, proposal_ids: ctx.proposalIds,
      });
      if (fe) console.error("capture_feedback", fe.message);
    }
    return { done, proposalIds: ctx.proposalIds };
  });

/** "Move to another job" on a Brain bar post: the author or office, for 7 days. Files move with it. */
export const moveBrainPost = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { messageId: string; jobId: string }) => { if (!isId(d?.messageId) || !isId(d?.jobId)) throw new Error("Bad id"); return d; })
  .handler(async ({ data, context }) => {
    const sb = context.supabase;
    // Read as the caller (RLS): the post, its files and the target job must all be visible to them.
    const { data: m } = await sb.from("messages").select("id, job_id, workspace_id, kind, body").eq("id", data.messageId).maybeSingle();
    const { data: to } = await sb.from("jobs").select("id, workspace_id, code").eq("id", data.jobId).maybeSingle();
    if (!m) throw new Error("Post not found");
    if (!to || to.workspace_id !== m.workspace_id) throw new Error("That job isn't available to you");
    const { data: atts } = await sb.from("attachments").select("storage_path").eq("message_id", m.id);
    // Same path rule as move_brain_post: workspace/job/<rest>.
    const paths = (atts ?? []).map((a) => ({ from: a.storage_path, to: `${m.workspace_id}/${to.id}/${a.storage_path.split("/").slice(2).join("/")}` }));
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const bucket = supabaseAdmin.storage.from("job-files");
    const copied: string[] = [];
    const undoCopies = async () => { if (copied.length) await bucket.remove(copied); };
    // 1. Copy every file first; any failure changes nothing.
    for (const p of paths) {
      const { error: ce } = await bucket.copy(p.from, p.to);
      if (ce) { console.error("copy file", ce.message); await undoCopies(); throw new Error("Couldn't move the files, so the post wasn't moved."); }
      copied.push(p.to);
    }
    // 2. Only then move the post in the database (all access checks live there).
    const { data: r, error } = await sb.rpc("move_brain_post", { _message_id: data.messageId, _to_job: data.jobId });
    if (error) { await undoCopies(); throw new Error(error.message); }
    const res = r as { code: string };
    // 3. Remove the old copies.
    if (paths.length) { const { error: re } = await bucket.remove(paths.map((p) => p.from)); if (re) console.error("remove old files", re.message); }
    // A moved Problem also tells the new job's foreman (the office is told by move_brain_post).
    if (m.kind === "problem") {
      try { await notifyForemen(m.workspace_id, to.id, to.code, m.body, context.userId); } catch (e) { console.error("notify foreman", (e as Error).message); }
    }
    return { code: res.code };
  });

async function notifyForemen(ws: string, jobId: string, code: string, body: string, author: string) {
  const { notify } = await import("./brain/notify.server");
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: asg } = await supabaseAdmin.from("assignments").select("crew_member_id").eq("job_id", jobId);
  const crew = [...new Set((asg ?? []).map((a) => a.crew_member_id))];
  if (!crew.length) return;
  const { data: fm } = await supabaseAdmin.from("memberships").select("user_id").eq("workspace_id", ws).eq("status", "active").eq("role", "foreman").in("crew_member_id", crew);
  const ids = ((fm ?? []).map((x) => x.user_id).filter(Boolean) as string[]).filter((u) => u !== author);
  if (ids.length) await notify({ ws, userIds: ids, kind: "problem", level: "red", title: `Problem moved to ${code}`, body: body.slice(0, 300), jobId, urgent: false });
}

/** Dismiss and undo go straight to the database functions; these wrappers keep the client tidy. */
export const dismissProposal = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string; reason?: string | null }) => { if (!isId(d?.id)) throw new Error("Bad id"); return { id: d.id, reason: d.reason ?? null }; })
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.rpc("dismiss_proposal", { _id: data.id, _reason: data.reason as string });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
export const undoProposal = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => { if (!isId(d?.id)) throw new Error("Bad id"); return d; })
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.rpc("undo_proposal", { _id: data.id });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
