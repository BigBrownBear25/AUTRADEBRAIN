/** The one place the Claude model is named. Change here to switch model. */
export const AI_MODEL = "anthropic/claude-sonnet-5";

export const SUMMARY_KEYS = ["scope", "measurements", "subfloor", "access", "hazards", "clientRequests", "openQuestions"] as const;
export const GUIDANCE_KEYS = ["prep", "install", "siteSpecific", "qa", "handover"] as const;

export const SUMMARY_LABEL: Record<(typeof SUMMARY_KEYS)[number], string> = {
  scope: "Scope", measurements: "Measurements", subfloor: "Subfloor", access: "Access",
  hazards: "Hazards", clientRequests: "Client requests", openQuestions: "Open questions",
};
export const GUIDANCE_LABEL: Record<(typeof GUIDANCE_KEYS)[number], string> = {
  prep: "Before you start", install: "Install", siteSpecific: "This site", qa: "Quality checks", handover: "Handover",
};

export type InspectionSummary = Record<(typeof SUMMARY_KEYS)[number], string[]>;
export type InstallGuidance = Record<(typeof GUIDANCE_KEYS)[number], string[]>;
/** Saved on the job: when, from how many notes, and edited-by-hand flag. */
export type AiResult<T> = { data: T; at: string; notes: number; model: string; edited?: boolean };

/** Returns a clean copy if obj has every key as a string list, else null. */
export function checkShape(obj: unknown, keys: readonly string[]): Record<string, string[]> | null {
  if (!obj || typeof obj !== "object") return null;
  const out: Record<string, string[]> = {};
  for (const k of keys) {
    const v = (obj as Record<string, unknown>)[k];
    if (!Array.isArray(v) || !v.every((x) => typeof x === "string")) return null;
    out[k] = v.map((x) => x.trim()).filter(Boolean);
  }
  return out;
}

/** Default model per Brain function; workspaces can override these in ai_config (owner only). */
export const DEFAULT_MODELS: Record<string, { model: string; maxTokens: number; rounds: number }> = {
  capture: { model: AI_MODEL, maxTokens: 3000, rounds: 4 },
  ask: { model: AI_MODEL, maxTokens: 4000, rounds: 8 },
  brief: { model: AI_MODEL, maxTokens: 2000, rounds: 0 },
  summary: { model: AI_MODEL, maxTokens: 4000, rounds: 0 },
  guidance: { model: AI_MODEL, maxTokens: 4000, rounds: 0 },
  drafting: { model: AI_MODEL, maxTokens: 4000, rounds: 4 },
  documents: { model: AI_MODEL, maxTokens: 6000, rounds: 0 },
  lookahead: { model: AI_MODEL, maxTokens: 3000, rounds: 0 },
  watcher: { model: AI_MODEL, maxTokens: 2000, rounds: 4 },
  closeout: { model: AI_MODEL, maxTokens: 3000, rounds: 0 },
  email_sort: { model: "anthropic/claude-haiku-4-5", maxTokens: 2000, rounds: 2 },
  photo_tag: { model: "anthropic/claude-haiku-4-5", maxTokens: 1500, rounds: 0 },
};
export const BRAIN_FUNCTIONS = Object.keys(DEFAULT_MODELS);
