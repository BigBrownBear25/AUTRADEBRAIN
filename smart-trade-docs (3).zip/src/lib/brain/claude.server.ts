/** Streamed Claude Messages call with tool use, through the built-in AI service. Never retried automatically. */
const GATEWAY = "https://ai.gateway.lovable.dev/v1/messages";

export type ToolDef = { name: string; description: string; input_schema: object };
export type Block =
  | { type: "text"; text: string }
  | { type: "thinking"; thinking: string; signature?: string }
  | { type: "redacted_thinking"; data: string }
  | { type: "tool_use"; id: string; name: string; input: unknown }
  | { type: "tool_result"; tool_use_id: string; content: string; is_error?: boolean }
  | { type: "image"; source: { type: "base64"; media_type: string; data: string } }
  | { type: "document"; source: { type: "base64"; media_type: string; data: string } };
export type Msg = { role: "user" | "assistant"; content: string | Block[] };

export class BrainError extends Error {
  shape?: string;
  constructor(message: string, public status = 500) { super(message); }
}

/** Drop empty/whitespace text blocks and any message left with no content. */
export function cleanMessages(messages: Msg[]): Msg[] {
  const out: Msg[] = [];
  for (const m of messages) {
    if (typeof m.content === "string") { if (m.content.trim()) out.push(m); continue; }
    const content = (m.content ?? []).filter((b) => !(b.type === "text" && !(b.text ?? "").trim()))
      .map((b) => b.type === "tool_result" && !String(b.content ?? "").trim() ? { ...b, content: "No results." } : b);
    if (content.length) out.push({ role: m.role, content });
  }
  return out;
}

/** Block types and lengths only (never the text) for ai_runs.error. */
export function messageShape(messages: Msg[]): string {
  return messages.map((m, i) => `${i}:${m.role}[` + (typeof m.content === "string" ? `string:${m.content.length}`
    : m.content.map((b) => `${b.type}:${b.type === "text" ? b.text.length : b.type === "tool_result" ? String(b.content).length : b.type === "thinking" ? b.thinking.length : b.type === "tool_use" ? JSON.stringify(b.input ?? {}).length : 0}`).join(",")) + "]").join(" ");
}

export async function claudeTurn(o: {
  model: string; maxTokens: number; system: string; messages: Msg[]; tools?: ToolDef[] | undefined; schema?: object | undefined; onText?: ((t: string) => void) | undefined;
}): Promise<{ content: Block[]; stop: string; inTok: number; outTok: number }> {
  const key = process.env["LOVABLE_API_KEY"];
  if (!key) throw new BrainError("The AI service isn't set up", 401);
  const messages = cleanMessages(o.messages);
  const shape = messageShape(messages);
  const fail = (m: string, st?: number) => { const e = new BrainError(m, st); e.shape = shape; return e; };
  if (!messages.length) throw fail("I didn't catch that. Try again.", 400);
  const body: Record<string, unknown> = { model: o.model, max_tokens: o.maxTokens, stream: true, system: o.system, messages };
  if (o.tools?.length) body["tools"] = o.tools;
  if (o.schema) body["output_config"] = { format: { type: "json_schema", schema: o.schema } };
  try { return await send(); } catch (e) {
    if (e instanceof BrainError) { e.shape ??= shape; throw e; }
    throw fail((e as Error)?.message ?? "The Brain stopped with an error");
  }
  async function send(): Promise<{ content: Block[]; stop: string; inTok: number; outTok: number }> {
  const res = await fetch(GATEWAY, {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json", "X-Lovable-AIG-SDK": "fetch" },
    body: JSON.stringify(body),
  });
  if (!res.ok || !res.body) {
    let msg = "";
    try { const j = await res.json(); msg = j?.error?.message ?? j?.message ?? ""; } catch { /* ignore */ }
    if (res.status === 402) throw new BrainError(msg || "AI credits have run out. Top up to keep using the Brain.", 402);
    if (res.status === 429) throw new BrainError("The Brain is busy right now. Try again in a minute.", 429);
    if (res.status === 403) throw new BrainError(msg || "The AI service refused this request.", 403);
    throw new BrainError(msg || `The Brain couldn't answer (${res.status}).`, res.status);
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  const blocks: (Block & { _json?: string })[] = [];
  let buf = "", stop = "", inTok = 0, outTok = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf("\n\n")) >= 0) {
      const frame = buf.slice(0, i); buf = buf.slice(i + 2);
      const line = frame.split("\n").find((l) => l.startsWith("data:"));
      if (!line) continue;
      let ev: any;
      try { ev = JSON.parse(line.slice(5).trim()); } catch { continue; }
      if (ev.type === "message_start") inTok = ev.message?.usage?.input_tokens ?? 0;
      else if (ev.type === "content_block_start") {
        const b = ev.content_block;
        blocks[ev.index] = b.type === "tool_use" ? { type: "tool_use", id: b.id, name: b.name, input: {}, _json: "" }
          : b.type === "text" ? { type: "text", text: b.text ?? "" }
          : b.type === "thinking" ? { type: "thinking", thinking: b.thinking ?? "", signature: b.signature ?? "" }
          : { ...b };
      } else if (ev.type === "content_block_delta") {
        const b = blocks[ev.index];
        if (ev.delta?.type === "text_delta" && b?.type === "text") { b.text += ev.delta.text; o.onText?.(ev.delta.text); }
        else if (ev.delta?.type === "input_json_delta" && b?.type === "tool_use") b._json += ev.delta.partial_json ?? "";
        else if (ev.delta?.type === "thinking_delta" && b?.type === "thinking") b.thinking += ev.delta.thinking ?? "";
        else if (ev.delta?.type === "signature_delta" && b?.type === "thinking") b.signature = (b.signature ?? "") + (ev.delta.signature ?? "");
      } else if (ev.type === "content_block_stop") {
        const b = blocks[ev.index];
        if (b?.type === "tool_use") { try { b.input = b._json ? JSON.parse(b._json) : {}; } catch { b.input = {}; } delete b._json; }
      } else if (ev.type === "message_delta") { stop = ev.delta?.stop_reason ?? stop; outTok = ev.usage?.output_tokens ?? outTok; }
      else if (ev.type === "error") throw new BrainError(ev.error?.message ?? "The Brain stopped with an error");
    }
  }
  if (stop === "refusal") throw new BrainError("The Brain declined to answer this one.", 400);
  // Keep Claude's blocks as received, minus empty text blocks (which the API rejects on replay).
  const content = (blocks.filter(Boolean) as Block[]).filter((b) => !(b.type === "text" && !b.text.trim()));
  return { content, stop, inTok, outTok };
  }
}
