/**
 * The Brain's tools (spec section 8). Read tools go through ctx.sb, which is the caller's own
 * sign-in for a person's request (RLS applies) or the admin client for background work.
 * The only write tool is propose. Never add finance columns to anything returned here.
 */
import { MATERIAL_ATTENTION_COLS, flattenMaterial } from "@/lib/materials-attention";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { buildSchedulingApi, loadSchedulingRaw, type SchedulingApi } from "@/lib/scheduling-core";
import { toRuleJob } from "@/lib/scheduling-core";
import { findCrew, findSlot, fitCheck } from "@/lib/rules/fit-check";
import { suggestPlan, planCandidates } from "@/lib/rules/suggest-plan";
import { needsAttention } from "@/lib/rules/attention";
import { jobDays, workingDays } from "@/lib/rules/working-days";
import { hm } from "@/lib/assignments";
import { addDays } from "@/lib/rules/board";
import { untrusted } from "./checks";
import type { ToolDef } from "./claude.server";

export type BrainCtx = {
  sb: SupabaseClient<Database>;
  background: boolean;
  ws: string;
  userId: string | null;
  office: boolean;
  crewIds: string[];
  prefix: string;
  businessName: string;
  today: string;
  source: Database["public"]["Enums"]["proposal_source"];
  /** Everything Claude has been shown, for the answer checks. */
  seen: { codes: Set<string>; names: Set<string> };
  proposalIds: string[];
  _api?: SchedulingApi;
};

/** Non-finance job columns. Client contact details stay out except names for office callers. */
const JOB_COLS = "id, code, name, status, sector, address, suburb, flooring, area_m2, duration_value, duration_unit, crew_size, start_date, start_time, importance, urgency, due_by, due_hard, main_skill, other_skills, hazards, extra_tickets, locked, unique_notes, safety_notes, builder_company, client_name, job_type";
const PROPOSAL_KINDS = ["place", "move", "swap", "add_person", "remove_person", "create_job", "update_job", "add_task", "add_dependency", "update_dependency", "mark_delivered", "update_ticket", "leave_request", "log_call"] as const;

const obj = (properties: Record<string, object>, required: string[] = []) => ({ type: "object", properties, required, additionalProperties: false });
const str = { type: "string" };
const strs = { type: "array", items: str };

export const TOOL_DEFS: Record<string, ToolDef> = {
  search_jobs: { name: "search_jobs", description: "Find jobs by code, name, client, builder or address. Returns up to 15.", input_schema: obj({ text: str, status: str }, ["text"]) },
  get_job: { name: "get_job", description: "One job with crew, bookings, tasks, materials, dependencies and recent chat. Pass job_id or code.", input_schema: obj({ job_id: str, code: str }) },
  get_schedule: { name: "get_schedule", description: "Bookings and leave between two ISO dates, optionally for some people (crew ids).", input_schema: obj({ from: str, to: str, people: strs }, ["from", "to"]) },
  get_crew: { name: "get_crew", description: "Crew with role, skills, tickets and home suburb. Optional name filter.", input_schema: obj({ person: str }) },
  fit_check: { name: "fit_check", description: "The fit check for one person on a job from a start date.", input_schema: obj({ job_id: str, person_id: str, start: str }, ["job_id", "person_id", "start"]) },
  find_crew: { name: "find_crew", description: "Best-scoring crew for a job from a start date.", input_schema: obj({ job_id: str, start: str }, ["job_id", "start"]) },
  find_slot: { name: "find_slot", description: "Earliest workable dates and team for a job.", input_schema: obj({ job_id: str }, ["job_id"]) },
  suggest_plan: { name: "suggest_plan", description: "A draft plan for unscheduled ready jobs (or the given job ids).", input_schema: obj({ job_ids: strs }) },
  needs_attention: { name: "needs_attention", description: "Jobs needing attention between two ISO dates (defaults to the next 3 weeks).", input_schema: obj({ from: str, to: str }) },
  drive_time: { name: "drive_time", description: "Estimated drive minutes from a person's home base to a job.", input_schema: obj({ person_id: str, job_id: str }, ["person_id", "job_id"]) },
  search_memory: { name: "search_memory", description: "Plain-words search across job chat, call logs, emails and notes the caller can see.", input_schema: obj({ text: str, job_id: str }, ["text"]) },
  propose: {
    name: "propose",
    description: "Suggest one change for a person to apply. Never applies it. For place/move/swap/add_person/remove_person give payload {rows:[{crew_member_id,date,start_time,end_time,is_lead}], start_date, start_time}. For update_job give {fields:{...}}. For leave_request give {crew_member_id,type,from_date,to_date,note}. For add_task {label,due_date}. For log_call {contact_name,contact_role,direction,summary}. For create_job the job fields.",
    input_schema: obj({ kind: { type: "string", enum: [...PROPOSAL_KINDS] }, job_id: str, title: str, explanation: str, level: { type: "string", enum: ["red", "amber", "info"] }, payload: { type: "object" } }, ["kind", "title", "explanation", "payload"]),
  },
};

export const OFFICE_TOOLS = Object.keys(TOOL_DEFS);
export const FIELD_TOOLS = ["get_job", "search_memory", "propose"];

async function api(ctx: BrainCtx) {
  if (!ctx._api) ctx._api = buildSchedulingApi(await loadSchedulingRaw(ctx.sb, ctx.ws, ctx.today));
  return ctx._api;
}
const note = (ctx: BrainCtx, code?: string | null, name?: string | null) => { if (code) ctx.seen.codes.add(code); if (name) ctx.seen.names.add(name); };
const isId = (s: unknown): s is string => typeof s === "string" && /^[0-9a-f-]{36}$/i.test(s);
const isDate = (s: unknown): s is string => typeof s === "string" && /^\d{4}-\d{2}-\d{2}$/.test(s);

async function jobByRef(ctx: BrainCtx, ref: { job_id?: string; code?: string }) {
  let q = ctx.sb.from("jobs").select(JOB_COLS).eq("workspace_id", ctx.ws);
  if (isId(ref.job_id)) q = q.eq("id", ref.job_id);
  else if (ref.code) q = q.ilike("code", ref.code.replace(/\s/g, "").replace(/^([a-z]+)(\d)/i, "$1-$2"));
  else throw new Error("Give job_id or code");
  const { data } = await q.maybeSingle();
  if (!data) throw new Error("No job you can see matches that");
  note(ctx, data.code);
  return data;
}

function peopleName(a: SchedulingApi, id: string) { return a.people.find((p) => p.id === id)?.name ?? "someone"; }

export async function runTool(ctx: BrainCtx, name: string, input: any): Promise<unknown> {
  const allowed = ctx.office || ctx.background ? OFFICE_TOOLS : FIELD_TOOLS;
  if (!allowed.includes(name)) throw new Error("That tool isn't available to you");

  switch (name) {
    case "search_jobs": {
      const t = String(input.text ?? "").replace(/[%,()]/g, " ").trim().slice(0, 80);
      let q = ctx.sb.from("jobs").select("id, code, name, status, suburb, sector, start_date, due_by, builder_company, client_name").eq("workspace_id", ctx.ws).limit(15);
      if (t) q = q.or(["code", "name", "client_name", "builder_company", "address", "suburb"].map((c) => `${c}.ilike.%${t}%`).join(","));
      if (input.status) q = q.eq("status", input.status);
      const { data } = await q;
      (data ?? []).forEach((j) => note(ctx, j.code));
      return data ?? [];
    }
    case "get_job": {
      const job = await jobByRef(ctx, input);
      const [asg, tasks, mats, deps, msgs] = await Promise.all([
        ctx.sb.from("assignments").select("id, crew_member_id, date, start_time, end_time, is_lead").eq("job_id", job.id).order("date"),
        ctx.sb.from("tasks").select("id, label, done, due_date").eq("job_id", job.id).order("sort"),
        ctx.sb.from("materials").select("id, item, qty, unit, status").eq("job_id", job.id).order("sort"),
        ctx.sb.from("dependencies").select("id, kind, description, party, due_date, status, blocks_start").eq("job_id", job.id),
        ctx.sb.from("messages").select("body, kind, created_at").eq("job_id", job.id).is("deleted_at", null).order("created_at", { ascending: false }).limit(15),
      ]);
      let crew: { crew_member_id: string; name: string; role: string }[] = [];
      if (ctx.office || ctx.background) {
        const ids = [...new Set((asg.data ?? []).map((a) => a.crew_member_id))];
        if (ids.length) crew = ((await ctx.sb.from("crew_members").select("id, name, role").in("id", ids)).data ?? []).map((c) => ({ crew_member_id: c.id, name: c.name, role: c.role }));
      } else {
        crew = ((await ctx.sb.rpc("crew_mates", { _job_id: job.id })).data ?? []).map((c) => ({ crew_member_id: c.crew_member_id, name: c.name, role: c.role }));
      }
      crew.forEach((c) => note(ctx, null, c.name));
      const out = { ...job } as Record<string, unknown>;
      if (!ctx.office && !ctx.background) delete out["client_name"];
      return {
        job: out, crew, bookings: asg.data ?? [], tasks: tasks.data ?? [], materials: mats.data ?? [], dependencies: deps.data ?? [],
        recent_chat: untrusted("job chat", (msgs.data ?? []).reverse().map((m) => `[${m.created_at.slice(0, 16)} ${m.kind}] ${m.body}`).join("\n")),
      };
    }
    case "get_schedule": {
      if (!isDate(input.from) || !isDate(input.to)) throw new Error("Dates must be YYYY-MM-DD");
      const a = await api(ctx);
      const people = Array.isArray(input.people) ? new Set(input.people as string[]) : null;
      const book = a.bookingsRaw.filter((b) => b.date >= input.from && b.date <= input.to && (!people || people.has(b.crew_member_id)))
        .map((b) => { const j = a.jobMap.get(b.job_id); note(ctx, j?.code); return { person: peopleName(a, b.crew_member_id), crew_member_id: b.crew_member_id, job: j?.code, date: b.date, start: hm(b.start_time), end: hm(b.end_time) }; });
      const leave = a.leave.filter((l) => l.status !== "declined" && l.to_date >= input.from && l.from_date <= input.to && (!people || people.has(l.crew_member_id)))
        .map((l) => ({ person: peopleName(a, l.crew_member_id), crew_member_id: l.crew_member_id, from: l.from_date, to: l.to_date, status: l.status, ...(ctx.office || ctx.background ? { type: l.type } : {}) }));
      a.people.forEach((p) => note(ctx, null, p.name));
      return { bookings: book.slice(0, 300), leave, working_days: workingDays(input.from, input.to, a.week) };
    }
    case "get_crew": {
      const a = await api(ctx);
      const f = String(input.person ?? "").toLowerCase();
      const list = a.people.filter((p) => !f || p.name.toLowerCase().includes(f)).map((p) => ({ id: p.id, name: p.name, role: p.role, skills: p.skills ?? [], tickets: p.crew_tickets, base: p.base_suburb }));
      list.forEach((p) => note(ctx, null, p.name));
      return list;
    }
    case "fit_check": {
      const a = await api(ctx);
      const j = a.jobMap.get(input.job_id); const p = a.people.find((x) => x.id === input.person_id);
      if (!j || !p || !isDate(input.start)) throw new Error("Unknown job, person or date");
      const rj = toRuleJob(j);
      return fitCheck(rj, { id: p.id, name: p.name, role: p.role, skills: p.skills ?? [], tickets: p.crew_tickets }, input.start, a.ctxFor(rj));
    }
    case "find_crew": {
      const a = await api(ctx);
      const j = a.jobMap.get(input.job_id); if (!j || !isDate(input.start)) throw new Error("Unknown job or date");
      const rj = toRuleJob(j);
      return findCrew(rj, input.start, a.ctxFor(rj)).map((r: any) => { note(ctx, null, r.person?.name); return r; });
    }
    case "find_slot": {
      const a = await api(ctx);
      const j = a.jobMap.get(input.job_id); if (!j) throw new Error("Unknown job");
      const rj = toRuleJob(j);
      const r = findSlot(rj, a.ctxFor(rj));
      return { ...r, options: r.options.slice(0, 3).map((o) => ({ ...o, team: o.team.map((id) => ({ id, name: peopleName(a, id) })) })) };
    }
    case "suggest_plan": {
      const a = await api(ctx);
      const ids = Array.isArray(input.job_ids) && input.job_ids.length ? new Set(input.job_ids as string[]) : null;
      const jobs = planCandidates(a.jobs.filter((j) => !ids || ids.has(j.id)).map(toRuleJob));
      const plan = suggestPlan(jobs, (job, extra) => a.ctxFor(job, extra), a.today);
      return plan.slice(0, 15).map((p) => { const j = a.jobMap.get(p.jobId); note(ctx, j?.code); return { job_id: p.jobId, code: j?.code, start: p.option?.start, days: p.option?.days, team: p.option?.team.map((id) => ({ id, name: peopleName(a, id) })), warnings: p.option?.warnings, reason: p.reason }; });
    }
    case "needs_attention": {
      const a = await api(ctx);
      const from = isDate(input.from) ? input.from : a.today; const to = isDate(input.to) ? input.to : addDays(a.today, 21);
      const ids = a.jobs.filter((j) => !["complete", "closed"].includes(j.status)).map((j) => j.id);
      const [mats, tasks] = await Promise.all([
        ctx.sb.from("materials").select(MATERIAL_ATTENTION_COLS).in("job_id", ids.length ? ids : ["00000000-0000-0000-0000-000000000000"]),
        ctx.sb.from("tasks").select("job_id, label, due_date, done").in("job_id", ids.length ? ids : ["00000000-0000-0000-0000-000000000000"]),
      ]);
      const out = [];
      for (const j of a.jobs) {
        if (!ids.includes(j.id)) continue;
        const rj = toRuleJob(j);
        if (j.start_date) { const d = jobDays(j.start_date, { value: rj.duration_value, unit: rj.duration_unit }, a.week); if (d[d.length - 1]! < from || d[0]! > to) continue; }
        const c = a.ctxFor(rj);
        const flags = needsAttention({ job: { ...rj, start_date: j.start_date, status: j.status }, ctx: c, crew: c.jobCrew,
          materials: (mats.data ?? []).filter((m) => m.job_id === j.id).map(flattenMaterial), tasks: (tasks.data ?? []).filter((t) => t.job_id === j.id) });
        if (flags.length) { note(ctx, j.code); out.push({ job_id: j.id, code: j.code, name: j.name, start_date: j.start_date, flags }); }
      }
      return out.slice(0, 40);
    }
    case "drive_time": {
      const a = await api(ctx);
      const j = a.jobMap.get(input.job_id); if (!j) throw new Error("Unknown job");
      const m = a.ctxFor(toRuleJob(j)).driveFromBase(input.person_id);
      return { minutes: m, note: m == null ? "No home base or site location on file" : "Estimate from home base" };
    }
    case "search_memory": {
      const t = String(input.text ?? "").replace(/[%,()]/g, " ").trim().slice(0, 80);
      if (!t) return [];
      const words = t.split(/\s+/).filter((w) => w.length > 2).slice(0, 4);
      const like = (col: string) => words.map((w) => `${col}.ilike.%${w}%`).join(",");
      let m = ctx.sb.from("messages").select("job_id, body, created_at").eq("workspace_id", ctx.ws).is("deleted_at", null).or(like("body")).limit(10);
      if (isId(input.job_id)) m = m.eq("job_id", input.job_id);
      const res: { source: string; job_id: string | null; at: string; text: string }[] = ((await m).data ?? []).map((x) => ({ source: "chat", job_id: x.job_id, at: x.created_at, text: x.body }));
      if (ctx.office || ctx.background) {
        const c = await ctx.sb.from("call_logs").select("job_id, summary, at").eq("workspace_id", ctx.ws).or(like("summary")).limit(8);
        res.push(...(c.data ?? []).map((x) => ({ source: "call", job_id: x.job_id, at: x.at, text: x.summary })));
        const e = await ctx.sb.from("inbound_emails").select("job_id, subject, body_text, received_at").eq("workspace_id", ctx.ws).or(`${like("subject")},${like("body_text")}`).limit(8);
        res.push(...(e.data ?? []).map((x) => ({ source: "email", job_id: x.job_id, at: x.received_at, text: `${x.subject}\n${(x.body_text ?? "").slice(0, 1500)}` })));
      }
      try {
        const mem = await ctx.sb.rpc("search_memory" as never, { _ws: ctx.ws, _query: t, _job_id: isId(input.job_id) ? input.job_id : null } as never);
        for (const x of ((mem as { data: { source_table: string; job_id: string | null; created_at: string; text: string }[] | null }).data ?? [])) res.push({ source: x.source_table, job_id: x.job_id, at: x.created_at, text: x.text });
      } catch { /* memory search arrives with B12 */ }
      return res.slice(0, 20).map((r) => ({ ...r, text: untrusted(r.source, r.text.slice(0, 1500)) }));
    }
    case "propose": return propose(ctx, input);
  }
  throw new Error("Unknown tool");
}

/** Creates one open proposal. Person requests insert as the caller, so RLS decides what they may suggest. */
export async function propose(ctx: BrainCtx, input: any) {
  const kind = String(input.kind);
  if (!(PROPOSAL_KINDS as readonly string[]).includes(kind)) throw new Error("That kind of change can't be proposed here");
  const payload = (input.payload && typeof input.payload === "object") ? input.payload : {};
  let jobId: string | null = isId(input.job_id) ? input.job_id : null;
  // Claude often gives the job code (FZ-1001) instead of the id; resolve either.
  const ref = [input.job_id, input.job_code, payload.code, payload.job_code, payload.job_id].find((v) => typeof v === "string" && v.trim());
  if (!jobId && ref) jobId = isId(ref) ? ref : (await jobByRef(ctx, { code: String(ref).trim() })).id;
  if (!jobId && kind !== "create_job" && kind !== "leave_request" && kind !== "update_ticket") throw new Error("Which job is this for? Give the job_id from get_job.");
  let fit: unknown = null, level = ["red", "amber", "info"].includes(input.level) ? input.level : "info";
  if (jobId && ["place", "move", "swap", "add_person"].includes(kind) && Array.isArray(payload.rows) && (ctx.office || ctx.background)) {
    const a = await api(ctx);
    const j = a.jobMap.get(jobId);
    if (j?.locked) throw new Error("That job is locked; mention it instead of proposing a change");
    if (j && payload.start_date) {
      const rj = toRuleJob(j);
      const ids = [...new Set((payload.rows as { crew_member_id: string }[]).map((r) => r.crew_member_id))];
      const others = a.ctxFor(rj).bookings.filter((b) => b.job_id !== jobId);
      const c = { ...a.ctxFor(rj), bookings: others };
      fit = ids.map((id) => { const p = a.people.find((x) => x.id === id); return p ? { person: p.name, ...fitCheck(rj, { id: p.id, name: p.name, role: p.role, skills: p.skills ?? [], tickets: p.crew_tickets }, payload.start_date, c) } : { person: id, level: "clash", reasons: [{ level: "clash", check: "Person", text: "Not found" }] }; });
    }
  }
  if (kind === "leave_request" && !ctx.office && !ctx.background) payload.crew_member_id = ctx.crewIds[0];
  const row = {
    workspace_id: ctx.ws, job_id: jobId, source: ctx.source, kind: kind as never, payload, fit: fit as never, level,
    title: String(input.title ?? "").slice(0, 160), explanation: String(input.explanation ?? "").slice(0, 1200),
    created_by: ctx.userId, created_by_brain: true, expires_at: payload.start_date ? `${payload.start_date}T00:00:00+10:00` : null,
  };
  const { data, error } = await ctx.sb.from("proposals").insert(row).select("id").single();
  if (error) throw new Error(error.message.includes("row-level security") ? "You can't suggest that change" : error.message);
  ctx.proposalIds.push(data.id);
  return { proposal_id: data.id, status: "open", note: "Saved for a person to apply." };
}
