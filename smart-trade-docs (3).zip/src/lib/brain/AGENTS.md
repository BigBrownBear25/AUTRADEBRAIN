# Brain rules

- All Claude tool-using calls go through runBrain() in src/lib/brain/runner.server.ts — so budget, rate limit, 60-second cap, tool limits and ai_runs logging apply everywhere.
- Background Brain work (watcher, overnight draft, look-ahead) lives in src/lib/brain/watch.server.ts behind token-checked /api/public/brain-* routes; the watcher's minute schedule is created by a brain_events trigger and removed when events drain — so the database isn't polled when nothing changed.
- Brain bar posts carry messages.via='brain_bar' and change job only through moveBrainPost (files copied first, then move_brain_post: author/office, 7 days, reason "moved: wrong job", then old files removed); every confirm writes capture_feedback — so wrong-job rates stay measurable.
- The morning brief is built server-side by getMorningBrief (src/lib/brief.functions.ts) with the caller's own client, reusing flagsFor/fixFor from watch.server for items and fixes; Claude (fn "brief") writes only the summary and falls back to briefTemplate() — so brief, watcher and overnight agree on what's wrong.

- Ask streams from the authenticated server route /api/brain-ask (bearer-verified) because server functions can't stream NDJSON; everything else in the Brain uses createServerFn.
- Photo reading: vision-tag lives in src/lib/vision.server.ts (fn photo_tag via runBrain); only tagPhoto (uploader, once per photo) and the AI test page call it; rules/photos.ts decides docket matches and moisture limits; changes are proposals, only an over-limit moisture reading posts a problem directly.
