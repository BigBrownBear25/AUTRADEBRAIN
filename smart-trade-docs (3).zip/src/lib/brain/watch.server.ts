/** Background Brain: the watcher (every minute) and the overnight draft + Monday look-ahead. Server-only, admin client, one workspace at a time. */
import { MATERIAL_ATTENTION_COLS, flattenMaterial } from "@/lib/materials-attention";
import { buildSchedulingApi, loadSchedulingRaw, toRuleJob, type SchedulingApi } from "@/lib/scheduling-core";
import { needsAttention, type Flag } from "@/lib/rules/attention";
import { findCrew, findSlot, jobBlock } from "@/lib/rules/fit-check";
import { priorityOf } from "@/lib/rules/priority";
import { planCandidates, suggestPlan } from "@/lib/rules/suggest-plan";
import { forwardAvailability } from "@/lib/rules/availability";
import { addDays } from "@/lib/rules/board";
import { hm } from "@/lib/assignments";
import { addPersonRows, bookedByWeek, localDate, localHm, localWeekday, newOrWorse, settledJobs, slotRows, urgentDespiteQuiet, weekPressure, type BookingRow } from "@/lib/rules/brain-rules";
import { notify, officeUserIds } from "./notify.server";
import { brainOn } from "@/lib/platform/flags.server";

const admin = async () => (await import("@/integrations/supabase/client.server")).supabaseAdmin;
type Sb = Awaited<ReturnType<typeof admin>>;
const daysBetween = (a: string, b: string) => Math.round((Date.parse(b) - Date.parse(a)) / 86_400_000);

async function settingsFor(sb: Sb, ws: string) {
  const { data } = await sb.from("brain_settings").select("*").eq("workspace_id", ws).maybeSingle();
  const f = (data?.features ?? {}) as Record<string, boolean>;
  return { tz: data?.timezone ?? "Australia/Melbourne", features: f, row: data };
}

export async function flagsFor(sb: Sb, a: SchedulingApi, jobIds: string[]) {
  const ids = jobIds.length ? jobIds : ["00000000-0000-0000-0000-000000000000"];
  const [mats, tasks] = await Promise.all([
    sb.from("materials").select(MATERIAL_ATTENTION_COLS).in("job_id", ids),
    sb.from("tasks").select("job_id, label, due_date, done").in("job_id", ids),
  ]);
  const out = new Map<string, Flag[]>();
  for (const id of jobIds) {
    const j = a.jobMap.get(id); if (!j) continue;
    const rj = toRuleJob(j); const c = a.ctxFor(rj);
    out.set(id, needsAttention({ job: { ...rj, start_date: j.start_date, status: j.status }, ctx: c, crew: c.jobCrew,
      materials: (mats.data ?? []).filter((m) => m.job_id === id).map(flattenMaterial), tasks: (tasks.data ?? []).filter((t) => t.job_id === id) }));
  }
  return out;
}

/** Works out a fix for one flag, as in the morning brief table, and saves it as a proposal. */
export async function fixFor(sb: Sb, a: SchedulingApi, ws: string, jobId: string, flag: Flag, source: "watcher" | "overnight" | "brief", group?: { id: string; label: string } | null, createdBy: string | null = null): Promise<string | null> {
  const j = a.jobMap.get(jobId); if (!j || j.locked) return null;
  const rj = toRuleJob(j); const c = a.ctxFor(rj);
  const rows: BookingRow[] = a.bookingsRaw.filter((b) => b.job_id === jobId).map((b) => ({ crew_member_id: b.crew_member_id, date: b.date, start_time: hm(b.start_time), end_time: hm(b.end_time), is_lead: false }));
  let kind: "add_person" | "place", payload: Record<string, unknown>, title: string, explanation: string;
  if (flag.text.startsWith("Crew short") && j.start_date && rows.length) {
    const pick = findCrew(rj, j.start_date, c, 10).find((x) => !x.busy);
    if (!pick) return null;
    const name = a.people.find((p) => p.id === pick.personId)?.name ?? "Someone";
    kind = "add_person"; payload = { rows: addPersonRows(rows, pick.personId), start_date: j.start_date, start_time: j.start_time };
    title = `Add ${name} to ${j.code}`; explanation = `${flag.text}. ${name} is free on those days (${pick.reasons.slice(0, 2).join(", ")}).`;
  } else if (flag.text.startsWith("No dates")) {
    const opt = findSlot(rj, c).options[0]; if (!opt) return null;
    const b = jobBlock(rj, c);
    kind = "place"; payload = { rows: slotRows(opt.team, opt.days, b.start, b.end), start_date: opt.start, start_time: b.start };
    title = `Book ${j.code} from ${opt.start}`; explanation = `${flag.text}. First slot that fits: ${opt.team.map((id) => a.people.find((p) => p.id === id)?.name ?? "?").join(", ")}.`;
  } else return null;
  const { data, error } = await sb.from("proposals").insert({
    workspace_id: ws, job_id: jobId, source, kind, level: flag.level, title, explanation, payload: payload as never,
    created_by: createdBy, created_by_brain: true, dedupe_key: `${source}:${jobId}:${flag.text.replace(/\d+/g, "#")}`,
    expires_at: payload["start_date"] ? `${payload["start_date"]}T00:00:00+10:00` : null,
    group_id: group?.id ?? null, group_label: group?.label ?? null,
  }).select("id").single();
  if (error) {
    if (error.code !== "23505") { console.error("proposal", error.message); return null; }
    const { data: same } = await sb.from("proposals").select("id").eq("workspace_id", ws).eq("dedupe_key", `${source}:${jobId}:${flag.text.replace(/\d+/g, "#")}`).eq("status", "open").limit(1).maybeSingle();
    return same?.id ?? null;
  }
  return data.id;
}

/** brain-watch: processes settled brain_events into flags, proposals and notifications. */
export async function runWatcher() {
  const sb = await admin();
  const { data: pending } = await sb.from("brain_events").select("id, workspace_id, kind, table_name, job_id, crew_member_id, at").is("processed_at", null).order("at").limit(1000);
  const byWs = new Map<string, NonNullable<typeof pending>>();
  for (const e of pending ?? []) byWs.set(e.workspace_id, [...(byWs.get(e.workspace_id) ?? []), e]);
  const summary: Record<string, number> = {};
  for (const [ws, evs] of byWs) {
    const st = await settingsFor(sb, ws);
    const now = Date.now();
    const settled = new Set(settledJobs(evs.map((e) => ({ job_id: e.job_id, at: e.at })), now));
    const done = evs.filter((e) => !e.job_id || settled.has(e.job_id));
    if (!done.length) continue;
    if (st.features["watcher"] === false || !(await brainOn(ws, "watcher"))) { await markDone(sb, done.map((e) => e.id)); continue; }
    const today = localDate(new Date(), st.tz);
    const a = buildSchedulingApi(await loadSchedulingRaw(sb as never, ws, today));
    const office = await officeUserIds(ws);
    const jobIds = [...settled].filter((id) => a.jobMap.has(id));
    const after = await flagsFor(sb, a, jobIds);
    const { data: prevRows } = await sb.from("brain_job_flags").select("job_id, flags").in("job_id", jobIds.length ? jobIds : ["00000000-0000-0000-0000-000000000000"]);
    const before = new Map((prevRows ?? []).map((r) => [r.job_id, r.flags as Flag[]]));
    for (const id of jobIds) {
      const j = a.jobMap.get(id)!; const flags = after.get(id) ?? [];
      const fresh = before.has(id) ? newOrWorse(before.get(id)!, flags) : flags.filter((f) => f.level === "red");
      await sb.from("brain_job_flags").upsert({ job_id: id, workspace_id: ws, flags: flags as never, updated_at: new Date().toISOString() });
      for (const f of fresh) {
        const pid = await fixFor(sb, a, ws, id, f, "watcher");
        const startsIn = j.start_date ? daysBetween(today, j.start_date) * 24 : null;
        await notify({ ws, userIds: office, kind: "watcher", level: f.level, title: `${j.code}: ${f.text}`, body: pid ? "A fix is waiting in the Brain feed." : j.name ?? "",
          jobId: id, proposalId: pid, urgent: urgentDespiteQuiet(f.level, priorityOf(toRuleJob(j), today), startsIn) });
      }
    }
    // Field users hear about their own booking changes, never why anyone else moved.
    const touched = new Map<string, Set<string>>();
    for (const e of done) if (e.table_name === "assignments" && e.crew_member_id && e.job_id) touched.set(e.crew_member_id, new Set([...(touched.get(e.crew_member_id) ?? []), e.job_id]));
    if (touched.size) {
      const { data: mem } = await sb.from("memberships").select("crew_member_id, user_id").eq("workspace_id", ws).eq("status", "active").in("crew_member_id", [...touched.keys()]);
      for (const m of mem ?? []) {
        const cm = { id: m.crew_member_id!, user_id: m.user_id };
        if (!cm.user_id || office.includes(cm.user_id)) continue;
        for (const jid of touched.get(cm.id) ?? []) {
          const j = a.jobMap.get(jid); if (!j) continue;
          const mine = a.bookingsRaw.filter((b) => b.job_id === jid && b.crew_member_id === cm.id && b.date >= today).sort((x, y) => x.date.localeCompare(y.date));
          const first = mine[0];
          const title = first ? `You're now on ${j.code} ${new Date(first.date + "T00:00:00").toLocaleDateString("en-AU", { weekday: "long", day: "numeric", month: "short" })}, ${hm(first.start_time)} start` : `You're no longer booked on ${j.code}`;
          await notify({ ws, userIds: [cm.user_id], kind: "booking", level: "info", title, jobId: first ? jid : null, push: true });
        }
      }
    }
    await markDone(sb, done.map((e) => e.id));
    summary[ws] = done.length;
  }
  return summary;
}
async function markDone(sb: Sb, ids: number[]) {
  for (let i = 0; i < ids.length; i += 200) await sb.from("brain_events").update({ processed_at: new Date().toISOString() }).in("id", ids.slice(i, i + 200));
}

/** brain-overnight: called every 15 minutes; each workspace runs once a day at 03:30 local, look-ahead Mondays from 03:45. */
export async function runOvernight(force?: { ws: string; what: "draft" | "lookahead" }) {
  const sb = await admin();
  const { data: all } = await sb.from("brain_settings").select("workspace_id, timezone, features, last_overnight_on, last_lookahead_on");
  const out: Record<string, string[]> = {};
  for (const s of all ?? []) {
    if (force && force.ws !== s.workspace_id) continue;
    const now = new Date(); const tz = s.timezone ?? "Australia/Melbourne";
    const t = localHm(now, tz); const today = localDate(now, tz);
    const f = (s.features ?? {}) as Record<string, boolean>;
    const did: string[] = [];
    if (force?.what === "draft" || (!force && t >= "03:30" && t < "05:00" && s.last_overnight_on !== today && f["overnight"] !== false && await brainOn(s.workspace_id, "overnight"))) {
      await sb.from("brain_settings").update({ last_overnight_on: today }).eq("workspace_id", s.workspace_id);
      did.push(`draft:${await overnightDraft(sb, s.workspace_id, today)}`);
    }
    if (force?.what === "lookahead" || (!force && localWeekday(now, tz) === 1 && t >= "03:45" && t < "05:00" && s.last_lookahead_on !== today && f["lookahead"] !== false && await brainOn(s.workspace_id, "lookahead"))) {
      await sb.from("brain_settings").update({ last_lookahead_on: today }).eq("workspace_id", s.workspace_id);
      did.push(`lookahead:${await lookAhead(sb, s.workspace_id, today)}`);
    }
    if (did.length) out[s.workspace_id] = did;
  }
  return out;
}

async function overnightDraft(sb: Sb, ws: string, today: string) {
  const a = buildSchedulingApi(await loadSchedulingRaw(sb as never, ws, today));
  // A new draft replaces any draft still open.
  await sb.from("proposals").update({ status: "superseded" }).eq("workspace_id", ws).eq("source", "overnight").eq("status", "open");
  const group = { id: crypto.randomUUID(), label: `Draft plan for ${new Date(today + "T00:00:00").toLocaleDateString("en-AU", { weekday: "long", day: "numeric", month: "long" })}` };
  const horizon = addDays(today, 42);
  const jobs = planCandidates(a.jobs.filter((j) => j.status === "ready" && !j.start_date && (!j.due_by || j.due_by <= horizon)).map(toRuleJob));
  let n = 0;
  for (const p of suggestPlan(jobs, (job, extra) => a.ctxFor(job, extra), today)) {
    if (!p.option) continue;
    const j = a.jobMap.get(p.jobId)!; const rj = toRuleJob(j); const b = jobBlock(rj, a.ctxFor(rj));
    const { error } = await sb.from("proposals").insert({
      workspace_id: ws, job_id: p.jobId, source: "overnight", kind: "place", level: "info", group_id: group.id, group_label: group.label,
      title: `Book ${j.code} from ${p.option.start}`, explanation: `${p.option.team.map((id) => a.people.find((x) => x.id === id)?.name ?? "?").join(", ")}${p.option.warnings.length ? ` · ${p.option.warnings.join("; ")}` : ""}`,
      payload: { rows: slotRows(p.option.team, p.option.days, b.start, b.end), start_date: p.option.start, start_time: b.start } as never,
      created_by_brain: true, expires_at: `${p.option.start}T00:00:00+10:00`,
    });
    if (!error) n++;
  }
  // Morning brief fixes for the next 10 working days.
  const soon = a.jobs.filter((j) => j.start_date && j.start_date >= today && j.start_date <= addDays(today, 14)).map((j) => j.id);
  const flags = await flagsFor(sb, a, soon);
  for (const [id, fl] of flags) for (const f of fl) if (await fixFor(sb, a, ws, id, f, "overnight", group)) n++;
  if (n) await notify({ ws, userIds: await officeUserIds(ws), kind: "overnight", level: "info", title: group.label, body: `${n} suggested change${n === 1 ? "" : "s"}, ticked and ready in the morning brief.`, push: false });
  return n;
}

async function lookAhead(sb: Sb, ws: string, today: string) {
  const a = buildSchedulingApi(await loadSchedulingRaw(sb as never, ws, today));
  const people = a.people.map((p) => p.id);
  const hours = { dayStart: hm(a.settings.day_start), dayEnd: hm(a.settings.day_end) };
  const leaveCap = a.leave.filter((l) => l.status === "approved" || l.status === "requested").map((l) => ({ crew_member_id: l.crew_member_id, from: l.from_date, to: l.to_date, status: l.status as "approved" | "requested" }));
  const approvedOnly = leaveCap.filter((l) => l.status === "approved");
  const caps = forwardAvailability(people, today, 6, a.week, hours, approvedOnly, []);
  const weekStarts = caps.map((c) => c.weekStart);
  const booked = bookedByWeek(a.bookingsRaw.filter((b) => b.date >= today).map((b) => b.date), weekStarts);
  const backlog = weekStarts.map(() => 0);
  for (const j of a.jobs) {
    if (j.start_date || ["complete", "closed"].includes(j.status)) continue;
    const days = (j.duration_unit === "hours" ? Math.max(1, Math.ceil(Number(j.duration_value) / 8)) : Number(j.duration_value)) * j.crew_size;
    const wi = j.due_by ? Math.max(0, weekStarts.reduce((k, w, i) => (w <= j.due_by! ? i : k), -1)) : weekStarts.length - 1;
    backlog[wi] = (backlog[wi] ?? 0) + days;
  }
  const weeks = caps.map((c, i) => {
    const available = c.freeCrewDays + (booked[i] ?? 0);
    const wp = weekPressure({ available, booked: booked[i] ?? 0, backlog: backlog[i] ?? 0 });
    const end = addDays(c.weekStart, 7);
    const req = leaveCap.filter((l) => l.status === "requested" && l.from < end && l.to >= c.weekStart).map((l) => a.people.find((p) => p.id === l.crew_member_id)?.name ?? "?");
    return { week: c.weekStart, available, booked: booked[i] ?? 0, backlog: backlog[i] ?? 0, loadPct: Number.isFinite(wp.load) ? Math.round(wp.load * 100) : 999, over: wp.over, leaveRequested: req };
  });
  const tickets: string[] = [];
  for (const p of a.people) for (const t of p.crew_tickets) {
    if (!t.expires_on) continue;
    const later = a.bookingsRaw.find((b) => b.crew_member_id === p.id && b.date > t.expires_on! && b.date >= today);
    if (later) tickets.push(`${p.name}: ${t.ticket_type} expires ${t.expires_on}, booked ${a.jobMap.get(later.job_id)?.code ?? ""} ${later.date}`);
  }
  const data = { weeks, tickets };
  let summary = weeks.map((w) => `Week of ${w.week}: ${w.loadPct}% (${w.booked} booked + ${w.backlog} backlog of ${w.available} crew-days)${w.over ? " — over 90%" : ""}${w.leaveRequested.length ? `; leave requested: ${w.leaveRequested.join(", ")}` : ""}`).join("\n") + (tickets.length ? `\nTickets: ${tickets.join("; ")}` : "");
  try {
    const { backgroundContext, runBrain } = await import("./runner.server");
    const { untrusted } = await import("./checks");
    const ctx = await backgroundContext(ws, "overnight");
    const r = await runBrain(ctx, { fn: "lookahead", feature: "lookahead", tools: [],
      task: "Write a one-page six-week look-ahead for the scheduler from these figures: short headline, then each pressured week with a suggested action (approve or decline leave, bring in a subcontractor, move a flexible job). Use only the figures given. No money.",
      input: untrusted("look-ahead figures", JSON.stringify(data)) });
    if (r.text.trim()) summary = r.text.trim();
  } catch (e) { console.error("lookahead summary", (e as Error).message); }
  await sb.from("brain_reports").upsert({ workspace_id: ws, kind: "lookahead", for_date: today, summary, data: data as never }, { onConflict: "workspace_id,kind,for_date" });
  const pressured = weeks.filter((w) => w.over).length;
  await notify({ ws, userIds: await officeUserIds(ws), kind: "lookahead", level: pressured ? "amber" : "info", title: "Six-week look-ahead is ready", body: pressured ? `${pressured} week${pressured === 1 ? "" : "s"} over 90%.` : "No week over 90%.", push: false });
  return pressured;
}
