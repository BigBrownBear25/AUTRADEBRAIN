/** Background health (spec section 12): each scheduled job records its last success or error. Server-only. */
export type JobName = "watcher" | "overnight" | "email_intake";

export async function recordJobRun(job: JobName, error?: unknown) {
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const now = new Date().toISOString();
    const row: { job: string; last_ok_at?: string; last_error_at?: string; last_error?: string } = error
      ? { job, last_error_at: now, last_error: (error instanceof Error ? error.message : String(error)).slice(0, 500) }
      : { job, last_ok_at: now };
    await supabaseAdmin.from("job_runs").upsert(row, { onConflict: "job" });
    if (error) await (await import("@/lib/platform/errors.server")).recordError(`job:${job}`, error);
  } catch (e) { console.error("job_runs", (e as Error).message); }
}
