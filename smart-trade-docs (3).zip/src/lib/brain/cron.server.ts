/** Scheduled calls carry x-cron-token: either the CRON_SECRET or the token the database scheduler holds. */
export async function cronAllowed(request: Request) {
  const t = request.headers.get("x-cron-token") ?? "";
  if (t.length < 32) return false;
  const env = process.env["CRON_SECRET"];
  if (env && env.length === t.length) {
    let d = 0; for (let i = 0; i < t.length; i++) d |= t.charCodeAt(i) ^ env.charCodeAt(i);
    if (d === 0) return true;
  }
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin.rpc("check_cron_token", { _t: t });
  return data === true;
}
