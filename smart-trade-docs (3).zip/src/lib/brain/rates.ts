/**
 * The only place AI cost rates live. Every cost_aud figure (runBrain, callClaude, Settings) uses runCostAud().
 *
 * NOTE: these are ESTIMATES in AUD per token for Claude through the Lovable AI gateway, used for the
 * owner's monthly budget tracking. They are not the gateway's billed amount; check real usage in
 * the workspace's credit usage and adjust these if they drift.
 */
export const RATES_AUD_PER_TOKEN: Record<"haiku" | "sonnet" | "opus", { in: number; out: number }> = {
  haiku: { in: 1.5e-6, out: 7.5e-6 },
  sonnet: { in: 4.5e-6, out: 22.5e-6 },
  opus: { in: 22.5e-6, out: 112.5e-6 },
};

export function rateFor(model: string) {
  if (/haiku/i.test(model)) return RATES_AUD_PER_TOKEN.haiku;
  if (/opus/i.test(model)) return RATES_AUD_PER_TOKEN.opus;
  return RATES_AUD_PER_TOKEN.sonnet;
}

/** Estimated AUD cost of one run from its token counts, rounded to 0.0001. */
export function runCostAud(model: string, inTok: number, outTok: number): number {
  const r = rateFor(model);
  return Math.round((inTok * r.in + outTok * r.out) * 10000) / 10000;
}
