/** Brain feed notifications plus web push, honouring quiet hours. Server-only, admin client. */
import { inQuietHours } from "@/lib/rules/brain-rules";

type Level = "red" | "amber" | "info";
const admin = async () => (await import("@/integrations/supabase/client.server")).supabaseAdmin;

/** Office opens jobs on /jobs, field on /my-jobs; with no job, their home page. */
export const jobLink = (office: boolean, jobId?: string | null) => jobId ? `${office ? "/jobs" : "/my-jobs"}?job=${jobId}` : "/";

export async function pushTo(userId: string, msg: { title: string; body: string; url?: string }) {
  const pub = process.env["VAPID_PUBLIC_KEY"]; const priv = process.env["VAPID_PRIVATE_KEY"];
  if (!pub || !priv) return 0;
  const { buildPushPayload } = await import("@block65/webcrypto-web-push");
  const sb = await admin();
  const { data: subs } = await sb.from("push_subscriptions").select("id, endpoint, p256dh, auth").eq("user_id", userId);
  let sent = 0;
  for (const s of subs ?? []) {
    try {
      const payload = await buildPushPayload({ data: JSON.stringify(msg), options: { ttl: 3600, urgency: "high" } } as never,
        { endpoint: s.endpoint, expirationTime: null, keys: { p256dh: s.p256dh, auth: s.auth } }, { subject: "mailto:brain@tradebrain.app", publicKey: pub, privateKey: priv });
      const res = await fetch(s.endpoint, payload as RequestInit);
      if (res.status === 404 || res.status === 410) await sb.from("push_subscriptions").delete().eq("id", s.id);
      else if (res.ok) sent++;
    } catch (e) { console.error("push failed", (e as Error).message); }
  }
  return sent;
}

/**
 * Notifies people. Red goes to the feed and push (except quiet hours, unless `urgent`);
 * amber and info go to the feed only.
 */
export async function notify(o: {
  ws: string; userIds: string[]; kind: string; level: Level; title: string; body?: string; jobId?: string | null; proposalId?: string | null; urgent?: boolean; push?: boolean;
}) {
  const sb = await admin();
  const { data: bs } = await sb.from("brain_settings").select("quiet_from, quiet_to, timezone").eq("workspace_id", o.ws).maybeSingle();
  const quiet = inQuietHours(new Date(), bs?.quiet_from ?? "20:00", bs?.quiet_to ?? "05:00", bs?.timezone ?? "Australia/Melbourne");
  const doPush = (o.push ?? o.level === "red") && (!quiet || o.urgent);
  const { data: mems } = await sb.from("memberships").select("user_id, role").eq("workspace_id", o.ws).eq("status", "active").in("user_id", o.userIds);
  const officeIds = new Set((mems ?? []).filter((m) => m.role === "owner" || m.role === "office").map((m) => m.user_id));
  for (const u of [...new Set(o.userIds)]) {
    const { data: n } = await sb.from("notifications").insert({
      workspace_id: o.ws, user_id: u, kind: o.kind, level: o.level, title: o.title.slice(0, 200), body: (o.body ?? "").slice(0, 2000),
      job_id: o.jobId ?? null, proposal_id: o.proposalId ?? null,
    }).select("id").single();
    if (doPush && n) {
      const sent = await pushTo(u, { title: o.title, body: o.body ?? "", url: jobLink(officeIds.has(u), o.jobId) });
      if (sent) await sb.from("notifications").update({ pushed_at: new Date().toISOString() }).eq("id", n.id);
    }
  }
}

export async function officeUserIds(ws: string) {
  const sb = await admin();
  const { data } = await sb.from("memberships").select("user_id").eq("workspace_id", ws).eq("status", "active").in("role", ["owner", "office"]);
  return (data ?? []).map((m) => m.user_id).filter(Boolean) as string[];
}
