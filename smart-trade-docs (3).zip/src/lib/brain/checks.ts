/** Pure answer checks for every Brain run (spec section 8, step 4). */

/** Wraps outside text (emails, documents, transcripts, messages) so Claude treats it as data. */
export function untrusted(label: string, text: string | null | undefined): string {
  const clean = (text ?? "").replace(/<\/?untrusted[^>]*>/gi, "");
  return `<untrusted source="${label.replace(/"/g, "")}">\n${clean}\n</untrusted>`;
}

const MONEY = /(\$\s?\d)|(\b\d[\d,]*(\.\d+)?\s?(aud|dollars?)\b)|(\bday rate\b)|(\bmargin\b\s*(of|is|:)?\s*\d)/i;
/** True when the text mentions a money value. */
export const hasMoney = (s: string) => MONEY.test(s);

/** Job codes like FZ-1041 mentioned in text that were never given to Claude. */
export function unknownCodes(text: string, prefix: string, known: Set<string>): string[] {
  const re = new RegExp(`\\b${prefix.replace(/[^A-Z0-9]/gi, "")}-?\\s?(\\d{3,6})\\b`, "gi");
  const out = new Set<string>();
  for (const m of text.matchAll(re)) {
    const code = `${prefix.toUpperCase()}-${m[1]}`;
    if (!known.has(code)) out.add(code);
  }
  return [...out];
}

/** ISO dates in text that are not real calendar dates. */
export function badDates(text: string): string[] {
  const out: string[] = [];
  for (const m of text.matchAll(/\b(\d{4})-(\d{2})-(\d{2})\b/g)) {
    const d = new Date(Date.UTC(+m[1]!, +m[2]! - 1, +m[3]!));
    if (d.getUTCMonth() !== +m[2]! - 1 || d.getUTCDate() !== +m[3]!) out.push(m[0]);
  }
  return out;
}

/** Names given as "people" that aren't on the known list (case-insensitive). */
export function unknownNames(names: string[], known: string[]): string[] {
  const k = new Set(known.map((n) => n.trim().toLowerCase()));
  return names.filter((n) => n.trim() && !k.has(n.trim().toLowerCase()));
}

/** Cost rates live only in ./rates (re-exported here for existing imports). */
export { runCostAud } from "./rates";

export type BudgetState = "ok" | "warn" | "paused";
/** 80% warns the owner; at 100% the pausable functions stop. */
export function budgetState(spent: number, budget: number): BudgetState {
  if (budget <= 0) return "ok";
  if (spent >= budget) return "paused";
  if (spent >= budget * 0.8) return "warn";
  return "ok";
}
/** Functions that pause when the monthly budget runs out; the rest keep running. */
export const PAUSABLE = new Set(["photo_tag", "lookahead", "closeout", "documents"]);

/** True when the person has hit 30 Brain requests in 10 minutes. */
export const overRateLimit = (recentCount: number) => recentCount >= 30;
