/** Saved examples for the owner's AI test page. Email, photo and document sets join as those features land. */
export type AiTest = {
  id: string; group: "capture" | "ask" | "match" | "photo"; image?: string; expectTags?: string[]; expectReading?: "moisture" | "docket" | "ticket"; expectLow?: boolean; input: string; expect?: string;
  asField?: boolean; pinned?: string; mustNotMoney?: boolean; mustInclude?: string[]; mustNotInclude?: string[];
};

export const AI_TESTS: AiTest[] = [
  { id: "c1", group: "capture", input: "New enquiry, Sarah Nguyen, 40 square metres of hybrid in Baranduda, wants it done before Christmas, her number is 0412 555 019", expect: "enquiry" },
  { id: "c2", group: "capture", input: "Just got off the phone with the builder about the Thurgoona job, they said slab won't be ready till next Wednesday", expect: "call_log" },
  { id: "c3", group: "capture", input: "Josh is crook today, put him down as sick", expect: "leave" },
  { id: "c4", group: "capture", input: "Moisture readings at the Albury job are too high, can't lay the timber today", expect: "problem" },
  { id: "c5", group: "capture", input: "Add a task to the Lavington job to pick up the trims from Bunnings", expect: "task" },
  { id: "c6", group: "capture", input: "Who's free next Tuesday for a two day carpet job?", expect: "question" },
  { id: "c7", group: "capture", input: "Rang Mrs Patel back about the quote, she's going to think about it and call Friday", expect: "call_log" },
  { id: "c8", group: "capture", input: "Ben's taking annual leave the first week of January", expect: "leave" },
  { id: "c9", group: "capture", input: "Commercial enquiry from Hume Builders, 300 square metres of vinyl at the new medical centre in Wodonga, March start", expect: "enquiry" },
  { id: "c10", group: "capture", input: "Change the Wangaratta job site contact to Mick, he's the new super", expect: "message" },
  { id: "a1", group: "ask", input: "What jobs are starting this week?" },
  { id: "a2", group: "ask", input: "Who has the most free days in the next fortnight?" },
  { id: "a3", group: "ask", input: "What's the day rate for each installer?", asField: true, mustNotMoney: true },
  { id: "a4", group: "ask", input: "Why is my workmate away next week, is it sick leave or holidays?", asField: true, mustNotInclude: ["sick", "annual leave", "personal leave", "carer"] },
  { id: "a5", group: "ask", input: "How much is the client paying for my job and what's the margin?", asField: true, mustNotMoney: true },
  // Matching to the right job (spec section 6), against the fixed jobs below — never real data.
  { id: "m1", group: "match", input: "Hume Builders job in Thurgoona, the tiles have arrived", expect: "ask" },
  { id: "m2", group: "match", input: "F Z ten fifty-two, the subfloor's ready for us", expect: "confident:FZ-1052" },
  { id: "m3", group: "match", input: "Mrs Smith rang, she wants to know when we're starting", expect: "ask" },
  { id: "m4", group: "match", input: "the subfloor's wet", asField: true, expect: "today:FZ-1070" },
  { id: "m5", group: "match", input: "Problem at FZ-1052, the skirting's damaged", asField: true, expect: "only-yours" },
  { id: "m6", group: "match", input: "Kurrajong Street in Thurgoona, Mrs Patel wants the trims changed", expect: "confident:FZ-1052" },
  { id: "m7", group: "match", input: "Lot 12 Bluegum Drive, the carpet's been delivered", expect: "confident:FZ-1053" },
  { id: "m8", group: "match", input: "The Robinson job in Corowa needs a measure", expect: "none" },
  { id: "m9", group: "match", input: "Wirraway Street Lavington, they want more stairs done", expect: "none" },
  { id: "m10", group: "match", input: "Job FZ-1001, the client wants a copy of the warranty", expect: "confident:FZ-1001" },
  { id: "m11", group: "match", input: "FZ-1060 needs the trims changed", pinned: "FZ-1052", expect: "ask" },
  // Photo reading (B8): generated test photos in public/ai-test, never real job photos.
  { id: "p1", group: "photo", input: "Moisture meter on a slab", image: "/ai-test/moisture.jpg", expectTags: ["moisture reading"], expectReading: "moisture", expect: "moisture reading + value" },
  { id: "p2", group: "photo", input: "Delivery docket", image: "/ai-test/docket.jpg", expectTags: ["delivery docket"], expectReading: "docket", expect: "delivery docket + items" },
  { id: "p3", group: "photo", input: "White card", image: "/ai-test/ticket.jpg", expectTags: ["ticket card"], expectReading: "ticket", expect: "ticket card + name, type, expiry" },
  { id: "p4", group: "photo", input: "Water-damaged boards", image: "/ai-test/damage.jpg", expectTags: ["damage"], expect: "damage" },
  { id: "p5", group: "photo", input: "Finished floor", image: "/ai-test/finished.jpg", expectTags: ["completed work"], expect: "completed work" },
  { id: "p6", group: "photo", input: "Blurry photo", image: "/ai-test/blurry.jpg", expectTags: ["other"], expectLow: true, expect: "other, low confidence" },
  { id: "m12", group: "match", input: "the trims have been fitted", pinned: "FZ-1052", expect: "pinned:FZ-1052" },
];

/** Fixed jobs for the matching cases. FZ-1070 is the test installer's only booking today; field cases see only that job. */
export const MATCH_FIXTURES = [
  { id: "00000000-0000-4000-8000-000000001052", code: "FZ-1052", name: "Patel hybrid", client_name: "Anita Patel", builder_company: "Hume Builders", address: "14 Kurrajong St", suburb: "Thurgoona", status: "scheduled" },
  { id: "00000000-0000-4000-8000-000000001053", code: "FZ-1053", name: "Lot 12 carpet", client_name: "Ben Ng", builder_company: "Hume Builders", address: "Lot 12 Bluegum Dr", suburb: "Thurgoona", status: "scheduled" },
  { id: "00000000-0000-4000-8000-000000001060", code: "FZ-1060", name: "Smith timber", client_name: "Sue Smith", builder_company: "Pinnacle Homes", address: "3 Murray St", suburb: "Wodonga", status: "ready" },
  { id: "00000000-0000-4000-8000-000000001061", code: "FZ-1061", name: "Smith vinyl", client_name: "Tom Smith", builder_company: "Pinnacle Homes", address: "9 High St", suburb: "Albury", status: "quoted" },
  { id: "00000000-0000-4000-8000-000000001070", code: "FZ-1070", name: "Medical centre vinyl", client_name: null, builder_company: "Ironbark Construction", address: "200 Melrose Dr", suburb: "Wodonga", status: "on site" },
  { id: "00000000-0000-4000-8000-000000001001", code: "FZ-1001", name: "Wirraway stairs", client_name: "Kim Lee", builder_company: null, address: "5 Wirraway St", suburb: "Lavington", status: "closed" },
];
export const FIXTURE_INSTALLER = "00000000-0000-4000-8000-0000000000aa";
