/**
 * Loads everything the scheduling rules need and builds a RuleContext per job.
 * The rules themselves live in src/lib/rules/ and stay pure.
 */
import { useMemo } from "react";
import { useQuery, type QueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Json } from "@/integrations/supabase/types";
import { hm } from "@/lib/assignments";
import { jobsQuery, type JobListItem } from "@/lib/jobs";
import { addDays } from "@/lib/rules/board";
import { jobBlock, type RuleBooking, type RuleContext, type RuleJob, type RulePerson } from "@/lib/rules/fit-check";
import { driveEstimate } from "@/lib/rules/travel";
import type { PlanJob } from "@/lib/rules/suggest-plan";
import type { HazardSetting, TicketRule } from "@/lib/rules/tickets";
import { todayIso } from "@/lib/rules/ticket-expiry";
import { toRuleLeave } from "@/lib/rules/leave";
import { leaveQuery, useDaysOff } from "@/lib/leave";
import { buildSchedulingApi, toRuleJob, type SchedRaw } from "@/lib/scheduling-core";

export { toRuleJob };

export function useSchedulingData(workspaceId: string) {
  const today = todayIso();
  const settings = useQuery({
    queryKey: ["workspace_settings", workspaceId, "board"],
    queryFn: async () => {
      const { data, error } = await supabase.from("workspace_settings")
        .select("working_days, day_start, morning_end, day_end, skills, hazards, ticket_rules, avg_kmh, holiday_states")
        .eq("workspace_id", workspaceId).single();
      if (error) throw error;
      return data;
    },
  });
  const people = useQuery({
    queryKey: ["sched-people", workspaceId],
    queryFn: async () => {
      const { data, error } = await supabase.from("crew_members")
        .select("id, name, role, base_suburb, base_lat, base_lng, skills, crew_tickets(ticket_type, expires_on)")
        .eq("workspace_id", workspaceId).eq("active", true).order("name");
      if (error) throw error;
      return data;
    },
  });
  const bookings = useQuery({
    queryKey: ["board-assignments", workspaceId, "sched", today],
    queryFn: async () => {
      const { data, error } = await supabase.from("assignments")
        .select("id, job_id, crew_member_id, date, start_time, end_time")
        .eq("workspace_id", workspaceId).gte("date", addDays(today, -30)).lte("date", addDays(today, 220));
      if (error) throw error;
      return data;
    },
  });
  const daysOff = useDaysOff(workspaceId, settings.data?.holiday_states);
  const leave = useQuery(leaveQuery(workspaceId));
  const deps = useQuery({
    queryKey: ["dependencies-all", workspaceId],
    queryFn: async () => {
      const { data, error } = await supabase.from("dependencies").select("job_id, description, status, blocks_start, due_date").eq("workspace_id", workspaceId);
      if (error) throw error;
      return data;
    },
  });
  const jobs = useQuery(jobsQuery(workspaceId));

  const ready = !!(settings.data && people.data && bookings.data && daysOff && leave.data && deps.data && jobs.data);

  const api = useMemo(() => {
    if (!ready) return null;
    return buildSchedulingApi({
      today, settings: settings.data as SchedRaw["settings"], people: people.data as SchedRaw["people"], bookings: bookings.data!,
      daysOff: daysOff!, leave: leave.data!, deps: deps.data as SchedRaw["deps"], jobs: jobs.data!,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, settings.data, people.data, bookings.data, daysOff, leave.data, deps.data, jobs.data, today]);

  return api;
}

export function invalidateSchedule(qc: QueryClient, workspaceId: string, jobId?: string) {
  qc.invalidateQueries({ queryKey: ["board-assignments", workspaceId] });
  qc.invalidateQueries({ queryKey: ["jobs", workspaceId] });
  if (jobId) qc.invalidateQueries({ queryKey: ["assignments", jobId] });
}

type Row = { crew_member_id: string; date: string; start_time: string; end_time: string };

/** Replaces a job's crew and dates through place_job, with a 7-second Undo that restores the exact previous state. */
export async function applyPlacement(o: {
  qc: QueryClient; workspaceId: string; job: JobListItem; ctx: RuleContext; team: string[]; days: string[]; label: string;
}) {
  const { data: prev, error: pe } = await supabase.from("assignments").select("id, crew_member_id, date, start_time, end_time, is_lead").eq("job_id", o.job.id);
  if (pe) { toast.error(pe.message); return false; }
  const rj = toRuleJob(o.job);
  const b = jobBlock(rj, o.ctx);
  const rows: Row[] = o.team.flatMap((c) => o.days.map((date) => ({ crew_member_id: c, date, start_time: b.start, end_time: b.end })));
  const { error } = await supabase.rpc("place_job", {
    _job_id: o.job.id, _rows: rows as unknown as Json, _start_date: o.days[0]!,
    _start_time: (rj.duration_unit === "hours" ? b.start : null) as string,
    _status: o.job.status === "ready" ? "scheduled" : o.job.status,
  });
  if (error) { toast.error(error.message); return false; }
  invalidateSchedule(o.qc, o.workspaceId, o.job.id);
  const before = { start_date: o.job.start_date, start_time: o.job.start_time, status: o.job.status };
  toast.success(o.label, {
    duration: 7000,
    action: {
      label: "Undo",
      onClick: async () => {
        const { error: e } = await supabase.rpc("place_job", {
          _job_id: o.job.id, _rows: prev as unknown as Json, _start_date: before.start_date as string,
          _start_time: before.start_time as string, _status: before.status, _ignore_lock: true,
        });
        if (e) toast.error(e.message); else { toast("Change undone"); invalidateSchedule(o.qc, o.workspaceId, o.job.id); }
      },
    },
  });
  return true;
}
