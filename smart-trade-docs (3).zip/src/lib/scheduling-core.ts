/**
 * Builds the scheduling RuleContext from raw rows. Shared by the browser (useSchedulingData)
 * and the Brain's server tools, so both feed the rules exactly the same inputs.
 * Pure apart from loadSchedulingRaw, which reads through whichever client it is given (RLS applies).
 */
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { hm } from "@/lib/assignments";
import { addDays } from "@/lib/rules/board";
import type { RuleBooking, RuleContext, RuleJob, RulePerson } from "@/lib/rules/fit-check";
import { driveEstimate } from "@/lib/rules/travel";
import type { PlanJob } from "@/lib/rules/suggest-plan";
import type { HazardSetting, TicketRule } from "@/lib/rules/tickets";
import { holidaysAsClosures, toRuleLeave, type LeaveRow } from "@/lib/rules/leave";
import type { DayOff } from "@/lib/rules/working-days";

type Job = Database["public"]["Tables"]["jobs"]["Row"];
export type SchedJob = Job & { tasks: { id: string; done: boolean }[] };
export type SchedRaw = {
  today: string;
  settings: { working_days: number[]; day_start: string; morning_end?: string; day_end: string; skills: string[]; hazards: unknown; ticket_rules: unknown; avg_kmh: number | string; holiday_states: string[] };
  people: { id: string; name: string; role: RulePerson["role"]; base_suburb: string | null; base_lat: number | null; base_lng: number | null; skills: string[] | null; crew_tickets: { ticket_type: string; expires_on: string | null }[] }[];
  bookings: { id: string; job_id: string; crew_member_id: string; date: string; start_time: string; end_time: string }[];
  daysOff: DayOff[];
  leave: LeaveRow[];
  deps: { job_id: string; description: string; status: "pending" | "confirmed" | "failed"; blocks_start: boolean; due_date: string | null }[];
  jobs: SchedJob[];
};

export function toRuleJob(j: SchedJob | Job): PlanJob {
  return {
    id: j.id, code: j.code, sector: j.sector, crew_size: j.crew_size, hazards: j.hazards, extra_tickets: j.extra_tickets,
    main_skill: j.main_skill, other_skills: j.other_skills, duration_value: Number(j.duration_value), duration_unit: j.duration_unit,
    start_time: j.start_time, due_by: j.due_by, due_hard: j.due_hard,
    access_window: { days: ((j.access_window as { days?: number[] } | null)?.days) ?? [] }, locked: j.locked,
    importance: j.importance, urgency: j.urgency, status: j.status, start_date: j.start_date, created_at: j.created_at,
  };
}

export function buildSchedulingApi(r: SchedRaw) {
  const s = r.settings;
  const today = r.today;
  const week = { workingDays: s.working_days, closures: r.daysOff };
  const ruleLeave = toRuleLeave(r.leave);
  const rulePeople: RulePerson[] = r.people.map((p) => ({ id: p.id, name: p.name, role: p.role, skills: p.skills ?? [], tickets: p.crew_tickets }));
  const allBookings: RuleBooking[] = r.bookings.map((b) => ({ crew_member_id: b.crew_member_id, job_id: b.job_id, date: b.date, start: hm(b.start_time), end: hm(b.end_time) }));
  const jobMap = new Map(r.jobs.map((j) => [j.id, j]));
  const ctxFor = (job: RuleJob, extra: RuleBooking[] = []): RuleContext => {
    const j = jobMap.get(job.id);
    const site = j?.lat != null && j.lng != null ? { lat: j.lat, lng: j.lng } : null;
    const est = (a: { lat: number | null; lng: number | null } | undefined) =>
      site && a?.lat != null && a.lng != null ? driveEstimate({ lat: a.lat, lng: a.lng }, site, Number(s.avg_kmh)).minutes : null;
    return {
      today, week, dayStart: hm(s.day_start), dayEnd: hm(s.day_end),
      hazards: s.hazards as HazardSetting[], ticketRules: s.ticket_rules as TicketRule[],
      jobCrew: [...new Set(allBookings.filter((b) => b.job_id === job.id).map((b) => b.crew_member_id))],
      people: rulePeople, bookings: [...allBookings, ...extra], leave: ruleLeave,
      dependencies: r.deps.filter((d) => d.job_id === job.id),
      driveFromBase: (pid) => { const p = r.people.find((x) => x.id === pid); return est(p ? { lat: p.base_lat, lng: p.base_lng } : undefined); },
      driveBetweenJobs: (fid) => { const f = jobMap.get(fid); return est(f ? { lat: f.lat, lng: f.lng } : undefined); },
    };
  };
  return { today, ctxFor, jobs: r.jobs, jobMap, people: r.people, bookingsRaw: r.bookings, week, settings: s, leave: r.leave };
}
export type SchedulingApi = ReturnType<typeof buildSchedulingApi>;

/** Reads everything the rules need through the given client; RLS decides what the caller sees. */
export async function loadSchedulingRaw(sb: SupabaseClient<Database>, ws: string, today: string): Promise<SchedRaw> {
  const [settings, people, bookings, closures, holidays, leave, deps, jobs] = await Promise.all([
    sb.from("workspace_settings").select("working_days, day_start, morning_end, day_end, skills, hazards, ticket_rules, avg_kmh, holiday_states").eq("workspace_id", ws).single(),
    sb.from("crew_members").select("id, name, role, base_suburb, base_lat, base_lng, skills, crew_tickets(ticket_type, expires_on)").eq("workspace_id", ws).eq("active", true).order("name"),
    sb.from("assignments").select("id, job_id, crew_member_id, date, start_time, end_time").eq("workspace_id", ws).gte("date", addDays(today, -30)).lte("date", addDays(today, 220)),
    sb.from("closures").select("name, from_date, to_date, kind, state").eq("workspace_id", ws),
    sb.from("public_holidays").select("state, date, name"),
    sb.from("leave").select("id, crew_member_id, type, from_date, to_date, start_time, end_time, status, note, created_at").eq("workspace_id", ws),
    sb.from("dependencies").select("job_id, description, status, blocks_start, due_date").eq("workspace_id", ws),
    sb.from("jobs").select("*, tasks(id, done)").eq("workspace_id", ws),
  ]);
  const err = [settings, people, bookings, closures, holidays, leave, deps, jobs].find((x) => x.error)?.error;
  if (err) throw new Error(err.message);
  const states = settings.data!.holiday_states ?? [];
  const own = closures.data!.filter((c) => c.kind !== "public holiday" || !c.state || states.includes(c.state));
  const daysOff = [...own.map((c) => ({ from_date: c.from_date, to_date: c.to_date, name: c.name })), ...holidaysAsClosures(holidays.data!, states)];
  return {
    today, settings: settings.data as SchedRaw["settings"], people: people.data as SchedRaw["people"], bookings: bookings.data!,
    daysOff, leave: leave.data as LeaveRow[], deps: deps.data as SchedRaw["deps"], jobs: jobs.data as SchedJob[],
  };
}
