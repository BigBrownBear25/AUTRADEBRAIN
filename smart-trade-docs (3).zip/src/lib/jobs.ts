import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type T = Database["public"]["Tables"];
type E = Database["public"]["Enums"];
export type Job = T["jobs"]["Row"];
export type JobInsert = T["jobs"]["Insert"];
export type JobStatus = E["job_status"];
export type Task = T["tasks"]["Row"];
export type Dependency = T["dependencies"]["Row"];
export type Material = T["materials"]["Row"];
export type AccessWindow = { days: number[]; from: string | null; to: string | null; note: string };
export type JobListItem = Job & { tasks: Pick<Task, "id" | "done">[] };

export const JOB_STATUSES: JobStatus[] = ["enquiry", "quoted", "ready", "scheduled", "on site", "complete", "closed"];

export const statusLabel: Record<JobStatus, string> = {
  enquiry: "Enquiry", quoted: "Quoted", ready: "Ready", scheduled: "Scheduled",
  "on site": "On site", complete: "Complete", closed: "Closed",
};

/** Last working day is calculated properly by the scheduling rules later; this is a calendar estimate for display. */
export function jobEndDate(job: Pick<Job, "start_date" | "duration_value" | "duration_unit">): string | null {
  if (!job.start_date) return null;
  if (job.duration_unit === "hours") return job.start_date;
  const d = new Date(`${job.start_date}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + Math.max(1, Math.ceil(Number(job.duration_value))) - 1);
  return d.toISOString().slice(0, 10);
}

export const jobsQuery = (workspaceId: string) =>
  queryOptions({
    queryKey: ["jobs", workspaceId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("jobs")
        .select("*, tasks(id, done)")
        .eq("workspace_id", workspaceId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as JobListItem[];
    },
  });

export const jobChildrenQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["job_children", jobId],
    queryFn: async () => {
      const [t, d, m] = await Promise.all([
        supabase.from("tasks").select("*").eq("job_id", jobId).order("sort"),
        supabase.from("dependencies").select("*").eq("job_id", jobId).order("created_at"),
        supabase.from("materials").select("*").eq("job_id", jobId).order("sort"),
      ]);
      if (t.error) throw t.error;
      if (d.error) throw d.error;
      if (m.error) throw m.error;
      return { tasks: t.data, dependencies: d.data, materials: m.data };
    },
  });

/** Returns nothing for non-finance users — the database enforces it. */
export const jobFinanceQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["job_finance", jobId],
    queryFn: async () => {
      const { data, error } = await supabase.from("job_finance").select("*").eq("job_id", jobId).maybeSingle();
      if (error) throw error;
      return data;
    },
  });

export const materialCostsQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["material_costs", jobId],
    queryFn: async () => {
      const { data, error } = await supabase.from("material_costs").select("material_id, unit_cost, materials!inner(job_id)").eq("materials.job_id", jobId);
      if (error) throw error;
      return new Map(data.map((r) => [r.material_id, r.unit_cost]));
    },
  });

export const jobSettingsQuery = (workspaceId: string) =>
  queryOptions({
    queryKey: ["workspace_settings", workspaceId, "job"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("workspace_settings")
        .select("skills, ticket_types, hazards, job_types")
        .eq("workspace_id", workspaceId)
        .single();
      if (error) throw error;
      return {
        skills: data.skills,
        jobTypes: data.job_types,
        ticketTypes: (data.ticket_types as { name: string }[]).map((t) => t.name),
        hazards: (data.hazards as { name: string }[]).map((h) => h.name),
      };
    },
  });
