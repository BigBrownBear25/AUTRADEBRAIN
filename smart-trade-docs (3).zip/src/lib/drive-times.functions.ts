import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type DriveLeg = { key: string; label: string; crewMemberId: string | null; km: number | null; minutes: number | null; source: "route" | "cache" | "none"; error?: string };

const norm = (s: string) => s.trim().toLowerCase().replace(/\s+/g, " ");
const GATEWAY = "https://connector-gateway.lovable.dev/google_maps";

/**
 * Drive times from the depot and each visible crew member's home base to the job site.
 * Google Routes API results are cached in drive_cache per origin and site. RLS decides
 * which crew bases the caller can see (field users: only their own).
 */
export const getDriveTimes = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { jobId: string }) => {
    if (!/^[0-9a-f-]{36}$/i.test(d.jobId)) throw new Error("Bad job id");
    return d;
  })
  .handler(async ({ data, context }) => {
    const sb = context.supabase;
    const { data: ok } = await sb.rpc("is_job_reader", { _job_id: data.jobId });
    if (!ok) throw new Error("You can't open this job");
    const { data: job, error } = await sb.from("jobs").select("id, workspace_id, address, suburb").eq("id", data.jobId).single();
    if (error || !job) throw new Error("Job not found");
    const site = [job.address, job.suburb].filter(Boolean).join(", ");
    if (!site) return { site: null, legs: [] as DriveLeg[] };

    const [{ data: ws }, { data: rows }] = await Promise.all([
      sb.from("workspaces").select("depot_name").eq("id", job.workspace_id).single(),
      sb.from("assignments").select("crew_member_id").eq("job_id", job.id),
    ]);
    const ids = [...new Set((rows ?? []).map((r) => r.crew_member_id))];
    const { data: crew } = ids.length ? await sb.from("crew_members").select("id, name, base_suburb").in("id", ids) : { data: [] };

    const origins: { key: string; label: string; crewMemberId: string | null; addr: string }[] = [];
    if (ws?.depot_name) origins.push({ key: "depot", label: "Depot", crewMemberId: null, addr: ws.depot_name });
    for (const c of crew ?? []) if (c.base_suburb) origins.push({ key: c.id, label: c.name, crewMemberId: c.id, addr: c.base_suburb });
    if (!origins.length) return { site, legs: [] as DriveLeg[] };

    const toKey = norm(site);
    // Cache keys are home-base addresses, so only the server reads them; origins above are already RLS-limited.
    const { supabaseAdmin: cacheDb } = await import("@/integrations/supabase/client.server");
    const { data: cached } = await cacheDb.from("drive_cache").select("from_key, km, minutes")
      .eq("workspace_id", job.workspace_id).eq("to_key", toKey).in("from_key", origins.map((o) => norm(o.addr)));
    const hit = new Map((cached ?? []).map((c) => [c.from_key, c]));
    const missing = [...new Set(origins.map((o) => norm(o.addr)).filter((k) => !hit.has(k)))].slice(0, 25);

    let apiError: string | undefined;
    const fresh = new Map<string, { km: number; minutes: number }>();
    if (missing.length) {
      const lk = process.env["LOVABLE_API_KEY"], gk = process.env["GOOGLE_MAPS_API_KEY"];
      if (!lk || !gk) apiError = "Google Maps isn't connected";
      else {
        const addrOf = (k: string) => origins.find((o) => norm(o.addr) === k)!.addr;
        const res = await fetch(`${GATEWAY}/routes/distanceMatrix/v2:computeRouteMatrix`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${lk}`, "X-Connection-Api-Key": gk, "Content-Type": "application/json",
            "X-Goog-FieldMask": "originIndex,destinationIndex,status,condition,distanceMeters,duration",
          },
          body: JSON.stringify({
            origins: missing.map((k) => ({ waypoint: { address: `${addrOf(k)}, Australia` } })),
            destinations: [{ waypoint: { address: `${site}, Australia` } }],
            travelMode: "DRIVE", regionCode: "AU",
          }),
        });
        {
          const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
          await supabaseAdmin.from("usage_events").insert({ workspace_id: job.workspace_id, kind: "maps", units: missing.length, detail: "routes" });
        }
        if (!res.ok) {
          const body = await res.text();
          console.error(`Routes API failed [${res.status}]: ${body}`);
          apiError = res.status === 403 ? "Google Maps refused the request" : `Google Maps error ${res.status}`;
        } else {
          const cells = (await res.json()) as { originIndex?: number; condition?: string; distanceMeters?: number; duration?: string }[];
          for (const c of cells) {
            if (c.condition !== "ROUTE_EXISTS" || !c.duration) continue;
            const k = missing[c.originIndex ?? 0]!;
            fresh.set(k, { km: Math.round((c.distanceMeters ?? 0) / 100) / 10, minutes: Math.round(parseFloat(c.duration) / 60) });
          }
          if (fresh.size) {
            const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
            await supabaseAdmin.from("drive_cache").upsert([...fresh].map(([from_key, v]) => ({
              workspace_id: job.workspace_id, from_key, to_key: toKey, km: v.km, minutes: v.minutes, fetched_at: new Date().toISOString(),
            })));
          }
        }
      }
    }
    const legs: DriveLeg[] = origins.map((o) => {
      const k = norm(o.addr), c = hit.get(k), f = fresh.get(k);
      if (c) return { key: o.key, label: o.label, crewMemberId: o.crewMemberId, km: Number(c.km), minutes: c.minutes, source: "cache" };
      if (f) return { key: o.key, label: o.label, crewMemberId: o.crewMemberId, ...f, source: "route" };
      return { key: o.key, label: o.label, crewMemberId: o.crewMemberId, km: null, minutes: null, source: "none", ...(apiError ? { error: apiError } : { error: "No route found" }) };
    });
    return { site, legs };
  });

export type PersonDrive = { hours: number; trips: number; unmeasured: number; noBase: boolean };

/**
 * Board drive hours: for each visible person, total driving in the range from cached drive times only
 * (never calls Google). Each booked day on a job counts a return trip home base → site → home base.
 * RLS on the caller's client decides which people and bookings are counted.
 */
export const getBoardDriveHours = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { workspaceId: string; from: string; to: string }) => {
    if (!/^[0-9a-f-]{36}$/i.test(d?.workspaceId) || !/^\d{4}-\d{2}-\d{2}$/.test(d.from) || !/^\d{4}-\d{2}-\d{2}$/.test(d.to)) throw new Error("Bad range");
    return d;
  })
  .handler(async ({ data, context }) => {
    const sb = context.supabase;
    const [{ data: crew }, { data: rows }] = await Promise.all([
      sb.from("crew_members").select("id, base_suburb").eq("workspace_id", data.workspaceId).eq("active", true),
      sb.from("assignments").select("crew_member_id, date, job_id, jobs(address, suburb)").eq("workspace_id", data.workspaceId).gte("date", data.from).lte("date", data.to),
    ]);
    const base = new Map((crew ?? []).map((c) => [c.id, c.base_suburb ? norm(c.base_suburb) : null]));
    const trips = new Map<string, { from: string; to: string }>();
    for (const r of rows ?? []) {
      const b = base.get(r.crew_member_id); const j = r.jobs as { address: string | null; suburb: string | null } | null;
      const site = j ? [j.address, j.suburb].filter(Boolean).join(", ") : "";
      if (!b || !site) continue;
      trips.set(`${r.crew_member_id}|${r.date}|${r.job_id}`, { from: b, to: norm(site) });
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const froms = [...new Set([...trips.values()].map((t) => t.from))];
    const { data: cached } = froms.length
      ? await supabaseAdmin.from("drive_cache").select("from_key, to_key, minutes").eq("workspace_id", data.workspaceId).in("from_key", froms)
      : { data: [] as { from_key: string; to_key: string; minutes: number }[] };
    const mins = new Map((cached ?? []).map((c) => [`${c.from_key}|${c.to_key}`, c.minutes]));
    const out: Record<string, PersonDrive> = {};
    for (const [id, b] of base) out[id] = { hours: 0, trips: 0, unmeasured: 0, noBase: !b };
    for (const [k, t] of trips) {
      const o = out[k.split("|")[0]!]; if (!o) continue;
      const m = mins.get(`${t.from}|${t.to}`);
      if (m == null) o.unmeasured++; else { o.trips++; o.hours += (m * 2) / 60; }
    }
    for (const o of Object.values(out)) o.hours = Math.round(o.hours * 10) / 10;
    return out;
  });
