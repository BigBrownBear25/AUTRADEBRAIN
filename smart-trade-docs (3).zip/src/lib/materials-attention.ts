/** One select and one flattening step for materials fed to needsAttention(), so the Overview, brief, watcher and Ask agree. */
export const MATERIAL_ATTENTION_COLS = "id, job_id, status, qty, item, ordered_at, order_by_date, catalogue_items(stocked, lead_time_days)" as const;

type Row = { job_id: string; status: string; item: string; ordered_at: string | null; order_by_date: string | null;
  catalogue_items: { stocked: boolean; lead_time_days: number | null } | null };

export function flattenMaterial<T extends Row>(m: T) {
  return { ...m, stocked: m.catalogue_items?.stocked ?? null, lead_time_days: m.catalogue_items?.lead_time_days ?? null };
}
