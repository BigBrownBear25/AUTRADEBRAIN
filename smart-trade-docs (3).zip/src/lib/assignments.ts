import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type Assignment = Database["public"]["Tables"]["assignments"]["Row"];
export type CrewMate = { crew_member_id: string; name: string; role: Database["public"]["Enums"]["crew_role"]; phone: string | null };

export const jobAssignmentsQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["assignments", jobId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("assignments")
        .select("*")
        .eq("job_id", jobId)
        .order("date")
        .order("start_time");
      if (error) throw error;
      return data;
    },
  });

/** The only way field screens see other people: name, role and phone for crew on a shared job. */
export const crewMatesQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["crew_mates", jobId],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("crew_mates", { _job_id: jobId });
      if (error) throw error;
      return (data ?? []) as CrewMate[];
    },
  });

export const standardHoursQuery = (workspaceId: string) =>
  queryOptions({
    queryKey: ["workspace_settings", workspaceId, "hours"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("workspace_settings")
        .select("working_days, day_start, morning_end, day_end")
        .eq("workspace_id", workspaceId)
        .single();
      if (error) throw error;
      return data;
    },
  });

export const hm = (t: string) => t.slice(0, 5);
