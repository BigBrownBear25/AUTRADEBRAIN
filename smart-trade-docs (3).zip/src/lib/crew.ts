import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type CrewMember = Database["public"]["Tables"]["crew_members"]["Row"];
export type CrewTicket = Database["public"]["Tables"]["crew_tickets"]["Row"];
export type CrewRole = Database["public"]["Enums"]["crew_role"];
export type CrewWithTickets = CrewMember & { crew_tickets: CrewTicket[] };

export const crewRoleLabel: Record<CrewRole, string> = {
  foreman: "Foreman",
  installer: "Installer",
  apprentice: "Apprentice",
};

/** Row-level security decides what comes back: office gets everyone, field gets only themselves. */
export const crewQuery = (workspaceId: string) =>
  queryOptions({
    queryKey: ["crew", workspaceId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("crew_members")
        .select("*, crew_tickets(*)")
        .eq("workspace_id", workspaceId)
        .order("sort")
        .order("name");
      if (error) throw error;
      return data as CrewWithTickets[];
    },
  });

/** Empty for anyone who isn't a finance user (enforced by the database). */
export const crewRatesQuery = (workspaceId: string) =>
  queryOptions({
    queryKey: ["crew_rates", workspaceId],
    queryFn: async () => {
      const { data, error } = await supabase.from("crew_rates").select("crew_member_id, day_rate").eq("workspace_id", workspaceId);
      if (error) throw error;
      return new Map(data.map((r) => [r.crew_member_id, r.day_rate]));
    },
  });

export const isFinanceQuery = (workspaceId: string) =>
  queryOptions({
    queryKey: ["is_finance", workspaceId],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("is_finance", { _ws: workspaceId });
      if (error) throw error;
      return !!data;
    },
  });

export const workspaceListsQuery = (workspaceId: string) =>
  queryOptions({
    queryKey: ["workspace_settings", workspaceId, "lists"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("workspace_settings")
        .select("skills, ticket_types")
        .eq("workspace_id", workspaceId)
        .single();
      if (error) throw error;
      return { skills: data.skills, ticketTypes: data.ticket_types as { name: string; expires: boolean }[] };
    },
  });
