import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Every workspace-scoped table. Add new tables here — the export test checks this list against the database. */
export const EXPORT_TABLES = [
  "workspaces", "memberships", "workspace_settings", "workspace_finance_settings", "closures",
  "crew_members", "crew_tickets", "crew_rates", "leave",
  "jobs", "job_finance", "dependencies", "tasks", "materials", "material_costs", "assignments",
  "messages", "attachments", "message_reads", "inbound_emails", "drive_cache", "usage_events", "audit_log", "access_reviews", "security_events", "suppliers", "catalogue_items", "catalogue_prices", "companion_rules",
  "brain_settings", "ai_config", "proposals", "notifications", "ai_runs", "brain_events", "push_subscriptions", "ask_messages", "call_logs", "brain_job_flags", "brain_reports", "capture_feedback", "morning_briefs",
] as const;

/** export-workspace: owner only. Reads with the admin client, filtered strictly to the owner's workspace. */
export const exportWorkspace = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { workspaceId: string }) => {
    if (!/^[0-9a-f-]{36}$/i.test(d?.workspaceId)) throw new Error("Bad workspace");
    return d;
  })
  .handler(async ({ data, context }) => {
    const { data: ok } = await context.supabase.rpc("is_owner", { _ws: data.workspaceId });
    if (!ok) throw new Error("Only the owner can export workspace data");
    const { supabaseAdmin: admin } = await import("@/integrations/supabase/client.server");
    const tables: Record<string, unknown[]> = {};
    for (const t of EXPORT_TABLES) {
      const col = t === "workspaces" ? "id" : "workspace_id";
      const rows: unknown[] = [];
      for (let from = 0; ; from += 1000) {
        const { data: page, error } = await (admin.from(t) as any).select("*").eq(col, data.workspaceId).range(from, from + 999);
        if (error) throw new Error(`${t}: ${error.message}`);
        rows.push(...(page ?? []));
        if (!page || page.length < 1000) break;
      }
      tables[t] = rows;
    }
    const { data: ws } = await admin.from("workspace_settings").select("holiday_states").eq("workspace_id", data.workspaceId).maybeSingle();
    const { data: hol } = await admin.from("public_holidays").select("*").in("state", ws?.holiday_states ?? []);
    tables["public_holidays"] = hol ?? [];
    return JSON.stringify({ exportedAt: new Date().toISOString(), workspaceId: data.workspaceId, tables });
  });
