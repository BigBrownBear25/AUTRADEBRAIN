/**
 * The email provider's inbound address (e.g. Postmark gives "abc123@inbound.postmarkapp.com").
 * Each workspace's address adds its own "+key". Empty until the provider account is connected.
 */
export const INBOUND_BASE = "";

export function inboundAddress(key: string): string | null {
  if (!INBOUND_BASE.includes("@")) return null;
  const [local, domain] = INBOUND_BASE.split("@");
  return `${local}+${key}@${domain}`;
}
