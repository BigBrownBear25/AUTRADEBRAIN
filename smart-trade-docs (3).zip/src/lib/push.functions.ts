import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** The public half of the push key pair (safe for the browser). */
export const pushPublicKey = createServerFn({ method: "GET" }).handler(async () => ({ key: process.env["VAPID_PUBLIC_KEY"] ?? null }));

/** Sends a test notification to the caller's own devices. */
export const pushTest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { pushTo } = await import("./brain/notify.server");
    const sent = await pushTo(context.userId, { title: "Trade Brain", body: "Notifications are on for this device.", url: "/" });
    return { sent };
  });
