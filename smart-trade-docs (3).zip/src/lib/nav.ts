import {
  LayoutDashboard,
  CalendarRange,
  Briefcase,
  MessageSquare,
  Users,
  Sun,
  CalendarDays,
  ClipboardList,
  Package,
  type LucideIcon,
} from "lucide-react";

export type NavItem = {
  to:
    | "/overview"
    | "/schedule"
    | "/jobs"
    | "/messages"
    | "/crew"
    | "/catalogue"
    | "/my-day"
    | "/my-schedule"
    | "/my-jobs";
  label: string;
  icon: LucideIcon;
  help: string;
};

export const officeNav: NavItem[] = [
  { to: "/overview", label: "Overview", icon: LayoutDashboard, help: "Headline figures, crew capacity, jobs that need attention and the to-schedule list." },
  { to: "/schedule", label: "Schedule", icon: CalendarRange, help: "The board: crew in rows, days in columns. Drag jobs on, see fit checks, leave and closures." },
  { to: "/jobs", label: "Jobs", icon: Briefcase, help: "Every job with filters and search. Open one to see its full job file." },
  { to: "/messages", label: "Messages", icon: MessageSquare, help: "Every job chat you can see, unread first, plus email waiting to be filed." },
  { to: "/crew", label: "Crew", icon: Users, help: "People, skills and tickets, plus leave requests, closures and forward availability." },
  { to: "/catalogue", label: "Catalogue", icon: Package, help: "Products and suppliers: search, links, lead times and (finance) price history." },
];

export const fieldNav: NavItem[] = [
  { to: "/my-day", label: "My day", icon: Sun, help: "Today's job, when to leave, directions and your next task." },
  { to: "/messages", label: "Messages", icon: MessageSquare, help: "Chats for the jobs you're on." },
  { to: "/my-schedule", label: "My schedule", icon: CalendarDays, help: "Where you're booked over the coming days and weeks." },
  { to: "/my-jobs", label: "My jobs", icon: ClipboardList, help: "The jobs you're assigned to, with tasks, safety and guidance." },
];
