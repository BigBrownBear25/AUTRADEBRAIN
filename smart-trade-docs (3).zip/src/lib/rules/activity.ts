/** Plain-English lines for the owner's Activity log (prompt S1), e.g. "Sam moved FZ-1052 to Thursday: builder delay". */
export type AuditRow = {
  id: number; actor_user_id: string | null; action: string; table_name: string; row_id: string | null;
  before: Record<string, unknown> | null; after: Record<string, unknown> | null; at: string; reason: string | null;
};
export type Lookup = { person: (userId: string | null) => string; jobCode: (jobId: string | null | undefined) => string | null };

export const FINANCE_TABLES = ["job_finance", "crew_rates", "material_costs", "workspace_finance_settings"] as const;

const THING: Record<string, string> = {
  jobs: "job", assignments: "booking", tasks: "task", materials: "material", dependencies: "dependency", messages: "message",
  attachments: "file", leave: "leave", crew_members: "crew member", crew_tickets: "ticket", crew_rates: "day rate",
  job_finance: "job finance", material_costs: "material cost", workspace_finance_settings: "finance settings",
  memberships: "membership", workspace_settings: "workspace settings", workspaces: "workspace", closures: "closure",
  proposals: "Brain proposal", brain_settings: "Brain settings", ai_config: "AI settings", inbound_emails: "email",
  access_reviews: "access review", security_events: "security event", morning_briefs: "morning brief",
};
const WEEKDAY = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const dayName = (d: unknown) => (typeof d === "string" && /^\d{4}-\d{2}-\d{2}$/.test(d) ? WEEKDAY[new Date(`${d}T00:00:00`).getDay()]! : null);
const str = (v: unknown) => (typeof v === "string" && v.trim() ? v.trim() : null);

export function describeAudit(r: AuditRow, l: Lookup): string {
  const who = l.person(r.actor_user_id);
  const row = r.after ?? r.before ?? {};
  const code = r.table_name === "jobs" ? str(row["code"]) : l.jobCode(str(row["job_id"]));
  const thing = THING[r.table_name] ?? r.table_name.replace(/_/g, " ");
  const label = str(row["label"]) ?? str(row["name"]) ?? str(row["item"]) ?? null;
  const why = r.reason && !r.reason.startsWith("brain:") ? `: ${r.reason}` : r.reason ? ` (via the Brain)` : "";
  let what: string;
  if (r.table_name === "assignments" && r.action === "update" && r.before?.["date"] !== r.after?.["date"]) {
    what = `moved ${code ?? "a booking"} to ${dayName(r.after?.["date"]) ?? str(r.after?.["date"]) ?? "another day"}`;
  } else if (r.table_name === "assignments") {
    const d = dayName(row["date"]);
    what = `${r.action === "insert" ? "booked" : r.action === "delete" ? "removed a booking from" : "changed a booking on"} ${code ?? "a job"}${d ? ` for ${d}` : ""}`;
  } else if (r.table_name === "jobs" && r.action === "update" && r.before?.["status"] !== r.after?.["status"]) {
    what = `set ${code ?? "a job"} to ${str(r.after?.["status"]) ?? "a new status"}`;
  } else {
    const verb = r.action === "insert" ? "added" : r.action === "delete" ? "deleted" : "changed";
    what = `${verb} ${r.table_name === "jobs" ? code ?? "a job" : `the ${thing}${label ? ` "${label.slice(0, 60)}"` : ""}${code ? ` on ${code}` : ""}`}`;
  }
  return `${who} ${what}${why}`;
}

/** CSV with quoting; the first row is the header. */
export function toCsv(rows: (string | number | null)[][]): string {
  return rows.map((r) => r.map((v) => { const s = v == null ? "" : String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; }).join(",")).join("\n");
}
