/** Access reviews (spec section 14 "Access reviews"; prompt S1): reminder every 90 days, members idle 60 days flagged. */
export const REVIEW_EVERY_DAYS = 90;
export const STALE_SIGN_IN_DAYS = 60;
const DAY = 86_400_000;

export function reviewDue(lastReviewedAt: string | null, now = new Date()): boolean {
  if (!lastReviewedAt) return true;
  return now.getTime() - Date.parse(lastReviewedAt) >= REVIEW_EVERY_DAYS * DAY;
}

/** Active members with no sign-in for 60 days (or never signed in) are flagged; pending invites are not. */
export function staleSignIn(m: { status: string; last_sign_in_at: string | null }, now = new Date()): boolean {
  if (m.status !== "active") return false;
  if (!m.last_sign_in_at) return true;
  return now.getTime() - Date.parse(m.last_sign_in_at) >= STALE_SIGN_IN_DAYS * DAY;
}
