/** Working days and job days (spec section 6 "Working days"). Pure — no database calls. */
import { isoWeekday } from "./assignments";
import { addDays } from "./board";

/** Closures and public holidays already filtered to the workspace's states. */
export type DayOff = { from_date: string; to_date: string; name: string };
export type WorkWeek = { workingDays: number[]; closures: DayOff[] };

export function closureFor(date: string, closures: DayOff[]): DayOff | undefined {
  return closures.find((c) => c.from_date <= date && date <= c.to_date);
}

/** In the working week and not a closure or public holiday. */
export function isWorkingDay(date: string, w: WorkWeek): boolean {
  return w.workingDays.includes(isoWeekday(date)) && !closureFor(date, w.closures);
}

/** Working days from `from` to `to` inclusive. */
export function workingDays(from: string, to: string, w: WorkWeek): string[] {
  const out: string[] = [];
  for (let d = from, i = 0; d <= to && i < 800; d = addDays(d, 1), i++) if (isWorkingDay(d, w)) out.push(d);
  return out;
}

/** The next `n` working days strictly after `date`. */
export function nextWorkingDays(date: string, n: number, w: WorkWeek): string[] {
  const out: string[] = [];
  for (let d = addDays(date, 1), i = 0; out.length < n && i < n * 4 + 60; d = addDays(d, 1), i++) if (isWorkingDay(d, w)) out.push(d);
  return out;
}

/**
 * Days a job covers from its start. A job in hours is one block on one day.
 * A job in days covers that many working days from the start (the start counts even when
 * it falls outside the working week — the fit check warns about that).
 */
export function jobDays(start: string, duration: { value: number; unit: "hours" | "days" }, w: WorkWeek): string[] {
  if (duration.unit === "hours") return [start];
  const n = Math.max(1, Math.ceil(duration.value));
  return [start, ...nextWorkingDays(start, n - 1, w)];
}
