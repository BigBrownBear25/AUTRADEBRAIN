/** Pure rules for the Brain: quiet hours, watcher debounce, proposal expiry and supersession, look-ahead maths. */

/** Wall-clock HH:MM in a time zone. */
export function localHm(now: Date, tz: string): string {
  return new Intl.DateTimeFormat("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(now);
}
/** Local ISO date in a time zone. */
export function localDate(now: Date, tz: string): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(now);
}
/** Local weekday 1 = Monday … 7 = Sunday. */
export function localWeekday(now: Date, tz: string): number {
  const d = new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "short" }).format(now);
  return ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].indexOf(d) + 1;
}

/** Quiet hours may wrap midnight (20:00 to 05:00). */
export function inQuietHours(now: Date, from: string, to: string, tz: string): boolean {
  const t = localHm(now, tz); const f = from.slice(0, 5); const e = to.slice(0, 5);
  return f <= e ? t >= f && t < e : t >= f || t < e;
}

/** A red item on a P1 job starting within 24 hours pushes even in quiet hours. */
export function urgentDespiteQuiet(level: "red" | "amber", priority: number | null, startsInHours: number | null) {
  return level === "red" && priority === 1 && startsInHours != null && startsInHours <= 24;
}

/** Jobs whose last event is at least `waitMs` old: a burst of edits counts once. */
export function settledJobs(events: { job_id: string | null; at: string }[], now: number, waitMs = 120_000): string[] {
  const last = new Map<string, number>();
  for (const e of events) if (e.job_id) last.set(e.job_id, Math.max(last.get(e.job_id) ?? 0, Date.parse(e.at)));
  return [...last.entries()].filter(([, t]) => now - t >= waitMs).map(([j]) => j);
}

export type Flag = { level: "red" | "amber"; text: string };
/** Only new or worsened flags count: present after, and either absent before or was amber and is now red. */
export function newOrWorse(before: Flag[], after: Flag[]): Flag[] {
  return after.filter((a) => {
    const key = a.text.replace(/\d+/g, "#");
    const b = before.find((x) => x.text.replace(/\d+/g, "#") === key);
    return !b || (b.level === "amber" && a.level === "red");
  });
}

/** A placement proposal is superseded when the job's current bookings no longer match the basis it was made from. */
export function bookingSignature(rows: { crew_member_id: string; date: string }[]): string {
  return rows.map((r) => `${r.crew_member_id}@${r.date}`).sort().join("|");
}
export function isSuperseded(basis: string | null | undefined, current: string): boolean {
  return !!basis && basis !== current;
}

/** Default expiry: the start of the affected day (local midnight, as an ISO string with the zone offset given). */
export function defaultExpiry(day: string | null, offset = "+10:00"): string | null {
  return day ? `${day}T00:00:00${offset}` : null;
}

/** Look-ahead per week: available vs booked + backlog crew-days; over 90% or short of a skill is flagged. */
export function weekPressure(o: { available: number; booked: number; backlog: number }) {
  const load = o.available > 0 ? (o.booked + o.backlog) / o.available : o.booked + o.backlog > 0 ? Infinity : 0;
  return { load, over: load > 0.9, free: Math.max(0, o.available - o.booked - o.backlog) };
}

export type BookingRow = { crew_member_id: string; date: string; start_time: string; end_time: string; is_lead: boolean };
/** Adding a person: copy each distinct booked day/time block of the job for the new person. */
export function addPersonRows(rows: BookingRow[], personId: string): BookingRow[] {
  const seen = new Set<string>(); const extra: BookingRow[] = [];
  for (const r of rows) { const k = `${r.date}|${r.start_time}|${r.end_time}`; if (seen.has(k)) continue; seen.add(k); extra.push({ crew_member_id: personId, date: r.date, start_time: r.start_time, end_time: r.end_time, is_lead: false }); }
  return [...rows.map(({ crew_member_id, date, start_time, end_time, is_lead }) => ({ crew_member_id, date, start_time, end_time, is_lead })), ...extra];
}
/** Rows for placing a Find a slot option: every team member on every day, first person leads. */
export function slotRows(team: string[], days: string[], start: string, end: string): BookingRow[] {
  return team.flatMap((id, i) => days.map((d) => ({ crew_member_id: id, date: d, start_time: start, end_time: end, is_lead: i === 0 })));
}

/** Crew-days per week (Monday start) from booking dates. */
export function bookedByWeek(dates: string[], weekStarts: string[]): number[] {
  return weekStarts.map((w, i) => { const end = weekStarts[i + 1] ?? "9999-12-31"; return dates.filter((d) => d >= w && d < end).length; });
}
