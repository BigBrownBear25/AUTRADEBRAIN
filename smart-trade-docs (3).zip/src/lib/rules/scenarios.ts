/** Rules test page scenarios (spec section 6 "Rules test page") on built-in sample data. Pure. */
import { priorityOf } from "./priority";
import { requiredTickets, type HazardSetting, type TicketRule } from "./tickets";
import { fitCheck, findSlot, type RuleContext, type RuleJob, type RulePerson } from "./fit-check";
import { addDays } from "./board";
import { nextWorkingDays, workingDays } from "./working-days";
import { suggestPlan, type PlanJob } from "./suggest-plan";
import { quantity } from "./materials";

export type ScenarioResult = { name: string; expected: string; actual: string; pass: boolean };

const HAZARDS: HazardSetting[] = [
  { name: "vulnerable occupants", controls: [], required_tickets: [{ ticket: "WWCC", who: "everyone" }] },
  { name: "concrete grinding", controls: [], required_tickets: [{ ticket: "Silica Awareness", who: "everyone" }] },
  { name: "after-hours work", controls: [], required_tickets: [{ ticket: "First Aid", who: "one" }] },
];
const RULES: TicketRule[] = [
  { when: "commercial", ticket: "White Card", who: "everyone" },
  { when: "crew_size_2_plus", ticket: "First Aid", who: "one" },
  { when: "all_hazards", hazards: ["old floor removal", "pre-1990 building"], ticket: "Asbestos Awareness", who: "everyone" },
  { when: "extra_tickets", who: "everyone" },
];
const WEEK = { workingDays: [1, 2, 3, 4, 5], closures: [] };

const job = (o: Partial<RuleJob> = {}): RuleJob => ({
  id: "job", sector: "domestic", crew_size: 1, hazards: [], extra_tickets: [], main_skill: "Hybrid", other_skills: [],
  duration_value: 3, duration_unit: "days", start_time: null, due_by: null, due_hard: false, access_window: { days: [] }, locked: false, ...o,
});
const T = (...names: string[]) => names.map((ticket_type) => ({ ticket_type, expires_on: null }));
const person = (id: string, role: RulePerson["role"], tickets: string[], skills = ["Hybrid"]): RulePerson => ({ id, name: id, role, skills, tickets: T(...tickets) });

function ctx(today: string, people: RulePerson[], o: Partial<RuleContext> = {}): RuleContext {
  return {
    today, week: WEEK, dayStart: "07:00", dayEnd: "15:30", hazards: HAZARDS, ticketRules: RULES,
    jobCrew: [], people, bookings: [], leave: [], dependencies: [], driveFromBase: () => 20, ...o,
  };
}
const reasonText = (r: { level: string; reasons: { level: string; text: string }[] }) =>
  `${r.level}: ${r.reasons.filter((x) => x.level === r.level).map((x) => x.text).join("; ") || "—"}`;

export function runScenarios(today: string): ScenarioResult[] {
  const out: ScenarioResult[] = [];
  const push = (name: string, expected: string, actual: string, pass: boolean) => out.push({ name, expected, actual, pass });
  const start = nextWorkingDays(today, 5, WEEK)[4]!;

  // 1
  const p1 = priorityOf({ importance: "key", urgency: "flexible", due_by: null, due_hard: false, status: "ready" }, today);
  push("Key importance, Flexible urgency, no due date", "P3", `P${p1}`, p1 === 3);

  // 2
  const p2 = priorityOf({ importance: "standard", urgency: "soon", due_by: addDays(today, 6), due_hard: true, status: "ready" }, today);
  push("Standard importance, Soon urgency, hard due date in 6 days", "P2", `P${p2}`, p2 === 2);

  // 3
  const commercial = job({ sector: "commercial", hazards: ["vulnerable occupants"] });
  const req = requiredTickets(commercial, HAZARDS, RULES);
  const wc = req.find((t) => t.ticket === "White Card"), ww = req.find((t) => t.ticket === "WWCC");
  push("Commercial job with vulnerable occupants", "White Card and WWCC for everyone",
    req.map((t) => `${t.ticket} (${t.who})`).join(", "), wc?.who === "everyone" && ww?.who === "everyone");

  // 4
  const noWwcc = person("Installer without WWCC", "installer", ["White Card"]);
  const f4 = fitCheck(commercial, noWwcc, start, ctx(today, [noWwcc]));
  push("Placing an installer with no WWCC on that job", "Clash: WWCC missing", reasonText(f4),
    f4.level === "clash" && f4.reasons.some((r) => r.level === "clash" && r.text === "WWCC missing"));

  // 5
  const inst = person("Installer", "installer", ["White Card", "WWCC"]);
  const days = workingDays(start, addDays(start, 6), WEEK).slice(0, 3);
  const f5 = fitCheck(job(), inst, start, ctx(today, [inst], { leave: [{ crew_member_id: inst.id, from: days[1]!, to: days[1]!, status: "approved" }] }));
  push("Installer on approved leave for one of the job's days", "Clash: on leave", reasonText(f5),
    f5.level === "clash" && f5.reasons.some((r) => r.check === "Leave" && r.level === "clash"));

  // 6
  const f6 = fitCheck(job(), inst, start, ctx(today, [inst], { leave: [{ crew_member_id: inst.id, from: days[2]!, to: days[2]!, status: "requested" }] }));
  push("Installer with requested leave on one day", "Warning", reasonText(f6), f6.level === "warning");

  // 7: installers score higher (closer) than the foreman, so the first pick has no foreman.
  const crew7 = [
    person("Installer A", "installer", ["First Aid"]), person("Installer B", "installer", []),
    person("Installer C", "installer", []), person("Foreman F", "foreman", []),
  ];
  const s7 = findSlot(job({ crew_size: 3 }), ctx(today, crew7, { driveFromBase: (id) => (id === "Foreman F" ? 110 : 15) }));
  const team7 = s7.options[0]?.team ?? [];
  push("3-person job and the chosen team has no foreman", "Find a slot swaps in a foreman",
    s7.options[0] ? `Team: ${team7.join(", ")}. ${s7.options[0].notes.join("; ")}` : `No slot: ${s7.reason}`,
    team7.includes("Foreman F") && (s7.options[0]?.notes.some((n) => n.includes("foreman")) ?? false));

  // 8: due hard in 5 working days; the only qualified people are booked every day until then.
  const due = nextWorkingDays(today, 5, WEEK)[4]!;
  const crew8 = [person("Installer X", "installer", []), person("Installer Y", "installer", [])];
  const busy = nextWorkingDays(today, 10, WEEK).flatMap((d) => crew8.map((p) => ({ crew_member_id: p.id, job_id: "other", date: d, start: "07:00", end: "15:30" })));
  const s8 = findSlot(job({ crew_size: 2, duration_value: 2, due_by: due, due_hard: true }), ctx(today, crew8, { bookings: busy }));
  push("Job due hard in 5 working days, nobody qualified free", "No slot, with the reason",
    s8.options.length ? `${s8.options.length} slot(s) found` : `No slot: ${s8.reason}`, !s8.options.length && !!s8.reason);

  // 9: Suggest a plan — locked job never moved; earlier picks count as booked.
  const solo = [person("Installer S", "installer", [])];
  const pj = (id: string, o: Partial<PlanJob>): PlanJob => ({
    ...job({ id, duration_value: 1 }), importance: "standard", urgency: "soon", status: "ready", start_date: null, created_at: "2026-01-01", ...o,
  });
  const plan = suggestPlan([
    pj("Locked", { locked: true, importance: "key", urgency: "critical" }),
    pj("First", { importance: "key", urgency: "critical" }),
    pj("Second", {}),
  ], (_j, extra) => ctx(today, solo, { bookings: extra }), today);
  const first = plan.find((p) => p.jobId === "First")?.option?.start;
  const second = plan.find((p) => p.jobId === "Second")?.option?.start;
  push("Suggest a plan with a locked job and one installer", "Locked job left alone; second job placed after the first",
    `${plan.map((p) => `${p.jobId}: ${p.option ? p.option.start : p.reason}`).join("; ")}`,
    !plan.some((p) => p.jobId === "Locked") && !!first && !!second && second > first);

  // 10-13: materials quantities (spec section 13 "Quantities"), always with the working.
  const q1 = quantity({ category: "lvt and hybrid", unit: "box", pack_size: 2.2, coverage: 2.2, waste_pct: null }, { area: 42 });
  push("Boxed goods: 42 m² of hybrid, 2.2 m² boxes, 8% waste", "21 boxes", q1.working, q1.qty === 21);
  const q2 = quantity({ category: "carpet", unit: "roll", pack_size: 3.66, coverage: null, waste_pct: null }, { area: 20 });
  push("Roll goods: 20 m² of carpet, 3.66 m roll, 10% waste", "6.1 m, check against the seam plan", `${q2.working} (${q2.note})`, q2.qty === 6.1 && q2.note === "Check against the seam plan");
  const q3 = quantity({ category: "levelling and prep", unit: "bag", pack_size: 20, coverage: 1.6, waste_pct: null }, { area: 30, depthMm: 3 });
  push("Levelling compound: 30 m² at 3 mm, 1.6 kg/m²/mm, 20 kg bags", "8 bags", q3.working, q3.qty === 8);
  const q4 = quantity({ category: "adhesive", unit: "pail", pack_size: 15, coverage: 15, waste_pct: null }, { area: 40 });
  push("Adhesive: 40 m² at 15 m² per pail", "3 pails", q4.working, q4.qty === 3);

  return out;
}
