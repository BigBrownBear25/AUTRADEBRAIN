/**
 * Fit check, Find crew score and Find a slot (spec section 6). Pure — no database calls.
 * Callers load jobs, people, bookings, leave and drive times and pass them in.
 */
import { minutes } from "./board";
import { isoWeekday } from "./assignments";
import { jobDays, nextWorkingDays, type WorkWeek } from "./working-days";
import { requiredTickets, ticketStatusForJob, type HazardSetting, type TicketRule, type TicketStatus, type RequiredTicket } from "./tickets";
import { sameDayTravelGap } from "./travel";

export type Level = "good" | "warning" | "clash";
export type Reason = { level: Level; check: string; text: string };

export type RuleJob = {
  id: string; code?: string;
  sector: "domestic" | "commercial";
  crew_size: number; hazards: string[]; extra_tickets: string[];
  main_skill: string | null; other_skills: string[];
  duration_value: number; duration_unit: "hours" | "days";
  start_time: string | null;
  due_by: string | null; due_hard: boolean;
  access_window: { days: number[] };
  locked: boolean;
};
export type RulePerson = {
  id: string; name: string; role: "foreman" | "installer" | "apprentice";
  skills: string[]; tickets: { ticket_type: string; expires_on: string | null }[];
};
export type RuleBooking = { crew_member_id: string; job_id: string; date: string; start: string; end: string };
export type RuleLeave = { crew_member_id: string; from: string; to: string; status: "approved" | "requested" };
export type RuleDependency = { description: string; status: "pending" | "confirmed" | "failed"; blocks_start: boolean; due_date: string | null };

export type RuleContext = {
  today: string;
  week: WorkWeek;
  dayStart: string;
  dayEnd: string;
  hazards: HazardSetting[];
  ticketRules: TicketRule[];
  /** Everyone already on the job (crew_member ids). */
  jobCrew: string[];
  people: RulePerson[];
  bookings: RuleBooking[];
  leave: RuleLeave[];
  dependencies: RuleDependency[];
  /** Minutes from a person's base to the job site. */
  driveFromBase: (personId: string) => number | null;
  /** Minutes from another job's site to this job's site. */
  driveBetweenJobs?: (fromJobId: string) => number | null;
};

const RANK: Record<Level, number> = { good: 0, warning: 1, clash: 2 };
export const worst = (rs: Reason[]): Level => rs.reduce<Level>((w, r) => (RANK[r.level] > RANK[w] ? r.level : w), "good");

/** The job's time block on each day: hours jobs from their start time, day jobs across standard hours. */
export function jobBlock(job: RuleJob, ctx: Pick<RuleContext, "dayStart" | "dayEnd">) {
  if (job.duration_unit === "hours") {
    const s = (job.start_time ?? ctx.dayStart).slice(0, 5);
    const e = minutes(s) + Math.round(job.duration_value * 60);
    return { start: s, end: `${String(Math.floor(e / 60)).padStart(2, "0")}:${String(e % 60).padStart(2, "0")}` };
  }
  return { start: ctx.dayStart.slice(0, 5), end: ctx.dayEnd.slice(0, 5) };
}

const overlaps = (a: { start: string; end: string }, b: { start: string; end: string }) =>
  minutes(a.start) < minutes(b.end) && minutes(b.start) < minutes(a.end);

/** Ticket status for a job. Re-exported so screens use one name. */
export const ticketStatus = ticketStatusForJob;

function holdsTicket(p: RulePerson, t: string) {
  return p.tickets.find((x) => x.ticket_type.toLowerCase() === t.toLowerCase());
}
export function personTicketStatus(p: RulePerson, t: string, today: string, lastDay: string): TicketStatus {
  return ticketStatus(holdsTicket(p, t), today, lastDay);
}

function leaveOn(personId: string, days: string[], leave: RuleLeave[], status: RuleLeave["status"]) {
  return days.filter((d) => leave.some((l) => l.crew_member_id === personId && l.status === status && l.from <= d && d <= l.to));
}
function bookedOn(personId: string, jobId: string, days: string[], block: { start: string; end: string }, bookings: RuleBooking[]) {
  return days.filter((d) => bookings.some((b) => b.crew_member_id === personId && b.job_id !== jobId && b.date === d && overlaps(b, block)));
}
const fmt = (d: string) => new Date(`${d}T00:00:00`).toLocaleDateString("en-AU", { weekday: "short", day: "numeric", month: "short" });
const list = (ds: string[]) => ds.map(fmt).join(", ");

/** fitCheck(job, person, startDate, replacing?) → level (worst reason) and reasons, good ones included. */
export function fitCheck(job: RuleJob, person: RulePerson, startDate: string, ctx: RuleContext, replacing?: string): { level: Level; reasons: Reason[] } {
  const R: Reason[] = [];
  const add = (level: Level, check: string, text: string) => R.push({ level, check, text });
  const days = jobDays(startDate, { value: job.duration_value, unit: job.duration_unit }, ctx.week);
  const last = days[days.length - 1]!;
  const block = jobBlock(job, ctx);
  const crewIds = [...new Set([...ctx.jobCrew.filter((id) => id !== replacing && id !== person.id), person.id])];
  const crew = crewIds.map((id) => ctx.people.find((p) => p.id === id)).filter((p): p is RulePerson => !!p);
  const others = crew.filter((p) => p.id !== person.id);

  if (job.locked) add("clash", "Locked", "Job is locked — unlock it to move");

  // Date
  if (startDate < ctx.today) add("clash", "Date", "Start is in the past");

  // Leave + other bookings
  const approved = leaveOn(person.id, days, ctx.leave, "approved");
  const requested = leaveOn(person.id, days, ctx.leave, "requested");
  const busy = bookedOn(person.id, job.id, days, block, ctx.bookings);
  if (approved.length) add("clash", "Leave", `On leave ${list(approved)}`);
  else if (requested.length) add("warning", "Leave", `Leave requested ${list(requested)}`);
  if (busy.length) add("clash", "Other bookings", `Booked elsewhere ${list(busy)}`);
  if (!approved.length && !requested.length && !busy.length) add("good", "Availability", `Free all ${days.length} day${days.length === 1 ? "" : "s"}`);

  // Working week + access window
  const aw = job.access_window?.days ?? [];
  const outside = days.filter((d) => !ctx.week.workingDays.includes(isoWeekday(d)));
  const outsideNotAllowed = outside.filter((d) => !aw.includes(isoWeekday(d)));
  if (outsideNotAllowed.length) add("warning", "Working week", `Outside the working week: ${list(outsideNotAllowed)}`);
  if (aw.length) {
    const bad = days.filter((d) => !aw.includes(isoWeekday(d)));
    if (bad.length) add("clash", "Access window", `Not an allowed day: ${list(bad)}`);
    else add("good", "Access window", "Inside the access window");
  }

  // Same-day travel
  if (ctx.driveBetweenJobs) {
    for (const d of days) {
      const prev = ctx.bookings
        .filter((b) => b.crew_member_id === person.id && b.job_id !== job.id && b.date === d && minutes(b.end) <= minutes(block.start))
        .sort((a, b) => minutes(b.end) - minutes(a.end))[0];
      if (!prev) continue;
      const drive = ctx.driveBetweenJobs(prev.job_id);
      if (drive == null) continue;
      const g = sameDayTravelGap(prev.end, block.start, drive);
      if (!g.ok) add("warning", "Same-day travel", `${fmt(d)}: ${g.gapMinutes} min gap, ${drive} min drive from previous job`);
    }
  }

  // Skills
  const has = (p: RulePerson, s: string) => p.skills.includes(s);
  if (job.main_skill) {
    if (has(person, job.main_skill)) add("good", "Main skill", `Has ${job.main_skill}`);
    else if (others.some((p) => has(p, job.main_skill!))) add("warning", "Main skill", `No ${job.main_skill}, but someone else on the crew has it`);
    else add("clash", "Main skill", `No ${job.main_skill}, and nobody else on the crew has it`);
  }
  const allSkills = [...new Set([job.main_skill, ...job.other_skills].filter((s): s is string => !!s))];
  const missingOther = job.other_skills.filter((s) => !has(person, s));
  if (missingOther.length) add("warning", "Other skills", `Missing ${missingOther.join(", ")}`);
  if (allSkills.length) add("good", "Skills", `${allSkills.filter((s) => has(person, s)).length}/${allSkills.length} skills`);

  // Tickets
  const req = requiredTickets({ sector: job.sector, crew_size: job.crew_size, hazards: job.hazards, extra_tickets: job.extra_tickets }, ctx.hazards, ctx.ticketRules);
  let ticketIssue = false;
  for (const t of req) {
    if (t.who === "everyone") {
      const st = personTicketStatus(person, t.ticket, ctx.today, last);
      if (st === "missing" || st === "expired") { add("clash", "Tickets", `${t.ticket} ${st}`); ticketIssue = true; }
      else if (st === "expires") { add("warning", "Tickets", `${t.ticket} expires before the job ends`); ticketIssue = true; }
    } else if (!crew.some((p) => ["current", "expires"].includes(personTicketStatus(p, t.ticket, ctx.today, last)))) {
      add("warning", "Tickets", `Nobody on the crew has ${t.ticket}`); ticketIssue = true;
    }
  }
  if (req.length && !ticketIssue) add("good", "Tickets", "Tickets current");

  // Rest of the crew
  for (const o of others) {
    const ob = bookedOn(o.id, job.id, days, block, ctx.bookings);
    const ol = leaveOn(o.id, days, ctx.leave, "approved");
    if (ob.length || ol.length) add("warning", "Rest of the crew", `${o.name} is ${ob.length ? "booked elsewhere" : "on leave"} ${list(ob.length ? ob : ol)}`);
  }

  // Due date
  if (job.due_by && last > job.due_by) add(job.due_hard ? "clash" : "warning", "Due date", `Finishes ${fmt(last)}, after the ${job.due_hard ? "hard" : "preferred"} due date ${fmt(job.due_by)}`);
  else if (job.due_by) add("good", "Due date", `Finishes before ${fmt(job.due_by)}`);

  // Dependencies
  for (const dep of ctx.dependencies) {
    if (dep.status === "failed") add("clash", "Dependencies", `Failed: ${dep.description}`);
    else if (dep.status === "pending" && dep.blocks_start && dep.due_date && dep.due_date > startDate) add("warning", "Dependencies", `Pending until ${fmt(dep.due_date)}: ${dep.description}`);
  }

  // Drive
  const drive = ctx.driveFromBase(person.id);
  if (drive != null) {
    if (drive > 90) add("warning", "Drive", `${drive} min drive from base`);
    else add("good", "Drive", `${drive} min drive`);
  }

  // Crew size
  const current = ctx.jobCrew.filter((id) => id !== replacing);
  if (!current.includes(person.id) && current.length >= job.crew_size) add("warning", "Crew size", "Crew already full, so only the dates move");

  return { level: worst(R), reasons: R };
}

const skillShare = (job: RuleJob, p: RulePerson) => {
  const all = [...new Set([job.main_skill, ...job.other_skills].filter((s): s is string => !!s))];
  return all.length ? all.filter((s) => p.skills.includes(s)).length / all.length : 1;
};

/** Find crew score 0–100 for the job's dates. Busy or on-leave people sort to the bottom. */
export function crewScore(job: RuleJob, person: RulePerson, startDate: string, ctx: RuleContext) {
  const days = jobDays(startDate, { value: job.duration_value, unit: job.duration_unit }, ctx.week);
  const last = days[days.length - 1]!;
  const reasons: string[] = [];
  const share = skillShare(job, person);
  let score = share * 55 + 20;
  reasons.push(`${Math.round(share * 100)}% of skills`);
  const drive = ctx.driveFromBase(person.id);
  if (drive != null) { score += Math.max(0, 1 - drive / 120) * 25; reasons.push(`${drive} min drive`); }
  const req = requiredTickets({ sector: job.sector, crew_size: job.crew_size, hazards: job.hazards, extra_tickets: job.extra_tickets }, ctx.hazards, ctx.ticketRules);
  for (const t of req.filter((t) => t.who === "everyone")) {
    const st = personTicketStatus(person, t.ticket, ctx.today, last);
    if (st !== "current") { score -= 18; reasons.push(`${t.ticket} ${st}`); }
  }
  const crew = ctx.jobCrew.map((id) => ctx.people.find((p) => p.id === id)).filter((p): p is RulePerson => !!p);
  if (person.role === "foreman" && !crew.some((p) => p.role === "foreman")) { score += 8; reasons.push("Job needs a foreman"); }
  const fa = req.find((t) => t.who === "one");
  if (fa && personTicketStatus(person, fa.ticket, ctx.today, last) !== "missing" && !crew.some((p) => holdsTicket(p, fa.ticket))) { score += 6; reasons.push(`Has ${fa.ticket}`); }
  if (person.role === "apprentice") { score -= 6; reasons.push("Apprentice"); }
  const block = jobBlock(job, ctx);
  const busy = bookedOn(person.id, job.id, days, block, ctx.bookings).length > 0 || leaveOn(person.id, days, ctx.leave, "approved").length > 0;
  if (busy) reasons.push("Busy or on leave");
  return { personId: person.id, score: Math.round(Math.max(0, Math.min(100, score))), busy, reasons };
}

export function findCrew(job: RuleJob, startDate: string, ctx: RuleContext, limit = 8) {
  return ctx.people
    .filter((p) => !ctx.jobCrew.includes(p.id))
    .map((p) => crewScore(job, p, startDate, ctx))
    .sort((a, b) => Number(a.busy) - Number(b.busy) || b.score - a.score)
    .slice(0, limit);
}

export type SlotOption = { start: string; days: string[]; team: string[]; averageDrive: number | null; warnings: string[]; notes: string[] };

/** Find a slot: up to 3 options at least 3 working days apart, or the reason nothing fits. */
export function findSlot(job: RuleJob, ctx: RuleContext, horizon = 90): { options: SlotOption[]; reason?: string } {
  const starts = nextWorkingDays(ctx.today, horizon, ctx.week);
  const req: RequiredTicket[] = requiredTickets({ sector: job.sector, crew_size: job.crew_size, hazards: job.hazards, extra_tickets: job.extra_tickets }, ctx.hazards, ctx.ticketRules);
  const everyone = req.filter((t) => t.who === "everyone");
  const oneOf = req.filter((t) => t.who === "one");
  const mainNeed = job.main_skill ? Math.ceil(job.crew_size / 2) : 0;
  const teamScore = (p: RulePerson) => skillShare(job, p) * 50 + (1 - (ctx.driveFromBase(p.id) ?? 0) / 150) * 35 - (p.role === "apprentice" ? 8 : 0);
  const block = jobBlock(job, ctx);
  const options: SlotOption[] = [];
  let lastIdx = -Infinity;

  starts.forEach((start, idx) => {
    if (options.length >= 3 || idx - lastIdx < 3) return;
    const days = jobDays(start, { value: job.duration_value, unit: job.duration_unit }, ctx.week);
    const last = days[days.length - 1]!;
    if (job.due_hard && job.due_by && last > job.due_by) return;
    const holdsAll = (p: RulePerson) => everyone.every((t) => ["current", "expires"].includes(personTicketStatus(p, t.ticket, ctx.today, last)));
    const free = ctx.people
      .filter((p) => !bookedOn(p.id, job.id, days, block, ctx.bookings).length && !leaveOn(p.id, days, ctx.leave, "approved").length && holdsAll(p))
      .sort((a, b) => teamScore(b) - teamScore(a));
    const mains = job.main_skill ? free.filter((p) => p.skills.includes(job.main_skill!)) : [];
    if (mains.length < mainNeed) return;
    const team = mains.slice(0, mainNeed);
    for (const p of free) if (team.length < job.crew_size && !team.includes(p)) team.push(p);
    if (team.length < job.crew_size) return;
    const notes: string[] = [];
    const keepMain = (out: RulePerson) =>
      !job.main_skill || team.filter((p) => p !== out && p.skills.includes(job.main_skill!)).length >= mainNeed;
    const swapIn = (cand: RulePerson, why: string) => {
      const out = [...team].reverse().find((p) => p.role !== "foreman" && keepMain(p)) ?? team[team.length - 1]!;
      team[team.indexOf(out)] = cand;
      notes.push(`Swapped ${out.name} for ${cand.name} (${why})`);
    };
    if (job.crew_size >= 3 && !team.some((p) => p.role === "foreman")) {
      const f = free.find((p) => p.role === "foreman" && !team.includes(p));
      if (!f) return;
      swapIn(f, "crew of 3+ needs a foreman");
    }
    for (const t of oneOf) {
      if (team.some((p) => personTicketStatus(p, t.ticket, ctx.today, last) !== "missing")) continue;
      const fa = free.find((p) => !team.includes(p) && personTicketStatus(p, t.ticket, ctx.today, last) !== "missing");
      if (fa) swapIn(fa, `needs ${t.ticket}`);
    }
    const drives = team.map((p) => ctx.driveFromBase(p.id)).filter((d): d is number => d != null);
    const warnings = team.flatMap((p) => fitCheck(job, p, start, { ...ctx, jobCrew: team.map((x) => x.id) }).reasons.filter((r) => r.level === "warning").map((r) => `${p.name}: ${r.text}`));
    options.push({ start, days, team: team.map((p) => p.id), averageDrive: drives.length ? Math.round(drives.reduce((a, b) => a + b, 0) / drives.length) : null, warnings, notes });
    lastIdx = idx;
  });

  if (options.length) return { options };
  const lastGuess = starts[starts.length - 1] ?? ctx.today;
  const ticketed = ctx.people.filter((p) => everyone.every((t) => ["current", "expires"].includes(personTicketStatus(p, t.ticket, ctx.today, lastGuess))));
  if (ticketed.length < job.crew_size) return { options, reason: `Too few people hold the tickets (${ticketed.length} of ${job.crew_size} needed)` };
  if (job.main_skill && ticketed.filter((p) => p.skills.includes(job.main_skill!)).length < mainNeed) return { options, reason: `Too few with ${job.main_skill} (need ${mainNeed})` };
  if (job.crew_size >= 3 && !ticketed.some((p) => p.role === "foreman")) return { options, reason: "No foreman holds the tickets" };
  return { options, reason: `Enough qualified people, but never free together${job.due_hard && job.due_by ? " before the deadline" : " in the next 90 working days"}` };
}
