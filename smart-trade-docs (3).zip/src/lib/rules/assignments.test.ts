import { describe, expect, it } from "vitest";
import { datesInRange, isValidBlock, presetOf, presetTimes } from "./assignments";

const h = { day_start: "07:00:00", morning_end: "11:30:00", day_end: "15:30:00" };

describe("assignment presets", () => {
  it("builds presets from standard hours", () => {
    expect(presetTimes("full", h)).toEqual({ start: "07:00", end: "15:30" });
    expect(presetTimes("morning", h)).toEqual({ start: "07:00", end: "11:30" });
    expect(presetTimes("afternoon", h)).toEqual({ start: "11:30", end: "15:30" });
  });
  it("recognises presets and custom blocks", () => {
    expect(presetOf("07:00:00", "11:30:00", h)).toBe("morning");
    expect(presetOf("09:00", "10:00", h)).toBe("custom");
  });
  it("rejects end before start", () => {
    expect(isValidBlock("10:00", "09:00")).toBe(false);
    expect(isValidBlock("09:00", "10:00")).toBe(true);
  });
  it("lists working days in a range", () => {
    // 2026-10-09 is a Friday
    expect(datesInRange("2026-10-09", "2026-10-13", [1, 2, 3, 4, 5], true)).toEqual(["2026-10-09", "2026-10-12", "2026-10-13"]);
    expect(datesInRange("2026-10-09", "2026-10-11", [1, 2, 3, 4, 5], false)).toHaveLength(3);
  });
});
