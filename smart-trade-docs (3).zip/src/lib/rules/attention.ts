/** Needs attention (spec section 6). Pure — no database calls. */
import { minutes } from "./board";
import { personTicketStatus, type RuleContext, type RuleJob } from "./fit-check";
import { requiredTickets } from "./tickets";
import { jobDays } from "./working-days";
import { orderByDate, orderFlag } from "./materials";

export type Flag = { level: "red" | "amber"; text: string };
export type AttentionInput = {
  job: RuleJob & { start_date: string | null; status: string };
  ctx: RuleContext;
  crew: string[];
  /** Catalogue fields are optional: free-text materials have none. */
  materials: { status: string; item?: string; ordered_at?: string | null; order_by_date?: string | null; lead_time_days?: number | null; stocked?: boolean | null }[];
  tasks: { label: string; due_date: string | null; done: boolean }[];
};

const daysUntil = (from: string, to: string) =>
  Math.round((Date.UTC(+to.slice(0, 4), +to.slice(5, 7) - 1, +to.slice(8, 10)) - Date.UTC(+from.slice(0, 4), +from.slice(5, 7) - 1, +from.slice(8, 10))) / 86_400_000);

export function needsAttention({ job, ctx, crew, materials, tasks }: AttentionInput): Flag[] {
  if (["complete", "closed"].includes(job.status)) return [];
  const F: Flag[] = [];
  const today = ctx.today;

  if (!job.start_date) {
    if (job.due_by && daysUntil(today, job.due_by) <= 14) F.push({ level: "red", text: `No dates, due in ${daysUntil(today, job.due_by)} days` });
    else F.push({ level: "amber", text: "No dates" });
  }
  if (job.due_by && job.start_date) {
    const days = jobDays(job.start_date, { value: job.duration_value, unit: job.duration_unit }, ctx.week);
    const last = days[days.length - 1]!;
    if (last > job.due_by) F.push({ level: job.due_hard ? "red" : "amber", text: `Finishes after its ${job.due_hard ? "hard" : "preferred"} due date` });
  }
  const startIn = job.start_date ? daysUntil(today, job.start_date) : null;

  if (crew.length < job.crew_size) F.push({ level: startIn != null && startIn <= 10 ? "red" : "amber", text: `Crew short (${crew.length}/${job.crew_size})` });

  if (job.start_date) {
    const days = jobDays(job.start_date, { value: job.duration_value, unit: job.duration_unit }, ctx.week);
    const last = days[days.length - 1]!;
    const mine = ctx.bookings.filter((b) => b.job_id === job.id);
    const names = (id: string) => ctx.people.find((p) => p.id === id)?.name ?? "Someone";
    for (const id of crew) {
      const double = mine.some((b) => b.crew_member_id === id && ctx.bookings.some((o) => o.job_id !== job.id && o.crew_member_id === id && o.date === b.date && minutes(o.start) < minutes(b.end) && minutes(b.start) < minutes(o.end)));
      if (double) F.push({ level: "red", text: `${names(id)} is double-booked` });
      const lv = ctx.leave.filter((l) => l.crew_member_id === id && days.some((d) => l.from <= d && d <= l.to));
      if (lv.some((l) => l.status === "approved")) F.push({ level: "red", text: `${names(id)} is on leave` });
      else if (lv.length) F.push({ level: "amber", text: `${names(id)} has requested leave` });
    }
    const req = requiredTickets({ sector: job.sector, crew_size: job.crew_size, hazards: job.hazards, extra_tickets: job.extra_tickets }, ctx.hazards, ctx.ticketRules);
    const people = crew.map((id) => ctx.people.find((p) => p.id === id)).filter((p) => !!p);
    for (const t of req) {
      if (t.who === "everyone") for (const p of people) {
        const st = personTicketStatus(p, t.ticket, today, last);
        if (st === "missing" || st === "expired") F.push({ level: "red", text: `${p.name}: ${t.ticket} ${st}` });
        else if (st === "expires") F.push({ level: "amber", text: `${p.name}: ${t.ticket} expires during the job` });
      } else if (people.length && !people.some((p) => personTicketStatus(p, t.ticket, today, last) !== "missing")) F.push({ level: "red", text: `Nobody has ${t.ticket}` });
    }
    const skills = [job.main_skill, ...job.other_skills].filter((s): s is string => !!s);
    const missing = skills.filter((s) => !people.some((p) => p.skills.includes(s)));
    if (people.length && missing.length) F.push({ level: "amber", text: `Nobody on the crew has ${missing.join(", ")}` });
    if (startIn != null && startIn <= 5 && materials.some((m) => m.status !== "delivered")) F.push({ level: startIn <= 2 ? "red" : "amber", text: "Materials not delivered" });
    for (const d of ctx.dependencies) if (d.status === "pending" && d.blocks_start && startIn != null && startIn <= 3) F.push({ level: "red", text: `Pending: ${d.description}` });
  }
  // Order-in items not ordered (section 13): amber 3 working days before the order-by date, red on the day.
  for (const m of materials) {
    const ob = orderByDate(job.start_date, m.lead_time_days ?? null, !!m.stocked, ctx.week) ?? m.order_by_date ?? null;
    const f = orderFlag({ item: m.item ?? "materials", status: m.status, ordered_at: m.ordered_at ?? null, order_by: ob }, today, ctx.week);
    if (f) F.push(f);
  }
  const overdue = tasks.filter((t) => !t.done && t.due_date && t.due_date < today);
  if (overdue.length) F.push({ level: "amber", text: `${overdue.length} task${overdue.length === 1 ? "" : "s"} overdue` });
  return F;
}
