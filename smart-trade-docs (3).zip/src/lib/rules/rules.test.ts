import { describe, expect, it } from "vitest";
import { runScenarios } from "./scenarios";
import { driveEstimate, leaveBy, overnight, sameDayTravelGap, utes } from "./travel";
import { jobDays, workingDays } from "./working-days";
import { capacity, skillDemand } from "./capacity";

describe("rules test page scenarios", () => {
  for (const today of ["2026-10-12", "2026-12-24", "2027-02-26"]) {
    it(`all pass from ${today}`, () => {
      for (const s of runScenarios(today)) expect(s.pass, `${s.name}: ${s.actual}`).toBe(true);
    });
  }
});

describe("supporting rules", () => {
  const w = { workingDays: [1, 2, 3, 4, 5], closures: [{ from_date: "2026-10-14", to_date: "2026-10-14", name: "Closed" }] };
  it("working days skip closures", () => {
    expect(workingDays("2026-10-12", "2026-10-16", w)).toEqual(["2026-10-12", "2026-10-13", "2026-10-15", "2026-10-16"]);
    expect(jobDays("2026-10-13", { value: 3, unit: "days" }, w)).toEqual(["2026-10-13", "2026-10-15", "2026-10-16"]);
    expect(jobDays("2026-10-13", { value: 2, unit: "hours" }, w)).toEqual(["2026-10-13"]);
  });
  it("travel", () => {
    expect(driveEstimate({ lat: 0, lng: 0 }, { lat: 0, lng: 0 }, 75).minutes).toBe(5);
    expect(leaveBy("07:00", 40, 10)).toBe("06:10");
    expect(utes(3)).toBe(2);
    expect(overnight(150, 3, 120)).toEqual({ overnight: true, nights: 2, trips: 1 });
    expect(sameDayTravelGap("11:30", "11:45", 30).ok).toBe(false);
  });
  it("capacity", () => {
    const c = capacity({ people: ["a", "b"], days: ["2026-10-12", "2026-10-13"], dayStart: "07:00", dayEnd: "15:00", approvedLeave: [{ crew_member_id: "a", date: "2026-10-12" }], bookings: [{ crew_member_id: "b", date: "2026-10-12", start: "07:00", end: "15:00" }] });
    expect(c.availableCrewDays).toBe(3);
    expect(c.freeCrewDays).toBe(2);
    expect(skillDemand(8, 10).level).toBe("tight");
  });
});

import { firstFreeTime, planPlacement } from "./placing";
describe("placing", () => {
  const base = { crewSize: 2, days: ["2026-10-12"], block: { start: "07:00", end: "15:30" } };
  it("modes", () => {
    expect(planPlacement({ ...base, currentCrew: ["a"], target: "a" }).mode).toBe("move");
    expect(planPlacement({ ...base, currentCrew: ["a", "b"], target: "c", from: "b" }).crew).toEqual(["a", "c"]);
    expect(planPlacement({ ...base, currentCrew: ["a"], target: "c" }).crew).toEqual(["a", "c"]);
    expect(planPlacement({ ...base, currentCrew: ["a", "b"], target: "c" }).mode).toBe("dates-only");
  });
  it("first free time", () => {
    expect(firstFreeTime([{ start: "07:00", end: "09:00" }], "07:00", "15:30", 60)).toBe("09:00");
    expect(firstFreeTime([], "07:00", "15:30", 60)).toBe("07:00");
  });
});
