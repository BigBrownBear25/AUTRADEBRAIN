import { describe, expect, it } from "vitest";
import { sessionEnd } from "./sessions";
import { reviewDue, staleSignIn } from "./access-review";
import { describeAudit, toCsv, type AuditRow } from "./activity";

const now = Date.parse("2026-10-15T10:00:00Z");
const s = (ms: number) => Math.floor((now - ms) / 1000);

describe("sessionEnd", () => {
  it("office: 60 minutes idle ends it", () => {
    expect(sessionEnd({ office: true, amr: [{ method: "totp", timestamp: s(60_000) }], lastActivity: now - 61 * 60_000, now })).not.toBeNull();
    expect(sessionEnd({ office: true, amr: [{ method: "totp", timestamp: s(60_000) }], lastActivity: now - 59 * 60_000, now })).toBeNull();
  });
  it("office: 12 hours since two-factor ends it", () => {
    expect(sessionEnd({ office: true, amr: [{ method: "totp", timestamp: s(13 * 3600_000) }], lastActivity: now, now })).not.toBeNull();
  });
  it("field: 30 days", () => {
    expect(sessionEnd({ office: false, amr: [{ method: "password", timestamp: s(29 * 86_400_000) }], lastActivity: now - 10 * 86_400_000, now })).toBeNull();
    expect(sessionEnd({ office: false, amr: [{ method: "password", timestamp: s(31 * 86_400_000) }], lastActivity: now, now })).not.toBeNull();
  });
});

describe("access review", () => {
  const n = new Date(now);
  it("due after 90 days or never", () => {
    expect(reviewDue(null, n)).toBe(true);
    expect(reviewDue("2026-08-01T00:00:00Z", n)).toBe(false);
    expect(reviewDue("2026-07-01T00:00:00Z", n)).toBe(true);
  });
  it("flags 60 days without sign-in, not invites", () => {
    expect(staleSignIn({ status: "active", last_sign_in_at: "2026-08-01T00:00:00Z" }, n)).toBe(true);
    expect(staleSignIn({ status: "active", last_sign_in_at: "2026-10-01T00:00:00Z" }, n)).toBe(false);
    expect(staleSignIn({ status: "invited", last_sign_in_at: null }, n)).toBe(false);
  });
});

describe("describeAudit", () => {
  const l = { person: () => "Sam", jobCode: (id: string | null | undefined) => (id === "j" ? "FZ-1052" : null) };
  it("a moved booking with a reason", () => {
    const r: AuditRow = { id: 1, actor_user_id: "u", action: "update", table_name: "assignments", row_id: "a", before: { job_id: "j", date: "2026-10-14" }, after: { job_id: "j", date: "2026-10-15" }, at: "", reason: "builder delay" };
    expect(describeAudit(r, l)).toBe("Sam moved FZ-1052 to Thursday: builder delay");
  });
  it("csv quotes", () => { expect(toCsv([["a", 'b"c', "d,e"]])).toBe('a,"b""c","d,e"'); });
});
