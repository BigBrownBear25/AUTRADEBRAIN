import { describe, expect, it } from "vitest";
import { NO_CLUES, decideCapture, matchJobs, parseSpokenCode, type Clues, type MatchJob } from "./jobMatch";

const J = (o: Partial<MatchJob> & { id: string; code: string }): MatchJob => ({
  name: "Job", client_name: null, builder_company: null, address: null, suburb: null, status: "scheduled", booked_dates: [], crew_ids: [], ...o,
});
const C = (o: Partial<Clues>): Clues => ({ ...NO_CLUES, ...o });
const ctx = { personCrewIds: [], recentJobIds: [] };

describe("parseSpokenCode", () => {
  it("reads spoken and typed codes", () => {
    expect(parseSpokenCode("F Z ten fifty-two")).toEqual({ letters: "FZ", digits: "1052" });
    expect(parseSpokenCode("fz1052")).toEqual({ letters: "FZ", digits: "1052" });
    expect(parseSpokenCode("eff zed one oh five two")).toEqual({ letters: "FZ", digits: "1052" });
    expect(parseSpokenCode("one thousand and fifty two")).toEqual({ letters: "", digits: "1052" });
  });
});

describe("matchJobs", () => {
  const jobs = [
    J({ id: "a", code: "FZ-1052", name: "Patel hybrid", client_name: "Anita Patel", builder_company: "Hume Builders", address: "14 Kurrajong St", suburb: "Thurgoona" }),
    J({ id: "b", code: "FZ-1053", name: "Lot 12 carpet", client_name: "Ben Ng", builder_company: "Hume Builders", address: "Lot 12 Bluegum Dr", suburb: "Thurgoona" }),
    J({ id: "c", code: "FZ-1001", name: "Old", status: "closed", address: "14 Kurrajong St", suburb: "Thurgoona" }),
  ];
  it("spoken code is confident", () => {
    const r = matchJobs(jobs, C({ job_codes: ["F Z ten fifty-two"] }), ctx);
    expect(r.kind).toBe("confident");
    expect(r.kind === "confident" && r.top.jobId).toBe("a");
  });
  it("same builder, same suburb → ask", () => {
    expect(matchJobs(jobs, C({ builder_names: ["Hume"], suburbs: ["Thurgoona"] }), ctx).kind).toBe("ask");
  });
  it("street + suburb + client is confident; closed jobs only by code", () => {
    const r = matchJobs(jobs, C({ streets: ["Kurrajong St"], suburbs: ["Thurgoona"], client_names: ["Mrs Patel"] }), ctx);
    expect(r.kind === "confident" && r.top.jobId).toBe("a");
    expect(r.candidates.find((x) => x.jobId === "c")).toBeUndefined();
    expect(matchJobs(jobs, C({ job_codes: ["FZ-1001"] }), ctx).kind).toBe("confident");
  });
  it("shared surname → ask; nothing → none", () => {
    const two = [J({ id: "x", code: "FZ-1", client_name: "Sue Smith" }), J({ id: "y", code: "FZ-2", client_name: "Tom Smith" })];
    expect(matchJobs(two, C({ client_names: ["Smith"] }), ctx).kind).toBe("ask");
    expect(matchJobs(jobs, C({ flooring: ["carpet"] }), ctx).kind).toBe("none");
  });
});

describe("decideCapture when pinned", () => {
  const jobs = [
    J({ id: "a", code: "FZ-1052", name: "Patel hybrid", client_name: "Anita Patel", address: "14 Kurrajong St", suburb: "Thurgoona" }),
    J({ id: "b", code: "FZ-1060", name: "Smith timber", client_name: "Sue Smith", address: "3 Murray St", suburb: "Wodonga" }),
  ];
  const o = { office: true, personCrewIds: [], recentJobIds: [], pinnedJobId: "a", todaysJobIds: [] };
  it("another job's code → asks with both, nothing preselected", () => {
    const d = decideCapture(jobs, C({ job_codes: ["FZ-1060"] }), o);
    expect(d.how).toBe("ask"); expect(d.preselected).toBeNull(); expect(d.scored.map((x) => x.jobId)).toEqual(["a", "b"]);
  });
  it("another job scoring 60+ → asks", () => {
    expect(decideCapture(jobs, C({ streets: ["Murray St"], suburbs: ["Wodonga"] }), o).how).toBe("ask");
  });
  it("no clues → the pinned job", () => {
    const d = decideCapture(jobs, NO_CLUES, o);
    expect(d.how).toBe("pinned"); expect(d.preselected).toBe("a");
  });
});
