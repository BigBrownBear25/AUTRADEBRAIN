/**
 * Photo reading rules (B8, spec section 8 vision-tag). Claude only reads the photo;
 * these decide what the readings mean for the job. Pure functions.
 */
export const PHOTO_TAGS = ["subfloor", "moisture reading", "damage", "progress", "completed work", "delivery docket", "ticket card", "plan or drawing", "other"] as const;
export type PhotoTag = (typeof PHOTO_TAGS)[number];
export type Confidence = "high" | "medium" | "low";

export type PhotoReadings = {
  moisture: { value: number; unit: string; confidence: Confidence } | null;
  docket: { items: { item: string; qty: number | null; unit: string }[]; confidence: Confidence } | null;
  ticket: { name: string; ticket_type: string; expires_on: string | null; confidence: Confidence } | null;
  tag_confidence: Confidence;
};

const CONF = new Set(["high", "medium", "low"]);
const conf = (c: unknown): Confidence => (CONF.has(String(c)) ? (c as Confidence) : "low");

/** Cleans Claude's answer: unknown tags dropped, blanks become null. */
export function normalisePhoto(raw: any): { tags: PhotoTag[]; readings: PhotoReadings } {
  const tags = [...new Set(((raw?.tags ?? []) as unknown[]).map((t) => String(t).toLowerCase().trim()).filter((t): t is PhotoTag => (PHOTO_TAGS as readonly string[]).includes(t)))];
  const m = raw?.moisture, d = raw?.docket, t = raw?.ticket;
  const mv = Number(m?.value);
  const readings: PhotoReadings = {
    moisture: m && m.value !== "" && m.value != null && Number.isFinite(mv) ? { value: mv, unit: String(m.unit ?? "").trim(), confidence: conf(m.confidence) } : null,
    docket: d && Array.isArray(d.items) && d.items.length ? {
      items: d.items.map((i: any) => ({ item: String(i?.item ?? "").trim(), qty: i?.qty === "" || i?.qty == null || !Number.isFinite(Number(i.qty)) ? null : Number(i.qty), unit: String(i?.unit ?? "").trim() })).filter((i: { item: string }) => i.item),
      confidence: conf(d.confidence),
    } : null,
    ticket: t && String(t.name ?? "").trim() && String(t.ticket_type ?? "").trim() ? {
      name: String(t.name).trim(), ticket_type: String(t.ticket_type).trim(),
      expires_on: /^\d{4}-\d{2}-\d{2}$/.test(String(t.expires_on ?? "")) ? String(t.expires_on) : null, confidence: conf(t.confidence),
    } : null,
    tag_confidence: conf(raw?.tag_confidence),
  };
  if (readings.docket && !readings.docket.items.length) readings.docket = null;
  return { tags: tags.length ? tags : ["other"], readings };
}

/** A reading is only acted on when Claude isn't unsure of it. */
export const usable = (c: Confidence) => c !== "low";

export type MoistureLimits = Record<string, { max: number; unit?: string }>;
const unitKey = (u: string) => u.toLowerCase().replace(/\s+/g, "");

/**
 * The limit for the job's flooring (case-insensitive) and whether the reading is over it.
 * Units must match when the limit has one; otherwise there's nothing to compare.
 */
export function moistureCheck(reading: { value: number; unit: string }, flooring: string | null, limits: MoistureLimits) {
  const key = Object.keys(limits ?? {}).find((k) => k.trim().toLowerCase() === (flooring ?? "").trim().toLowerCase());
  const lim = key ? limits[key] : undefined;
  if (!lim || !Number.isFinite(Number(lim.max))) return { known: false as const, over: false, reason: flooring ? `No moisture limit set for ${flooring}.` : "The job has no flooring type." };
  if (lim.unit && reading.unit && unitKey(lim.unit) !== unitKey(reading.unit)) return { known: false as const, over: false, reason: `The reading is in ${reading.unit} but the ${key} limit is in ${lim.unit}.` };
  return { known: true as const, over: reading.value > Number(lim.max), max: Number(lim.max), unit: lim.unit ?? reading.unit, flooring: key! };
}

const words = (s: string) => s.toLowerCase().replace(/[^a-z0-9 ]/g, " ").split(/\s+/).filter((w) => w.length > 2);

/**
 * Docket lines to the job's materials not yet delivered: a material matches a line when at least
 * half of its words appear in the line (and at least one). Each material is matched once, best line first.
 */
export function matchDocket<M extends { id: string; item: string; status: string }>(lines: { item: string }[], materials: M[]) {
  const out: { material: M; line: string; score: number }[] = [];
  const used = new Set<string>();
  for (const m of materials) {
    if (m.status === "delivered") continue;
    const mw = words(m.item);
    if (!mw.length) continue;
    let best: { line: string; score: number } | null = null;
    for (const l of lines) {
      const lw = new Set(words(l.item));
      const hit = mw.filter((w) => lw.has(w)).length;
      const score = hit / mw.length;
      if (hit >= 1 && score >= 0.5 && (!best || score > best.score)) best = { line: l.item, score };
    }
    if (best && !used.has(m.id)) { used.add(m.id); out.push({ material: m, ...best }); }
  }
  return out;
}

/** Short text for a reading, shown beside the photo. */
export function readingLines(r: Partial<PhotoReadings> | null | undefined): string[] {
  if (!r) return [];
  const out: string[] = [];
  if (r.moisture) out.push(`Moisture ${r.moisture.value}${r.moisture.unit ? ` ${r.moisture.unit}` : ""} (${r.moisture.confidence})`);
  if (r.docket) out.push(`Docket: ${r.docket.items.map((i) => `${i.item}${i.qty != null ? ` × ${i.qty}${i.unit ? ` ${i.unit}` : ""}` : ""}`).join(", ")} (${r.docket.confidence})`);
  if (r.ticket) out.push(`Ticket: ${r.ticket.name}, ${r.ticket.ticket_type}${r.ticket.expires_on ? `, expires ${r.ticket.expires_on}` : ""} (${r.ticket.confidence})`);
  return out;
}
