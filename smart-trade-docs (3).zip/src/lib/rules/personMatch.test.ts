import { describe, expect, it } from "vitest";
import { matchPeople } from "./personMatch";

const crew = [
  { id: "1", name: "Sam Hill", role: "installer", base_suburb: "Wodonga" },
  { id: "2", name: "Sam Ortiz", role: "foreman", base_suburb: "Albury" },
  { id: "3", name: "Samantha Lee", role: "installer", base_suburb: "Wangaratta" },
  { id: "4", name: "Jo Sam", role: "apprentice", base_suburb: "Corowa" },
];

describe("matchPeople", () => {
  it("two people called Sam: lists both, picks none", () => {
    const r = matchPeople("sam", crew.slice(0, 2));
    expect(r.kind).toBe("many");
    if (r.kind === "many") expect(r.people.map((p) => p.id)).toEqual(["1", "2"]);
  });
  it("Sam and Samantha: Sam matches only Sam", () => {
    const r = matchPeople("Sam", [crew[0]!, crew[2]!]);
    expect(r).toEqual({ kind: "one", person: crew[0] });
    expect(matchPeople("samantha", [crew[0]!, crew[2]!])).toEqual({ kind: "one", person: crew[2] });
  });
  it("full name picks exactly that person", () => {
    expect(matchPeople("  SAM  ortiz ", crew)).toEqual({ kind: "one", person: crew[1] });
  });
  it("surname matches", () => {
    const r = matchPeople("Sam", crew);
    expect(r.kind === "many" && r.people.map((p) => p.id)).toEqual(["1", "2", "4"]);
    expect(matchPeople("lee", crew)).toEqual({ kind: "one", person: crew[2] });
  });
  it("no match says so", () => {
    expect(matchPeople("Sam", [crew[2]!])).toEqual({ kind: "none", message: "I couldn't find anyone called Sam." });
  });
});
