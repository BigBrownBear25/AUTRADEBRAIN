/** Pure assignment helpers: block presets and date ranges. No database calls. */

export type StandardHours = { day_start: string; morning_end: string; day_end: string };
export type BlockPreset = "full" | "morning" | "afternoon" | "custom";

const hhmm = (t: string) => t.slice(0, 5);

/** Start/end times for a preset, from the workspace's standard hours. */
export function presetTimes(preset: Exclude<BlockPreset, "custom">, h: StandardHours): { start: string; end: string } {
  if (preset === "morning") return { start: hhmm(h.day_start), end: hhmm(h.morning_end) };
  if (preset === "afternoon") return { start: hhmm(h.morning_end), end: hhmm(h.day_end) };
  return { start: hhmm(h.day_start), end: hhmm(h.day_end) };
}

/** Names a stored block as a preset when it matches one. */
export function presetOf(start: string, end: string, h: StandardHours): BlockPreset {
  for (const p of ["full", "morning", "afternoon"] as const) {
    const t = presetTimes(p, h);
    if (t.start === hhmm(start) && t.end === hhmm(end)) return p;
  }
  return "custom";
}

export function isValidBlock(start: string, end: string): boolean {
  return /^\d\d:\d\d/.test(start) && /^\d\d:\d\d/.test(end) && hhmm(end) > hhmm(start);
}

/** ISO weekday 1 (Mon) … 7 (Sun) for a YYYY-MM-DD date. */
export function isoWeekday(date: string): number {
  const d = new Date(`${date}T00:00:00Z`).getUTCDay();
  return d === 0 ? 7 : d;
}

/**
 * Dates from `from` to `to` inclusive. With `onlyWorkingDays`, keeps days in the working week
 * (closures and public holidays are applied by the working-days rule in a later step).
 */
export function datesInRange(from: string, to: string, workingDays: number[], onlyWorkingDays: boolean): string[] {
  const out: string[] = [];
  const d = new Date(`${from}T00:00:00Z`);
  const end = new Date(`${to}T00:00:00Z`);
  if (Number.isNaN(d.getTime()) || Number.isNaN(end.getTime())) return out;
  for (let i = 0; d <= end && i < 366; i++) {
    const iso = d.toISOString().slice(0, 10);
    if (!onlyWorkingDays || workingDays.includes(isoWeekday(iso))) out.push(iso);
    d.setUTCDate(d.getUTCDate() + 1);
  }
  return out;
}
