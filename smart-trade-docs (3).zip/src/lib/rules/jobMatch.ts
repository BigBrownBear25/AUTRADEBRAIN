/**
 * Matching Brain bar words to the right job (spec section 6 "Matching to the right job").
 * Claude only extracts clues; this scores open jobs; the person confirms on the card.
 * Never falls back to a closest guess: below the confidence bar the card asks.
 */
export type Clues = {
  job_codes: string[]; client_names: string[]; builder_names: string[]; streets: string[]; suburbs: string[];
  lot_units: string[]; job_words: string[]; people: string[]; dates: string[]; flooring: string[];
};
export const NO_CLUES: Clues = { job_codes: [], client_names: [], builder_names: [], streets: [], suburbs: [], lot_units: [], job_words: [], people: [], dates: [], flooring: [] };

export type MatchJob = {
  id: string; code: string; name: string; client_name: string | null; builder_company: string | null;
  address: string | null; suburb: string | null; status: string; booked_dates: string[]; crew_ids: string[];
};
export type MatchCtx = { personCrewIds: string[]; recentJobIds: string[] };
export type Scored = { jobId: string; score: number; matchedOn: string[] };
export type MatchResult =
  | { kind: "confident"; top: Scored; candidates: Scored[] }
  | { kind: "ask"; candidates: Scored[] }
  | { kind: "none"; candidates: [] };

export const POINTS = { code: 100, streetSuburb: 60, street: 45, client: 40, builder: 25, lot: 25, date: 20, suburb: 15, words: 15, assigned: 15, recent: 10 } as const;
const CLOSED = new Set(["complete", "closed"]);

const low = (s: string | null | undefined) => (s ?? "").toLowerCase().replace(/[^a-z0-9 ]+/g, " ").replace(/\s+/g, " ").trim();
const STREET_TYPES = /\b(st|street|rd|road|ave|avenue|ct|court|cres|crescent|dr|drive|pl|place|pde|parade|tce|terrace|way|lane|ln|cl|close|hwy|highway|bvd|boulevard|gr|grove)\b/g;
const streetCore = (s: string) => low(s).replace(/^\d+[a-z]?\s+/, "").replace(/\b(lot|unit)\s*\d+[a-z]?\b/g, "").replace(STREET_TYPES, "").trim();
const TITLES = /\b(mrs|mr|ms|miss|dr)\b/g;
const surname = (s: string) => { const w = low(s).replace(TITLES, "").trim().split(" ").filter(Boolean); return w[w.length - 1] ?? ""; };
const BUILDER_NOISE = /\b(pty|ltd|builders?|building|homes?|construction|constructions|group|the|and)\b/g;
const builderCore = (s: string) => low(s).replace(BUILDER_NOISE, " ").replace(/\s+/g, " ").trim();
const STOP = new Set(["the", "job", "and", "for", "at", "on", "of", "a", "an", "to", "in", "new", "house", "site"]);

// ---------- spoken job codes ----------
const LETTER_NAMES: Record<string, string> = { ef: "F", eff: "F", zed: "Z", zee: "Z", ess: "S", em: "M", en: "N", ar: "R", el: "L", bee: "B", see: "C", dee: "D", gee: "G", jay: "J", kay: "K", pee: "P", tee: "T", vee: "V", ex: "X", why: "Y", aitch: "H" };
const UNITS: Record<string, number> = { zero: 0, oh: 0, o: 0, nought: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9 };
const TEENS: Record<string, number> = { ten: 10, eleven: 11, twelve: 12, thirteen: 13, fourteen: 14, fifteen: 15, sixteen: 16, seventeen: 17, eighteen: 18, nineteen: 19 };
const TENS: Record<string, number> = { twenty: 20, thirty: 30, forty: 40, fifty: 50, sixty: 60, seventy: 70, eighty: 80, ninety: 90 };

/** "F Z ten fifty-two", "fz1052", "FZ 1052", "eff zed one oh five two" → { letters: "FZ", digits: "1052" }. */
export function parseSpokenCode(said: string): { letters: string; digits: string } | null {
  const toks = said.toLowerCase().replace(/[-–]/g, " ").replace(/([a-z])(\d)/g, "$1 $2").split(/[\s,.]+/).filter(Boolean);
  let letters = ""; let digits = ""; let i = 0;
  for (; i < toks.length; i++) {
    const t = toks[i]!;
    if (/^[a-z]$/.test(t) && !(t === "o" && letters)) letters += t.toUpperCase();
    else if (LETTER_NAMES[t]) letters += LETTER_NAMES[t];
    else if (i === 0 && /^[a-z]{2,3}$/.test(t) && !(t in UNITS) && !(t in TEENS) && !(t in TENS) && !["job", "the"].includes(t)) letters += t.toUpperCase();
    else break;
  }
  let group: number | null = null; let kind: "unit" | "teen" | "tens" | "big" | null = null;
  const flush = () => { if (group != null) digits += String(group); group = null; kind = null; };
  for (; i < toks.length; i++) {
    const t = toks[i]!;
    if (/^\d+$/.test(t)) { flush(); digits += t; continue; }
    if (t === "hundred" || t === "thousand") { const m = t === "hundred" ? 100 : 1000; group = (group ?? 1) * m; kind = "big"; continue; }
    if (t === "and") continue;
    if (t in TENS) { if (kind === "big") { group = group! + TENS[t]!; kind = "big"; } else { flush(); group = TENS[t]!; kind = "tens"; } continue; }
    if (t in TEENS) { if (kind === "big") group = group! + TEENS[t]!; else { flush(); group = TEENS[t]!; kind = "teen"; } continue; }
    if (t in UNITS) {
      if (kind === "tens" && group! % 10 === 0) { group = group! + UNITS[t]!; kind = "unit"; }
      else if (kind === "big") { group = group! + UNITS[t]!; }
      else { flush(); group = UNITS[t]!; kind = "unit"; }
      continue;
    }
    break;
  }
  flush();
  if (!digits) return null;
  return { letters, digits };
}

function codeMatches(clue: string, code: string): boolean {
  const p = parseSpokenCode(clue);
  if (!p) return false;
  const m = code.toUpperCase().match(/^([A-Z]+)-?(\d+)$/);
  if (!m) return false;
  return p.digits === m[2] && (!p.letters || p.letters === m[1]);
}

// ---------- scoring ----------
export function scoreJob(job: MatchJob, c: Clues, ctx: MatchCtx): Scored {
  const on: string[] = []; let s = 0;
  if (c.job_codes.some((x) => codeMatches(x, job.code))) { s += POINTS.code; on.push(job.code); }
  if (CLOSED.has(job.status)) return { jobId: job.id, score: s, matchedOn: on };

  const addr = low(job.address); const sub = low(job.suburb);
  const street = c.streets.find((x) => { const k = streetCore(x); return k.length >= 3 && addr.includes(k); });
  const suburbHit = c.suburbs.find((x) => low(x) && (low(x) === sub || addr.includes(low(x))));
  if (street && suburbHit) { s += POINTS.streetSuburb; on.push(`${street}, ${suburbHit}`); }
  else if (street && !c.suburbs.length) { s += POINTS.street; on.push(street); }
  else if (suburbHit && !street) { s += POINTS.suburb; on.push(suburbHit); }

  const cs = surname(job.client_name ?? "");
  const client = c.client_names.find((x) => cs && surname(x) === cs);
  if (client) { s += POINTS.client; on.push(client); }

  const bc = builderCore(job.builder_company ?? "");
  const builder = c.builder_names.find((x) => { const k = builderCore(x); return k.length >= 3 && bc && (bc.includes(k) || k.includes(bc)); });
  if (builder) { s += POINTS.builder; on.push(builder); }

  const lot = c.lot_units.find((x) => { const m = low(x).match(/(lot|unit)\s*(\d+[a-z]?)/); return !!m && new RegExp(`\\b${m[1]}\\s*${m[2]}\\b`).test(addr); });
  if (lot) { s += POINTS.lot; on.push(lot); }

  const date = c.dates.find((d) => job.booked_dates.includes(d));
  if (date) { s += POINTS.date; on.push(`booked ${date}`); }

  const nameWords = new Set(low(job.name).split(" ").filter((w) => w.length >= 3 && !STOP.has(w)));
  const word = c.job_words.map(low).find((w) => w.length >= 3 && !STOP.has(w) && nameWords.has(w));
  if (word) { s += POINTS.words; on.push(`"${word}"`); }

  if (ctx.personCrewIds.some((id) => job.crew_ids.includes(id))) { s += POINTS.assigned; on.push("their job"); }
  if (ctx.recentJobIds.includes(job.id)) { s += POINTS.recent; on.push("opened recently"); }
  return { jobId: job.id, score: s, matchedOn: on };
}

/** Confident = top score at least 60 and at least 30 ahead of the next. Otherwise ask with up to 3. */
export function matchJobs(jobs: MatchJob[], c: Clues, ctx: MatchCtx): MatchResult {
  const scored = jobs.map((j) => scoreJob(j, c, ctx)).filter((x) => x.score > 0).sort((a, b) => b.score - a.score);
  if (!scored.length) return { kind: "none", candidates: [] };
  const [top, next] = scored;
  if (top!.score >= 60 && top!.score - (next?.score ?? 0) >= 30) return { kind: "confident", top: top!, candidates: scored.slice(0, 3) };
  return { kind: "ask", candidates: scored.slice(0, 3) };
}

/** True when the words point at a job (so a field user's single booking today isn't assumed). */
export const cluesPointSomewhere = (c: Clues) =>
  [c.job_codes, c.client_names, c.builder_names, c.streets, c.suburbs, c.lot_units, c.job_words].some((a) => a.some((x) => x.trim()));

export type Decision = { how: "pinned" | "today" | "confident" | "ask" | "none"; scored: Scored[]; preselected: string | null; notice: string | null };

/**
 * The whole Brain bar decision: pinned job first; a field user's only booking today when nothing points
 * elsewhere; otherwise the scores. A field user naming a code that isn't on their list hears "I can only see your jobs."
 */
export function decideCapture(jobs: MatchJob[], c: Clues, o: { office: boolean; personCrewIds: string[]; recentJobIds: string[]; pinnedJobId: string | null; todaysJobIds: string[] }): Decision {
  if (o.pinnedJobId && jobs.some((j) => j.id === o.pinnedJobId)) {
    const pin: Scored = { jobId: o.pinnedJobId, score: 100, matchedOn: ["opened from this job"] };
    // The words point at a different job (its code, or 60+ points): show both side by side, preselect nothing.
    const other = jobs.filter((j) => j.id !== o.pinnedJobId).map((j) => scoreJob(j, c, { personCrewIds: o.personCrewIds, recentJobIds: o.recentJobIds }))
      .filter((x) => x.score >= 60 || x.matchedOn.some((m) => /^[A-Z]+-\d+$/.test(m))).sort((a, b) => b.score - a.score)[0];
    if (other) return { how: "ask", scored: [pin, other], preselected: null, notice: null };
    return { how: "pinned", scored: [pin], preselected: o.pinnedJobId, notice: null };
  }
  if (!o.office && !cluesPointSomewhere(c) && o.todaysJobIds.length === 1) {
    return { how: "today", scored: [{ jobId: o.todaysJobIds[0]!, score: 0, matchedOn: ["your only booking today"] }], preselected: o.todaysJobIds[0]!, notice: null };
  }
  const r = matchJobs(jobs, c, { personCrewIds: o.personCrewIds, recentJobIds: o.recentJobIds });
  const namedCode = c.job_codes.some((x) => parseSpokenCode(x));
  const codeHit = r.candidates.some((x) => x.matchedOn.some((m) => /^[A-Z]+-\d+$/.test(m)));
  const notice = namedCode && !codeHit && !o.office ? "I can only see your jobs." : null;
  if (r.kind === "confident") return { how: "confident", scored: r.candidates, preselected: r.top.jobId, notice };
  if (r.kind === "ask") return { how: "ask", scored: r.candidates, preselected: null, notice };
  return { how: "none", scored: [], preselected: null, notice: notice ?? "I couldn't find a job for that." };
}
