/** Morning brief rules. Pure — no database calls. */
import { minutes } from "./board";
import { leaveClashes, type LeaveRow, type BookingRow } from "./leave";
import type { RuleLeave } from "./fit-check";

export type BriefBooking = BookingRow & { id: string };
export type LeaveClash = {
  key: string;
  leave: LeaveRow & { created_at: string };
  jobId: string;
  bookings: BriefBooking[];
  /** True when the leave was entered since the brief's "overnight" cut-off. */
  overnight: boolean;
};

/** "Overnight" starts at the end of the previous working day (local time). */
export function overnightSince(today: string, prevWorkingDay: string, dayEnd: string): string {
  void today;
  return new Date(`${prevWorkingDay}T${dayEnd.slice(0, 5)}:00`).toISOString();
}

/**
 * Leave (requested or approved) that clashes with bookings in the brief window, grouped per leave and job.
 * Overnight entries come first.
 */
export function leaveClashesInWindow(
  leave: (LeaveRow & { created_at: string })[], bookings: BriefBooking[], from: string, to: string, since: string,
): LeaveClash[] {
  const out: LeaveClash[] = [];
  const inWindow = bookings.filter((b) => b.date >= from && b.date <= to);
  for (const l of leave) {
    if (l.status === "declined" || l.to_date < from || l.from_date > to) continue;
    const hits = leaveClashes(l, inWindow) as BriefBooking[];
    const byJob = new Map<string, BriefBooking[]>();
    for (const b of hits) byJob.set(b.job_id, [...(byJob.get(b.job_id) ?? []), b]);
    for (const [jobId, bs] of byJob) {
      out.push({ key: `${l.id}:${jobId}`, leave: l, jobId, bookings: bs.sort((a, b) => a.date.localeCompare(b.date)), overnight: l.created_at >= since });
    }
  }
  return out.sort((a, b) => Number(b.overnight) - Number(a.overnight) || a.bookings[0]!.date.localeCompare(b.bookings[0]!.date));
}

/** A person is free for a swap when they have no overlapping booking and no (non-declined) leave on every clash block. */
export function freeForBlocks(personId: string, blocks: BriefBooking[], bookings: BookingRow[], leave: RuleLeave[]): boolean {
  return blocks.every((blk) =>
    !leave.some((l) => l.crew_member_id === personId && l.from <= blk.date && blk.date <= l.to) &&
    !bookings.some((b) => b.crew_member_id === personId && b.date === blk.date &&
      minutes(b.start) < minutes(blk.end) && minutes(blk.start) < minutes(b.end)));
}

/** Rows for place_job after swapping one person for another on the given booking ids. */
export function swapRows<T extends { id: string; crew_member_id: string }>(rows: T[], bookingIds: string[], to: string): T[] {
  const ids = new Set(bookingIds);
  return rows.map((r) => (ids.has(r.id) ? { ...r, crew_member_id: to } : r));
}

// ---------- Step 18b: Today, Since you last looked, Sort first, summary ----------
export type BriefToday = { crewWorking: number; jobsStarting: number; away: { name: string; type: string }[]; utilisationPct: number };
export type BriefChange = { kind: string; label: string; count: number; to: "/crew" | "/jobs" | "/messages" };
export type BriefItemStatus = "open" | "applied" | "opened" | "dismissed";
export type BriefItem = {
  key: string; job_id: string; code: string; name: string; suburb: string | null; level: "red" | "amber";
  problem: string; reasons: string[]; start: string | null; priority: number;
  fix: { proposal_id: string; title: string } | null; status: BriefItemStatus;
};

/** Sort first: red before amber, then soonest start (undated last), then priority (P1 first). Up to `max`. */
export function rankBriefItems<T extends Pick<BriefItem, "level" | "start" | "priority">>(items: T[], max = 5): T[] {
  return [...items].sort((a, b) =>
    (a.level === "red" ? 0 : 1) - (b.level === "red" ? 0 : 1) ||
    (a.start ?? "9999").localeCompare(b.start ?? "9999") ||
    a.priority - b.priority).slice(0, max);
}

/** Template wording used when Claude fails, is over budget, or names something it wasn't given. */
export function briefTemplate(today: BriefToday, changes: BriefChange[], items: BriefItem[]): string {
  const s: string[] = [];
  const red = items.filter((i) => i.level === "red");
  if (items.length) {
    const top = items[0]!;
    s.push(`${red.length ? `${red.length} red item${red.length === 1 ? "" : "s"}` : `${items.length} item${items.length === 1 ? "" : "s"}`} to sort before 10 am, starting with ${top.code} ${top.name}: ${top.problem}.`);
  } else s.push("Nothing needs sorting before 10 am.");
  s.push(`${today.crewWorking} crew working today, ${today.jobsStarting} job${today.jobsStarting === 1 ? "" : "s"} starting, ${today.away.length} away, ${today.utilisationPct}% booked.`);
  const ch = changes.filter((c) => c.count > 0);
  if (ch.length) s.push(`Since you last looked: ${ch.map((c) => `${c.count} ${c.label.toLowerCase()}`).join(", ")}.`);
  return s.join(" ");
}

/** Names of people that appear in the answer but not in the facts — any hit means the answer is rejected. */
export function namesNotInFacts(answer: string, facts: string, people: string[]): string[] {
  const out = new Set<string>();
  for (const full of people) for (const w of full.split(/\s+/).filter((x) => x.length >= 3)) {
    const re = new RegExp(`\\b${w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i");
    if (re.test(answer) && !re.test(facts)) out.add(w);
  }
  return [...out];
}

/** At most n sentences. */
export const capSentences = (t: string, n = 3) => (t.match(/[^.!?]+[.!?]+/g) ?? [t]).slice(0, n).join("").trim();
