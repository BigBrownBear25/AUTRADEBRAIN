import { describe, expect, it } from "vitest";
import { jobHealth } from "./job-health";
const now = new Date("2026-10-15T01:00:00Z");
describe("jobHealth", () => {
  it("overnight late after 30 minutes", () => {
    expect(jobHealth({ job: "overnight", last_ok_at: "2026-10-15T00:20:00Z", last_error_at: null, last_error: null }, "overnight", now).late).toBe(true);
    expect(jobHealth({ job: "overnight", last_ok_at: "2026-10-15T00:45:00Z", last_error_at: null, last_error: null }, "overnight", now).late).toBe(false);
  });
  it("newer error is red; event jobs aren't late just from quiet", () => {
    expect(jobHealth({ job: "watcher", last_ok_at: "2026-10-14T00:00:00Z", last_error_at: "2026-10-15T00:00:00Z", last_error: "x" }, "watcher", now)).toEqual({ late: true, reason: "x" });
    expect(jobHealth({ job: "email_intake", last_ok_at: "2026-10-01T00:00:00Z", last_error_at: null, last_error: null }, "email_intake", now).late).toBe(false);
  });
});
