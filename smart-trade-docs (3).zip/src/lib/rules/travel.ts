/** Travel rules (spec section 6 "Travel"). Pure — no database calls. */
import { minutes } from "./board";

export type Point = { lat: number; lng: number };

export function straightLineKm(a: Point, b: Point): number {
  const R = 6371, rad = Math.PI / 180;
  const dLat = (b.lat - a.lat) * rad, dLng = (b.lng - a.lng) * rad;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/**
 * Drive time in minutes. Uses the cached route result when there is one; otherwise
 * estimates: straight-line km × 1.25, then minutes = km ÷ avg_kmh × 60 + 5.
 */
export function driveEstimate(from: Point, to: Point, avgKmh: number, cached?: { minutes: number; km: number } | null) {
  if (cached) return { minutes: cached.minutes, km: cached.km, source: "route" as const };
  const km = straightLineKm(from, to) * 1.25;
  return { minutes: Math.round((km / avgKmh) * 60 + 5), km: Math.round(km * 10) / 10, source: "estimate" as const };
}

const toHm = (m: number) => {
  const x = ((m % 1440) + 1440) % 1440;
  return `${String(Math.floor(x / 60)).padStart(2, "0")}:${String(x % 60).padStart(2, "0")}`;
};

/** Leave-by time = job start − drive time − unload buffer. */
export function leaveBy(startTime: string, driveMinutes: number, unloadBufferMin: number): string {
  return toHm(minutes(startTime) - driveMinutes - unloadBufferMin);
}

/** Utes = crew size ÷ 2, rounded up. */
export const utes = (crewSize: number) => Math.ceil(crewSize / 2);

/** Overnight: more than overnight_minutes each way and longer than 1 day. Crew drives up once and stays (days − 1) nights. */
export function overnight(driveMinutes: number, days: number, overnightMinutes: number) {
  const isOvernight = driveMinutes > overnightMinutes && days > 1;
  return { overnight: isOvernight, nights: isOvernight ? days - 1 : 0, trips: isOvernight ? 1 : days };
}

/** Same-day gap between two jobs: overlapping is a clash, too short for the drive is a warning. */
export function sameDayTravelGap(prevEnd: string, nextStart: string, driveMinutes: number) {
  const gap = minutes(nextStart) - minutes(prevEnd);
  return { gapMinutes: gap, needed: driveMinutes, overlap: gap < 0, ok: gap >= driveMinutes };
}

/** Finance only. Return km × utes × trips × km_rate, plus room-nights × accommodation_rate. */
export function travelCost(o: { oneWayKm: number; crewSize: number; trips: number; nights: number; kmRate: number; accommodationRate: number }) {
  return o.oneWayKm * 2 * utes(o.crewSize) * o.trips * o.kmRate + o.nights * o.crewSize * o.accommodationRate;
}
