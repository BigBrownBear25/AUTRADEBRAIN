/** Leave rules. Pure — no database calls. */
import { minutes } from "./board";
import type { RuleLeave } from "./fit-check";

export type LeaveRow = {
  id: string; crew_member_id: string; type: string; from_date: string; to_date: string;
  start_time: string | null; end_time: string | null; status: "requested" | "approved" | "declined";
};
export type BookingRow = { crew_member_id: string; job_id: string; date: string; start: string; end: string };

/** Leave as the fit check sees it. Declined leave is ignored. */
export function toRuleLeave(rows: LeaveRow[]): RuleLeave[] {
  return rows.filter((l) => l.status !== "declined").map((l) => ({ crew_member_id: l.crew_member_id, from: l.from_date, to: l.to_date, status: l.status as "approved" | "requested" }));
}

/** Bookings that a leave request would clash with: same person, a day in the range, and overlapping times for part-day leave. */
export function leaveClashes(l: LeaveRow, bookings: BookingRow[]): BookingRow[] {
  return bookings.filter((b) => {
    if (b.crew_member_id !== l.crew_member_id || b.date < l.from_date || b.date > l.to_date) return false;
    if (!l.start_time || !l.end_time) return true;
    return minutes(b.start) < minutes(l.end_time) && minutes(l.start_time) < minutes(b.end);
  });
}

/** Leave covering a person on a date (approved first, then requested). */
export function leaveOnDay(rows: LeaveRow[], personId: string, date: string): LeaveRow | undefined {
  const on = rows.filter((l) => l.status !== "declined" && l.crew_member_id === personId && l.from_date <= date && date <= l.to_date);
  return on.find((l) => l.status === "approved") ?? on[0];
}

/** Public holidays for the workspace's states, shaped like closures. */
export function holidaysAsClosures(h: { state: string; date: string; name: string }[], states: string[]) {
  const seen = new Map<string, { from_date: string; to_date: string; name: string }>();
  for (const x of h) if (states.includes(x.state)) {
    const cur = seen.get(x.date);
    if (cur) { if (!cur.name.includes(x.state)) cur.name = cur.name.replace(/\(([^)]*)\)$/, `($1, ${x.state})`); }
    else seen.set(x.date, { from_date: x.date, to_date: x.date, name: `${x.name} (${x.state})` });
  }
  return [...seen.values()];
}
