/** Pure schedule-board helpers: time frames, columns, overlaps and utilisation. No database calls. */
import { isoWeekday } from "./assignments";

export type Frame = "day" | "week" | "2weeks" | "month" | "quarter" | "custom";
export type Block = { id: string; date: string; start: string; end: string };
export type Closure = { from_date: string; to_date: string; name: string };

const toDate = (iso: string) => new Date(`${iso}T00:00:00Z`);
const toIso = (d: Date) => d.toISOString().slice(0, 10);
export function addDays(iso: string, n: number): string {
  const d = toDate(iso);
  d.setUTCDate(d.getUTCDate() + n);
  return toIso(d);
}
function addMonths(iso: string, n: number): string {
  const d = toDate(iso);
  d.setUTCMonth(d.getUTCMonth() + n);
  return toIso(d);
}
export function mondayOf(iso: string): string {
  return addDays(iso, 1 - isoWeekday(iso));
}
export const minutes = (t: string) => +t.slice(0, 2) * 60 + +t.slice(3, 5);

/** Date range shown for a frame anchored on `anchor`. */
export function frameRange(frame: Frame, anchor: string, custom?: { from: string; to: string }): { from: string; to: string } {
  switch (frame) {
    case "day": return { from: anchor, to: anchor };
    case "week": { const m = mondayOf(anchor); return { from: m, to: addDays(m, 6) }; }
    case "2weeks": { const m = mondayOf(anchor); return { from: m, to: addDays(m, 13) }; }
    case "month": { const f = `${anchor.slice(0, 7)}-01`; return { from: f, to: addDays(addMonths(f, 1), -1) }; }
    case "quarter": {
      const q = Math.floor((+anchor.slice(5, 7) - 1) / 3) * 3 + 1;
      const f = `${anchor.slice(0, 4)}-${String(q).padStart(2, "0")}-01`;
      return { from: f, to: addDays(addMonths(f, 3), -1) };
    }
    case "custom": return custom && custom.to >= custom.from ? custom : { from: anchor, to: anchor };
  }
}

/** New anchor after pressing earlier (-1) or later (+1). */
export function shiftAnchor(frame: Frame, anchor: string, dir: -1 | 1, custom?: { from: string; to: string }): string {
  switch (frame) {
    case "day": return addDays(anchor, dir);
    case "week": return addDays(anchor, 7 * dir);
    case "2weeks": return addDays(anchor, 14 * dir);
    case "month": return addMonths(anchor, dir);
    case "quarter": return addMonths(anchor, 3 * dir);
    case "custom": {
      if (!custom) return anchor;
      const len = Math.round((toDate(custom.to).getTime() - toDate(custom.from).getTime()) / 86_400_000) + 1;
      return addDays(anchor, len * dir);
    }
  }
}

/** Board columns: dates in range on the working week. Weekends appear only when the workspace works them. */
export function boardColumns(from: string, to: string, workingDays: number[]): string[] {
  const out: string[] = [];
  for (let d = from, i = 0; d <= to && i < 400; d = addDays(d, 1), i++) {
    if (workingDays.includes(isoWeekday(d))) out.push(d);
  }
  return out;
}

export function closureOn(date: string, closures: Closure[]): Closure | undefined {
  return closures.find((c) => c.from_date <= date && date <= c.to_date);
}

/** Ids of blocks that overlap another block for the same person on the same day. */
export function overlappingIds(blocks: Block[]): Set<string> {
  const out = new Set<string>();
  const byDay = new Map<string, Block[]>();
  for (const b of blocks) byDay.set(b.date, [...(byDay.get(b.date) ?? []), b]);
  for (const list of byDay.values()) {
    for (let i = 0; i < list.length; i++)
      for (let j = i + 1; j < list.length; j++) {
        const a = list[i]!, b = list[j]!;
        if (minutes(a.start) < minutes(b.end) && minutes(b.start) < minutes(a.end)) { out.add(a.id); out.add(b.id); }
      }
  }
  return out;
}

/** True when a block is short enough to draw as a small block inside the day rather than a bar. */
export function isShortBlock(start: string, end: string, dayStart: string, dayEnd: string): boolean {
  return minutes(end) - minutes(start) < (minutes(dayEnd) - minutes(dayStart)) * 0.75;
}

/** Booked share (0–1+) of standard hours across the given columns; overlapping time counts once. */
export function utilisation(blocks: Block[], columns: string[], dayStart: string, dayEnd: string): number {
  const dayMin = minutes(dayEnd) - minutes(dayStart);
  if (!columns.length || dayMin <= 0) return 0;
  const cols = new Set(columns);
  const byDay = new Map<string, [number, number][]>();
  for (const b of blocks) if (cols.has(b.date)) byDay.set(b.date, [...(byDay.get(b.date) ?? []), [minutes(b.start), minutes(b.end)]]);
  let booked = 0;
  for (const spans of byDay.values()) {
    spans.sort((a, b) => a[0] - b[0]);
    let [s, e] = spans[0]!;
    for (const [ns, ne] of spans.slice(1)) {
      if (ns <= e) e = Math.max(e, ne);
      else { booked += e - s; [s, e] = [ns, ne]; }
    }
    booked += e - s;
  }
  return booked / (dayMin * columns.length);
}

/** Groups a person's full-day blocks for one job into runs of adjacent columns, for drawing bars. */
export function columnRuns(colIdx: number[]): [number, number][] {
  const sorted = [...new Set(colIdx)].sort((a, b) => a - b);
  const runs: [number, number][] = [];
  for (const i of sorted) {
    const last = runs[runs.length - 1];
    if (last && i === last[1] + 1) last[1] = i;
    else runs.push([i, i]);
  }
  return runs;
}
