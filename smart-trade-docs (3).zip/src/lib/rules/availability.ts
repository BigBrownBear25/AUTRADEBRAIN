/** Capacity by day, forward availability by week and job cost/margin (spec section 6). Pure. */
import { capacity } from "./capacity";
import { addDays, minutes, mondayOf } from "./board";
import { workingDays, type WorkWeek } from "./working-days";

export type CapBooking = { crew_member_id: string; date: string; start: string; end: string };
export type CapLeave = { crew_member_id: string; from: string; to: string; status: "approved" | "requested" };

/** Approved leave expanded to the given days. */
export function approvedLeaveDays(leave: CapLeave[], days: string[]) {
  return leave.filter((l) => l.status === "approved").flatMap((l) => days.filter((d) => l.from <= d && d <= l.to).map((date) => ({ crew_member_id: l.crew_member_id, date })));
}

/** The single capacity calculation used by the board, the Overview headline figures and the daily chart. */
export function rangeCapacity(people: string[], days: string[], hours: { dayStart: string; dayEnd: string }, leave: CapLeave[], bookings: CapBooking[]) {
  return capacity({ people, days, dayStart: hours.dayStart, dayEnd: hours.dayEnd, approvedLeave: approvedLeaveDays(leave, days), bookings });
}

export function dailyCapacity(people: string[], days: string[], hours: { dayStart: string; dayEnd: string }, leave: CapLeave[], bookings: CapBooking[]) {
  return days.map((d) => ({ date: d, ...rangeCapacity(people, [d], hours, leave, bookings) }));
}

export type WeekCell = { weekStart: string; freeCrewDays: number; free: string[]; partly: string[]; notFree: string[] };

/** Free crew-days by week for a group of people, with who is free all week, partly free or not free. */
export function forwardAvailability(people: string[], fromDate: string, weeks: number, week: WorkWeek, hours: { dayStart: string; dayEnd: string }, leave: CapLeave[], bookings: CapBooking[]): WeekCell[] {
  const out: WeekCell[] = [];
  const dayH = (minutes(hours.dayEnd) - minutes(hours.dayStart)) / 60;
  for (let i = 0, ws = mondayOf(fromDate); i < weeks; i++, ws = addDays(ws, 7)) {
    const days = workingDays(ws, addDays(ws, 6), week);
    const cell: WeekCell = { weekStart: ws, freeCrewDays: rangeCapacity(people, days, hours, leave, bookings).freeCrewDays, free: [], partly: [], notFree: [] };
    for (const p of people) {
      const c = rangeCapacity([p], days, hours, leave, bookings);
      if (c.freeHours >= days.length * dayH - 0.01 && days.length) cell.free.push(p);
      else if (c.freeHours > 0.01) cell.partly.push(p);
      else cell.notFree.push(p);
    }
    out.push(cell);
  }
  return out;
}

/** Finance only. Labour (day rates × days, open spots at the default rate) + travel + accommodation + materials. */
export function jobCost(o: { days: number; crewDayRates: number[]; openSpots: number; defaultDayRate: number; travel: number; accommodation: number; materials: number }) {
  const labour = (o.crewDayRates.reduce((a, b) => a + b, 0) + o.openSpots * o.defaultDayRate) * o.days;
  return { labour, total: labour + o.travel + o.accommodation + o.materials };
}

/** Margin = (quote − total) ÷ quote. Under 10% red, under 20% amber. */
export function margin(quote: number | null, total: number) {
  if (!quote) return { margin: null, level: "none" as const };
  const m = (quote - total) / quote;
  return { margin: m, level: m < 0.1 ? ("red" as const) : m < 0.2 ? ("amber" as const) : ("ok" as const) };
}
