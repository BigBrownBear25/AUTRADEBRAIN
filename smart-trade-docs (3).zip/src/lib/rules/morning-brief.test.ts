import { describe, expect, it } from "vitest";
import { leaveClashesInWindow, freeForBlocks, swapRows } from "./morning-brief";

const b = (id: string, who: string, date: string, job = "j1") => ({ id, crew_member_id: who, job_id: job, date, start: "07:00", end: "15:30" });

describe("morning brief", () => {
  const sick = { id: "l1", crew_member_id: "kyle", type: "sick leave", from_date: "2026-10-15", to_date: "2026-10-15", start_time: null, end_time: null, status: "approved" as const, created_at: "2026-10-14T20:00:00Z" };
  it("finds sick leave entered overnight over a booking", () => {
    const r = leaveClashesInWindow([sick], [b("a1", "kyle", "2026-10-15"), b("a2", "kyle", "2026-10-16")], "2026-10-15", "2026-10-16", "2026-10-14T05:30:00Z");
    expect(r).toHaveLength(1);
    expect(r[0]!.overnight).toBe(true);
    expect(r[0]!.bookings.map((x) => x.id)).toEqual(["a1"]);
  });
  it("ignores declined leave", () => {
    expect(leaveClashesInWindow([{ ...sick, status: "declined" }], [b("a1", "kyle", "2026-10-15")], "2026-10-15", "2026-10-16", "")).toHaveLength(0);
  });
  it("checks the swap person is free", () => {
    expect(freeForBlocks("jack", [b("a1", "kyle", "2026-10-15")], [b("x", "jack", "2026-10-15", "j2")], [])).toBe(false);
    expect(freeForBlocks("jack", [b("a1", "kyle", "2026-10-15")], [], [])).toBe(true);
  });
  it("swaps only the clashing rows", () => {
    expect(swapRows([b("a1", "kyle", "d"), b("a2", "kyle", "e")], ["a1"], "jack").map((r) => r.crew_member_id)).toEqual(["jack", "kyle"]);
  });
});

import { rankBriefItems, briefTemplate, namesNotInFacts, capSentences } from "./morning-brief";
describe("18b brief", () => {
  it("ranks red, then soonest start, then priority", () => {
    const r = rankBriefItems([
      { id: "a", level: "amber" as const, start: "2026-10-16", priority: 1 },
      { id: "b", level: "red" as const, start: "2026-10-20", priority: 2 },
      { id: "c", level: "red" as const, start: "2026-10-17", priority: 3 },
      { id: "d", level: "red" as const, start: "2026-10-17", priority: 1 },
      { id: "e", level: "red" as const, start: null, priority: 1 },
    ]);
    expect(r.map((x) => x.id)).toEqual(["d", "c", "b", "e", "a"]);
  });
  it("caps at 5", () => expect(rankBriefItems(Array.from({ length: 8 }, () => ({ level: "red" as const, start: null, priority: 1 }))).length).toBe(5));
  it("rejects names not given", () => {
    expect(namesNotInFacts("Swap Kyle for Sam", "Kyle is on leave", ["Kyle Brown", "Sam Lee"])).toEqual(["Sam"]);
  });
  it("template leads with what to sort", () => {
    const t = briefTemplate({ crewWorking: 4, jobsStarting: 1, away: [], utilisationPct: 80 }, [{ kind: "leave", label: "Leave", count: 2, to: "/crew" }],
      [{ key: "k", job_id: "j", code: "FZ-1", name: "Patel", suburb: null, level: "red", problem: "Crew short", reasons: [], start: null, priority: 1, fix: null, status: "open" }]);
    expect(t.startsWith("1 red item to sort before 10 am")).toBe(true);
    expect(capSentences("A. B. C. D.")).toBe("A. B. C.");
  });
});
