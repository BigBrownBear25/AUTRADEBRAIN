import { describe, expect, it } from "vitest";
import { ticketExpiryStatus } from "./ticket-expiry";

describe("ticketExpiryStatus", () => {
  const today = "2026-10-11";
  it("no expiry is current", () => expect(ticketExpiryStatus(null, today)).toBe("current"));
  it("yesterday is expired", () => expect(ticketExpiryStatus("2026-10-10", today)).toBe("expired"));
  it("today is expiring", () => expect(ticketExpiryStatus("2026-10-11", today)).toBe("expiring"));
  it("45 days out is expiring", () => expect(ticketExpiryStatus("2026-11-25", today)).toBe("expiring"));
  it("46 days out is current", () => expect(ticketExpiryStatus("2026-11-26", today)).toBe("current"));
});
