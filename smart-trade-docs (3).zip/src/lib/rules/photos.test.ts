import { describe, expect, it } from "vitest";
import { matchDocket, moistureCheck, normalisePhoto } from "./photos";

describe("photo rules", () => {
  it("drops unknown tags and defaults to other", () => {
    expect(normalisePhoto({ tags: ["cat"] }).tags).toEqual(["other"]);
    expect(normalisePhoto({ tags: ["Damage", "progress"] }).tags).toEqual(["damage", "progress"]);
  });
  it("blank moisture is no reading", () => {
    expect(normalisePhoto({ tags: ["subfloor"], moisture: { value: "", unit: "" } }).readings.moisture).toBeNull();
  });
  it("moisture over the flooring limit", () => {
    const lim = { Timber: { max: 12, unit: "%" } };
    expect(moistureCheck({ value: 14, unit: "%" }, "timber", lim)).toMatchObject({ known: true, over: true });
    expect(moistureCheck({ value: 10, unit: "%" }, "Timber", lim)).toMatchObject({ known: true, over: false });
    expect(moistureCheck({ value: 80, unit: "%RH" }, "Timber", lim).known).toBe(false);
    expect(moistureCheck({ value: 80, unit: "%" }, "Carpet", lim).known).toBe(false);
  });
  it("docket lines match undelivered materials", () => {
    const mats = [
      { id: "a", item: "Hybrid oak planks", status: "ordered" },
      { id: "b", item: "Underlay", status: "delivered" },
      { id: "c", item: "Scotia trims", status: "to order" },
    ];
    const r = matchDocket([{ item: "HYBRID PLANK OAK 2.2m2" }, { item: "Underlay 15m roll" }], mats);
    expect(r.map((x) => x.material.id)).toEqual(["a"]);
  });
});
