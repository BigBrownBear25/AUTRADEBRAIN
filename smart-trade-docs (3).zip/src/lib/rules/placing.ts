/** Placing a job (spec section 6 "Placing a job"). Pure — no database calls. */
import { minutes } from "./board";

export type PlacedRow = { crew_member_id: string; date: string; start_time: string; end_time: string };
export type PlacementMode = "move" | "swap" | "add" | "dates-only";

const toHm = (m: number) => `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;

/**
 * Works out the job's new assignments.
 * - Target already on the job: move the dates for the whole crew.
 * - Dragged from another person's bar: swap the target in for them.
 * - Crew short: add the target.
 * - Crew full: only the dates move.
 */
export function planPlacement(o: {
  currentCrew: string[];
  crewSize: number;
  target: string;
  from?: string | null;
  days: string[];
  block: { start: string; end: string };
}): { mode: PlacementMode; crew: string[]; rows: PlacedRow[] } {
  const crew = [...new Set(o.currentCrew)];
  let mode: PlacementMode;
  let next: string[];
  if (crew.includes(o.target)) { mode = "move"; next = crew; }
  else if (o.from && crew.includes(o.from)) { mode = "swap"; next = crew.map((c) => (c === o.from ? o.target : c)); }
  else if (crew.length < o.crewSize) { mode = "add"; next = [...crew, o.target]; }
  else { mode = "dates-only"; next = crew; }
  const rows = next.flatMap((c) => o.days.map((date) => ({ crew_member_id: c, date, start_time: o.block.start, end_time: o.block.end })));
  return { mode, crew: next, rows };
}

/** First free start time in a person's day that fits `durationMin`, within standard hours. Falls back to day start. */
export function firstFreeTime(busy: { start: string; end: string }[], dayStart: string, dayEnd: string, durationMin: number): string {
  const spans = busy.map((b) => [minutes(b.start), minutes(b.end)] as const).sort((a, b) => a[0] - b[0]);
  let t = minutes(dayStart);
  for (const [s, e] of spans) {
    if (s - t >= durationMin) break;
    t = Math.max(t, e);
  }
  return t + durationMin <= minutes(dayEnd) ? toHm(t) : dayStart.slice(0, 5);
}

export function addMinutes(t: string, m: number): string {
  return toHm(minutes(t) + m);
}
