/**
 * Session limits (spec section 14, rule 2; prompt S1).
 * Office/owner (and platform admins): 60 minutes idle, 12 hours since two-factor. Field: 30 days on their own device.
 * The database enforces the 12-hour two-factor window too (private.has_aal2), so this is the friendly side of it.
 */
export const OFFICE_IDLE_MS = 60 * 60_000;
export const OFFICE_TOTAL_MS = 12 * 60 * 60_000;
export const FIELD_TOTAL_MS = 30 * 24 * 60 * 60_000;

export type Amr = { method: string; timestamp: number }[];
const MFA = new Set(["totp", "phone", "webauthn", "mfa/totp", "mfa/phone", "mfa/webauthn"]);

/** Latest two-factor time (ms) from the token's amr claim, or null. */
export const mfaAt = (amr: Amr | undefined) => {
  const t = (amr ?? []).filter((a) => MFA.has(a.method)).map((a) => Number(a.timestamp) * 1000);
  return t.length ? Math.max(...t) : null;
};
/** Earliest sign-in time (ms) from the token's amr claim, or null. */
export const signedInAt = (amr: Amr | undefined) => {
  const t = (amr ?? []).map((a) => Number(a.timestamp) * 1000).filter((n) => n > 0);
  return t.length ? Math.min(...t) : null;
};

export type SessionEnd = { reason: string } | null;

export function sessionEnd(o: { office: boolean; amr: Amr | undefined; lastActivity: number | null; now: number }): SessionEnd {
  if (o.office) {
    if (o.lastActivity != null && o.now - o.lastActivity > OFFICE_IDLE_MS) return { reason: "You were signed out after 60 minutes without activity." };
    const m = mfaAt(o.amr);
    if (m != null && o.now - m > OFFICE_TOTAL_MS) return { reason: "Office sessions last 12 hours. Sign in with two-factor again." };
    return null;
  }
  const s = signedInAt(o.amr);
  if (s != null && o.now - s > FIELD_TOTAL_MS) return { reason: "Sessions last 30 days. Please sign in again." };
  return null;
}
