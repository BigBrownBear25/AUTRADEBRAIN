import { describe, expect, it } from "vitest";
import { guessFromWords, orderByDate, orderFlag, quantity } from "./materials";

const W = { workingDays: [1, 2, 3, 4, 5], closures: [] };

describe("quantity", () => {
  it("boxed goods", () => {
    const q = quantity({ category: "lvt and hybrid", unit: "box", pack_size: 2.2, coverage: 2.2, waste_pct: null }, { area: 42 });
    expect(q.qty).toBe(21); expect(q.working).toBe("42 m² + 8% waste ÷ 2.2 m² per box = 21 boxes");
  });
  it("roll goods to 0.1 m with the seam note", () => {
    const q = quantity({ category: "carpet", unit: "roll", pack_size: 3.66, coverage: null, waste_pct: null }, { area: 20 });
    expect(q.qty).toBe(6.1); expect(q.note).toBe("Check against the seam plan");
  });
  it("levelling compound", () => {
    const q = quantity({ category: "levelling and prep", unit: "bag", pack_size: 20, coverage: 1.6, waste_pct: null }, { area: 30, depthMm: 3 });
    expect(q.qty).toBe(8); expect(q.working).toBe("30 m² × 3 mm × 1.6 kg/m²/mm ÷ 20 kg bag = 8 bags");
  });
  it("adhesive", () => {
    expect(quantity({ category: "adhesive", unit: "pail", pack_size: 15, coverage: 15, waste_pct: null }, { area: 40 }).working).toBe("40 m² ÷ 15 m² per pail = 3 pails");
  });
  it("trims as entered; no area asks for it", () => {
    expect(quantity({ category: "trims and accessories", unit: "each", pack_size: null, coverage: null, waste_pct: null }, { area: 40, entered: 4 }).qty).toBe(4);
    expect(quantity({ category: "carpet", unit: "roll", pack_size: 3.66, coverage: null, waste_pct: null }, { area: null }).qty).toBeNull();
  });
});

describe("order-by", () => {
  it("start minus lead time in working days", () => { expect(orderByDate("2026-10-19", 3, false, W)).toBe("2026-10-14"); });
  it("stocked has none", () => { expect(orderByDate("2026-10-19", 3, true, W)).toBeNull(); });
  it("amber 3 working days before, red on the day", () => {
    const m = { item: "Hybrid", status: "to order", ordered_at: null, order_by: "2026-10-16" };
    expect(orderFlag(m, "2026-10-12", W)).toBeNull();
    expect(orderFlag(m, "2026-10-13", W)?.level).toBe("amber");
    expect(orderFlag(m, "2026-10-16", W)?.level).toBe("red");
    expect(orderFlag({ ...m, status: "ordered" }, "2026-10-16", W)).toBeNull();
  });
});

describe("guessFromWords", () => {
  it("fills what it can", () => {
    expect(guessFromWords("6 bags Ardex K15 20kg leveller")).toMatchObject({ category: "levelling and prep", unit: "bag", pack_size: 20 });
    expect(guessFromWords("Underlay 10mm")).toMatchObject({ category: "underlay" });
  });
});
