/** Capacity and availability (spec section 6). Pure — no database calls. */
import { minutes } from "./board";

export type CapacityInput = {
  people: string[];
  /** Working days in range (closures and public holidays already removed). */
  days: string[];
  dayStart: string;
  dayEnd: string;
  approvedLeave: { crew_member_id: string; date: string }[];
  bookings: { crew_member_id: string; date: string; start: string; end: string }[];
};

/** Hours, also shown as crew-days (hours ÷ standard day). Available = people × days × standard hours − approved leave. */
export function capacity(i: CapacityInput) {
  const dayHours = (minutes(i.dayEnd) - minutes(i.dayStart)) / 60;
  const ppl = new Set(i.people), ds = new Set(i.days);
  const leaveDays = new Set(i.approvedLeave.filter((l) => ppl.has(l.crew_member_id) && ds.has(l.date)).map((l) => `${l.crew_member_id}|${l.date}`));
  const available = i.people.length * i.days.length * dayHours - leaveDays.size * dayHours;
  const booked = i.bookings
    .filter((b) => ppl.has(b.crew_member_id) && ds.has(b.date))
    .reduce((s, b) => s + (minutes(b.end) - minutes(b.start)) / 60, 0);
  const free = available - booked;
  const cd = (h: number) => (dayHours > 0 ? h / dayHours : 0);
  return {
    availableHours: available, bookedHours: booked, freeHours: free,
    availableCrewDays: cd(available), bookedCrewDays: cd(booked), freeCrewDays: cd(free),
  };
}

/** Skills demand: over 70% is tight, over 90% is short. */
export function skillDemand(neededCrewDays: number, availableCrewDays: number) {
  const ratio = availableCrewDays > 0 ? neededCrewDays / availableCrewDays : neededCrewDays > 0 ? Infinity : 0;
  return { ratio, level: ratio > 0.9 ? ("short" as const) : ratio > 0.7 ? ("tight" as const) : ("ok" as const) };
}
