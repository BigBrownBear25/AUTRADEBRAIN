/** Background health (spec section 12): when a scheduled job counts as late or failing. */
export type JobRun = { job: string; last_ok_at: string | null; last_error_at: string | null; last_error: string | null };

/** Jobs on a clock and how long without a success counts as late. Event-driven jobs only go red on errors. */
export const LATE_AFTER_MIN: Record<string, number> = { overnight: 30 };
export const JOB_LABEL: Record<string, string> = { watcher: "Watcher", overnight: "Overnight run", email_intake: "Email intake" };

export function jobHealth(r: JobRun | undefined, job: string, now = new Date()): { late: boolean; reason: string | null } {
  if (!r?.last_ok_at) return { late: job in LATE_AFTER_MIN || !!r?.last_error_at, reason: r?.last_error ?? "Hasn't succeeded yet" };
  const ok = Date.parse(r.last_ok_at);
  if (r.last_error_at && Date.parse(r.last_error_at) > ok) return { late: true, reason: r.last_error ?? "Last run failed" };
  const lim = LATE_AFTER_MIN[job];
  if (lim && now.getTime() - ok > lim * 60_000) return { late: true, reason: `No success in over ${lim} minutes` };
  return { late: false, reason: null };
}
