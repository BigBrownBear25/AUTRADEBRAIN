/**
 * Priority rule (spec section 6 "Priority"). Pure — no database calls.
 *
 *               Critical  Soon  Flexible
 *   Key            P1      P2      P3
 *   Standard       P2      P3      P4
 *   Minor          P3      P4      P4
 *
 * If a job isn't complete and due_by is 10 days away or less, urgency becomes
 * Critical when the deadline is hard, or at least Soon when it's preferred.
 * Sort by priority, then due date, then start date.
 */
export type Importance = "key" | "standard" | "minor";
export type Urgency = "critical" | "soon" | "flexible";
export type Priority = 1 | 2 | 3 | 4;

export const PRIORITY_LABEL: Record<Priority, string> = {
  1: "Do first",
  2: "Next up",
  3: "Fit in",
  4: "Fill gaps",
};

export const DUE_SOON_DAYS = 10;

export type PriorityInput = {
  importance: Importance;
  urgency: Urgency;
  due_by: string | null;
  due_hard: boolean;
  status: string;
  start_date?: string | null;
};

const MATRIX: Record<Importance, Record<Urgency, Priority>> = {
  key: { critical: 1, soon: 2, flexible: 3 },
  standard: { critical: 2, soon: 3, flexible: 4 },
  minor: { critical: 3, soon: 4, flexible: 4 },
};

const DONE = new Set(["complete", "closed"]);

function daysBetween(fromIso: string, toIso: string): number {
  const a = Date.UTC(+fromIso.slice(0, 4), +fromIso.slice(5, 7) - 1, +fromIso.slice(8, 10));
  const b = Date.UTC(+toIso.slice(0, 4), +toIso.slice(5, 7) - 1, +toIso.slice(8, 10));
  return Math.round((b - a) / 86_400_000);
}

export function effectiveUrgency(job: PriorityInput, today: string): Urgency {
  if (DONE.has(job.status) || !job.due_by) return job.urgency;
  if (daysBetween(today, job.due_by) > DUE_SOON_DAYS) return job.urgency;
  if (job.due_hard) return "critical";
  return job.urgency === "flexible" ? "soon" : job.urgency;
}

export function priorityOf(job: PriorityInput, today: string): Priority {
  return MATRIX[job.importance][effectiveUrgency(job, today)];
}

/** Comparator: priority, then due date, then start date (missing dates last). */
export function comparePriority(today: string) {
  const d = (x: string | null | undefined) => x ?? "9999-12-31";
  return (a: PriorityInput, b: PriorityInput) =>
    priorityOf(a, today) - priorityOf(b, today) ||
    d(a.due_by).localeCompare(d(b.due_by)) ||
    d(a.start_date).localeCompare(d(b.start_date));
}
