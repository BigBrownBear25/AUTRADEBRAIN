import { describe, expect, it } from "vitest";
import { bookingSignature, inQuietHours, isSuperseded, newOrWorse, settledJobs, urgentDespiteQuiet, weekPressure } from "./brain-rules";

describe("brain rules", () => {
  it("quiet hours wrap midnight", () => {
    // 11:00 UTC = 22:00 Melbourne (AEDT)
    expect(inQuietHours(new Date("2026-10-14T11:00:00Z"), "20:00", "05:00", "Australia/Melbourne")).toBe(true);
    // 00:00 UTC = 11:00 Melbourne
    expect(inQuietHours(new Date("2026-10-14T00:00:00Z"), "20:00", "05:00", "Australia/Melbourne")).toBe(false);
  });
  it("urgent red P1 within 24h pushes in quiet hours", () => {
    expect(urgentDespiteQuiet("red", 1, 10)).toBe(true);
    expect(urgentDespiteQuiet("red", 2, 10)).toBe(false);
    expect(urgentDespiteQuiet("amber", 1, 10)).toBe(false);
  });
  it("waits two minutes after the last event on a job", () => {
    const now = Date.parse("2026-10-14T10:10:00Z");
    expect(settledJobs([{ job_id: "a", at: "2026-10-14T10:07:00Z" }, { job_id: "a", at: "2026-10-14T10:09:30Z" }, { job_id: "b", at: "2026-10-14T10:05:00Z" }], now)).toEqual(["b"]);
  });
  it("only new or worsened flags count", () => {
    const before = [{ level: "amber" as const, text: "Crew short (1/2)" }, { level: "amber" as const, text: "No dates" }];
    const after = [{ level: "red" as const, text: "Crew short (1/2)" }, { level: "amber" as const, text: "No dates" }, { level: "amber" as const, text: "Materials not ordered" }];
    expect(newOrWorse(before, after).map((f) => f.text)).toEqual(["Crew short (1/2)", "Materials not ordered"]);
  });
  it("supersession by booking signature", () => {
    const a = bookingSignature([{ crew_member_id: "x", date: "2026-10-15" }]);
    expect(isSuperseded(a, a)).toBe(false);
    expect(isSuperseded(a, bookingSignature([{ crew_member_id: "y", date: "2026-10-15" }]))).toBe(true);
  });
  it("week pressure over 90%", () => {
    expect(weekPressure({ available: 10, booked: 8, backlog: 2 }).over).toBe(true);
    expect(weekPressure({ available: 10, booked: 5, backlog: 2 }).over).toBe(false);
  });
});

import { addPersonRows, bookedByWeek, slotRows } from "./brain-rules";
describe("brain fix rows", () => {
  it("adds a person to each distinct block", () => {
    const r = addPersonRows([{ crew_member_id: "a", date: "2026-10-15", start_time: "07:30", end_time: "15:30", is_lead: true }, { crew_member_id: "b", date: "2026-10-15", start_time: "07:30", end_time: "15:30", is_lead: false }], "c");
    expect(r.filter((x) => x.crew_member_id === "c")).toHaveLength(1);
  });
  it("slot rows and weekly counts", () => {
    expect(slotRows(["a", "b"], ["2026-10-15", "2026-10-16"], "07:30", "15:30")).toHaveLength(4);
    expect(bookedByWeek(["2026-10-12", "2026-10-13", "2026-10-20"], ["2026-10-12", "2026-10-19"])).toEqual([2, 1]);
  });
});
