import { describe, expect, it } from "vitest";
import { boardColumns, columnRuns, frameRange, overlappingIds, shiftAnchor, utilisation } from "./board";

describe("board rules", () => {
  it("frames", () => {
    expect(frameRange("week", "2026-10-14")).toEqual({ from: "2026-10-12", to: "2026-10-18" });
    expect(frameRange("month", "2026-10-14")).toEqual({ from: "2026-10-01", to: "2026-10-31" });
    expect(frameRange("quarter", "2026-11-14")).toEqual({ from: "2026-10-01", to: "2026-12-31" });
    expect(shiftAnchor("2weeks", "2026-10-14", 1)).toBe("2026-10-28");
  });
  it("columns skip non-working days", () => {
    expect(boardColumns("2026-10-12", "2026-10-18", [1, 2, 3, 4, 5])).toHaveLength(5);
    expect(boardColumns("2026-10-12", "2026-10-18", [1, 2, 3, 4, 5, 6])).toHaveLength(6);
  });
  it("finds overlaps", () => {
    const ids = overlappingIds([
      { id: "a", date: "2026-10-12", start: "07:00", end: "11:30" },
      { id: "b", date: "2026-10-12", start: "11:00", end: "15:30" },
      { id: "c", date: "2026-10-12", start: "15:30", end: "16:00" },
    ]);
    expect([...ids].sort()).toEqual(["a", "b"]);
  });
  it("utilisation counts overlap once", () => {
    const u = utilisation([
      { id: "a", date: "2026-10-12", start: "07:00", end: "15:00" },
      { id: "b", date: "2026-10-12", start: "07:00", end: "11:00" },
    ], ["2026-10-12", "2026-10-13"], "07:00", "15:00");
    expect(u).toBeCloseTo(0.5);
  });
  it("runs", () => {
    expect(columnRuns([0, 1, 2, 4])).toEqual([[0, 2], [4, 4]]);
  });
});
