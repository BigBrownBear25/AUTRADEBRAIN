import { describe, expect, it } from "vitest";
import { priorityOf, comparePriority, type PriorityInput } from "./priority";
import { requiredTickets, ticketStatusForJob, type HazardSetting, type TicketRule } from "./tickets";

const today = "2026-10-11";
const base: PriorityInput = { importance: "standard", urgency: "flexible", due_by: null, due_hard: false, status: "ready" };

describe("priority", () => {
  it("matrix", () => {
    expect(priorityOf({ ...base, importance: "key", urgency: "critical" }, today)).toBe(1);
    expect(priorityOf({ ...base, importance: "standard", urgency: "soon" }, today)).toBe(3);
    expect(priorityOf({ ...base, importance: "minor", urgency: "critical" }, today)).toBe(3);
    expect(priorityOf({ ...base, importance: "minor", urgency: "flexible" }, today)).toBe(4);
  });
  it("hard deadline within 10 days becomes critical", () =>
    expect(priorityOf({ ...base, due_by: "2026-10-21", due_hard: true }, today)).toBe(2));
  it("preferred deadline within 10 days is at least soon", () =>
    expect(priorityOf({ ...base, due_by: "2026-10-15" }, today)).toBe(3));
  it("11 days away has no effect", () =>
    expect(priorityOf({ ...base, due_by: "2026-10-22", due_hard: true }, today)).toBe(4));
  it("complete jobs ignore the deadline", () =>
    expect(priorityOf({ ...base, due_by: "2026-10-12", due_hard: true, status: "complete" }, today)).toBe(4));
  it("sorts by priority then due then start", () => {
    const a = { ...base, importance: "key" as const, urgency: "soon" as const };
    const b = { ...base, due_by: "2026-12-01" };
    const c = { ...base, due_by: "2026-11-30" };
    expect([b, a, c].sort(comparePriority(today))).toEqual([a, c, b]);
  });
});

const hazards: HazardSetting[] = [
  { name: "vulnerable occupants", controls: [], required_tickets: [{ ticket: "WWCC", who: "everyone" }] },
  { name: "concrete grinding", controls: [], required_tickets: [{ ticket: "Silica Awareness", who: "everyone" }] },
  { name: "after-hours work", controls: [], required_tickets: [{ ticket: "First Aid", who: "one" }] },
];
const rules: TicketRule[] = [
  { when: "commercial", ticket: "White Card", who: "everyone" },
  { when: "crew_size_2_plus", ticket: "First Aid", who: "one" },
  { when: "all_hazards", hazards: ["old floor removal", "pre-1990 building"], ticket: "Asbestos Awareness", who: "everyone" },
  { when: "extra_tickets", who: "everyone" },
];
const job = { sector: "domestic" as const, crew_size: 1, hazards: [] as string[], extra_tickets: [] as string[] };
const names = (r: ReturnType<typeof requiredTickets>) => r.map((x) => x.ticket).sort();

describe("required tickets", () => {
  it("domestic solo job needs nothing", () => expect(requiredTickets(job, hazards, rules)).toEqual([]));
  it("commercial needs White Card", () => expect(names(requiredTickets({ ...job, sector: "commercial" }, hazards, rules))).toEqual(["White Card"]));
  it("asbestos needs both hazards", () => {
    expect(names(requiredTickets({ ...job, hazards: ["old floor removal"] }, hazards, rules))).toEqual([]);
    expect(names(requiredTickets({ ...job, hazards: ["old floor removal", "pre-1990 building"] }, hazards, rules))).toEqual(["Asbestos Awareness"]);
  });
  it("crew of 2 needs one First Aid", () => {
    const r = requiredTickets({ ...job, crew_size: 2, hazards: ["after-hours work"] }, hazards, rules);
    expect(r).toEqual([{ ticket: "First Aid", who: "one", reasons: ["Crew of 2 or more", "Hazard: after-hours work"] }]);
  });
  it("vulnerable occupants, grinding and extras", () =>
    expect(names(requiredTickets({ ...job, hazards: ["vulnerable occupants", "concrete grinding"], extra_tickets: ["EWP"] }, hazards, rules)))
      .toEqual(["EWP", "Silica Awareness", "WWCC"]));
  it("ticket status", () => {
    expect(ticketStatusForJob(undefined, today, "2026-10-20")).toBe("missing");
    expect(ticketStatusForJob({ expires_on: "2026-10-10" }, today, "2026-10-20")).toBe("expired");
    expect(ticketStatusForJob({ expires_on: "2026-10-20" }, today, "2026-10-20")).toBe("expires");
    expect(ticketStatusForJob({ expires_on: "2026-10-21" }, today, "2026-10-20")).toBe("current");
    expect(ticketStatusForJob({ expires_on: null }, today, "2026-10-20")).toBe("current");
  });
});
