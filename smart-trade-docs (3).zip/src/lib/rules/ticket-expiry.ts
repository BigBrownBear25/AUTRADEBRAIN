/** Ticket colour on the people list: current (green), expiring within `warnDays` (amber), expired (red). Pure. */
export type TicketExpiry = "current" | "expiring" | "expired";

export const TICKET_WARN_DAYS = 45;

export function ticketExpiryStatus(
  expiresOn: string | null,
  today: string,
  warnDays: number = TICKET_WARN_DAYS,
): TicketExpiry {
  if (!expiresOn) return "current";
  if (expiresOn < today) return "expired";
  const limit = new Date(`${today}T00:00:00Z`);
  limit.setUTCDate(limit.getUTCDate() + warnDays);
  return expiresOn <= limit.toISOString().slice(0, 10) ? "expiring" : "current";
}

export function todayIso(now: Date = new Date()): string {
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}
