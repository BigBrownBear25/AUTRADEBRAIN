/** Suggest a plan (spec section 6). Pure — no database calls. */
import { comparePriority, type PriorityInput } from "./priority";
import { findSlot, jobBlock, type RuleBooking, type RuleContext, type RuleJob, type SlotOption } from "./fit-check";

export type PlanJob = RuleJob & PriorityInput & { created_at: string; start_date: string | null };
export type PlanItem = { jobId: string; option: SlotOption | null; reason?: string };

/** Jobs that are ready to schedule or have no dates, excluding finished and locked jobs. */
export function planCandidates<J extends PlanJob>(jobs: J[]): J[] {
  return jobs.filter((j) => !j.locked && !["complete", "closed"].includes(j.status) && (j.status === "ready" || !j.start_date));
}

/**
 * Sort by priority, then due date, then creation date. Run Find a slot for each in turn,
 * treating earlier picks as booked. Never touches locked jobs.
 */
export function suggestPlan(jobs: PlanJob[], ctxFor: (job: PlanJob, extra: RuleBooking[]) => RuleContext, today: string): PlanItem[] {
  const byPriority = comparePriority(today);
  const order = planCandidates(jobs).sort((a, b) => byPriority({ ...a, start_date: null }, { ...b, start_date: null }) || a.created_at.localeCompare(b.created_at));
  const picked: RuleBooking[] = [];
  const out: PlanItem[] = [];
  for (const job of order) {
    const ctx = ctxFor(job, picked);
    const res = findSlot(job, ctx);
    const opt = res.options[0] ?? null;
    if (opt) {
      const b = jobBlock(job, ctx);
      for (const id of opt.team) for (const d of opt.days) picked.push({ crew_member_id: id, job_id: job.id, date: d, start: b.start, end: b.end });
      out.push({ jobId: job.id, option: opt });
    } else out.push({ jobId: job.id, option: null, reason: res.reason ?? "No slot found" });
  }
  return out;
}
