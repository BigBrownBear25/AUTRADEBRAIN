/**
 * Materials catalogue rules (spec section 13 "Quantities", "Order-by dates"). Pure — no database calls.
 * Every quantity comes back with its working as text, e.g. "42 m² + 8% waste ÷ 2.2 m² per box = 21 boxes".
 */
import { isWorkingDay, workingDays, type WorkWeek } from "./working-days";
import { addDays } from "./board";

export const CATEGORIES = [
  "carpet", "sheet vinyl", "lvt and hybrid", "laminate", "engineered timber", "solid timber", "tiles", "underlay",
  "adhesive", "levelling and prep", "trims and accessories", "consumables", "other",
] as const;
export type Category = (typeof CATEGORIES)[number];
export const UNITS = ["m²", "linear metre", "box", "roll", "each", "bag", "pail", "litre"] as const;
export type Unit = (typeof UNITS)[number];
export const CATEGORY_LABEL: Record<Category, string> = {
  carpet: "Carpet", "sheet vinyl": "Sheet vinyl", "lvt and hybrid": "LVT and hybrid", laminate: "Laminate", "engineered timber": "Engineered timber",
  "solid timber": "Solid timber", tiles: "Tiles", underlay: "Underlay", adhesive: "Adhesive", "levelling and prep": "Levelling and prep",
  "trims and accessories": "Trims and accessories", consumables: "Consumables", other: "Other",
};
/** Section 13 defaults; categories not listed have no default (0% until set in Settings or on the item). */
export const WASTE_DEFAULTS: Partial<Record<Category, number>> = { carpet: 10, "lvt and hybrid": 8, laminate: 8, tiles: 10, "sheet vinyl": 10 };

export type QtyItem = { category: string; unit: string; pack_size: number | null; coverage: number | null; waste_pct: number | null };
export type QtyInput = { area: number | null; depthMm?: number | null; entered?: number | null; wasteDefaults?: Record<string, number> };
export type Kind = "boxed" | "roll" | "leveller" | "adhesive" | "entered";
export type Qty = { kind: Kind; qty: number | null; unit: string; working: string; note?: string };

const n = (x: number) => (Number.isInteger(x) ? String(x) : String(Math.round(x * 100) / 100));
const ceil = (x: number) => Math.ceil(x - 1e-9);
const ceilTenth = (x: number) => Math.ceil(x * 10 - 1e-9) / 10;
const plural = (u: string, q: number) => (q === 1 || u === "m²" || u === "linear metre" ? u : u === "box" ? "boxes" : `${u}s`);

export function kindOf(i: QtyItem): Kind {
  if (i.category === "trims and accessories" || i.category === "consumables" || i.unit === "each") return "entered";
  if (i.category === "levelling and prep" && i.unit === "bag") return "leveller";
  if (i.category === "adhesive") return "adhesive";
  if (i.unit === "roll" || i.unit === "linear metre") return "roll";
  return "boxed";
}
export const wasteFor = (i: QtyItem, defaults: Record<string, number> = WASTE_DEFAULTS as Record<string, number>) =>
  i.waste_pct ?? defaults[i.category] ?? 0;

export function quantity(i: QtyItem, inp: QtyInput): Qty {
  const kind = kindOf(i);
  const area = inp.area ?? 0;
  const w = wasteFor(i, inp.wasteDefaults);
  const withWaste = w ? ` + ${n(w)}% waste` : "";
  const need = (what: string): Qty => ({ kind, qty: inp.entered ?? null, unit: i.unit, working: `Needs ${what} to calculate; enter the quantity` });

  if (kind === "entered") {
    const q = inp.entered ?? null;
    return { kind, qty: q, unit: i.unit, working: q == null ? "As entered" : `As entered: ${n(q)} ${plural(i.unit, q)}` };
  }
  if (!(area > 0)) return need("the job's area");
  if (kind === "boxed") {
    const per = i.unit === "m²" ? 1 : i.coverage ?? i.pack_size;
    if (!per) return need("coverage per unit");
    const q = ceil((area * (1 + w / 100)) / per);
    const label = i.unit === "m²" ? "" : ` ÷ ${n(per)} m² per ${i.unit}`;
    return { kind, qty: q, unit: i.unit, working: `${n(area)} m²${withWaste}${label} = ${q} ${plural(i.unit, q)}` };
  }
  if (kind === "roll") {
    const width = i.pack_size;
    if (!width) return need("the roll width");
    const q = ceilTenth((area * (1 + w / 100)) / width);
    return { kind, qty: q, unit: "linear metre", working: `${n(area)} m²${withWaste} ÷ ${n(width)} m roll width = ${n(q)} m`, note: "Check against the seam plan" };
  }
  if (kind === "leveller") {
    const depth = inp.depthMm ?? null;
    if (!depth) return need("the depth in mm");
    if (!i.coverage) return need("kg per m² per mm");
    if (!i.pack_size) return need("the bag size in kg");
    const q = ceil((area * depth * i.coverage) / i.pack_size);
    return { kind, qty: q, unit: "bag", working: `${n(area)} m² × ${n(depth)} mm × ${n(i.coverage)} kg/m²/mm ÷ ${n(i.pack_size)} kg bag = ${q} ${plural("bag", q)}` };
  }
  // adhesive
  if (!i.coverage) return need("coverage per " + i.unit);
  const q = ceil(area / i.coverage);
  return { kind, qty: q, unit: i.unit, working: `${n(area)} m² ÷ ${n(i.coverage)} m² per ${i.unit} = ${q} ${plural(i.unit, q)}` };
}

/** Order-by date = job start minus the lead time in working days. Stocked items and items without a lead time have none. */
export function orderByDate(start: string | null, leadDays: number | null, stocked: boolean, w: WorkWeek): string | null {
  if (!start || stocked || leadDays == null) return null;
  let d = start; let left = leadDays;
  for (let i = 0; left > 0 && i < leadDays * 4 + 60; i++) { d = addDays(d, -1); if (isWorkingDay(d, w)) left--; }
  return d;
}

/** Needs attention for an order-in item: amber from 3 working days before the order-by date, red on the day (and after). */
export function orderFlag(m: { item: string; status: string; ordered_at: string | null; order_by: string | null }, today: string, w: WorkWeek): { level: "red" | "amber"; text: string } | null {
  if (!m.order_by || m.status !== "to order" || m.ordered_at) return null;
  if (today >= m.order_by) return { level: "red", text: `Order ${m.item} (order by ${m.order_by})` };
  const left = workingDays(addDays(today, 1), m.order_by, w).length;
  return left <= 3 ? { level: "amber", text: `Order ${m.item} by ${m.order_by}` } : null;
}

/** "Add to catalogue" from a free-text material: fill what the words make clear; the person checks the rest. */
export function guessFromWords(text: string): { name: string; category: Category; unit: Unit; pack_size: number | null } {
  const t = text.toLowerCase();
  const has = (...w: string[]) => w.some((x) => t.includes(x));
  const category: Category =
    has("underlay") ? "underlay" : has("adhesive", "glue") ? "adhesive" : has("level", "screed", "primer") ? "levelling and prep"
    : has("trim", "scotia", "nosing", "reducer", "threshold", "skirting") ? "trims and accessories"
    : has("hybrid", "lvt", "vinyl plank") ? "lvt and hybrid" : has("sheet vinyl", "lino") ? "sheet vinyl" : has("laminate") ? "laminate"
    : has("engineered") ? "engineered timber" : has("timber", "oak", "hardwood") ? "solid timber" : has("tile") ? "tiles"
    : has("carpet") ? "carpet" : has("tape", "screw", "nail", "silicone", "sealant") ? "consumables" : "other";
  const unit: Unit = has(" box", "boxes") ? "box" : has("roll") ? "roll" : has("bag") ? "bag" : has("pail", "bucket") ? "pail"
    : has("litre", " l ") ? "litre" : has("lm", "linear") ? "linear metre" : has("m2", "m²", "sqm") ? "m²"
    : category === "lvt and hybrid" || category === "laminate" ? "box" : category === "carpet" || category === "sheet vinyl" ? "roll"
    : category === "levelling and prep" ? "bag" : category === "adhesive" ? "pail" : "each";
  const size = t.match(/(\d+(?:\.\d+)?)\s*(kg|m2|m²|sqm|l|litre|m)\b/);
  const pack_size = size ? Number(size[1]) : null;
  const name = text.replace(/^\s*\d+(?:\.\d+)?\s*(x|boxes?|rolls?|bags?|pails?|lm|m2|m²)?\s+/i, "").trim() || text.trim();
  return { name, category, unit, pack_size };
}
