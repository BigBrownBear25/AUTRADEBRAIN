/**
 * Required-tickets rule (spec section 6 "Required tickets"). Pure — no database calls.
 * The rules themselves come from workspace settings (hazards[].required_tickets + ticket_rules),
 * so other businesses can change them.
 */
export type Who = "everyone" | "one";

export type HazardSetting = { name: string; controls: string[]; required_tickets: { ticket: string; who: Who }[] };

export type TicketRule =
  | { when: "commercial"; ticket: string; who: Who }
  | { when: "crew_size_2_plus"; ticket: string; who: Who }
  | { when: "all_hazards"; hazards: string[]; ticket: string; who: Who }
  | { when: "extra_tickets"; who: Who };

export type TicketJob = { sector: "domestic" | "commercial"; crew_size: number; hazards: string[]; extra_tickets: string[] };

export type RequiredTicket = { ticket: string; who: Who; reasons: string[] };

export function requiredTickets(job: TicketJob, hazards: HazardSetting[], rules: TicketRule[]): RequiredTicket[] {
  const out = new Map<string, RequiredTicket>();
  const add = (ticket: string, who: Who, reason: string) => {
    const cur = out.get(ticket);
    if (!cur) return void out.set(ticket, { ticket, who, reasons: [reason] });
    if (who === "everyone") cur.who = "everyone"; // the stricter requirement wins
    cur.reasons.push(reason);
  };

  for (const r of rules) {
    if (r.when === "commercial" && job.sector === "commercial") add(r.ticket, r.who, "Commercial job");
    if (r.when === "crew_size_2_plus" && job.crew_size >= 2) add(r.ticket, r.who, "Crew of 2 or more");
    if (r.when === "all_hazards" && r.hazards.every((h) => job.hazards.includes(h))) add(r.ticket, r.who, r.hazards.join(" + "));
    if (r.when === "extra_tickets") for (const t of job.extra_tickets) add(t, r.who, "Listed on the job");
  }
  for (const h of hazards) {
    if (!job.hazards.includes(h.name)) continue;
    for (const rt of h.required_tickets) add(rt.ticket, rt.who, `Hazard: ${h.name}`);
  }
  return [...out.values()];
}

export type TicketStatus = "missing" | "expired" | "expires" | "current";

/** missing; expired (before today); expires (on or before the job's last day); current. */
export function ticketStatusForJob(
  held: { expires_on: string | null } | undefined,
  today: string,
  jobLastDay: string | null,
): TicketStatus {
  if (!held) return "missing";
  if (!held.expires_on) return "current";
  if (held.expires_on < today) return "expired";
  if (jobLastDay && held.expires_on <= jobLastDay) return "expires";
  return "current";
}
