/**
 * Matching a spoken name to crew members (spec section 6 "Matching to the right job"):
 * Claude only extracts the name; this scores it; the person confirms.
 * A name matches on first name, surname or full name, ignoring case and extra spaces.
 * "Sam" does not match "Samantha" — partial words never match.
 */
export type PersonCandidate = { id: string; name: string; role?: string | null; base_suburb?: string | null };
export type PersonMatch<T extends PersonCandidate> =
  | { kind: "one"; person: T }
  | { kind: "many"; people: T[] }
  | { kind: "none"; message: string };

const norm = (s: string) => s.trim().toLowerCase().replace(/[’']s$/, "").replace(/\s+/g, " ");

export function matchPeople<T extends PersonCandidate>(said: string, crew: T[]): PersonMatch<T> {
  const q = norm(said);
  if (!q) return { kind: "none", message: "Who is this for? Add a name." };
  const full = crew.filter((c) => norm(c.name) === q);
  const hits = full.length ? full : crew.filter((c) => {
    const parts = norm(c.name).split(" ");
    return parts[0] === q || (parts.length > 1 && parts[parts.length - 1] === q);
  });
  if (hits.length === 1) return { kind: "one", person: hits[0]! };
  if (hits.length > 1) return { kind: "many", people: hits };
  return { kind: "none", message: `I couldn't find anyone called ${said.trim()}.` };
}
