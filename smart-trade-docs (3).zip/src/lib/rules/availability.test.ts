import { describe, expect, it } from "vitest";
import { dailyCapacity, forwardAvailability, rangeCapacity } from "./availability";
const H = { dayStart: "07:00", dayEnd: "15:30" };
const week = { workingDays: [1, 2, 3, 4, 5], closures: [{ from_date: "2026-10-21", to_date: "2026-10-21", name: "Closed" }] };
const days = ["2026-10-19", "2026-10-20", "2026-10-22", "2026-10-23"];
const leave = [{ crew_member_id: "a", from: "2026-10-20", to: "2026-10-20", status: "approved" as const }, { crew_member_id: "b", from: "2026-10-22", to: "2026-10-22", status: "requested" as const }];
const bookings = [{ crew_member_id: "a", date: "2026-10-19", start: "07:00", end: "15:30" }, { crew_member_id: "b", date: "2026-10-22", start: "09:00", end: "10:00" }];
describe("capacity", () => {
  it("range total equals the sum of days and of people", () => {
    const t = rangeCapacity(["a", "b"], days, H, leave, bookings);
    expect(t.availableCrewDays).toBe(7);
    const byDay = dailyCapacity(["a", "b"], days, H, leave, bookings).reduce((s, d) => s + d.bookedHours, 0);
    const byPerson = rangeCapacity(["a"], days, H, leave, bookings).freeHours + rangeCapacity(["b"], days, H, leave, bookings).freeHours;
    expect(byDay).toBeCloseTo(t.bookedHours);
    expect(byPerson).toBeCloseTo(t.freeHours);
  });
  it("forward availability sorts people", () => {
    const [w] = forwardAvailability(["a", "b", "c"], "2026-10-21", 1, week, H, leave, bookings);
    expect(w!.free).toEqual(["c"]); expect(w!.partly.sort()).toEqual(["a", "b"]);
  });
});
