import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Theme = "light" | "dark";

type ShellState = {
  theme: Theme;
  setTheme: (t: Theme) => void;
};

const ShellContext = createContext<ShellState | null>(null);

// Theme only. Office/field view now follows the signed-in person's role (see src/lib/session.ts).
export function ShellProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>("light");

  useEffect(() => {
    const t = localStorage.getItem("tb-theme");
    if (t === "light" || t === "dark") setThemeState(t);
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [theme]);

  const setTheme = (t: Theme) => {
    setThemeState(t);
    localStorage.setItem("tb-theme", t);
  };

  return <ShellContext.Provider value={{ theme, setTheme }}>{children}</ShellContext.Provider>;
}

export function useShell() {
  const ctx = useContext(ShellContext);
  if (!ctx) throw new Error("useShell must be used inside ShellProvider");
  return ctx;
}
