import { queryOptions, useQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { holidaysAsClosures, type LeaveRow } from "@/lib/rules/leave";

/** Office: everyone's leave. Field: RLS returns only their own. */
export const leaveQuery = (workspaceId: string) =>
  queryOptions({
    queryKey: ["leave", workspaceId],
    queryFn: async () => {
      const { data, error } = await supabase.from("leave")
        .select("id, crew_member_id, type, from_date, to_date, start_time, end_time, status, note, created_at")
        .eq("workspace_id", workspaceId).order("from_date");
      if (error) throw error;
      return data as (LeaveRow & { note: string | null; created_at: string })[];
    },
  });

export const holidaysQuery = queryOptions({
  queryKey: ["public_holidays"],
  staleTime: 24 * 3600_000,
  queryFn: async () => {
    const { data, error } = await supabase.from("public_holidays").select("state, date, name").order("date");
    if (error) throw error;
    return data;
  },
});

/** Closures plus public holidays for the workspace's states — everything that isn't a working day. */
export function useDaysOff(workspaceId: string, holidayStates: string[] | undefined) {
  const { data: closures } = useQuery({
    queryKey: ["closures", workspaceId],
    queryFn: async () => {
      const { data, error } = await supabase.from("closures").select("name, from_date, to_date, kind, state").eq("workspace_id", workspaceId);
      if (error) throw error;
      return data;
    },
  });
  const { data: holidays } = useQuery(holidaysQuery);
  return useMemo(() => {
    if (!closures || !holidays || !holidayStates) return undefined;
    const own = closures.filter((c) => c.kind !== "public holiday" || !c.state || holidayStates.includes(c.state));
    return [...own.map((c) => ({ from_date: c.from_date, to_date: c.to_date, name: c.name })), ...holidaysAsClosures(holidays, holidayStates)];
  }, [closures, holidays, holidayStates]);
}
