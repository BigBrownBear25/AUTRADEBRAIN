/** Browser side of the session limits in src/lib/rules/sessions.ts: tracks activity per session and signs out when a limit is passed. */
import { useEffect } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { sessionEnd, type Amr } from "@/lib/rules/sessions";

const KEY = "tb:last-activity";
type Claims = { session_id?: string; amr?: Amr };

function claimsOf(token: string | undefined): Claims {
  try { return token ? (JSON.parse(atob(token.split(".")[1]!.replace(/-/g, "+").replace(/_/g, "/"))) as Claims) : {}; } catch { return {}; }
}
function lastActivity(sid: string | undefined): number | null {
  try { const v = JSON.parse(localStorage.getItem(KEY) ?? "null") as { sid: string; at: number } | null; return v && v.sid === sid ? v.at : null; } catch { return null; }
}
function touch(sid: string | undefined) { if (sid) localStorage.setItem(KEY, JSON.stringify({ sid, at: Date.now() })); }

/** Returns why the session should end, or null. Records activity for a session seen for the first time. */
export async function checkSession(office: boolean): Promise<string | null> {
  const { data } = await supabase.auth.getSession();
  if (!data.session) return null;
  const c = claimsOf(data.session.access_token);
  const last = lastActivity(c.session_id);
  if (last == null) touch(c.session_id);
  return sessionEnd({ office, amr: c.amr, lastActivity: last, now: Date.now() })?.reason ?? null;
}

export async function endSession(reason: string) {
  localStorage.removeItem(KEY);
  await supabase.auth.signOut({ scope: "local" });
  toast.message(reason);
  window.location.assign("/auth");
}

/** Mount once in the signed-in shell: records activity and checks every minute. */
export function useSessionGuard(office: boolean) {
  useEffect(() => {
    let sid: string | undefined; let lastWrite = 0;
    void supabase.auth.getSession().then(({ data }) => { sid = claimsOf(data.session?.access_token).session_id; });
    const onAct = () => { const n = Date.now(); if (n - lastWrite > 30_000) { lastWrite = n; touch(sid); } };
    const check = async () => { const r = await checkSession(office); if (r) await endSession(r); };
    const evs = ["pointerdown", "keydown", "touchstart", "scroll"] as const;
    evs.forEach((e) => window.addEventListener(e, onAct, { passive: true }));
    const onVis = () => { if (document.visibilityState === "visible") void check(); };
    document.addEventListener("visibilitychange", onVis);
    const t = window.setInterval(() => void check(), 60_000);
    return () => { evs.forEach((e) => window.removeEventListener(e, onAct)); document.removeEventListener("visibilitychange", onVis); window.clearInterval(t); };
  }, [office]);
}
