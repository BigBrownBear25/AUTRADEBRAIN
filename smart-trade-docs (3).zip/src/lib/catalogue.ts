/** Catalogue data access (spec section 13). Office reads through RLS; prices only for finance users. */
import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type CatalogueItem = Database["public"]["Tables"]["catalogue_items"]["Row"];
export type Supplier = Database["public"]["Tables"]["suppliers"]["Row"];
export type CataloguePrice = Database["public"]["Tables"]["catalogue_prices"]["Row"];
export type CompanionRule = Database["public"]["Tables"]["companion_rules"]["Row"];

export const catalogueQuery = (ws: string) => queryOptions({
  queryKey: ["catalogue_items", ws],
  queryFn: async () => {
    const { data, error } = await supabase.from("catalogue_items").select("*").eq("workspace_id", ws).order("name");
    if (error) throw error;
    return data;
  },
});
export const suppliersQuery = (ws: string) => queryOptions({
  queryKey: ["suppliers", ws],
  queryFn: async () => {
    const { data, error } = await supabase.from("suppliers").select("*").eq("workspace_id", ws).order("name");
    if (error) throw error;
    return data;
  },
});
export const pricesQuery = (itemId: string) => queryOptions({
  queryKey: ["catalogue_prices", itemId],
  queryFn: async () => {
    const { data, error } = await supabase.from("catalogue_prices").select("*").eq("item_id", itemId)
      .order("effective_from", { ascending: false }).order("created_at", { ascending: false });
    if (error) throw error;
    return data;
  },
});
export const companionQuery = (ws: string) => queryOptions({
  queryKey: ["companion_rules", ws],
  queryFn: async () => {
    const { data, error } = await supabase.from("companion_rules").select("*").eq("workspace_id", ws).order("when_category");
    if (error) throw error;
    return data;
  },
});
export const wasteDefaultsQuery = (ws: string) => queryOptions({
  queryKey: ["waste_defaults", ws],
  queryFn: async () => {
    const { data, error } = await supabase.from("workspace_settings").select("waste_defaults").eq("workspace_id", ws).single();
    if (error) throw error;
    return (data.waste_defaults ?? {}) as Record<string, number>;
  },
});
