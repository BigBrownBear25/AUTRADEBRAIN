import { queryOptions, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type Proposal = Database["public"]["Tables"]["proposals"]["Row"];
export type Notification = Database["public"]["Tables"]["notifications"]["Row"];

export const KIND_LABEL: Record<Proposal["kind"], string> = {
  place: "Book", move: "Move", swap: "Swap", add_person: "Add person", remove_person: "Remove person", create_job: "New job",
  update_job: "Update job", add_task: "Add task", add_dependency: "Add dependency", update_dependency: "Update dependency",
  mark_delivered: "Mark delivered", update_ticket: "Update ticket", leave_request: "Leave request", log_call: "Log call",
  send_email: "Send email", send_sms: "Send text",
};
export const SOURCE_LABEL: Record<Proposal["source"], string> = {
  brief: "Morning brief", watcher: "Watcher", overnight: "Overnight draft", capture: "Brain bar", ask: "Ask", email: "Email",
  photo: "Photo", document: "Document", variation: "Variation",
};
export const DISMISS_REASONS = [
  { value: "wrong", label: "Wrong" }, { value: "not_now", label: "Not now" }, { value: "already_done", label: "Already done" }, { value: "other", label: "Other" },
] as const;

/** RLS: office sees every proposal; field users only the ones they created. */
export const proposalsQuery = (ws: string, open: boolean) =>
  queryOptions({
    queryKey: ["proposals", ws, open ? "open" : "history"],
    queryFn: async () => {
      let q = supabase.from("proposals").select("*, jobs(code, name, locked)").eq("workspace_id", ws).order("created_at", { ascending: false }).limit(100);
      q = open ? q.eq("status", "open") : q.neq("status", "open");
      const { data, error } = await q;
      if (error) throw error;
      const now = Date.now();
      return (data ?? []).filter((p) => !open || !p.expires_at || new Date(p.expires_at).getTime() > now) as (Proposal & { jobs: { code: string; name: string; locked: boolean } | null })[];
    },
  });

export const jobProposalsQuery = (jobId: string) =>
  queryOptions({
    queryKey: ["proposals", "job", jobId],
    queryFn: async () => (await supabase.from("proposals").select("*, jobs(code, name, locked)").eq("job_id", jobId).eq("status", "open").order("created_at", { ascending: false })).data ?? [],
  });

export const notificationsQuery = (userId: string) =>
  queryOptions({
    queryKey: ["notifications", userId],
    queryFn: async () => (await supabase.from("notifications").select("*").eq("user_id", userId).order("created_at", { ascending: false }).limit(60)).data ?? [],
  });

/** Live updates for proposals and the caller's notifications (RLS-filtered). */
export function useBrainLive(ws: string, userId: string) {
  const qc = useQueryClient();
  useEffect(() => {
    const ch = supabase.channel(`brain-${userId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "proposals", filter: `workspace_id=eq.${ws}` }, () => qc.invalidateQueries({ queryKey: ["proposals"] }))
      .on("postgres_changes", { event: "*", schema: "public", table: "notifications", filter: `user_id=eq.${userId}` }, () => qc.invalidateQueries({ queryKey: ["notifications", userId] }))
      .subscribe();
    return () => { void supabase.removeChannel(ch); };
  }, [ws, userId, qc]);
}

export function invalidateAfterApply(qc: ReturnType<typeof useQueryClient>, ws: string) {
  for (const k of [["proposals"], ["jobs", ws], ["board-assignments", ws], ["leave", ws], ["assignments"], ["dependencies-all", ws], ["notifications"]]) qc.invalidateQueries({ queryKey: k });
}
