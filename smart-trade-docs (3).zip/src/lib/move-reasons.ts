/** Reasons picked when a scheduled job is moved; stored on the audit log row by the database. */
export const MOVE_REASONS = [
  { value: "builder_delay", label: "Builder delay" },
  { value: "weather", label: "Weather" },
  { value: "crew_away", label: "Crew away" },
  { value: "materials", label: "Materials" },
  { value: "client_request", label: "Client request" },
  { value: "other", label: "Other" },
] as const;
export type MoveReason = (typeof MOVE_REASONS)[number]["value"];
export const moveReasonLabel = (v: string | null | undefined) => MOVE_REASONS.find((r) => r.value === v)?.label ?? null;
