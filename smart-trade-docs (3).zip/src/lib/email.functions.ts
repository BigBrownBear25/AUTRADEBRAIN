import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const uuid = /^[0-9a-f-]{36}$/i;

/** Office check through the caller's own client: RLS only returns the email to office users. */
async function officeEmail(sb: any, emailId: string) {
  const { data: e } = await sb.from("inbound_emails").select("id, workspace_id, subject, from_address, body_text, status").eq("id", emailId).maybeSingle();
  if (!e) throw new Error("Email not found");
  const { data: ok } = await sb.rpc("is_office", { _ws: e.workspace_id });
  if (!ok) throw new Error("Only office users can file email");
  return e as { id: string; workspace_id: string; subject: string; from_address: string; body_text: string; status: string };
}

export const fileEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { emailId: string; jobId: string }) => {
    if (!uuid.test(d?.emailId) || !uuid.test(d?.jobId)) throw new Error("Bad id");
    return d;
  })
  .handler(async ({ data, context }) => {
    const e = await officeEmail(context.supabase, data.emailId);
    if (e.status === "filed") throw new Error("Already filed");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { fileToJob } = await import("./email-intake.server");
    await fileToJob(supabaseAdmin, e.id, data.jobId, context.userId);
    return { ok: true };
  });

export const ignoreEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { emailId: string }) => {
    if (!uuid.test(d?.emailId)) throw new Error("Bad id");
    return d;
  })
  .handler(async ({ data, context }) => {
    const e = await officeEmail(context.supabase, data.emailId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("inbound_emails").update({ status: "ignored", filed_by: context.userId, filed_at: new Date().toISOString() }).eq("id", e.id);
    return { ok: true };
  });

/** New enquiry from an email: the job is created as the office user (their RLS), then the email is filed on it. */
export const enquiryFromEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { emailId: string; name: string; sector: "domestic" | "commercial" }) => {
    if (!uuid.test(d?.emailId) || !d.name?.trim() || !["domestic", "commercial"].includes(d.sector)) throw new Error("Give the job a name");
    return { ...d, name: d.name.trim().slice(0, 200) };
  })
  .handler(async ({ data, context }) => {
    const e = await officeEmail(context.supabase, data.emailId);
    const { data: job, error } = await context.supabase.from("jobs")
      .insert({ workspace_id: e.workspace_id, name: data.name, sector: data.sector, status: "enquiry", client_contact: e.from_address.slice(0, 200) } as any)
      .select("id, code").single();
    if (error || !job) throw new Error(error?.message ?? "Couldn't create the job");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { fileToJob } = await import("./email-intake.server");
    await fileToJob(supabaseAdmin, e.id, job.id, context.userId);
    return job as { id: string; code: string };
  });
