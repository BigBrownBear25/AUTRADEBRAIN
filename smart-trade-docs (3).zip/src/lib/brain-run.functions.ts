import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Owner-only "Run now" for the overnight draft or look-ahead (normally scheduled). */
export const runBrainNow = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { workspaceId: string; what: "draft" | "lookahead" | "watch" }) => ({ workspaceId: String(d.workspaceId), what: d.what === "lookahead" ? "lookahead" as const : d.what === "watch" ? "watch" as const : "draft" as const }))
  .handler(async ({ data, context }) => {
    const { data: ok } = await context.supabase.rpc("is_owner", { _ws: data.workspaceId });
    if (!ok) throw new Error("Only the owner can run this");
    const w = await import("./brain/watch.server");
    if (data.what === "watch") { const r = await w.runWatcher(); return { result: `${r[data.workspaceId] ?? 0} events processed` }; }
    return { result: JSON.stringify(await w.runOvernight({ ws: data.workspaceId, what: data.what })) };
  });
