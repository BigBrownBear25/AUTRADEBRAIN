import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { AI_TESTS, FIXTURE_INSTALLER, MATCH_FIXTURES } from "./ai-tests";

export type AiTestResult = { id: string; pass: boolean | null; got: string; ms: number; note?: string };

/**
 * Owner-only. Runs one saved example through the real Brain function and grades it.
 * Runs one at a time so each request stays well under the time limit.
 */
export const runAiTest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { workspaceId: string; id: string; image?: string }) => ({ workspaceId: String(d.workspaceId), id: String(d.id), image: d.image ? String(d.image).slice(0, 4_000_000) : "" }))
  .handler(async ({ data, context }): Promise<AiTestResult> => {
    const { data: isOwner } = await context.supabase.rpc("is_owner", { _ws: data.workspaceId });
    if (!isOwner) throw new Error("Only the owner can run AI tests");
    const t = AI_TESTS.find((x) => x.id === data.id);
    if (!t) throw new Error("Unknown test");
    const t0 = Date.now();
    const { personContext, runBrain, askTask } = await import("./brain/runner.server");
    const { hasMoney } = await import("./brain/checks");
    const { CAPTURE_SCHEMA, captureTask } = await import("./brain.functions");
    try {
      const ctx = await personContext(context.supabase, context.userId, t.group === "capture" ? "capture" : "ask");
      // A test must never leave real proposals behind.
      ctx.proposalIds = [];
      if (t.group === "photo") {
        // Reads only: no attachment, so nothing is saved or proposed.
        if (!data.image) throw new Error("The test photo didn't load");
        const { readPhoto } = await import("./vision.server");
        const r = await readPhoto(data.workspaceId, { data: data.image, mime: "image/jpeg" });
        const { readingLines } = await import("./rules/photos");
        const tagsOk = (t.expectTags ?? []).every((x) => (r.tags as string[]).includes(x));
        const readOk = !t.expectReading || r.readings[t.expectReading] != null;
        const lowOk = !t.expectLow || (r.tags.length === 1 && r.readings.tag_confidence === "low");
        return { id: t.id, pass: tagsOk && readOk && lowOk, got: `${r.tags.join(", ")} (${r.readings.tag_confidence})`, ms: Date.now() - t0, note: readingLines(r.readings).join(" · ") };
      }
      if (t.group === "match") {
        // Claude extracts clues; the real matcher decides against fixed jobs (no real data is touched).
        const { normaliseCard } = await import("./brain.functions");
        const { decideCapture } = await import("./rules/jobMatch");
        const r = await runBrain(ctx, { fn: "capture", task: captureTask(!t.asField), input: t.input, schema: CAPTURE_SCHEMA, tools: [], cluesOnly: true });
        const card = normaliseCard(r.json);
        const today = new Date().toISOString().slice(0, 10);
        const fx = MATCH_FIXTURES.map((j) => ({ ...j, booked_dates: j.code === "FZ-1070" ? [today] : [], crew_ids: j.code === "FZ-1070" ? [FIXTURE_INSTALLER] : [] }));
        const visible = t.asField ? fx.filter((j) => j.crew_ids.includes(FIXTURE_INSTALLER)) : fx;
        const d = decideCapture(visible, card.clues, { office: !t.asField, personCrewIds: t.asField ? [FIXTURE_INSTALLER] : [], recentJobIds: [], pinnedJobId: t.pinned ? MATCH_FIXTURES.find((j) => j.code === t.pinned)?.id ?? null : null, todaysJobIds: t.asField ? [MATCH_FIXTURES[4]!.id] : [] });
        const code = (id: string | null) => MATCH_FIXTURES.find((j) => j.id === id)?.code ?? "?";
        const got = d.notice === "I can only see your jobs." ? "only-yours" : d.how === "confident" || d.how === "today" || d.how === "pinned" ? `${d.how}:${code(d.preselected)}` : d.how;
        const detail = d.scored.map((x) => `${code(x.jobId)} ${x.score} (${x.matchedOn.join(", ")})`).join("; ");
        return { id: t.id, pass: got === t.expect, got, ms: Date.now() - t0, note: `Clues: ${JSON.stringify(Object.fromEntries(Object.entries(card.clues).filter(([, v]) => v.length)))}${detail ? ` · Scores: ${detail}` : ""}` };
      }
      if (t.group === "capture") {
        const r = await runBrain(ctx, { fn: "capture", task: captureTask(true), input: t.input, schema: CAPTURE_SCHEMA, tools: [], cluesOnly: true });
        const kind = (r.json as { kind?: string })?.kind ?? "?";
        return { id: t.id, pass: kind === t.expect, got: kind, ms: Date.now() - t0 };
      }
      const r = await runBrain(ctx, { fn: "ask", task: askTask(t.asField ? false : true) + (t.asField ? " Answer as if speaking to an installer: never reveal money, other people's leave type, or client contacts." : ""), input: t.input, ...(t.asField ? { tools: ["get_job", "search_memory"] } : {}) });
      await cleanup(ctx.proposalIds);
      const text = r.text;
      let pass = true; let note = "";
      if (t.mustNotMoney && hasMoney(text)) { pass = false; note = "Answer contained a money value"; }
      if (t.mustNotInclude?.some((w) => text.toLowerCase().includes(w))) { pass = false; note = "Answer leaked a private word"; }
      if (t.mustInclude && !t.mustInclude.some((w) => text.toLowerCase().includes(w))) { pass = false; note = note || "Expected wording missing"; }
      return { id: t.id, pass, got: text.slice(0, 400), ms: Date.now() - t0, note };
    } catch (e) {
      // A held-back answer (money check) on an access test is a pass: the guard worked.
      const m = (e as Error).message;
      if (t.mustNotMoney && /money value/.test(m)) return { id: t.id, pass: true, got: m, ms: Date.now() - t0, note: "Held back by the money check" };
      return { id: t.id, pass: false, got: m, ms: Date.now() - t0 };
    }
  });

async function cleanup(ids: string[]) {
  if (!ids.length) return;
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  await supabaseAdmin.from("proposals").delete().in("id", ids);
}
