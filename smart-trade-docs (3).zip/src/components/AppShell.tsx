import { Link, getRouteApi, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { Building2, Check, CircleUser, Settings, HelpCircle, ShieldCheck, FlaskConical, Moon, Sun, LogOut } from "lucide-react";
import { officeNav, fieldNav } from "@/lib/nav";
import { useShell } from "@/lib/shell-context";
import { listMyWorkspaces, roleLabel } from "@/lib/session";
import { supabase } from "@/integrations/supabase/client";
import { useSessionGuard } from "@/lib/session-guard";
import { requiresTwoFactor } from "@/lib/session";
import { BrainFeed } from "@/components/brain/BrainFeed";
import { BrainBar } from "@/components/brain/BrainBar";

const authRoute = getRouteApi("/_authenticated");

function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2 text-nav-foreground">
      <span className="grid h-8 w-8 place-items-center rounded-sm bg-primary font-heading text-lg font-bold text-primary-foreground">
        TB
      </span>
      <span className="font-heading text-xl font-semibold uppercase tracking-wide">Trade Brain</span>
    </Link>
  );
}

function AccountMenu() {
  const { theme, setTheme } = useShell();
  const { user, membership, mode } = authRoute.useRouteContext();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const workspaces = useQuery({ queryKey: ["my-workspaces", user.id], queryFn: () => listMyWorkspaces(user.id) });
  const switchTo = async (ws: string) => {
    const { error } = await supabase.rpc("select_workspace", { _ws: ws });
    if (error) return;
    await queryClient.cancelQueries();
    queryClient.clear();
    window.location.assign("/"); // reload so every screen and the server agree on the new workspace
  };

  useEffect(() => {
    const close = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  const signOut = async () => {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };
  const signOutEverywhere = async () => {
    if (!window.confirm("Sign out of Trade Brain on every device, including this one?")) return;
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut({ scope: "global" });
    navigate({ to: "/auth", replace: true });
  };

  const item =
    "flex w-full min-h-11 items-center gap-3 rounded-sm px-3 text-left text-sm hover:bg-muted";

  return (
    <div ref={ref} className="relative">
      <button
        aria-label="Account menu"
        onClick={() => setOpen((o) => !o)}
        className="grid h-11 w-11 place-items-center rounded-sm text-nav-foreground hover:bg-nav-foreground/10"
      >
        <CircleUser className="h-6 w-6" />
      </button>
      {open && (
        <div className="absolute right-0 z-50 mt-2 w-64 rounded-md border bg-popover p-1 text-popover-foreground shadow-lg">
          <div className="px-3 py-2">
            <p className="truncate text-sm font-medium">{user.email}</p>
            <p className="text-xs text-muted-foreground">
              {roleLabel[membership.role]} · {membership.workspaceName}
            </p>
          </div>
          {(workspaces.data?.length ?? 0) > 1 && (
            <>
              <div className="my-1 border-t" />
              <p className="px-3 pt-1 text-xs uppercase text-muted-foreground">Switch workspace</p>
              {workspaces.data!.map((w) => (
                <button key={w.workspaceId} className={item} onClick={() => w.workspaceId !== membership.workspaceId && switchTo(w.workspaceId)}>
                  <Building2 className="h-4 w-4" />
                  <span className="flex-1 truncate">{w.name}</span>
                  <span className="text-xs text-muted-foreground">{roleLabel[w.role]}</span>
                  {w.workspaceId === membership.workspaceId && <Check className="h-4 w-4 text-primary" />}
                </button>
              ))}
            </>
          )}
          <div className="my-1 border-t" />
          {mode === "office" && (
            <Link to="/settings" className={item} onClick={() => setOpen(false)}>
              <Settings className="h-4 w-4" /> Settings
            </Link>
          )}
          {membership.role === "owner" && (
            <Link to="/access-check" className={item} onClick={() => setOpen(false)}>
              <ShieldCheck className="h-4 w-4" /> Access check
            </Link>
          )}
          {membership.role === "owner" && (
            <Link to="/rules-test" className={item} onClick={() => setOpen(false)}>
              <FlaskConical className="h-4 w-4" /> Rules test
            </Link>
          )}
          {membership.role === "owner" && (
            <Link to="/ai-test" className={item} onClick={() => setOpen(false)}>
              <FlaskConical className="h-4 w-4" /> AI test
            </Link>
          )}
          <Link to="/help" className={item} onClick={() => setOpen(false)}>
            <HelpCircle className="h-4 w-4" /> What's where
          </Link>
          <button className={item} onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            {theme === "dark" ? "Light theme" : "Dark theme"}
          </button>
          <div className="my-1 border-t" />
          <button className={item} onClick={signOut}>
            <LogOut className="h-4 w-4" /> Sign out
          </button>
          <button className={item} onClick={signOutEverywhere}>
            <LogOut className="h-4 w-4" /> Sign out everywhere
          </button>
        </div>
      )}
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { mode, membership, user } = authRoute.useRouteContext();
  const nav = mode === "office" ? officeNav : fieldNav;
  useSessionGuard(requiresTwoFactor(membership.role));

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-40 bg-nav pt-safe">
        <div className="mx-auto flex h-14 max-w-[1600px] items-center gap-6 px-4">
          <Logo />
          <nav className="hidden flex-1 items-center gap-1 md:flex">
            {nav.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                className="rounded-sm px-3 py-2 font-heading text-base font-medium uppercase tracking-wide hover:text-nav-foreground"
                inactiveProps={{ className: "text-nav-muted" }}
                activeProps={{ className: "bg-nav-foreground/10 text-nav-foreground" }}
              >
                {n.label}
              </Link>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-2">
            <span className="hidden rounded-sm border border-nav-foreground/20 px-2 py-0.5 font-mono text-xs uppercase text-nav-muted sm:inline">
              {roleLabel[membership.role]}
            </span>
            <BrainFeed ws={membership.workspaceId} userId={user.id} office={mode === "office"} />
            <AccountMenu />
          </div>
        </div>
      </header>

      <main className={`flex-1 pb-24 ${mode === "office" ? "md:pb-20" : "md:pb-0"}`}>{children}</main>
      <BrainBar ws={membership.workspaceId} userId={user.id} office={mode === "office"} />

      <nav className="fixed inset-x-0 bottom-0 z-40 border-t bg-card pb-safe md:hidden">
        <div className="grid" style={{ gridTemplateColumns: `repeat(${nav.length}, 1fr)` }}>
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="flex min-h-16 flex-col items-center justify-center gap-1 text-xs font-medium"
              inactiveProps={{ className: "text-muted-foreground" }}
              activeProps={{ className: "text-primary" }}
            >
              <n.icon className="h-6 w-6" />
              {n.label}
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
}
