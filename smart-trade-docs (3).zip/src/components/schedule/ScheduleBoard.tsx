import { useEffect, useMemo, useState, type CSSProperties, type DragEvent, type ReactElement } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, Lock, Unlock, X, GripVertical } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Database, Json } from "@/integrations/supabase/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { hm, jobAssignmentsQuery } from "@/lib/assignments";
import { jobsQuery, type JobListItem } from "@/lib/jobs";
import { comparePriority, priorityOf } from "@/lib/rules/priority";
import { todayIso } from "@/lib/rules/ticket-expiry";
import {
  addDays, boardColumns, closureOn, columnRuns, frameRange, isShortBlock, minutes, overlappingIds, shiftAnchor,
  type Block, type Frame,
} from "@/lib/rules/board";
import { fitCheck, jobBlock, type Level, type Reason, type RuleContext, type RuleJob, type RulePerson } from "@/lib/rules/fit-check";
import { jobDays, workingDays } from "@/lib/rules/working-days";
import { rangeCapacity, type CapLeave } from "@/lib/rules/availability";
import { CapacityTotals } from "./CapacityTotals";
import { driveEstimate } from "@/lib/rules/travel";
import { getBoardDriveHours } from "@/lib/drive-times.functions";
import { addMinutes, firstFreeTime, planPlacement } from "@/lib/rules/placing";
import { SuggestPlanButton } from "./SuggestPlan";
import { leaveQuery, useDaysOff } from "@/lib/leave";
import { toRuleLeave } from "@/lib/rules/leave";
import type { HazardSetting, TicketRule } from "@/lib/rules/tickets";
import { MOVE_REASONS, type MoveReason } from "@/lib/move-reasons";

type CrewRole = Database["public"]["Enums"]["crew_role"];
type Person = {
  id: string; name: string; role: CrewRole; is_subcontractor: boolean; base_suburb: string | null;
  base_lat: number | null; base_lng: number | null; skills: string[] | null;
  crew_tickets: { ticket_type: string; expires_on: string | null }[];
};
type BoardJob = { id: string; code: string; name: string; sector: string; importance: "key" | "standard" | "minor"; urgency: "critical" | "soon" | "flexible"; due_by: string | null; due_hard: boolean; status: string; locked: boolean };
type Row = { id: string; job_id: string; crew_member_id: string; date: string; start_time: string; end_time: string; jobs: BoardJob | null };
type LeaveBlock = { crew_member_id: string; from: string; to: string; requested: boolean; type: string };
type Placing = { jobId: string; from: string | null; via: "drag" | "tap" };
type PropRow = { crew_member_id: string; date: string; start_time: string; end_time: string; is_lead?: boolean };
type Target = { personId: string; date: string; time: string | null; dropped: boolean };

const FRAMES: { v: Frame; label: string }[] = [
  { v: "day", label: "Day" }, { v: "week", label: "Week" }, { v: "2weeks", label: "2 weeks" },
  { v: "month", label: "Month" }, { v: "quarter", label: "Quarter" }, { v: "custom", label: "Custom" },
];
const GROUPS: { key: string; label: string; match: (p: Person) => boolean }[] = [
  { key: "foreman", label: "Foremen", match: (p) => !p.is_subcontractor && p.role === "foreman" },
  { key: "installer", label: "Installers", match: (p) => !p.is_subcontractor && p.role === "installer" },
  { key: "apprentice", label: "Apprentices", match: (p) => !p.is_subcontractor && p.role === "apprentice" },
  { key: "sub", label: "Subcontractors", match: (p) => p.is_subcontractor },
];
const SLOT = 30;
const FIT_CELL: Record<Level, string> = { good: "bg-fit-soft", warning: "bg-warn-soft", clash: "hatch-clash" };
const FIT_TEXT: Record<Level, string> = { good: "text-fit", warning: "text-warn", clash: "text-clash" };
const FIT_LABEL: Record<Level, string> = { good: "Good fit", warning: "Warning", clash: "Clash" };
const isPhone = () => typeof window !== "undefined" && window.matchMedia("(max-width: 767px)").matches;
const fmtDay = (d: string) => new Date(`${d}T00:00:00`).toLocaleDateString("en-AU", { weekday: "short", day: "numeric", month: "short" });

function toRuleJob(j: JobListItem): RuleJob {
  return {
    id: j.id, code: j.code, sector: j.sector, crew_size: j.crew_size, hazards: j.hazards, extra_tickets: j.extra_tickets,
    main_skill: j.main_skill, other_skills: j.other_skills, duration_value: Number(j.duration_value), duration_unit: j.duration_unit,
    start_time: j.start_time, due_by: j.due_by, due_hard: j.due_hard,
    access_window: { days: ((j.access_window as { days?: number[] } | null)?.days) ?? [] }, locked: j.locked,
  };
}

export function ScheduleBoard({ workspaceId, mode, onOpenJob, initialPlace, initialProposal }: {
  workspaceId: string; mode: "office" | "field"; onOpenJob: (jobId: string) => void; initialPlace?: string | undefined; initialProposal?: string | undefined;
}) {
  const qc = useQueryClient();
  const today = todayIso();
  const office = mode === "office";
  const [frame, setFrame] = useState<Frame>("2weeks");
  const [anchor, setAnchor] = useState(today);
  const [custom, setCustom] = useState({ from: today, to: today });
  const [skill, setSkill] = useState("");
  const [placing, setPlacing] = useState<Placing | null>(null);
  const [hover, setHover] = useState<{ personId: string; date: string; time: string | null } | null>(null);
  const [target, setTarget] = useState<Target | null>(null);
  const [busy, setBusy] = useState(false);
  const [moveReason, setMoveReason] = useState<MoveReason | null>(null);
  // A scheduling proposal opened with Edit: its rows, anchored on the first person/date so moving the target shifts them all.
  const [proposed, setProposed] = useState<{ rows: PropRow[]; anchor: PropRow } | null>(null);

  const range = frameRange(frame, anchor, custom);

  const { data: settings } = useQuery({
    queryKey: ["workspace_settings", workspaceId, "board"],
    queryFn: async () => {
      const { data, error } = await supabase.from("workspace_settings")
        .select("working_days, day_start, morning_end, day_end, skills, hazards, ticket_rules, avg_kmh, holiday_states")
        .eq("workspace_id", workspaceId).single();
      if (error) throw error;
      return data;
    },
  });
  const { data: people = [] } = useQuery({
    queryKey: ["board-people", workspaceId],
    queryFn: async () => {
      // Office reads every crew record; RLS gives a field user only their own.
      const { data, error } = await supabase.from("crew_members")
        .select("id, name, role, is_subcontractor, base_suburb, base_lat, base_lng, skills, crew_tickets(ticket_type, expires_on)")
        .eq("workspace_id", workspaceId).eq("active", true).order("sort").order("name");
      if (error) throw error;
      return data as Person[];
    },
  });
  const ruleTo = addDays(range.to, 40);
  const { data: rows = [] } = useQuery({
    queryKey: ["board-assignments", workspaceId, range.from, ruleTo],
    queryFn: async () => {
      const { data, error } = await supabase.from("assignments")
        .select("id, job_id, crew_member_id, date, start_time, end_time, jobs(id, code, name, sector, importance, urgency, due_by, due_hard, status, locked)")
        .eq("workspace_id", workspaceId).gte("date", range.from).lte("date", ruleTo);
      if (error) throw error;
      return data as unknown as Row[];
    },
  });
  const closures = useDaysOff(workspaceId, settings?.holiday_states) ?? [];
  const { data: leaveRows = [] } = useQuery(leaveQuery(workspaceId));
  const { data: jobs = [] } = useQuery({ ...jobsQuery(workspaceId), enabled: office });
  const { data: placingRows = [] } = useQuery({ ...jobAssignmentsQuery(placing?.jobId ?? ""), enabled: !!placing });
  const { data: placingDeps = [] } = useQuery({
    queryKey: ["dependencies", placing?.jobId],
    enabled: !!placing,
    queryFn: async () => {
      const { data, error } = await supabase.from("dependencies").select("description, status, blocks_start, due_date").eq("job_id", placing!.jobId);
      if (error) throw error;
      return data;
    },
  });
  const leave: LeaveBlock[] = leaveRows.filter((l) => l.status !== "declined").map((l) => ({ crew_member_id: l.crew_member_id, from: l.from_date, to: l.to_date, requested: l.status === "requested", type: l.type }));
  const jobMap = useMemo(() => new Map(jobs.map((j) => [j.id, j])), [jobs]);
  const visiblePeople = useMemo(() => people.filter((p) => !skill || (p.skills ?? []).includes(skill)), [people, skill]);
  const ownIds = useMemo(() => new Set(people.map((p) => p.id)), [people]);
  // Field users only ever get their own row, so only their own bookings are drawn.
  const myRows = useMemo(() => rows.filter((r) => ownIds.has(r.crew_member_id)), [rows, ownIds]);

  const tray = useMemo(
    () => jobs.filter((j) => !["complete", "closed"].includes(j.status) && (j.status === "ready" || !j.start_date)).sort(comparePriority(today)),
    [jobs, today],
  );

  useEffect(() => {
    if (initialPlace && jobMap.has(initialPlace) && !jobMap.get(initialPlace)!.locked) setPlacing({ jobId: initialPlace, from: null, via: "tap" });
  }, [initialPlace, jobMap]);

  const placingJob = placing ? jobMap.get(placing.jobId) ?? null : null;

  const { data: draft } = useQuery({
    queryKey: ["proposal-draft", initialProposal], enabled: office && !!initialProposal,
    queryFn: async () => (await supabase.from("proposals").select("id, job_id, payload, status").eq("id", initialProposal!).maybeSingle()).data,
  });
  useEffect(() => {
    if (!draft?.job_id || !jobMap.has(draft.job_id) || jobMap.get(draft.job_id)!.locked) return;
    const pr = (((draft.payload as { rows?: PropRow[] })?.rows) ?? []).filter((r) => r?.crew_member_id && r?.date).sort((a, b) => a.date.localeCompare(b.date));
    setPlacing({ jobId: draft.job_id, from: null, via: "tap" });
    if (!pr.length) return;
    const a = pr[0]!;
    setProposed({ rows: pr, anchor: a });
    setTarget({ personId: a.crew_member_id, date: a.date, time: jobMap.get(draft.job_id)!.duration_unit === "hours" ? a.start_time?.slice(0, 5) ?? null : null, dropped: false });
    setAnchor(a.date);
  }, [draft, jobMap]);
  const { data: driveHours } = useQuery({
    queryKey: ["board-drive", workspaceId, range.from, range.to],
    queryFn: () => getBoardDriveHours({ data: { workspaceId, from: range.from, to: range.to } }),
    staleTime: 5 * 60_000,
  });

  // Everything fitCheck needs, built once per placing session.
  const ctx = useMemo<RuleContext | null>(() => {
    if (!settings || !placingJob) return null;
    const rulePeople: RulePerson[] = people.map((p) => ({ id: p.id, name: p.name, role: p.role, skills: p.skills ?? [], tickets: p.crew_tickets }));
    const site = placingJob.lat != null && placingJob.lng != null ? { lat: placingJob.lat, lng: placingJob.lng } : null;
    return {
      today, week: { workingDays: settings.working_days, closures }, dayStart: hm(settings.day_start), dayEnd: hm(settings.day_end),
      hazards: settings.hazards as HazardSetting[], ticketRules: settings.ticket_rules as TicketRule[],
      jobCrew: [...new Set(placingRows.map((r) => r.crew_member_id))], people: rulePeople,
      bookings: rows.map((r) => ({ crew_member_id: r.crew_member_id, job_id: r.job_id, date: r.date, start: hm(r.start_time), end: hm(r.end_time) })),
      leave: toRuleLeave(leaveRows), dependencies: placingDeps,
      driveFromBase: (pid) => {
        const p = people.find((x) => x.id === pid);
        if (!site || p?.base_lat == null || p.base_lng == null) return null;
        return driveEstimate({ lat: p.base_lat, lng: p.base_lng }, site, Number(settings.avg_kmh)).minutes;
      },
      driveBetweenJobs: (fromJobId) => {
        const f = jobMap.get(fromJobId);
        if (!site || f?.lat == null || f.lng == null) return null;
        return driveEstimate({ lat: f.lat, lng: f.lng }, site, Number(settings.avg_kmh)).minutes;
      },
    };
  }, [settings, placingJob, people, closures, placingRows, rows, placingDeps, jobMap, today, leaveRows]);

  const ruleJobFor = (time: string | null) => (placingJob ? { ...toRuleJob(placingJob), start_time: time ?? placingJob.start_time } : null);
  const fitAt = (personId: string, date: string, time: string | null) => {
    const rj = ruleJobFor(time);
    const p = ctx?.people.find((x) => x.id === personId);
    if (!rj || !p || !ctx) return null;
    return fitCheck(rj, p, date, ctx, placing?.from ?? undefined);
  };

  const columnsForCells = settings ? (frame === "day" ? [range.from] : boardColumns(range.from, range.to, settings.working_days)) : [];
  const cellFit = useMemo(() => {
    const m = new Map<string, Level>();
    if (!ctx || !placingJob) return m;
    const rj = toRuleJob(placingJob);
    for (const p of visiblePeople) {
      const rp = ctx.people.find((x) => x.id === p.id)!;
      for (const d of columnsForCells) m.set(`${p.id}|${d}`, fitCheck(rj, rp, d, ctx, placing?.from ?? undefined).level);
    }
    return m;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ctx, placingJob, visiblePeople, columnsForCells.join(","), placing?.from]);

  const cancel = () => { setPlacing(null); setTarget(null); setHover(null); setMoveReason(null); setProposed(null); };
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") cancel(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const defaultTime = (personId: string, date: string) => {
    if (!placingJob || !settings || placingJob.duration_unit !== "hours") return null;
    const dur = Math.round(Number(placingJob.duration_value) * 60);
    const taken = rows.filter((r) => r.crew_member_id === personId && r.date === date && r.job_id !== placingJob.id).map((r) => ({ start: hm(r.start_time), end: hm(r.end_time) }));
    return firstFreeTime(taken, hm(settings.day_start), hm(settings.day_end), dur);
  };

  const place = async (t: Target, anyway: boolean) => {
    if (!placingJob || !settings || !ctx) return;
    const rj = ruleJobFor(t.time)!;
    const days = jobDays(t.date, { value: rj.duration_value, unit: rj.duration_unit }, ctx.week);
    const block = jobBlock(rj, ctx);
    let plan = planPlacement({ currentCrew: ctx.jobCrew, crewSize: rj.crew_size, target: t.personId, from: placing?.from ?? null, days, block });
    if (proposed) {
      // Keep the proposed people and dates, shifted by however far the target was moved.
      const shift = Math.round((Date.parse(t.date) - Date.parse(proposed.anchor.date)) / 86_400_000);
      const swapTo = t.personId !== proposed.anchor.crew_member_id ? t.personId : null;
      const pRows = proposed.rows.map((r) => ({
        crew_member_id: swapTo && r.crew_member_id === proposed.anchor.crew_member_id ? swapTo : r.crew_member_id,
        date: addDays(r.date, shift),
        start_time: rj.duration_unit === "hours" && t.time ? t.time : r.start_time,
        end_time: rj.duration_unit === "hours" && t.time ? addMinutes(t.time, Math.round(Number(placingJob.duration_value) * 60)) : r.end_time,
        is_lead: !!r.is_lead,
      }));
      days.splice(0, days.length, ...[...new Set(pRows.map((r) => r.date))].sort());
      plan = { ...plan, rows: pRows as never };
    }
    const fit = fitAt(t.personId, t.date, t.time);
    if (fit?.level === "clash" && !anyway) return;
    const before = {
      rows: placingRows.map((r) => ({ id: r.id, crew_member_id: r.crew_member_id, date: r.date, start_time: r.start_time, end_time: r.end_time, is_lead: r.is_lead })),
      start_date: placingJob.start_date, start_time: placingJob.start_time, status: placingJob.status,
    };
    const jobId = placingJob.id, code = placingJob.code;
    setBusy(true);
    const { error } = await supabase.rpc("place_job", {
      _job_id: jobId, _rows: plan.rows as unknown as Json, _start_date: days[0]!,
      _start_time: (rj.duration_unit === "hours" ? block.start : null) as string,
      _status: placingJob.status === "ready" ? "scheduled" : placingJob.status,
      ...(placingJob.start_date && moveReason ? { _reason: moveReason } : {}),
    });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    const refresh = () => {
      qc.invalidateQueries({ queryKey: ["board-assignments", workspaceId] });
      qc.invalidateQueries({ queryKey: ["assignments", jobId] });
      qc.invalidateQueries({ queryKey: ["jobs", workspaceId] });
    };
    refresh();
    cancel();
    const who = people.find((p) => p.id === t.personId)?.name ?? "";
    const what = { move: "Moved", swap: `Swapped in ${who} on`, add: `Added ${who} to`, "dates-only": "Moved dates for" }[plan.mode];
    toast.success(`${what} ${code} · ${fmtDay(days[0]!)}`, {
      duration: 7000,
      action: {
        label: "Undo",
        onClick: async () => {
          const { error: e } = await supabase.rpc("place_job", {
            _job_id: jobId, _rows: before.rows as unknown as Json, _start_date: before.start_date as string,
            _start_time: before.start_time as string, _status: before.status, _ignore_lock: true,
          });
          if (e) toast.error(e.message); else { toast("Change undone"); refresh(); }
        },
      },
    });
  };

  const choose = (personId: string, date: string, time: string | null, dropped: boolean) => {
    const t: Target = { personId, date, time: time ?? defaultTime(personId, date), dropped };
    setTarget(t);
    setHover(null);
    // Drag and drop: good or warning places straight away; clash, or an hours job needing a time, waits in the placing bar.
    if (dropped && !(placingJob?.duration_unit === "hours" && !time)) {
      const f = fitAt(personId, date, t.time);
      if (f && f.level !== "clash") void place(t, false);
    }
  };

  const toggleLock = async (jobId: string, locked: boolean) => {
    const { error } = await supabase.from("jobs").update({ locked }).eq("id", jobId);
    if (error) { toast.error(error.message); return; }
    toast(locked ? "Job locked" : "Job unlocked");
    qc.invalidateQueries({ queryKey: ["jobs", workspaceId] });
    qc.invalidateQueries({ queryKey: ["board-assignments", workspaceId] });
  };

  const startPlacing = (jobId: string, from: string | null, via: Placing["via"]) => {
    const j = jobMap.get(jobId);
    if (!j) return;
    if (j.locked) { toast("This job is locked. Unlock it to move it."); return; }
    setTarget(null);
    setPlacing({ jobId, from, via });
  };
  const dragStart = (e: DragEvent, jobId: string, from: string | null) => {
    e.dataTransfer.setData("text/plain", jobId);
    e.dataTransfer.effectAllowed = "move";
    startPlacing(jobId, from, "drag");
  };
  const dragEnd = () => setPlacing((p) => (p && p.via === "drag" ? (target ? p : null) : p));

  if (!settings) return <p className="text-sm text-muted-foreground">Loading…</p>;

  const isDay = frame === "day";
  const columns = columnsForCells;
  const dayStart = hm(settings.day_start), dayEnd = hm(settings.day_end);
  // Same capacity formula as the Overview: working days minus closures, minus approved leave; booked = every assignment hour.
  const capDays = workingDays(range.from, range.to, { workingDays: settings.working_days, closures });
  const capLeave: CapLeave[] = leaveRows.filter((l) => l.status !== "declined").map((l) => ({ crew_member_id: l.crew_member_id, from: l.from_date, to: l.to_date, status: l.status === "approved" ? "approved" : "requested" }));
  const capBookings = myRows.map((r) => ({ crew_member_id: r.crew_member_id, date: r.date, start: hm(r.start_time), end: hm(r.end_time) }));
  const capOf = (ids: string[]) => rangeCapacity(ids, capDays, { dayStart, dayEnd }, capLeave, capBookings);

  let slotStart = minutes(dayStart), slotEnd = minutes(dayEnd);
  if (isDay) for (const r of myRows) if (r.date === range.from) { slotStart = Math.min(slotStart, minutes(r.start_time)); slotEnd = Math.max(slotEnd, minutes(r.end_time)); }
  slotStart = Math.floor(slotStart / 60) * 60; slotEnd = Math.ceil(slotEnd / 60) * 60;
  const slots = isDay ? Array.from({ length: (slotEnd - slotStart) / SLOT }, (_, i) => slotStart + i * SLOT) : [];
  const slotHm = (m: number) => `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
  const nCols = isDay ? slots.length : columns.length;
  const colW = isDay ? 36 : frame === "quarter" ? 26 : frame === "month" ? 40 : 96;
  const gridCols: CSSProperties = { gridTemplateColumns: `repeat(${nCols}, minmax(${colW}px, 1fr))` };
  const colIndex = new Map(columns.map((d, i) => [d, i]));
  const shownRows = myRows.filter((r) => r.date >= range.from && r.date <= range.to);

  const label = (d: string) => {
    const dt = new Date(`${d}T00:00:00`);
    if (frame === "quarter") return String(dt.getDate());
    if (frame === "month") return dt.toLocaleDateString("en-AU", { weekday: "narrow", day: "numeric" });
    return dt.toLocaleDateString("en-AU", { weekday: "short", day: "numeric", month: "short" });
  };

  // Ghost bar: where the job would land for the hovered (or chosen) cell.
  const ghostFor = (personId: string): ReactElement | null => {
    const g = hover ?? target;
    if (!g || g.personId !== personId || !placingJob || !ctx) return null;
    const rj = ruleJobFor(g.time)!;
    if (isDay) {
      const b = jobBlock(rj, ctx);
      return <div className="pointer-events-none rounded-sm border-2 border-dashed border-primary bg-primary/20" style={{ gridColumnStart: Math.max(1, Math.floor((minutes(b.start) - slotStart) / SLOT) + 1), gridColumnEnd: Math.max(2, Math.ceil((minutes(b.end) - slotStart) / SLOT) + 1), gridRow: 1, height: "2rem" }} />;
    }
    const idx = jobDays(g.date, { value: rj.duration_value, unit: rj.duration_unit }, ctx.week).map((d) => colIndex.get(d)).filter((i): i is number => i != null);
    return <>{columnRuns(idx).map(([a, b]) => <div key={a} className="pointer-events-none mx-0.5 flex h-8 items-center rounded-sm border-2 border-dashed border-primary bg-primary/20 px-1.5 font-mono text-xs" style={{ gridColumn: `${a + 1} / ${b + 2}`, gridRow: 1 }}>{placingJob.code}</div>)}</>;
  };

  const cellHandlers = (personId: string, date: string, time: string | null) =>
    placing ? {
      onDragOver: (e: DragEvent) => { e.preventDefault(); if (hover?.personId !== personId || hover.date !== date || hover.time !== time) setHover({ personId, date, time }); },
      onDragLeave: () => {},
      onDrop: (e: DragEvent) => { e.preventDefault(); choose(personId, date, time, true); },
      onClick: () => choose(personId, date, time, false),
    } : {};

  const targetFit = target ? fitAt(target.personId, target.date, target.time) : null;
  const hoverFit = !target && hover ? fitAt(hover.personId, hover.date, hover.time) : null;

  return (
    <div className="space-y-3">
      {/* To schedule tray */}
      {office && (
        <section className="rounded-md border bg-card p-3">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="font-heading text-lg font-semibold uppercase">To schedule <span className="text-muted-foreground">· {tray.length}</span></h2>
            <div className="flex items-center gap-3">
              <p className="hidden text-xs text-muted-foreground md:block">Drag a card onto the board, or tap it and then tap a day.</p>
              <SuggestPlanButton workspaceId={workspaceId} size="sm" />
            </div>
          </div>
          {!tray.length ? <p className="text-sm text-muted-foreground">Nothing waiting. Jobs that are ready or have no dates appear here.</p> : (
            <div className="flex gap-2 overflow-x-auto pb-1">
              {tray.map((j) => {
                const p = priorityOf(j, today);
                const active = placing?.jobId === j.id;
                return (
                  <div key={j.id} draggable={!j.locked} onDragStart={(e) => dragStart(e, j.id, null)} onDragEnd={dragEnd}
                    className={`flex w-56 shrink-0 overflow-hidden rounded-md border bg-background text-left shadow-sm ${active ? "ring-2 ring-primary" : ""} ${j.locked ? "opacity-70" : "cursor-grab"}`}>
                    <span className={`w-1.5 shrink-0 ${j.sector === "commercial" ? "bg-commercial" : "bg-domestic"}`} />
                    <button className="min-w-0 flex-1 p-2 text-left" onClick={() => (active ? cancel() : startPlacing(j.id, null, "tap"))}>
                      <span className="flex items-center gap-1.5">
                        {!j.locked && <GripVertical className="hidden h-3.5 w-3.5 text-muted-foreground md:block" />}
                        <span className="font-mono text-xs font-medium">{j.code}</span>
                        <span className="rounded-sm bg-muted px-1 font-mono text-[10px] font-bold">P{p}</span>
                      </span>
                      <span className="block truncate text-sm font-medium">{j.name}</span>
                      <span className="block truncate text-xs text-muted-foreground">{j.suburb ?? "No suburb"} · {Number(j.duration_value)} {j.duration_unit} · crew {j.crew_size}</span>
                    </button>
                    <button className="px-2 text-muted-foreground hover:text-foreground" aria-label={j.locked ? "Unlock job" : "Lock job"} onClick={() => toggleLock(j.id, !j.locked)}>
                      {j.locked ? <Lock className="h-4 w-4" /> : <Unlock className="h-4 w-4" />}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      )}

      {/* Time frame control */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex flex-wrap rounded-md border bg-card p-0.5">
          {FRAMES.map((f) => (
            <button key={f.v} onClick={() => setFrame(f.v)}
              className={`min-h-9 rounded-sm px-3 text-sm ${frame === f.v ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>
              {f.label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1">
          <Button variant="outline" size="icon" aria-label="Earlier" onClick={() => setAnchor(shiftAnchor(frame, anchor, -1, custom))}><ChevronLeft className="h-4 w-4" /></Button>
          <Button variant="outline" onClick={() => setAnchor(today)}>Today</Button>
          <Button variant="outline" size="icon" aria-label="Later" onClick={() => setAnchor(shiftAnchor(frame, anchor, 1, custom))}><ChevronRight className="h-4 w-4" /></Button>
        </div>
        {frame === "custom" ? (
          <div className="flex items-center gap-1">
            <Input type="date" className="w-40" value={custom.from} onChange={(e) => setCustom({ ...custom, from: e.target.value })} />
            <span className="text-muted-foreground">to</span>
            <Input type="date" className="w-40" value={custom.to} min={custom.from} onChange={(e) => setCustom({ ...custom, to: e.target.value })} />
          </div>
        ) : (
          <p className="text-sm font-medium">
            {new Date(`${range.from}T00:00:00`).toLocaleDateString("en-AU", { day: "numeric", month: "short", year: "numeric" })}
            {range.to !== range.from && <> – {new Date(`${range.to}T00:00:00`).toLocaleDateString("en-AU", { day: "numeric", month: "short", year: "numeric" })}</>}
          </p>
        )}
        {office && (
          <select className="ml-auto h-10 rounded-md border bg-background px-3 text-sm" value={skill} onChange={(e) => setSkill(e.target.value)} aria-label="Filter by skill">
            <option value="">All skills</option>
            {(settings.skills ?? []).map((s) => <option key={s}>{s}</option>)}
          </select>
        )}
      </div>

      {office && <CapacityTotals cap={capOf(visiblePeople.map((p) => p.id))} label={skill ? `${skill} crew` : "Whole crew"} />}

      {/* Board */}
      <div className="overflow-x-auto rounded-md border bg-card">
        <div className="min-w-max">
          <div className="sticky top-0 z-10 grid border-b bg-card" style={{ gridTemplateColumns: "220px 1fr" }}>
            <div className="sticky left-0 z-10 border-r bg-card px-3 py-2 text-xs font-semibold uppercase text-muted-foreground">Crew</div>
            <div className="grid" style={gridCols}>
              {isDay
                ? slots.map((m) => <div key={m} className="border-r px-1 py-2 font-mono text-[10px] text-muted-foreground">{m % 60 === 0 ? slotHm(m) : ""}</div>)
                : columns.map((d) => {
                  const c = closureOn(d, closures);
                  return (
                    <div key={d} title={c?.name} className={`border-r px-1 py-2 text-center text-xs ${d === today ? "bg-primary/15 font-semibold text-primary" : ""} ${c ? "shade-closure" : ""}`}>
                      {label(d)}
                    </div>
                  );
                })}
            </div>
          </div>

          {GROUPS.map((g) => {
            const members = visiblePeople.filter(g.match);
            if (!members.length) return null;
            return (
              <div key={g.key}>
                <div className="sticky left-0 border-b bg-muted/60 px-3 py-1 font-heading text-sm font-semibold uppercase tracking-wide">{g.label} <span className="text-muted-foreground">· {members.length}</span></div>
                {members.map((p) => {
                  const mine = shownRows.filter((r) => r.crew_member_id === p.id);
                  const blocks: Block[] = mine.map((r) => ({ id: r.id, date: r.date, start: hm(r.start_time), end: hm(r.end_time) }));
                  const clash = overlappingIds(blocks);
                  const clashDays = new Set(mine.filter((r) => clash.has(r.id)).map((r) => r.date));
                  const pc = capOf([p.id]); const util = pc.availableHours > 0 ? pc.bookedHours / pc.availableHours : pc.bookedHours > 0 ? 2 : 0;
                  const dayFit = isDay ? cellFit.get(`${p.id}|${range.from}`) : undefined;
                  return (
                    <div key={p.id} className="grid border-b" style={{ gridTemplateColumns: "220px 1fr" }}>
                      <div className="sticky left-0 z-[5] border-r bg-card px-3 py-2">
                        <p className="truncate text-sm font-medium">{p.name}</p>
                        <p className="truncate text-xs text-muted-foreground">{p.base_suburb || "No home base"}</p>
                        <div className="mt-1 flex items-center gap-2">
                          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted" title={`${Math.round(util * 100)}% booked`}>
                            <div className={`h-full ${util > 1 ? "bg-clash" : "bg-primary"}`} style={{ width: `${Math.min(100, util * 100)}%` }} />
                          </div>
                          <span className="w-9 text-right font-mono text-[10px]">{Math.round(util * 100)}%</span>
                          {(() => {
                            const dh = driveHours?.[p.id];
                            if (!p.base_suburb || dh?.noBase) return <span className="font-mono text-[10px] text-muted-foreground" title="No home base set">—</span>;
                            if (!dh) return <span className="font-mono text-[10px] text-muted-foreground">… h</span>;
                            const tip = `Driving in this range: ${dh.hours} h over ${dh.trips} return trip${dh.trips === 1 ? "" : "s"}${dh.unmeasured ? ` · ${dh.unmeasured} not measured yet (open the job's Travel tab)` : ""}`;
                            return <span className="font-mono text-[10px] text-muted-foreground" title={tip}>{dh.hours} h{dh.unmeasured ? "+" : ""}</span>;
                          })()}
                        </div>
                      </div>
                      <div className="relative min-h-14">
                        {/* Background cells: closures, today, double-bookings, leave, and fit colours while placing */}
                        <div className="absolute inset-0 grid" style={gridCols}>
                          {isDay
                            ? slots.map((m) => (
                              <div key={m} {...cellHandlers(p.id, range.from, placingJob?.duration_unit === "hours" ? slotHm(m) : null)}
                                className={`${m % 60 === 0 ? "border-l" : ""} ${dayFit ? FIT_CELL[dayFit] : clashDays.size ? "hatch-clash opacity-60" : ""} ${placing ? "cursor-pointer" : ""}`} />
                            ))
                            : columns.map((d) => {
                              const lv = leave.find((l) => l.crew_member_id === p.id && l.from <= d && d <= l.to);
                              const fit = cellFit.get(`${p.id}|${d}`);
                              return (
                                <div key={d} {...cellHandlers(p.id, d, null)}
                                  className={`border-r ${fit ? FIT_CELL[fit] : `${closureOn(d, closures) ? "shade-closure" : ""} ${d === today ? "bg-primary/5" : ""} ${clashDays.has(d) ? "hatch-clash" : ""}`} ${placing ? "cursor-pointer" : ""}`}>
                                  {lv && <div title={`${lv.type}${lv.requested ? " (requested)" : ""}`} className={`m-1 h-[calc(100%-0.5rem)] rounded-sm hatch-leave ${lv.requested ? "border border-dashed border-muted-foreground" : ""}`} />}
                                </div>
                              );
                            })}
                        </div>
                        {/* Foreground: bars and blocks (click-through while placing) */}
                        <div className={`relative grid gap-y-1 py-1.5 ${placing ? "pointer-events-none" : ""}`} style={{ ...gridCols, gridAutoFlow: "row dense" }}>
                          {placing && ghostFor(p.id)}
                          {(() => {
                            const out: ReactElement[] = [];
                            const bar = (key: string, r: Row, style: CSSProperties, clashOn: boolean, small?: boolean, time?: string) => (
                              <JobBar key={key} job={r.jobs!} today={today} clash={clashOn} small={small} time={time} style={style}
                                draggable={office && !r.jobs!.locked}
                                onDragStart={(e) => dragStart(e, r.job_id, p.id)} onDragEnd={dragEnd}
                                onOpen={() => (office && isPhone() && !r.jobs!.locked ? startPlacing(r.job_id, p.id, "tap") : onOpenJob(r.job_id))} />
                            );
                            if (isDay) {
                              for (const r of mine) if (r.jobs) out.push(bar(r.id, r, {
                                gridColumnStart: Math.max(1, Math.floor((minutes(r.start_time) - slotStart) / SLOT) + 1),
                                gridColumnEnd: Math.max(2, Math.ceil((minutes(r.end_time) - slotStart) / SLOT) + 1),
                              }, clash.has(r.id), false, `${hm(r.start_time)}–${hm(r.end_time)}`));
                              return out;
                            }
                            const byJob = new Map<string, Row[]>();
                            for (const r of mine) {
                              if (!colIndex.has(r.date) || !r.jobs) continue;
                              if (isShortBlock(r.start_time, r.end_time, dayStart, dayEnd)) {
                                out.push(bar(r.id, r, { gridColumn: `${colIndex.get(r.date)! + 1} / span 1` }, clash.has(r.id), true, `${hm(r.start_time)}–${hm(r.end_time)}`));
                              } else byJob.set(r.job_id, [...(byJob.get(r.job_id) ?? []), r]);
                            }
                            for (const [jobId, list] of byJob) {
                              for (const [a, b] of columnRuns(list.map((r) => colIndex.get(r.date)!))) {
                                const runClash = list.some((r) => clash.has(r.id) && colIndex.get(r.date)! >= a && colIndex.get(r.date)! <= b);
                                out.push(bar(`${jobId}-${a}`, list[0]!, { gridColumn: `${a + 1} / ${b + 2}` }, runClash));
                              }
                            }
                            return out;
                          })()}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            );
          })}
          {!visiblePeople.length && <p className="px-3 py-8 text-center text-sm text-muted-foreground">{office ? "No crew match this filter." : "Your crew record isn't linked yet. Ask the office."}</p>}
        </div>
      </div>

      <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
        <span className="flex items-center gap-1.5"><span className="h-3 w-5 rounded-sm bg-domestic" />Domestic</span>
        <span className="flex items-center gap-1.5"><span className="h-3 w-5 rounded-sm bg-commercial" />Commercial</span>
        <span className="flex items-center gap-1.5"><span className="h-3 w-5 rounded-sm hatch-clash" />Double-booked / clash</span>
        {office && <span className="flex items-center gap-1.5"><span className="h-3 w-5 rounded-sm bg-fit-soft" />Good fit</span>}
        {office && <span className="flex items-center gap-1.5"><span className="h-3 w-5 rounded-sm bg-warn-soft" />Warning</span>}
        <span className="flex items-center gap-1.5"><span className="h-3 w-5 rounded-sm hatch-leave" />Leave</span>
        <span className="flex items-center gap-1.5"><span className="h-3 w-5 rounded-sm border border-dashed border-muted-foreground hatch-leave" />Leave requested</span>
        <span className="flex items-center gap-1.5"><span className="h-3 w-5 rounded-sm shade-closure" />Closure</span>
      </div>

      {/* Placing bar */}
      {placing && placingJob && (
        <PlacingBar
          code={placingJob.code} name={placingJob.name} locked={placingJob.locked}
          proposedLabel={proposed ? (() => {
            const shift = target ? Math.round((Date.parse(target.date) - Date.parse(proposed.anchor.date)) / 86_400_000) : 0;
            const names = [...new Set(proposed.rows.map((r) => target && r.crew_member_id === proposed.anchor.crew_member_id ? target.personId : r.crew_member_id))].map((id) => people.find((x) => x.id === id)?.name ?? "Someone");
            const ds = proposed.rows.map((r) => addDays(r.date, shift)).sort();
            return `Proposed: ${names.join(", ")} · ${fmtDay(ds[0]!)}${ds.length > 1 && ds[ds.length - 1] !== ds[0] ? ` to ${fmtDay(ds[ds.length - 1]!)}` : ""}`;
          })() : null}
          hoursJob={placingJob.duration_unit === "hours"}
          durationMin={Math.round(Number(placingJob.duration_value) * 60)}
          targetLabel={target ? `${people.find((x) => x.id === target.personId)?.name ?? ""} · ${fmtDay(target.date)}` : hover ? `${people.find((x) => x.id === hover.personId)?.name ?? ""} · ${fmtDay(hover.date)}` : null}
          fit={targetFit ?? hoverFit}
          time={target?.time ?? null}
          hasTarget={!!target}
          busy={busy}
          isMove={!!placingJob.start_date} reason={moveReason} onReason={setMoveReason}
          onTime={(t) => target && setTarget({ ...target, time: t })}
          onPlace={(anyway) => target && place(target, anyway)}
          onCancel={cancel}
          onLock={() => { toggleLock(placingJob.id, true); cancel(); }}
          onOpen={() => { onOpenJob(placingJob.id); cancel(); }}
        />
      )}
    </div>
  );
}

function PlacingBar(p: {
  code: string; name: string; locked: boolean; hoursJob: boolean; durationMin: number; targetLabel: string | null; proposedLabel: string | null;
  fit: { level: Level; reasons: Reason[] } | null; time: string | null; hasTarget: boolean; busy: boolean;
  isMove: boolean; reason: MoveReason | null; onReason: (r: MoveReason | null) => void;
  onTime: (t: string) => void; onPlace: (anyway: boolean) => void; onCancel: () => void; onLock: () => void; onOpen: () => void;
}) {
  const order: Record<Level, number> = { clash: 0, warning: 1, good: 2 };
  const reasons = [...(p.fit?.reasons ?? [])].sort((a, b) => order[a.level] - order[b.level]);
  return (
    <div className="fixed inset-x-2 bottom-[calc(4.5rem+env(safe-area-inset-bottom))] z-40 mx-auto max-w-3xl rounded-md border bg-popover p-3 text-popover-foreground shadow-xl md:bottom-4">
      <div className="flex items-start gap-2">
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm"><span className="font-mono font-medium">{p.code}</span> · {p.name}</p>
          <p className="text-sm text-muted-foreground">{p.targetLabel ?? "Tap a day on the board, or drop the job on a cell."}</p>
          {p.proposedLabel && <p className="text-xs text-muted-foreground">{p.proposedLabel}. Tap another cell to move it.</p>}
        </div>
        {p.fit && <span className={`shrink-0 font-heading text-sm font-semibold uppercase ${FIT_TEXT[p.fit.level]}`}>{FIT_LABEL[p.fit.level]}</span>}
        <Button size="icon" variant="ghost" aria-label="Cancel" onClick={p.onCancel}><X className="h-4 w-4" /></Button>
      </div>
      {reasons.length > 0 && (
        <ul className="mt-2 max-h-36 space-y-0.5 overflow-y-auto text-sm">
          {reasons.map((r, i) => (
            <li key={i} className="flex gap-2"><span className={`w-16 shrink-0 text-xs font-semibold uppercase ${FIT_TEXT[r.level]}`}>{r.level === "good" ? "Good" : r.level === "warning" ? "Warn" : "Clash"}</span><span className="text-muted-foreground">{r.check}:</span> {r.text}</li>
          ))}
        </ul>
      )}
      {p.hasTarget && (
        <div className="mt-3 flex flex-wrap items-center gap-2">
          {p.hoursJob && (
            <label className="flex items-center gap-2 text-sm">Start
              <Input type="time" className="w-28" value={p.time ?? ""} onChange={(e) => p.onTime(e.target.value)} />
              <span className="font-mono text-xs text-muted-foreground">to {p.time ? addMinutes(p.time, p.durationMin) : "—"}</span>
            </label>
          )}
          {p.isMove && (
            <label className="flex items-center gap-2 text-sm">Reason
              <select aria-label="Move reason" className="h-9 rounded-md border bg-background px-2 text-sm" value={p.reason ?? ""} onChange={(e) => p.onReason((e.target.value || null) as MoveReason | null)}>
                <option value="">Pick a reason</option>
                {MOVE_REASONS.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
              </select>
            </label>
          )}
          <div className="ml-auto flex gap-2">
            <Button variant="outline" size="sm" onClick={p.onOpen}>Open job</Button>
            <Button variant="outline" size="sm" onClick={p.onLock}><Lock className="h-4 w-4" />Lock</Button>
            {p.fit?.level === "clash"
              ? <Button size="sm" variant="destructive" disabled={p.busy} onClick={() => p.onPlace(true)}>Place anyway</Button>
              : <Button size="sm" disabled={p.busy} onClick={() => p.onPlace(false)}>Place</Button>}
          </div>
        </div>
      )}
    </div>
  );
}

function JobBar({ job, today, clash, small, time, style, onOpen, draggable, onDragStart, onDragEnd }: {
  job: BoardJob; today: string; clash: boolean; small?: boolean | undefined; time?: string | undefined; style: CSSProperties; onOpen: () => void;
  draggable: boolean; onDragStart: (e: DragEvent) => void; onDragEnd: () => void;
}) {
  const p = priorityOf(job, today);
  const sector = job.sector === "commercial" ? "bg-commercial text-primary-foreground" : "bg-domestic text-primary-foreground";
  return (
    <button onClick={onOpen} style={style} title={`${job.code} ${job.name}${time ? ` · ${time}` : ""}${job.locked ? " · locked" : ""}`}
      draggable={draggable} onDragStart={onDragStart} onDragEnd={onDragEnd}
      className={`pointer-events-auto mx-0.5 flex min-w-0 items-center gap-1 overflow-hidden rounded-sm px-1.5 text-left text-xs shadow-sm ${sector} ${small ? "h-6 opacity-90" : "h-8"} ${clash ? "ring-2 ring-clash" : ""} ${draggable ? "cursor-grab" : ""}`}>
      {p <= 2 && <span className="shrink-0 rounded-sm bg-background/90 px-1 font-mono text-[10px] font-bold text-foreground">P{p}</span>}
      {job.locked && <Lock className="h-3 w-3 shrink-0" aria-label="Locked" />}
      <span className="shrink-0 font-mono">{job.code}</span>
      <span className="truncate">{small && time ? time : job.name}</span>
    </button>
  );
}
