import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { applyPlacement, toRuleJob, useSchedulingData } from "@/lib/scheduling";
import { suggestPlan, type PlanItem } from "@/lib/rules/suggest-plan";

const fmt = (d: string) => new Date(`${d}T00:00:00`).toLocaleDateString("en-AU", { weekday: "short", day: "numeric", month: "short" });

/** Suggest a plan: preview with a tick box per job; applies only the ticked ones. Locked jobs are never included. */
export function SuggestPlanButton({ workspaceId, size = "default" }: { workspaceId: string; size?: "default" | "sm" }) {
  const qc = useQueryClient();
  const api = useSchedulingData(workspaceId);
  const [open, setOpen] = useState(false);
  const [plan, setPlan] = useState<PlanItem[]>([]);
  const [ticked, setTicked] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);

  const run = () => {
    if (!api) return;
    const p = suggestPlan(api.jobs.map(toRuleJob), (j, extra) => api.ctxFor(j, extra), api.today);
    setPlan(p);
    setTicked(new Set(p.filter((x) => x.option).map((x) => x.jobId)));
    setOpen(true);
  };
  const name = (id: string) => api?.people.find((p) => p.id === id)?.name ?? "Unknown";

  const apply = async () => {
    if (!api) return;
    setBusy(true);
    let done = 0;
    for (const item of plan) {
      if (!item.option || !ticked.has(item.jobId)) continue;
      const job = api.jobMap.get(item.jobId);
      if (!job || job.locked) continue;
      const ok = await applyPlacement({ qc, workspaceId, job, ctx: api.ctxFor(toRuleJob(job)), team: item.option.team, days: item.option.days, label: `${job.code} booked from ${fmt(item.option.start)}` });
      if (ok) done++;
    }
    setBusy(false);
    setOpen(false);
    toast.success(`Applied ${done} of ${ticked.size} jobs`);
  };

  return (
    <>
      <Button size={size} variant="outline" disabled={!api} onClick={run}><Sparkles className="h-4 w-4" />Suggest a plan</Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader><DialogTitle className="font-heading text-2xl uppercase">Suggested plan</DialogTitle></DialogHeader>
          {!plan.length ? <p className="text-sm text-muted-foreground">No unlocked jobs are waiting to be scheduled.</p> : (
            <ul className="divide-y rounded-md border">
              {plan.map((item) => {
                const job = api?.jobMap.get(item.jobId);
                if (!job) return null;
                const o = item.option;
                return (
                  <li key={item.jobId} className="flex items-start gap-3 p-3">
                    <Checkbox className="mt-1" disabled={!o} checked={!!o && ticked.has(item.jobId)}
                      onCheckedChange={(c) => { const n = new Set(ticked); if (c) n.add(item.jobId); else n.delete(item.jobId); setTicked(n); }} />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm"><span className="font-mono font-medium">{job.code}</span> · {job.name}</p>
                      {o ? (
                        <>
                          <p className="text-sm">{fmt(o.days[0]!)}{o.days.length > 1 && ` – ${fmt(o.days[o.days.length - 1]!)}`} · {o.team.map(name).join(", ")}</p>
                          {o.averageDrive != null && <p className="text-xs text-muted-foreground">Average drive {o.averageDrive} min</p>}
                          {o.warnings.map((w) => <p key={w} className="text-xs text-warn">{w}</p>)}
                        </>
                      ) : <p className="text-sm text-clash">No slot: {item.reason}</p>}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button disabled={busy || !ticked.size} onClick={apply}>Apply selected ({ticked.size})</Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
