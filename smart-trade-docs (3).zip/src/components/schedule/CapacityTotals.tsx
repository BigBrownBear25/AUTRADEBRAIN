import type { capacity } from "@/lib/rules/capacity";

type Cap = ReturnType<typeof capacity>;
const f = (n: number) => (Math.round(n * 10) / 10).toLocaleString("en-AU");

/** Available / booked / free crew-days for a range. Shown on both the board and the Overview so the totals can be compared. */
export function CapacityTotals({ cap, label }: { cap: Cap; label: string }) {
  const pct = cap.availableHours > 0 ? Math.round((cap.bookedHours / cap.availableHours) * 100) : 0;
  return (
    <div className="flex flex-wrap items-baseline gap-x-5 gap-y-1 rounded-md border bg-card px-4 py-2 text-sm" data-testid="capacity-totals">
      <span className="font-heading font-semibold uppercase tracking-wide">{label}</span>
      <span>Available <b className="font-mono">{f(cap.availableCrewDays)}</b> crew-days</span>
      <span>Booked <b className="font-mono">{f(cap.bookedCrewDays)}</b></span>
      <span className={cap.freeHours < 0 ? "text-clash" : ""}>Free <b className="font-mono">{f(cap.freeCrewDays)}</b></span>
      <span className="text-muted-foreground">{pct}% booked</span>
    </div>
  );
}
