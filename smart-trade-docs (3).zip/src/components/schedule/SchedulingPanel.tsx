import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { crewRoleLabel } from "@/lib/crew";
import { applyPlacement, toRuleJob, useSchedulingData } from "@/lib/scheduling";
import { findCrew, findSlot, type SlotOption } from "@/lib/rules/fit-check";
import { jobDays } from "@/lib/rules/working-days";

const fmt = (d: string) => new Date(`${d}T00:00:00`).toLocaleDateString("en-AU", { weekday: "short", day: "numeric", month: "short" });

/** Job overview: Crew (Find crew) and Schedule this job (Find a slot, Place on schedule). */
export function SchedulingPanel({ workspaceId, jobId }: { workspaceId: string; jobId: string }) {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const api = useSchedulingData(workspaceId);
  const [crewOpen, setCrewOpen] = useState(false);
  const [slots, setSlots] = useState<{ options: SlotOption[]; reason?: string } | null>(null);
  const [busy, setBusy] = useState(false);

  if (!api) return <p className="text-sm text-muted-foreground">Loading scheduling…</p>;
  const job = api.jobMap.get(jobId);
  if (!job) return null;
  const rj = toRuleJob(job);
  const ctx = api.ctxFor(rj);
  const name = (id: string) => api.people.find((p) => p.id === id)?.name ?? "Unknown";
  const start = job.start_date;
  const days = start ? jobDays(start, { value: rj.duration_value, unit: rj.duration_unit }, ctx.week) : [];
  const ranked = crewOpen && start ? findCrew(rj, start, ctx) : [];

  const add = async (personId: string) => {
    setBusy(true);
    await applyPlacement({ qc, workspaceId, job, ctx, team: [...ctx.jobCrew, personId], days, label: `Added ${name(personId)} to ${job.code}` });
    setBusy(false);
  };
  const use = async (o: SlotOption) => {
    setBusy(true);
    const ok = await applyPlacement({ qc, workspaceId, job, ctx, team: o.team, days: o.days, label: `${job.code} booked from ${fmt(o.start)}` });
    setBusy(false);
    if (ok) setSlots(null);
  };

  return (
    <div className="space-y-4">
      <fieldset className="space-y-3 rounded-md border p-4">
        <legend className="px-1 font-heading text-sm font-semibold uppercase tracking-wide">Crew</legend>
        <p className="text-sm">
          {ctx.jobCrew.length ? ctx.jobCrew.map(name).join(", ") : "Nobody yet"} <span className="text-muted-foreground">· {ctx.jobCrew.length}/{job.crew_size}</span>
        </p>
        {start ? (
          <Button variant="outline" onClick={() => setCrewOpen(!crewOpen)}>{crewOpen ? "Hide" : "Find crew"}</Button>
        ) : <p className="text-sm text-muted-foreground">Give the job dates (Find a slot below) to find crew for those days.</p>}
        {crewOpen && (
          <ul className="divide-y rounded-md border">
            {ranked.map((r) => {
              const p = api.people.find((x) => x.id === r.personId)!;
              return (
                <li key={r.personId} className={`flex items-start gap-3 px-3 py-2 ${r.busy ? "opacity-60" : ""}`}>
                  <span className="w-10 shrink-0 text-right font-mono text-lg font-semibold">{r.score}</span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium">{p.name} <span className="text-muted-foreground">· {crewRoleLabel[p.role]}</span></p>
                    <p className="text-xs text-muted-foreground">{r.reasons.join(" · ")}</p>
                  </div>
                  <Button size="sm" disabled={busy || job.locked} onClick={() => add(r.personId)}>Add</Button>
                </li>
              );
            })}
            {!ranked.length && <li className="px-3 py-2 text-sm text-muted-foreground">No one else to suggest.</li>}
          </ul>
        )}
      </fieldset>

      <fieldset className="space-y-3 rounded-md border p-4">
        <legend className="px-1 font-heading text-sm font-semibold uppercase tracking-wide">Schedule this job</legend>
        {job.locked && <p className="text-sm text-warn">This job is locked. Unlock it to move it.</p>}
        <div className="flex flex-wrap gap-2">
          <Button disabled={job.locked} onClick={() => setSlots(findSlot(rj, ctx))}>Find a slot</Button>
          <Button variant="outline" disabled={job.locked} onClick={() => navigate({ to: "/schedule", search: { place: job.id } })}>Place on schedule</Button>
        </div>
        {slots && !slots.options.length && <p className="rounded-sm bg-warn-soft p-2 text-sm">No slot found. {slots.reason}.</p>}
        {slots?.options.map((o, i) => (
          <div key={o.start} className="rounded-md border bg-card p-3">
            <div className="flex items-start gap-2">
              <div className="min-w-0 flex-1">
                <p className="font-medium">Option {i + 1}: {fmt(o.days[0]!)}{o.days.length > 1 && ` – ${fmt(o.days[o.days.length - 1]!)}`}</p>
                <p className="text-sm">{o.team.map(name).join(", ")}</p>
                <p className="text-xs text-muted-foreground">Average drive {o.averageDrive != null ? `${o.averageDrive} min` : "unknown (no site or base location)"}</p>
              </div>
              <Button size="sm" disabled={busy} onClick={() => use(o)}>Use this</Button>
            </div>
            {[...o.notes, ...o.warnings].length > 0 && (
              <ul className="mt-2 space-y-0.5 text-xs">
                {o.notes.map((n) => <li key={n} className="text-muted-foreground">{n}</li>)}
                {o.warnings.map((w) => <li key={w} className="text-warn">{w}</li>)}
              </ul>
            )}
          </div>
        ))}
      </fieldset>
    </div>
  );
}
