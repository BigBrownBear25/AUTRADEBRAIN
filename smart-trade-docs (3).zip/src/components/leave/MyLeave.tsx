import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { leaveQuery } from "@/lib/leave";
import { hm } from "@/lib/assignments";
import { todayIso } from "@/lib/rules/ticket-expiry";
import { useLeaveSettings } from "./LeavePanel";

const fmt = (d: string) => new Date(`${d}T00:00:00`).toLocaleDateString("en-AU", { weekday: "short", day: "numeric", month: "short" });
const STATUS = { requested: "Requested", approved: "Approved", declined: "Declined" } as const;

/** Field: own leave (RLS returns only theirs), request leave, edit or withdraw while still requested. */
export function MyLeave({ workspaceId, crewMemberId }: { workspaceId: string; crewMemberId: string }) {
  const qc = useQueryClient();
  const today = todayIso();
  const { data: leave = [] } = useQuery(leaveQuery(workspaceId));
  const { data: settings } = useLeaveSettings(workspaceId);
  const types = settings?.leave_types ?? [];
  const blank = { id: null as string | null, type: "", from_date: today, to_date: today, partDay: false, start_time: "07:00", end_time: "11:30", note: "" };
  const [f, setF] = useState<typeof blank | null>(null);
  const refresh = () => qc.invalidateQueries({ queryKey: ["leave", workspaceId] });

  const save = async () => {
    if (!f) return;
    const row = {
      workspace_id: workspaceId, crew_member_id: crewMemberId, type: f.type || types[0] || "annual leave",
      from_date: f.from_date, to_date: f.to_date < f.from_date ? f.from_date : f.to_date,
      start_time: f.partDay ? f.start_time : null, end_time: f.partDay ? f.end_time : null, note: f.note || null,
    };
    const { error } = f.id ? await supabase.from("leave").update(row).eq("id", f.id) : await supabase.from("leave").insert(row);
    if (error) { toast.error(error.message); return; }
    toast.success(f.id ? "Request updated" : "Leave requested");
    setF(null); refresh();
  };
  const withdraw = async (id: string) => {
    const { error } = await supabase.from("leave").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast("Request withdrawn"); refresh();
  };

  const mine = leave.filter((l) => l.to_date >= today);
  return (
    <section className="mt-6 rounded-md border bg-card p-5">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold uppercase">My leave</h2>
        {!f && <Button onClick={() => setF(blank)}>Request leave</Button>}
      </div>
      {f && (
        <div className="mt-3 grid gap-3 rounded-md border p-3 sm:grid-cols-2">
          <div className="space-y-1.5"><Label>Type</Label>
            <select className="h-11 w-full rounded-md border bg-background px-3 text-sm capitalize" value={f.type || types[0]} onChange={(e) => setF({ ...f, type: e.target.value })}>
              {types.map((t) => <option key={t}>{t}</option>)}
            </select></div>
          <div className="space-y-1.5"><Label>Note (optional)</Label><Input className="h-11" value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>From</Label><Input className="h-11" type="date" value={f.from_date} onChange={(e) => setF({ ...f, from_date: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>To</Label><Input className="h-11" type="date" min={f.from_date} value={f.to_date} onChange={(e) => setF({ ...f, to_date: e.target.value })} /></div>
          <label className="flex min-h-11 items-center gap-2 text-sm"><Checkbox checked={f.partDay} onCheckedChange={(c) => setF({ ...f, partDay: !!c })} />Part day</label>
          {f.partDay && <div className="flex gap-2">
            <Input className="h-11" type="time" value={f.start_time} onChange={(e) => setF({ ...f, start_time: e.target.value })} aria-label="Start" />
            <Input className="h-11" type="time" value={f.end_time} onChange={(e) => setF({ ...f, end_time: e.target.value })} aria-label="Finish" />
          </div>}
          <div className="flex justify-end gap-2 sm:col-span-2">
            <Button variant="outline" onClick={() => setF(null)}>Cancel</Button>
            <Button onClick={save}>{f.id ? "Save" : "Send request"}</Button>
          </div>
        </div>
      )}
      <ul className="mt-3 divide-y text-sm">
        {!mine.length && <li className="py-2 text-muted-foreground">No leave coming up.</li>}
        {mine.map((l) => (
          <li key={l.id} className="flex flex-wrap items-center gap-2 py-2">
            <span className="capitalize">{l.type}</span>
            <span>{fmt(l.from_date)}{l.to_date !== l.from_date && ` – ${fmt(l.to_date)}`}{l.start_time && ` · ${hm(l.start_time)}–${hm(l.end_time!)}`}</span>
            <span className={`rounded-sm px-1.5 text-xs ${l.status === "approved" ? "bg-fit-soft text-fit" : l.status === "declined" ? "bg-clash-soft text-clash" : "bg-warn-soft"}`}>{STATUS[l.status]}</span>
            {l.status === "requested" && (
              <span className="ml-auto flex gap-1">
                <Button size="sm" variant="ghost" onClick={() => setF({ id: l.id, type: l.type, from_date: l.from_date, to_date: l.to_date, partDay: !!l.start_time, start_time: hm(l.start_time ?? "07:00"), end_time: hm(l.end_time ?? "11:30"), note: l.note ?? "" })}>Edit</Button>
                <Button size="sm" variant="ghost" onClick={() => withdraw(l.id)}>Withdraw</Button>
              </span>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}
