import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { crewQuery } from "@/lib/crew";
import { leaveQuery, useDaysOff } from "@/lib/leave";
import { hm, standardHoursQuery } from "@/lib/assignments";
import { leaveClashes, leaveOnDay, type LeaveRow } from "@/lib/rules/leave";
import { addDays, boardColumns, closureOn, mondayOf } from "@/lib/rules/board";
import { todayIso } from "@/lib/rules/ticket-expiry";

const fmt = (d: string) => new Date(`${d}T00:00:00`).toLocaleDateString("en-AU", { weekday: "short", day: "numeric", month: "short" });
const range = (l: { from_date: string; to_date: string; start_time: string | null; end_time: string | null }) =>
  `${fmt(l.from_date)}${l.to_date !== l.from_date ? ` – ${fmt(l.to_date)}` : ""}${l.start_time ? ` · ${hm(l.start_time)}–${hm(l.end_time!)}` : ""}`;

function useLeaveSettings(workspaceId: string) {
  return useQuery({
    queryKey: ["workspace_settings", workspaceId, "leave"],
    queryFn: async () => {
      const { data, error } = await supabase.from("workspace_settings").select("leave_types, holiday_states, working_days").eq("workspace_id", workspaceId).single();
      if (error) throw error;
      return data;
    },
  });
}

/** Office: requests to approve with clash warnings, add leave, closures and holidays, and the leave planner. */
export function LeavePanel({ workspaceId }: { workspaceId: string }) {
  const qc = useQueryClient();
  const today = todayIso();
  const { data: crew = [] } = useQuery(crewQuery(workspaceId));
  const { data: leave = [] } = useQuery(leaveQuery(workspaceId));
  const { data: settings } = useLeaveSettings(workspaceId);
  const daysOff = useDaysOff(workspaceId, settings?.holiday_states) ?? [];
  const { data: bookings = [] } = useQuery({
    queryKey: ["board-assignments", workspaceId, "leave"],
    queryFn: async () => {
      const { data, error } = await supabase.from("assignments").select("crew_member_id, job_id, date, start_time, end_time, jobs(code)").eq("workspace_id", workspaceId).gte("date", addDays(today, -1));
      if (error) throw error;
      return data;
    },
  });
  const name = (id: string) => crew.find((c) => c.id === id)?.name ?? "Unknown";
  const bk = bookings.map((b) => ({ crew_member_id: b.crew_member_id, job_id: b.job_id, date: b.date, start: hm(b.start_time), end: hm(b.end_time), code: (b.jobs as { code: string } | null)?.code ?? "" }));
  const requests = leave.filter((l) => l.status === "requested" && l.to_date >= today);
  const refresh = () => { qc.invalidateQueries({ queryKey: ["leave", workspaceId] }); };

  const decide = async (id: string, status: "approved" | "declined") => {
    const { error } = await supabase.from("leave").update({ status }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success(status === "approved" ? "Leave approved" : "Leave declined");
    refresh();
  };
  const remove = async (id: string) => {
    const { error } = await supabase.from("leave").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    refresh();
  };

  return (
    <div className="space-y-6">
      <section>
        <h3 className="font-heading text-lg font-semibold uppercase">Requests to approve <span className="text-muted-foreground">· {requests.length}</span></h3>
        {!requests.length && <p className="mt-1 text-sm text-muted-foreground">No leave waiting for a decision.</p>}
        <ul className="mt-2 space-y-2">
          {requests.map((l) => {
            const clashes = leaveClashes(l, bk) as typeof bk;
            return (
              <li key={l.id} className={`rounded-md border border-l-4 bg-card p-3 ${clashes.length ? "border-l-clash" : "border-l-fit"}`}>
                <div className="flex flex-wrap items-start gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="font-medium">{name(l.crew_member_id)} · <span className="capitalize">{l.type}</span></p>
                    <p className="text-sm">{range(l)}</p>
                    {l.note && <p className="text-sm text-muted-foreground">{l.note}</p>}
                    {clashes.length
                      ? <p className="mt-1 text-sm text-clash">Clash: booked on {[...new Set(clashes.map((c) => `${c.code} ${fmt(c.date)}`))].join(", ")}</p>
                      : <p className="mt-1 text-sm text-fit">No bookings on these days</p>}
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => decide(l.id, "declined")}>Decline</Button>
                    <Button size="sm" variant={clashes.length ? "destructive" : "default"} onClick={() => decide(l.id, "approved")}>{clashes.length ? "Approve anyway" : "Approve"}</Button>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      </section>

      <AddLeave workspaceId={workspaceId} people={crew.filter((c) => c.active).map((c) => ({ id: c.id, name: c.name }))} types={settings?.leave_types ?? []} onDone={refresh} />

      <LeavePlanner people={crew.filter((c) => c.active)} leave={leave} daysOff={daysOff} workingDays={settings?.working_days ?? [1, 2, 3, 4, 5]} onRemove={remove} />

      <section>
        <div className="flex items-center justify-between">
          <h3 className="font-heading text-lg font-semibold uppercase">Closures and public holidays</h3>
          <Link to="/settings" className="text-sm text-primary underline-offset-2 hover:underline">Edit closures in Settings</Link>
        </div>
        <ul className="mt-2 grid gap-1 text-sm sm:grid-cols-2">
          {daysOff.filter((d) => d.to_date >= today && d.from_date <= addDays(today, 120)).sort((a, b) => a.from_date.localeCompare(b.from_date)).map((d) => (
            <li key={d.from_date + d.name} className="flex gap-2 rounded-sm border bg-card px-2 py-1"><span className="w-40 shrink-0">{range({ ...d, start_time: null, end_time: null })}</span><span className="text-muted-foreground">{d.name}</span></li>
          ))}
        </ul>
      </section>
    </div>
  );
}

function AddLeave({ workspaceId, people, types, onDone }: { workspaceId: string; people: { id: string; name: string }[]; types: string[]; onDone: () => void }) {
  const today = todayIso();
  const [f, setF] = useState({ crew_member_id: "", type: "", from_date: today, to_date: today, partDay: false, start_time: "07:00", end_time: "11:30", note: "", approved: true });
  const [busy, setBusy] = useState(false);
  const save = async () => {
    if (!f.crew_member_id || !(f.type || types[0])) { toast.error("Pick a person and leave type"); return; }
    setBusy(true);
    const { error } = await supabase.from("leave").insert({
      workspace_id: workspaceId, crew_member_id: f.crew_member_id, type: f.type || types[0]!, from_date: f.from_date, to_date: f.to_date,
      start_time: f.partDay ? f.start_time : null, end_time: f.partDay ? f.end_time : null, note: f.note || null,
      status: f.approved ? "approved" : "requested",
    });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Leave added");
    setF({ ...f, note: "" });
    onDone();
  };
  return (
    <fieldset className="rounded-md border p-4">
      <legend className="px-1 font-heading text-sm font-semibold uppercase tracking-wide">Add leave</legend>
      <div className="grid gap-3 sm:grid-cols-3">
        <div className="space-y-1.5"><Label>Person</Label>
          <select className="h-10 w-full rounded-md border bg-background px-3 text-sm" value={f.crew_member_id} onChange={(e) => setF({ ...f, crew_member_id: e.target.value })}>
            <option value="">—</option>{people.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select></div>
        <div className="space-y-1.5"><Label>Type</Label>
          <select className="h-10 w-full rounded-md border bg-background px-3 text-sm capitalize" value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}>
            {types.map((t) => <option key={t}>{t}</option>)}
          </select></div>
        <div className="space-y-1.5"><Label>Note</Label><Input value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} /></div>
        <div className="space-y-1.5"><Label>From</Label><Input type="date" value={f.from_date} onChange={(e) => setF({ ...f, from_date: e.target.value, to_date: e.target.value > f.to_date ? e.target.value : f.to_date })} /></div>
        <div className="space-y-1.5"><Label>To</Label><Input type="date" min={f.from_date} value={f.to_date} onChange={(e) => setF({ ...f, to_date: e.target.value })} /></div>
        <div className="flex flex-col justify-end gap-2 text-sm">
          <label className="flex items-center gap-2"><Checkbox checked={f.partDay} onCheckedChange={(c) => setF({ ...f, partDay: !!c })} />Part day</label>
          <label className="flex items-center gap-2"><Checkbox checked={f.approved} onCheckedChange={(c) => setF({ ...f, approved: !!c })} />Approved</label>
        </div>
        {f.partDay && <>
          <div className="space-y-1.5"><Label>Start</Label><Input type="time" value={f.start_time} onChange={(e) => setF({ ...f, start_time: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Finish</Label><Input type="time" value={f.end_time} onChange={(e) => setF({ ...f, end_time: e.target.value })} /></div>
        </>}
      </div>
      <div className="mt-3 flex justify-end"><Button disabled={busy} onClick={save}>Add leave</Button></div>
    </fieldset>
  );
}

function LeavePlanner({ people, leave, daysOff, workingDays, onRemove }: {
  people: { id: string; name: string }[]; leave: (LeaveRow & { note: string | null })[];
  daysOff: { from_date: string; to_date: string; name: string }[]; workingDays: number[]; onRemove: (id: string) => void;
}) {
  const today = todayIso();
  const [start, setStart] = useState(mondayOf(today));
  const cols = useMemo(() => boardColumns(start, addDays(start, 41), workingDays), [start, workingDays]);
  const [sel, setSel] = useState<string | null>(null);
  const selected = leave.find((l) => l.id === sel);
  return (
    <section>
      <div className="flex flex-wrap items-center gap-2">
        <h3 className="font-heading text-lg font-semibold uppercase">Leave planner</h3>
        <div className="ml-auto flex items-center gap-1">
          <Button size="icon" variant="outline" aria-label="Earlier" onClick={() => setStart(addDays(start, -42))}><ChevronLeft className="h-4 w-4" /></Button>
          <Button variant="outline" onClick={() => setStart(mondayOf(today))}>Today</Button>
          <Button size="icon" variant="outline" aria-label="Later" onClick={() => setStart(addDays(start, 42))}><ChevronRight className="h-4 w-4" /></Button>
        </div>
      </div>
      <div className="mt-2 overflow-x-auto rounded-md border bg-card">
        <table className="min-w-max border-collapse text-xs">
          <thead>
            <tr>
              <th className="sticky left-0 z-10 min-w-40 border-b border-r bg-card px-2 py-1 text-left">Person</th>
              {cols.map((d) => {
                const off = closureOn(d, daysOff);
                return <th key={d} title={off?.name} className={`w-8 border-b border-r px-0.5 py-1 font-normal ${d === today ? "bg-primary/15 font-semibold text-primary" : ""} ${off ? "shade-closure" : ""}`}>
                  <span className="block text-[10px] text-muted-foreground">{new Date(`${d}T00:00:00`).toLocaleDateString("en-AU", { weekday: "narrow" })}</span>{+d.slice(8)}
                </th>;
              })}
            </tr>
          </thead>
          <tbody>
            {people.map((p) => (
              <tr key={p.id}>
                <td className="sticky left-0 border-b border-r bg-card px-2 py-1 font-medium">{p.name}</td>
                {cols.map((d) => {
                  const l = leaveOnDay(leave, p.id, d);
                  const off = closureOn(d, daysOff);
                  return (
                    <td key={d} className={`h-7 border-b border-r p-0.5 ${off ? "shade-closure" : ""}`}>
                      {l && <button title={`${l.type}${l.status === "requested" ? " (requested)" : ""}`} onClick={() => setSel(l.id)}
                        className={`block h-full w-full rounded-sm hatch-leave ${l.status === "requested" ? "border border-dashed border-muted-foreground" : ""} ${sel === l.id ? "ring-2 ring-primary" : ""}`} />}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {selected && (
        <div className="mt-2 flex flex-wrap items-center gap-2 rounded-md border bg-card p-2 text-sm">
          <span className="font-medium">{people.find((p) => p.id === selected.crew_member_id)?.name}</span>
          <span className="capitalize">{selected.type}</span><span>{range(selected)}</span>
          <span className="text-muted-foreground">{selected.status}</span>
          <Button size="sm" variant="outline" className="ml-auto" onClick={() => { onRemove(selected.id); setSel(null); }}>Delete</Button>
        </div>
      )}
      <p className="mt-1 text-xs text-muted-foreground">Grey hatching is approved leave; dashed is requested. Shaded columns are closures and public holidays.</p>
    </section>
  );
}

export { useLeaveSettings };
