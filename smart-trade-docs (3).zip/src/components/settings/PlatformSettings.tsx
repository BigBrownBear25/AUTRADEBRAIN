import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Download } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { exportWorkspace } from "@/lib/export.functions";

type Membership = { workspaceId: string; role: string };

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
}

function toCsv(rows: Record<string, unknown>[]) {
  if (!rows.length) return "";
  const cols = [...new Set(rows.flatMap((r) => Object.keys(r)))];
  const cell = (v: unknown) => {
    const s = v == null ? "" : typeof v === "object" ? JSON.stringify(v) : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [cols.join(","), ...rows.map((r) => cols.map((c) => cell(r[c])).join(","))].join("\n");
}

/** Owner only: demo data switch, usage per workspace, data export. */
export function PlatformSettings({ membership }: { membership: Membership }) {
  if (membership.role !== "owner") return null;
  return (
    <>
      <DemoSwitch ws={membership.workspaceId} />
      <Usage ws={membership.workspaceId} />
      <Export ws={membership.workspaceId} />
    </>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-md border bg-card p-5">
      <h2 className="font-heading text-xl font-semibold uppercase">{title}</h2>
      <div className="mt-3">{children}</div>
    </section>
  );
}

function DemoSwitch({ ws }: { ws: string }) {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["demo", ws], queryFn: async () => (await supabase.from("workspaces").select("demo_data").eq("id", ws).single()).data });
  const [busy, setBusy] = useState(false);
  async function set(on: boolean) {
    if (!on && !confirm("Remove all demo crew, jobs and bookings?")) return;
    setBusy(true);
    const { error } = await supabase.rpc("set_demo_data", { _ws: ws, _on: on });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success(on ? "Demo data added" : "Demo data removed");
    qc.invalidateQueries();
  }
  return (
    <Panel title="Demo data">
      <label className="flex items-center gap-3">
        <Switch checked={!!q.data?.demo_data} disabled={busy || !q.data} onCheckedChange={set} />
        <span className="text-sm">Show sample crew, jobs and bookings, each named “Demo — …”. Turning it off removes only those rows; your real data is never touched.</span>
      </label>
    </Panel>
  );
}

const KIND_LABEL: Record<string, string> = { ai: "Claude (tokens)", maps: "Google Maps (routes)", email: "Inbound email (emails)" };

function Usage({ ws }: { ws: string }) {
  const since = new Date(Date.now() - 30 * 86400000).toISOString();
  const q = useQuery({
    queryKey: ["usage", ws],
    queryFn: async () => {
      const { data, error } = await supabase.from("usage_events").select("kind, units, detail").eq("workspace_id", ws).gte("at", since).limit(10000);
      if (error) throw error;
      return data;
    },
  });
  const totals = new Map<string, { units: number; calls: number }>();
  for (const r of q.data ?? []) {
    const t = totals.get(r.kind) ?? { units: 0, calls: 0 };
    t.units += r.units; t.calls += 1; totals.set(r.kind, t);
  }
  return (
    <Panel title="Usage, last 30 days">
      <div className="grid gap-3 sm:grid-cols-3">
        {["ai", "maps", "email"].map((k) => (
          <div key={k} className="rounded-md border p-3">
            <p className="text-xs text-muted-foreground">{KIND_LABEL[k]}</p>
            <p className="font-heading text-2xl font-semibold">{(totals.get(k)?.units ?? 0).toLocaleString("en-AU")}</p>
            <p className="text-xs text-muted-foreground">{totals.get(k)?.calls ?? 0} calls</p>
          </div>
        ))}
      </div>
    </Panel>
  );
}

function Export({ ws }: { ws: string }) {
  const run = useServerFn(exportWorkspace);
  const [file, setFile] = useState<{ json: Blob; zip: Blob; counts: [string, number][] } | null>(null);
  const [busy, setBusy] = useState(false);
  async function prepare() {
    setBusy(true);
    try {
      const raw = await run({ data: { workspaceId: ws } });
      const out = JSON.parse(raw) as { tables: Record<string, Record<string, unknown>[]> };
      const json = new Blob([JSON.stringify(out, null, 2)], { type: "application/json" });
      const { default: JSZip } = await import("jszip");
      const zip = new JSZip();
      for (const [t, rows] of Object.entries(out.tables)) zip.file(`${t}.csv`, toCsv(rows));
      const zb = await zip.generateAsync({ type: "blob" });
      setFile({ json, zip: zb, counts: Object.entries(out.tables).map(([t, r]) => [t, r.length]) });
    } catch (e) { toast.error(e instanceof Error ? e.message : "Export failed"); }
    finally { setBusy(false); }
  }
  const stamp = new Date().toISOString().slice(0, 10);
  return (
    <Panel title="Data export">
      <p className="text-sm text-muted-foreground">Everything in this workspace, every table, as one JSON file or a ZIP of CSV files.</p>
      <div className="mt-3 flex flex-wrap gap-2">
        <Button onClick={prepare} disabled={busy}>{busy ? "Preparing…" : file ? "Prepare again" : "Prepare export"}</Button>
        {file && <>
          <Button variant="outline" onClick={() => downloadBlob(file.json, `trade-brain-${stamp}.json`)}><Download className="mr-1 h-4 w-4" />JSON</Button>
          <Button variant="outline" onClick={() => downloadBlob(file.zip, `trade-brain-${stamp}-csv.zip`)}><Download className="mr-1 h-4 w-4" />CSV (ZIP)</Button>
        </>}
      </div>
      {file && (
        <ul className="mt-3 grid grid-cols-2 gap-x-4 text-xs text-muted-foreground sm:grid-cols-4">
          {file.counts.map(([t, n]) => <li key={t}><span className="font-mono">{t}</span> {n}</li>)}
        </ul>
      )}
    </Panel>
  );
}
