import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Section } from "./SettingsForms";
import { PushToggle } from "@/components/brain/PushToggle";
import { useServerFn } from "@tanstack/react-start";
import { runBrainNow } from "@/lib/brain-run.functions";
import type { ActiveMembership } from "@/lib/session";

type BS = Database["public"]["Tables"]["brain_settings"]["Row"];
import { JOB_LABEL } from "@/lib/rules/job-health";
const FEATURES: [string, string][] = [
  ["capture", "Brain bar"], ["job_ai", "Inspection summary and install guidance"], ["ask", "Ask Trade Brain"], ["watcher", "Watcher (live alerts)"], ["overnight", "Overnight draft plan"],
  ["lookahead", "Monday look-ahead"], ["email", "Reading emails"], ["photos", "Reading photos"], ["documents", "Reading documents"],
  ["variations", "Variations"], ["swms", "SWMS drafts"], ["memory", "Memory and search"], ["sms", "Text messages"],
];
const FN_LABEL: Record<string, string> = {
  capture: "Brain bar", ask: "Ask", brief: "Morning brief", summary: "Inspection summary", guidance: "Install guidance", drafting: "Drafting",
  documents: "Documents", lookahead: "Look-ahead", watcher: "Watcher", closeout: "Close-outs", email_sort: "Sorting emails", email_match: "Matching emails", photo_tag: "Tagging photos",
};
const MODELS = ["anthropic/claude-sonnet-5", "anthropic/claude-haiku-4-5", "anthropic/claude-opus-5"];

/** Brain section: office can see it; only the owner changes it. */
export function BrainSettings({ membership }: { membership: ActiveMembership }) {
  const qc = useQueryClient();
  const ws = membership.workspaceId;
  const owner = membership.role === "owner";
  const { data } = useQuery({ queryKey: ["brain_settings", ws], queryFn: async () => (await supabase.from("brain_settings").select("*").eq("workspace_id", ws).maybeSingle()).data });
  const usage = useQuery({
    queryKey: ["ai_runs", ws, "month"], enabled: owner,
    queryFn: async () => {
      const start = new Date(); start.setDate(1); start.setHours(0, 0, 0, 0);
      const { data } = await supabase.from("ai_runs").select("cost_aud, function, ok").eq("workspace_id", ws).gte("at", start.toISOString());
      return data ?? [];
    },
  });
  const runs = useQuery({ queryKey: ["job_runs"], enabled: owner, refetchInterval: 60_000, queryFn: async () => (await supabase.rpc("background_health")).data ?? [] });
  const cfg = useQuery({ queryKey: ["ai_config", ws], enabled: owner, queryFn: async () => (await supabase.from("ai_config").select("*").eq("workspace_id", ws).order("function")).data ?? [] });
  const [b, setB] = useState<BS | null>(null);
  useEffect(() => { if (data) setB(data); }, [data]);
  if (!b) return null;
  const features = (b.features ?? {}) as Record<string, boolean>;
  const spent = (usage.data ?? []).reduce((s, r) => s + Number(r.cost_aud), 0);
  const pct = Number(b.monthly_ai_budget) > 0 ? Math.min(100, Math.round((spent / Number(b.monthly_ai_budget)) * 100)) : 0;

  const save = async () => {
    const { error } = await supabase.from("brain_settings").update({
      features: b.features, quiet_from: b.quiet_from, quiet_to: b.quiet_to, monthly_ai_budget: b.monthly_ai_budget,
      sms_auto_reminders: b.sms_auto_reminders, variation_price_to_builder: b.variation_price_to_builder, updated_at: new Date().toISOString(),
    }).eq("workspace_id", ws);
    if (error) { toast.error(error.message); return; }
    toast.success("Brain settings saved");
    qc.invalidateQueries({ queryKey: ["brain_settings", ws] });
  };
  const setModel = async (fn: string, model: string) => {
    const { error } = await supabase.from("ai_config").update({ model }).eq("workspace_id", ws).eq("function", fn);
    if (error) toast.error(error.message); else { toast.success("Model updated"); qc.invalidateQueries({ queryKey: ["ai_config", ws] }); }
  };

  return (
    <Section title="Brain" footer={owner && <Button className="h-11" onClick={save}>Save</Button>}>
      <div className="grid gap-2 sm:grid-cols-2">
        {FEATURES.map(([k, label]) => (
          <label key={k} className="flex min-h-11 items-center justify-between gap-3 rounded-md border px-3 text-sm">
            {label}
            <Switch disabled={!owner} checked={features[k] !== false} onCheckedChange={(c) => setB({ ...b, features: { ...features, [k]: c } })} />
          </label>
        ))}
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        <label className="text-sm">Quiet hours from<Input disabled={!owner} type="time" value={b.quiet_from.slice(0, 5)} onChange={(e) => setB({ ...b, quiet_from: e.target.value })} /></label>
        <label className="text-sm">Quiet hours to<Input disabled={!owner} type="time" value={b.quiet_to.slice(0, 5)} onChange={(e) => setB({ ...b, quiet_to: e.target.value })} /></label>
        <label className="text-sm">Monthly AI budget ($)<Input disabled={!owner} type="number" min={0} value={b.monthly_ai_budget} onChange={(e) => setB({ ...b, monthly_ai_budget: Number(e.target.value) })} /></label>
      </div>
      {owner && (
        <div>
          <p className="text-sm font-medium">Background jobs</p>
          <ul className="mt-1 grid gap-1 text-sm">
            {Object.keys(JOB_LABEL).map((k) => {
              const r = (runs.data ?? []).find((x) => x.job === k);
              const late = r ? r.late : k === "overnight";
              return (
                <li key={k} className={`flex flex-wrap items-center justify-between gap-2 rounded-md border px-3 py-2 ${late ? "border-destructive text-destructive" : ""}`}>
                  <span>{JOB_LABEL[k]}</span>
                  <span className="text-xs">{r?.last_ok_at ? `Last succeeded ${new Date(r.last_ok_at).toLocaleString("en-AU", { dateStyle: "medium", timeStyle: "short" })}` : "Never succeeded"}{late ? " · Late or failing" : ""}</span>
                </li>
              );
            })}
          </ul>
        </div>
      )}
      {owner && (
        <div>
          <div className="flex justify-between text-sm"><span>Used this month</span><span className="font-mono">${spent.toFixed(2)} of ${Number(b.monthly_ai_budget).toFixed(0)} · {pct}%</span></div>
          <div className="mt-1 h-2 rounded-full bg-muted"><div className={`h-2 rounded-full ${pct >= 100 ? "bg-clash" : pct >= 80 ? "bg-warn" : "bg-fit"}`} style={{ width: `${pct}%` }} /></div>
          <p className="mt-1 text-xs text-muted-foreground">At 80% you're notified. At 100% photo tagging, the look-ahead, document reading and close-outs pause; the Brain bar, Ask, the morning brief, the watcher and safety drafting keep running.</p>
        </div>
      )}
      <div className="grid gap-2 sm:grid-cols-2">
        <label className="flex min-h-11 items-center justify-between gap-3 rounded-md border px-3 text-sm">Send day-before text reminders automatically
          <Switch disabled={!owner} checked={b.sms_auto_reminders} onCheckedChange={(c) => setB({ ...b, sms_auto_reminders: c })} /></label>
        <label className="flex min-h-11 items-center justify-between gap-3 rounded-md border px-3 text-sm">Show variation price to the builder
          <Switch disabled={!owner} checked={b.variation_price_to_builder} onCheckedChange={(c) => setB({ ...b, variation_price_to_builder: c })} /></label>
      </div>
      <PushToggle />
      {owner && (cfg.data ?? []).length > 0 && (
        <details className="rounded-md border p-3">
          <summary className="cursor-pointer text-sm font-medium">Models per task</summary>
          <div className="mt-2 grid gap-2 sm:grid-cols-2">
            {cfg.data!.map((c) => (
              <label key={c.function} className="flex items-center justify-between gap-2 text-sm">{FN_LABEL[c.function] ?? c.function}
                <select className="h-9 rounded-md border bg-background px-2 text-sm" value={c.model} onChange={(e) => setModel(c.function, e.target.value)}>
                  {[...new Set([c.model, ...MODELS])].map((m) => <option key={m} value={m}>{m.replace("anthropic/", "")}</option>)}
                </select>
              </label>
            ))}
          </div>
          <p className="mt-2 text-xs text-muted-foreground">After changing a model, run the <Link to="/ai-test" className="text-primary underline">AI test page</Link>.</p>
        </details>
      )}
      {owner && <RunNow ws={ws} />}
      {!owner && <p className="text-xs text-muted-foreground">Only the owner can change these.</p>}
    </Section>
  );
}

function RunNow({ ws }: { ws: string }) {
  const run = useServerFn(runBrainNow);
  const qc = useQueryClient();
  const [busy, setBusy] = useState<string | null>(null);
  const go = async (what: "draft" | "lookahead" | "watch") => {
    setBusy(what);
    try { await run({ data: { workspaceId: ws, what } }); qc.invalidateQueries(); toast.success(what === "watch" ? "Watcher checked recent changes" : what === "draft" ? "Draft plan made — see the Overview" : "Look-ahead written — see the Overview"); }
    catch (e) { toast.error((e as Error).message); }
    finally { setBusy(null); }
  };
  return (
    <div className="mt-3 flex flex-wrap gap-2">
      <span className="w-full text-xs text-muted-foreground">These run by themselves (watcher every minute, draft plan 3:30 am, look-ahead Monday 3:45 am). Run one now to try it:</span>
      <Button size="sm" variant="outline" disabled={!!busy} onClick={() => go("watch")}>Check changes now</Button>
      <Button size="sm" variant="outline" disabled={!!busy} onClick={() => go("draft")}>{busy === "draft" ? "Planning…" : "Make draft plan now"}</Button>
      <Button size="sm" variant="outline" disabled={!!busy} onClick={() => go("lookahead")}>{busy === "lookahead" ? "Writing…" : "Write look-ahead now"}</Button>
    </div>
  );
}
