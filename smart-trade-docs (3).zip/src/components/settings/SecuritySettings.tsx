import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Section } from "./SettingsForms";
import type { ActiveMembership } from "@/lib/session";
import { describeAudit, toCsv, type AuditRow } from "@/lib/rules/activity";
import { reviewDue, staleSignIn } from "@/lib/rules/access-review";

const fmt = (s: string | null) => (s ? new Date(s).toLocaleString("en-AU", { dateStyle: "medium", timeStyle: "short" }) : "Never");

function useMembers(ws: string, enabled: boolean) {
  return useQuery({ queryKey: ["member_access", ws], enabled, queryFn: async () => {
    const { data, error } = await supabase.rpc("member_access", { _ws: ws });
    if (error) throw error;
    return data ?? [];
  } });
}
const personName = (m: { crew_name: string | null; email: string | null }) => m.crew_name ?? m.email ?? "Someone";

/** Settings > People and access (owner only): every member, review record, flags and sign-out. */
export function PeopleAccess({ membership }: { membership: ActiveMembership }) {
  const ws = membership.workspaceId;
  const owner = membership.role === "owner";
  const qc = useQueryClient();
  const members = useMembers(ws, owner);
  const reviews = useQuery({ queryKey: ["access_reviews", ws], enabled: owner, queryFn: async () =>
    (await supabase.from("access_reviews").select("reviewed_at, reviewed_by").eq("workspace_id", ws).order("reviewed_at", { ascending: false }).limit(5)).data ?? [] });
  if (!owner) return null;
  const list = members.data ?? [];
  const last = reviews.data?.[0] ?? null;
  const due = reviewDue(last?.reviewed_at ?? null);
  const reviewer = (id: string) => { const m = list.find((x) => x.user_id === id); return m ? personName(m) : "Someone"; };

  const markReviewed = async () => {
    const { error } = await supabase.from("access_reviews").insert({ workspace_id: ws, member_count: list.length });
    if (error) { toast.error(error.message); return; }
    toast.success("Access review recorded");
    qc.invalidateQueries({ queryKey: ["access_reviews", ws] });
  };
  const signOutMember = async (userId: string, name: string) => {
    if (!window.confirm(`Sign ${name} out of every device? They'll need to sign in again.`)) return;
    const { error } = await supabase.rpc("sign_out_member", { _ws: ws, _user: userId });
    if (error) { toast.error(error.message); return; }
    toast.success(`${name} is signed out everywhere`);
  };

  return (
    <Section title="People and access" footer={<Button onClick={markReviewed} disabled={!list.length}>Mark reviewed</Button>}>
      <p className={`rounded-md border px-3 py-2 text-sm ${due ? "border-warn bg-warn-soft" : ""}`}>
        {last ? `Last reviewed ${fmt(last.reviewed_at)} by ${reviewer(last.reviewed_by)}.` : "Access hasn't been reviewed yet."}
        {due ? " A review is due: check everyone below still needs their access, then press Mark reviewed." : " Next review due within 90 days of that."}
      </p>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-xs uppercase text-muted-foreground">
            <tr><th className="py-1 pr-3">Person</th><th className="pr-3">Role</th><th className="pr-3">Status</th><th className="pr-3">Last sign-in</th><th className="pr-3">Two-factor</th><th className="pr-3">Crew record</th><th /></tr>
          </thead>
          <tbody>
            {list.map((m) => {
              const stale = staleSignIn({ status: m.status, last_sign_in_at: m.last_sign_in_at });
              return (
                <tr key={m.membership_id} className="border-t align-middle">
                  <td className="py-2 pr-3">{m.email ?? "—"}</td>
                  <td className="pr-3 capitalize">{m.role}</td>
                  <td className="pr-3 capitalize">{m.status}</td>
                  <td className={`pr-3 ${stale ? "font-medium text-destructive" : ""}`}>{fmt(m.last_sign_in_at)}{stale ? " · no sign-in for 60 days" : ""}</td>
                  <td className="pr-3">{m.two_factor ? "On" : "Off"}</td>
                  <td className="pr-3">{m.crew_name ?? "—"}</td>
                  <td className="text-right">{m.user_id && m.status === "active" && (
                    <Button size="sm" variant="outline" onClick={() => signOutMember(m.user_id!, personName(m))}>Sign out of all devices</Button>
                  )}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Section>
  );
}

const ACTIONS = ["insert", "update", "delete"];
const ACTION_LABEL: Record<string, string> = { insert: "Added", update: "Changed", delete: "Deleted" };

/** Settings > Activity (owner only): the audit log in plain English with filters and CSV export. Finance rows are filtered by the database. */
export function ActivityLog({ membership }: { membership: ActiveMembership }) {
  const ws = membership.workspaceId;
  const owner = membership.role === "owner";
  const [f, setF] = useState({ person: "", table: "", action: "", from: "", to: "", reason: "" });
  const members = useMembers(ws, owner);
  const jobs = useQuery({ queryKey: ["activity_jobs", ws], enabled: owner, queryFn: async () => (await supabase.from("jobs").select("id, code").eq("workspace_id", ws)).data ?? [] });
  const rows = useQuery({
    queryKey: ["activity", ws, f], enabled: owner,
    queryFn: async () => {
      let q = supabase.from("audit_log").select("id, actor_user_id, action, table_name, row_id, before, after, at, reason").eq("workspace_id", ws).order("at", { ascending: false }).limit(500);
      if (f.person) q = q.eq("actor_user_id", f.person);
      if (f.table) q = q.eq("table_name", f.table);
      if (f.action) q = q.eq("action", f.action);
      if (f.from) q = q.gte("at", new Date(`${f.from}T00:00:00`).toISOString());
      if (f.to) q = q.lt("at", new Date(new Date(`${f.to}T00:00:00`).getTime() + 86_400_000).toISOString());
      if (f.reason) q = q.ilike("reason", `%${f.reason}%`);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as unknown as AuditRow[];
    },
  });
  const lookup = useMemo(() => {
    const people = new Map((members.data ?? []).filter((m) => m.user_id).map((m) => [m.user_id!, personName(m)]));
    const codes = new Map((jobs.data ?? []).map((j) => [j.id, j.code]));
    return { person: (id: string | null) => (id ? people.get(id) ?? "Someone outside the team" : "Trade Brain"), jobCode: (id: string | null | undefined) => (id ? codes.get(id) ?? null : null) };
  }, [members.data, jobs.data]);
  const tables = useMemo(() => [...new Set((rows.data ?? []).map((r) => r.table_name).concat(f.table ? [f.table] : []))].sort(), [rows.data, f.table]);
  if (!owner) return null;
  const list = rows.data ?? [];

  const exportCsv = () => {
    const csv = toCsv([["When", "Person", "What happened", "Table", "Action", "Reason"],
      ...list.map((r) => [r.at, lookup.person(r.actor_user_id), describeAudit(r, lookup), r.table_name, r.action, r.reason])]);
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = `activity-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click(); URL.revokeObjectURL(a.href);
  };
  const sel = "h-10 rounded-md border bg-background px-2 text-sm";

  return (
    <Section title="Activity" footer={<Button variant="outline" onClick={exportCsv} disabled={!list.length}>Export CSV</Button>}>
      <div className="grid gap-2 sm:grid-cols-3 lg:grid-cols-6">
        <select aria-label="Person" className={sel} value={f.person} onChange={(e) => setF({ ...f, person: e.target.value })}>
          <option value="">Everyone</option>
          {(members.data ?? []).filter((m) => m.user_id).map((m) => <option key={m.user_id!} value={m.user_id!}>{personName(m)}</option>)}
        </select>
        <select aria-label="Table" className={sel} value={f.table} onChange={(e) => setF({ ...f, table: e.target.value })}>
          <option value="">All records</option>
          {tables.map((t) => <option key={t} value={t}>{t.replace(/_/g, " ")}</option>)}
        </select>
        <select aria-label="Action" className={sel} value={f.action} onChange={(e) => setF({ ...f, action: e.target.value })}>
          <option value="">All actions</option>
          {ACTIONS.map((a) => <option key={a} value={a}>{ACTION_LABEL[a]}</option>)}
        </select>
        <Input aria-label="From date" type="date" value={f.from} onChange={(e) => setF({ ...f, from: e.target.value })} />
        <Input aria-label="To date" type="date" value={f.to} onChange={(e) => setF({ ...f, to: e.target.value })} />
        <Input aria-label="Reason" placeholder="Reason contains" value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} />
      </div>
      <ul className="max-h-[28rem] divide-y overflow-y-auto rounded-md border text-sm">
        {list.map((r) => (
          <li key={r.id} className="flex flex-wrap items-baseline justify-between gap-2 px-3 py-2">
            <span>{describeAudit(r, lookup)}</span>
            <span className="text-xs text-muted-foreground">{fmt(r.at)}</span>
          </li>
        ))}
        {!list.length && <li className="px-3 py-4 text-muted-foreground">{rows.isLoading ? "Loading…" : "Nothing matches these filters."}</li>}
      </ul>
      {list.length === 500 && <p className="text-xs text-muted-foreground">Showing the latest 500. Narrow the filters to see older activity.</p>}
    </Section>
  );
}

/** Overview banner for the owner when the 90-day access review is due. */
export function AccessReviewReminder({ membership }: { membership: ActiveMembership }) {
  const owner = membership.role === "owner";
  const { data } = useQuery({ queryKey: ["access_reviews", membership.workspaceId, "last"], enabled: owner, queryFn: async () =>
    (await supabase.from("access_reviews").select("reviewed_at").eq("workspace_id", membership.workspaceId).order("reviewed_at", { ascending: false }).limit(1)).data ?? [] });
  if (!owner || !data || !reviewDue(data[0]?.reviewed_at ?? null)) return null;
  return (
    <a href="/settings#people-and-access" className="block rounded-md border border-warn bg-warn-soft px-4 py-3 text-sm">
      Access review due: check who can sign in to Trade Brain in Settings › People and access.
    </a>
  );
}
