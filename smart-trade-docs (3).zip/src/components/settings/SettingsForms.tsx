import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { X, Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import type { ActiveMembership } from "@/lib/session";

type SettingsRow = Database["public"]["Tables"]["workspace_settings"]["Row"];
type TicketType = { name: string; expires: boolean };
type Who = "everyone" | "one";
type Hazard = { name: string; controls: string[]; required_tickets: { ticket: string; who: Who }[] };

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const STATES = ["NSW", "VIC", "QLD", "SA", "WA", "TAS", "ACT", "NT"];

export function Section({ title, children, footer }: { title: string; children: ReactNode; footer?: ReactNode }) {
  return (
    <section className="rounded-md border bg-card p-5">
      <h2 className="text-xl font-semibold uppercase">{title}</h2>
      <div className="mt-4 space-y-4">{children}</div>
      {footer && <div className="mt-4 flex justify-end">{footer}</div>}
    </section>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
    </div>
  );
}

const hhmm = (t: string) => t.slice(0, 5);

/* ---------- Workspace settings (one row, saved per section) ---------- */

export function WorkspaceSettings({ membership }: { membership: ActiveMembership }) {
  const qc = useQueryClient();
  const key = ["workspace_settings", membership.workspaceId];
  const { data } = useQuery({
    queryKey: key,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("workspace_settings")
        .select("*")
        .eq("workspace_id", membership.workspaceId)
        .single();
      if (error) throw error;
      return data;
    },
  });
  const [s, setS] = useState<SettingsRow | null>(null);
  useEffect(() => { if (data) setS(data); }, [data]);
  if (!s) return <p className="text-sm text-muted-foreground">Loading settings…</p>;

  const set = <K extends keyof SettingsRow>(k: K, v: SettingsRow[K]) => setS({ ...s, [k]: v });
  const save = async (fields: (keyof SettingsRow)[]) => {
    const patch = Object.fromEntries(fields.map((f) => [f, s[f]])) as Database["public"]["Tables"]["workspace_settings"]["Update"];
    const { error } = await supabase.from("workspace_settings").update(patch).eq("workspace_id", membership.workspaceId);
    if (error) { toast.error(error.message); return; }
    toast.success("Saved");
    qc.invalidateQueries({ queryKey: key });
  };
  const SaveBtn = ({ f }: { f: (keyof SettingsRow)[] }) => <Button className="h-11" onClick={() => save(f)}>Save</Button>;

  const tickets = s.ticket_types as TicketType[];
  const hazards = s.hazards as Hazard[];

  return (
    <>
      <Section title="Working week and hours" footer={<SaveBtn f={["working_days", "day_start", "morning_end", "day_end"]} />}>
        <div className="flex flex-wrap gap-2">
          {DAYS.map((d, i) => {
            const n = i + 1;
            const on = s.working_days.includes(n);
            return (
              <label key={d} className={`flex min-h-11 cursor-pointer items-center gap-2 rounded-sm border px-3 ${on ? "border-primary bg-primary/10" : ""}`}>
                <Checkbox checked={on} onCheckedChange={(c) => set("working_days", c ? [...s.working_days, n].sort() : s.working_days.filter((x) => x !== n))} />
                {d}
              </label>
            );
          })}
        </div>
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Day start"><Input type="time" value={hhmm(s.day_start)} onChange={(e) => set("day_start", e.target.value)} /></Field>
          <Field label="Morning ends"><Input type="time" value={hhmm(s.morning_end)} onChange={(e) => set("morning_end", e.target.value)} /></Field>
          <Field label="Day end"><Input type="time" value={hhmm(s.day_end)} onChange={(e) => set("day_end", e.target.value)} /></Field>
        </div>
      </Section>

      <Section title="Travel" footer={<SaveBtn f={["avg_kmh", "unload_buffer_min", "overnight_minutes"]} />}>
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Average speed (km/h)"><Input type="number" min={1} value={s.avg_kmh} onChange={(e) => set("avg_kmh", Number(e.target.value))} /></Field>
          <Field label="Unload buffer (minutes)"><Input type="number" min={0} value={s.unload_buffer_min} onChange={(e) => set("unload_buffer_min", Number(e.target.value))} /></Field>
          <Field label="Overnight after (minutes each way)"><Input type="number" min={0} value={s.overnight_minutes} onChange={(e) => set("overnight_minutes", Number(e.target.value))} /></Field>
        </div>
      </Section>

      <Section title="Skills" footer={<SaveBtn f={["skills"]} />}>
        <ListEditor items={s.skills} onChange={(v) => set("skills", v)} placeholder="Add a skill" />
      </Section>

      <Section title="Ticket types" footer={<SaveBtn f={["ticket_types"]} />}>
        <ul className="divide-y">
          {tickets.map((t, i) => (
            <li key={i} className="flex min-h-12 items-center gap-3 py-1">
              <Input value={t.name} onChange={(e) => set("ticket_types", tickets.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))} />
              <label className="flex shrink-0 items-center gap-2 text-sm">
                <Checkbox checked={t.expires} onCheckedChange={(c) => set("ticket_types", tickets.map((x, j) => (j === i ? { ...x, expires: !!c } : x)))} />
                Expires
              </label>
              <Button variant="ghost" size="icon" aria-label="Remove" onClick={() => set("ticket_types", tickets.filter((_, j) => j !== i))}><X className="h-4 w-4" /></Button>
            </li>
          ))}
        </ul>
        <Button variant="outline" onClick={() => set("ticket_types", [...tickets, { name: "", expires: false }])}><Plus className="h-4 w-4" /> Add ticket type</Button>
      </Section>

      <Section title="Hazards" footer={<SaveBtn f={["hazards"]} />}>
        <div className="space-y-3">
          {hazards.map((h, i) => {
            const upd = (nh: Hazard) => set("hazards", hazards.map((x, j) => (j === i ? nh : x)));
            return (
              <div key={i} className="rounded-sm border p-3">
                <div className="flex gap-2">
                  <Input value={h.name} onChange={(e) => upd({ ...h, name: e.target.value })} className="font-medium" />
                  <Button variant="ghost" size="icon" aria-label="Remove hazard" onClick={() => set("hazards", hazards.filter((_, j) => j !== i))}><X className="h-4 w-4" /></Button>
                </div>
                <div className="mt-2 grid gap-3 md:grid-cols-2">
                  <Field label="Controls (one per line)">
                    <Textarea rows={3} value={h.controls.join("\n")} onChange={(e) => upd({ ...h, controls: e.target.value.split("\n") })} />
                  </Field>
                  <Field label="Required tickets">
                    <div className="space-y-1">
                      {tickets.filter((t) => t.name).map((t) => {
                        const rule = h.required_tickets.find((r) => r.ticket === t.name);
                        return (
                          <div key={t.name} className="flex items-center justify-between gap-2 text-sm">
                            <span>{t.name}</span>
                            <select
                              className="h-9 rounded-md border bg-background px-2"
                              value={rule?.who ?? ""}
                              onChange={(e) => {
                                const rest = h.required_tickets.filter((r) => r.ticket !== t.name);
                                upd({ ...h, required_tickets: e.target.value ? [...rest, { ticket: t.name, who: e.target.value as Who }] : rest });
                              }}
                            >
                              <option value="">Not needed</option>
                              <option value="everyone">Everyone</option>
                              <option value="one">At least one person</option>
                            </select>
                          </div>
                        );
                      })}
                    </div>
                  </Field>
                </div>
              </div>
            );
          })}
        </div>
        <Button variant="outline" onClick={() => set("hazards", [...hazards, { name: "", controls: [], required_tickets: [] }])}><Plus className="h-4 w-4" /> Add hazard</Button>
        <div className="rounded-sm bg-muted p-3 text-sm">
          <p className="font-medium">Other ticket rules</p>
          <ul className="mt-1 list-disc pl-5 text-muted-foreground">
            <li>Commercial job: White Card for everyone</li>
            <li>Crew of 2 or more: First Aid for at least one person</li>
            <li>Old floor removal and pre-1990 building together: Asbestos Awareness for everyone</li>
            <li>Tickets listed on the job: everyone</li>
          </ul>
        </div>
      </Section>

      <Section title="Leave types" footer={<SaveBtn f={["leave_types"]} />}>
        <ListEditor items={s.leave_types} onChange={(v) => set("leave_types", v)} placeholder="Add a leave type" />
      </Section>

      <Section title="Job types" footer={<SaveBtn f={["job_types"]} />}>
        <ListEditor items={s.job_types} onChange={(v) => set("job_types", v)} placeholder="Add a job type" />
      </Section>

      <Section title="Public holiday states" footer={<SaveBtn f={["holiday_states"]} />}>
        <div className="flex flex-wrap gap-2">
          {STATES.map((st) => {
            const on = s.holiday_states.includes(st);
            return (
              <label key={st} className={`flex min-h-11 cursor-pointer items-center gap-2 rounded-sm border px-3 ${on ? "border-primary bg-primary/10" : ""}`}>
                <Checkbox checked={on} onCheckedChange={(c) => set("holiday_states", c ? [...s.holiday_states, st] : s.holiday_states.filter((x) => x !== st))} />
                {st}
              </label>
            );
          })}
        </div>
      </Section>
    </>
  );
}

function ListEditor({ items, onChange, placeholder }: { items: string[]; onChange: (v: string[]) => void; placeholder: string }) {
  const [draft, setDraft] = useState("");
  const add = () => {
    const v = draft.trim();
    if (!v || items.includes(v)) return;
    onChange([...items, v]);
    setDraft("");
  };
  return (
    <div>
      <div className="flex flex-wrap gap-2">
        {items.map((it) => (
          <span key={it} className="flex items-center gap-1 rounded-sm border bg-muted px-2 py-1 text-sm">
            {it}
            <button aria-label={`Remove ${it}`} onClick={() => onChange(items.filter((x) => x !== it))}><X className="h-3.5 w-3.5" /></button>
          </span>
        ))}
      </div>
      <div className="mt-3 flex gap-2">
        <Input value={draft} placeholder={placeholder} onChange={(e) => setDraft(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); add(); } }} />
        <Button variant="outline" onClick={add}>Add</Button>
      </div>
    </div>
  );
}

/* ---------- Workspace details (owner edits) ---------- */

export function WorkspaceDetails({ membership }: { membership: ActiveMembership }) {
  const qc = useQueryClient();
  const isOwner = membership.role === "owner";
  const key = ["workspace", membership.workspaceId];
  const { data } = useQuery({
    queryKey: key,
    queryFn: async () => {
      const { data, error } = await supabase.from("workspaces").select("*").eq("id", membership.workspaceId).single();
      if (error) throw error;
      return data;
    },
  });
  const [w, setW] = useState(data);
  useEffect(() => { if (data) setW(data); }, [data]);
  if (!w) return null;

  const save = async () => {
    const { error } = await supabase.from("workspaces").update({
      name: w.name, code_prefix: w.code_prefix.trim().toUpperCase(), depot_name: w.depot_name,
      finance_visible_to_office: w.finance_visible_to_office,
    }).eq("id", w.id);
    if (error) { toast.error(error.message); return; }
    toast.success("Saved");
    qc.invalidateQueries({ queryKey: key });
    qc.invalidateQueries({ queryKey: ["finance_settings"] });
  };

  return (
    <Section title="Workspace and depot" footer={isOwner && <Button className="h-11" onClick={save}>Save</Button>}>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Business name"><Input disabled={!isOwner} value={w.name} onChange={(e) => setW({ ...w, name: e.target.value })} /></Field>
        <Field label="Job code prefix"><Input disabled={!isOwner} className="font-mono uppercase" maxLength={6} value={w.code_prefix} onChange={(e) => setW({ ...w, code_prefix: e.target.value })} /></Field>
        <div className="sm:col-span-2">
          <Field label="Depot address"><Input disabled={!isOwner} value={w.depot_name ?? ""} placeholder="Street, suburb, state" onChange={(e) => setW({ ...w, depot_name: e.target.value })} /></Field>
        </div>
      </div>
      {isOwner && (
        <label className="flex min-h-11 items-center gap-2 text-sm">
          <Checkbox checked={w.finance_visible_to_office} onCheckedChange={(c) => setW({ ...w, finance_visible_to_office: !!c })} />
          Let office staff see finance (job values, costs, rates)
        </label>
      )}
      {!isOwner && <p className="text-xs text-muted-foreground">Only the owner can change these.</p>}
    </Section>
  );
}

/* ---------- Finance settings (finance users only; owner edits) ---------- */

export function FinanceSettings({ membership }: { membership: ActiveMembership }) {
  const qc = useQueryClient();
  const isOwner = membership.role === "owner";
  const key = ["finance_settings", membership.workspaceId];
  // Row-level security returns nothing to non-finance users, so the section simply doesn't render.
  const { data } = useQuery({
    queryKey: key,
    queryFn: async () => {
      const { data, error } = await supabase.from("workspace_finance_settings").select("*").eq("workspace_id", membership.workspaceId).maybeSingle();
      if (error) throw error;
      return data;
    },
  });
  const [f, setF] = useState<Database["public"]["Tables"]["workspace_finance_settings"]["Row"] | null | undefined>(data);
  useEffect(() => { setF(data); }, [data]);
  if (!f) return null;

  const save = async () => {
    const { error } = await supabase.from("workspace_finance_settings").update({
      km_rate: f.km_rate, accommodation_rate: f.accommodation_rate, default_day_rate: f.default_day_rate,
      variation_margin_pct: f.variation_margin_pct,
    }).eq("workspace_id", membership.workspaceId);
    if (error) { toast.error(error.message); return; }
    toast.success("Saved");
    qc.invalidateQueries({ queryKey: key });
  };

  return (
    <Section title="Finance" footer={isOwner && <Button className="h-11" onClick={save}>Save</Button>}>
      <div className="grid gap-3 sm:grid-cols-3">
        <Field label="Km rate ($ per km)"><Input disabled={!isOwner} type="number" step="0.01" min={0} value={f.km_rate} onChange={(e) => setF({ ...f, km_rate: Number(e.target.value) })} /></Field>
        <Field label="Accommodation ($ per room-night)"><Input disabled={!isOwner} type="number" min={0} value={f.accommodation_rate} onChange={(e) => setF({ ...f, accommodation_rate: Number(e.target.value) })} /></Field>
        <Field label="Default day rate ($)"><Input disabled={!isOwner} type="number" min={0} value={f.default_day_rate} onChange={(e) => setF({ ...f, default_day_rate: Number(e.target.value) })} /></Field>
        <Field label="Variation margin (%)"><Input disabled={!isOwner} type="number" step="0.5" min={0} max={100} value={f.variation_margin_pct ?? ""} onChange={(e) => setF({ ...f, variation_margin_pct: e.target.value === "" ? null : Number(e.target.value) })} /></Field>
      </div>
      {!isOwner && <p className="text-xs text-muted-foreground">Only the owner can change finance settings.</p>}
    </Section>
  );
}

/* ---------- Closures ---------- */

export function Closures({ membership }: { membership: ActiveMembership }) {
  const qc = useQueryClient();
  const key = ["closures", membership.workspaceId];
  const { data: rows = [] } = useQuery({
    queryKey: key,
    queryFn: async () => {
      const { data, error } = await supabase.from("closures").select("*").eq("workspace_id", membership.workspaceId).eq("kind", "closure").order("from_date");
      if (error) throw error;
      return data;
    },
  });
  const [name, setName] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const add = async () => {
    if (!name.trim() || !from) { toast.error("Add a name and start date"); return; }
    const { error } = await supabase.from("closures").insert({ workspace_id: membership.workspaceId, name: name.trim(), from_date: from, to_date: to || from, kind: "closure" });
    if (error) { toast.error(error.message.includes("closures_range") ? "End date must be on or after the start date" : error.message); return; }
    setName(""); setFrom(""); setTo("");
    qc.invalidateQueries({ queryKey: key });
  };
  const remove = async (id: string) => {
    const { error } = await supabase.from("closures").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: key });
  };

  return (
    <Section title="Closures">
      <ul className="divide-y">
        {rows.length === 0 && <li className="py-2 text-sm text-muted-foreground">No closures yet.</li>}
        {rows.map((c) => (
          <li key={c.id} className="flex min-h-12 items-center gap-3 py-1 text-sm">
            <span className="flex-1">{c.name}</span>
            <span className="font-mono text-xs">{c.from_date}{c.to_date !== c.from_date && ` → ${c.to_date}`}</span>
            <Button variant="ghost" size="icon" aria-label="Remove closure" onClick={() => remove(c.id)}><X className="h-4 w-4" /></Button>
          </li>
        ))}
      </ul>
      <div className="grid gap-2 sm:grid-cols-[1fr_auto_auto_auto]">
        <Input placeholder="e.g. Christmas shutdown" value={name} onChange={(e) => setName(e.target.value)} />
        <Input type="date" aria-label="From" value={from} onChange={(e) => setFrom(e.target.value)} />
        <Input type="date" aria-label="To" value={to} onChange={(e) => setTo(e.target.value)} />
        <Button variant="outline" onClick={add}>Add closure</Button>
      </div>
    </Section>
  );
}
