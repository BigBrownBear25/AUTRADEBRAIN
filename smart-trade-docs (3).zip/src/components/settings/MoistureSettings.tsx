import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Section } from "./SettingsForms";
import type { MoistureLimits } from "@/lib/rules/photos";

type Row = { flooring: string; max: string; unit: string };

/** Settings > Moisture limits (B8): a photo reading above the job's flooring limit posts a problem. Office edits. */
export function MoistureSettings({ ws }: { ws: string }) {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["moisture_limits", ws],
    queryFn: async () => ((await supabase.from("workspace_settings").select("moisture_limits").eq("workspace_id", ws).single()).data?.moisture_limits ?? {}) as MoistureLimits,
  });
  const [rows, setRows] = useState<Row[]>([]);
  useEffect(() => { if (q.data) setRows(Object.entries(q.data).map(([flooring, v]) => ({ flooring, max: String(v.max), unit: v.unit ?? "" }))); }, [q.data]);
  const save = async () => {
    const out: MoistureLimits = {};
    for (const r of rows) if (r.flooring.trim() && r.max !== "" && Number.isFinite(Number(r.max))) out[r.flooring.trim()] = { max: Number(r.max), ...(r.unit.trim() ? { unit: r.unit.trim() } : {}) };
    const { error } = await supabase.from("workspace_settings").update({ moisture_limits: out as never }).eq("workspace_id", ws);
    if (error) { toast.error(error.message); return; }
    toast.success("Moisture limits saved");
    qc.invalidateQueries({ queryKey: ["moisture_limits", ws] });
  };
  return (
    <Section title="Moisture limits" footer={<Button onClick={save}>Save moisture limits</Button>}>
      <p className="text-xs text-muted-foreground">By flooring type, matching the job's flooring. When a photo's moisture reading is above the limit (same unit), a problem is posted on the job and the office is told. Empty means no checks.</p>
      <div className="space-y-2">
        {rows.map((r, i) => (
          <div key={i} className="flex flex-wrap gap-2">
            <Input className="w-48" placeholder="Flooring, e.g. Timber" value={r.flooring} onChange={(e) => setRows(rows.map((x, j) => j === i ? { ...x, flooring: e.target.value } : x))} aria-label="Flooring" />
            <Input className="w-28" type="number" placeholder="Max" value={r.max} onChange={(e) => setRows(rows.map((x, j) => j === i ? { ...x, max: e.target.value } : x))} aria-label="Maximum" />
            <Input className="w-28" placeholder="Unit, e.g. %" value={r.unit} onChange={(e) => setRows(rows.map((x, j) => j === i ? { ...x, unit: e.target.value } : x))} aria-label="Unit" />
            <Button size="icon" variant="ghost" aria-label="Remove limit" onClick={() => setRows(rows.filter((_, j) => j !== i))}><X className="h-4 w-4" /></Button>
          </div>
        ))}
        <Button variant="outline" onClick={() => setRows([...rows, { flooring: "", max: "", unit: "" }])}>Add limit</Button>
      </div>
    </Section>
  );
}
