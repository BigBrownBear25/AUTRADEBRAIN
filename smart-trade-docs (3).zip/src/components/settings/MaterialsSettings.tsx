import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Section } from "./SettingsForms";
import type { ActiveMembership } from "@/lib/session";
import { catalogueQuery, companionQuery, wasteDefaultsQuery } from "@/lib/catalogue";
import { CATEGORIES, CATEGORY_LABEL } from "@/lib/rules/materials";

const sel = "h-10 rounded-md border bg-background px-2 text-sm";

/** Settings > Materials (section 13): waste defaults by category and companion rules. Office edits. */
export function MaterialsSettings({ membership }: { membership: ActiveMembership }) {
  const ws = membership.workspaceId;
  const qc = useQueryClient();
  const waste = useQuery(wasteDefaultsQuery(ws));
  const rules = useQuery(companionQuery(ws));
  const items = useQuery(catalogueQuery(ws));
  const [w, setW] = useState<Record<string, string>>({});
  useEffect(() => { if (waste.data) setW(Object.fromEntries(Object.entries(waste.data).map(([k, v]) => [k, String(v)]))); }, [waste.data]);
  const [r, setR] = useState({ when: "lvt and hybrid", add: "underlay", item: "", note: "" });

  const saveWaste = async () => {
    const out: Record<string, number> = {};
    for (const [k, v] of Object.entries(w)) if (v !== "" && !Number.isNaN(Number(v))) out[k] = Math.max(0, Math.min(100, Number(v)));
    const { error } = await supabase.from("workspace_settings").update({ waste_defaults: out }).eq("workspace_id", ws);
    if (error) { toast.error(error.message); return; }
    toast.success("Waste defaults saved");
    qc.invalidateQueries({ queryKey: ["waste_defaults", ws] });
  };
  const addRule = async () => {
    const { error } = await supabase.from("companion_rules").insert({ workspace_id: ws, when_category: r.when, add_category: r.add, default_item_id: r.item || null, note: r.note || null });
    if (error) { toast.error(error.message); return; }
    setR({ ...r, item: "", note: "" });
    qc.invalidateQueries({ queryKey: ["companion_rules", ws] });
  };
  const delRule = async (id: string) => {
    const { error } = await supabase.from("companion_rules").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["companion_rules", ws] });
  };
  const itemName = (id: string | null) => (id ? (items.data ?? []).find((i) => i.id === id)?.name ?? "an item" : null);

  return (
    <Section title="Materials" footer={<Button onClick={saveWaste}>Save waste defaults</Button>}>
      <div>
        <p className="text-sm font-medium">Waste by category (%)</p>
        <p className="text-xs text-muted-foreground">Used when an item has no waste of its own. Leave blank for none.</p>
        <div className="mt-2 grid gap-2 sm:grid-cols-3 lg:grid-cols-4">
          {CATEGORIES.map((c) => (
            <label key={c} className="grid gap-1 text-sm">{CATEGORY_LABEL[c]}
              <Input type="number" min={0} max={100} value={w[c] ?? ""} onChange={(e) => setW({ ...w, [c]: e.target.value })} />
            </label>
          ))}
        </div>
      </div>
      <div>
        <p className="text-sm font-medium">Companion rules</p>
        <p className="text-xs text-muted-foreground">What goes with what, for example hybrid flooring adds underlay. The Brain uses these when it suggests materials.</p>
        <ul className="mt-2 divide-y rounded-md border text-sm">
          {(rules.data ?? []).map((x) => (
            <li key={x.id} className="flex items-center justify-between gap-2 px-3 py-2">
              <span>{CATEGORY_LABEL[x.when_category as keyof typeof CATEGORY_LABEL] ?? x.when_category} adds {(CATEGORY_LABEL[x.add_category as keyof typeof CATEGORY_LABEL] ?? x.add_category).toLowerCase()}{itemName(x.default_item_id) ? ` (${itemName(x.default_item_id)})` : ""}{x.note ? ` · ${x.note}` : ""}</span>
              <Button size="icon" variant="ghost" aria-label="Delete rule" onClick={() => delRule(x.id)}><X className="h-4 w-4" /></Button>
            </li>
          ))}
          {!rules.data?.length && <li className="px-3 py-2 text-muted-foreground">No companion rules yet.</li>}
        </ul>
        <div className="mt-2 flex flex-wrap gap-2">
          <select aria-label="When" className={sel} value={r.when} onChange={(e) => setR({ ...r, when: e.target.value })}>{CATEGORIES.map((c) => <option key={c} value={c}>{CATEGORY_LABEL[c]}</option>)}</select>
          <span className="self-center text-sm">adds</span>
          <select aria-label="Adds" className={sel} value={r.add} onChange={(e) => setR({ ...r, add: e.target.value, item: "" })}>{CATEGORIES.map((c) => <option key={c} value={c}>{CATEGORY_LABEL[c]}</option>)}</select>
          <select aria-label="Default item" className={sel} value={r.item} onChange={(e) => setR({ ...r, item: e.target.value })}>
            <option value="">No default item</option>
            {(items.data ?? []).filter((i) => i.category === r.add && i.active).map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}
          </select>
          <Input className="w-48" placeholder="Note" value={r.note} onChange={(e) => setR({ ...r, note: e.target.value })} />
          <Button variant="outline" onClick={addRule}>Add rule</Button>
        </div>
      </div>
    </Section>
  );
}
