import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Mail, Copy } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { fileEmail, ignoreEmail, enquiryFromEmail } from "@/lib/email.functions";
import { inboundAddress } from "@/lib/email-config";

type Suggestion = { jobId: string | null; code: string | null; confidence: string; reason: string } | null;

/** Office only: emails that didn't carry a job code, with Claude's suggested job. */
export function UnfiledEmail({ workspaceId }: { workspaceId: string }) {
  const qc = useQueryClient();
  const ws = useQuery({
    queryKey: ["inbound_key", workspaceId],
    queryFn: async () => (await supabase.from("workspaces").select("inbound_key").eq("id", workspaceId).single()).data,
  });
  const emails = useQuery({
    queryKey: ["inbound_emails", workspaceId],
    queryFn: async () => {
      const { data, error } = await supabase.from("inbound_emails").select("*").eq("workspace_id", workspaceId).eq("status", "unfiled").order("received_at", { ascending: false }).limit(100);
      if (error) throw error;
      return data;
    },
    refetchInterval: 60000,
  });
  const jobs = useQuery({
    queryKey: ["open_jobs_pick", workspaceId],
    queryFn: async () => (await supabase.from("jobs").select("id, code, name").eq("workspace_id", workspaceId).not("status", "in", "(complete,closed)").order("code")).data ?? [],
  });
  const file = useServerFn(fileEmail), ignore = useServerFn(ignoreEmail), enquiry = useServerFn(enquiryFromEmail);
  const [pick, setPick] = useState<Record<string, string>>({});
  const [newName, setNewName] = useState<Record<string, string>>({});
  const refresh = () => { qc.invalidateQueries({ queryKey: ["inbound_emails", workspaceId] }); qc.invalidateQueries({ queryKey: ["inbox"] }); };
  const act = async (p: Promise<unknown>, ok: string) => { try { await p; toast.success(ok); refresh(); } catch (e) { toast.error(e instanceof Error ? e.message : "Didn't work"); } };

  const addr = ws.data ? inboundAddress(ws.data.inbound_key) : null;
  const list = emails.data ?? [];

  return (
    <section className="mb-4 rounded-md border bg-card p-3">
      <div className="flex flex-wrap items-center gap-2">
        <Mail className="h-4 w-4" />
        <h2 className="font-heading text-lg font-semibold uppercase">Unfiled email</h2>
        <span className="text-sm text-muted-foreground">{list.length} waiting</span>
      </div>
      <p className="mt-1 text-sm text-muted-foreground">
        Forward job emails to {addr ? (
          <button className="inline-flex items-center gap-1 font-mono text-foreground" onClick={() => { navigator.clipboard.writeText(addr); toast.success("Address copied"); }}>{addr}<Copy className="h-3 w-3" /></button>
        ) : <span className="text-foreground">the workspace address (email provider not connected yet)</span>}. A job code in the subject (e.g. <span className="font-mono">FZ-1041</span>) files it straight onto that job.
      </p>
      {list.length > 0 && (
        <ul className="mt-3 divide-y">
          {list.map((e) => {
            const s = e.ai_suggestion as Suggestion;
            const chosen = pick[e.id] ?? s?.jobId ?? "";
            return (
              <li key={e.id} className="space-y-2 py-3">
                <div>
                  <p className="font-medium">{e.subject || "(no subject)"}</p>
                  <p className="text-xs text-muted-foreground">{e.from_address} · {new Date(e.received_at).toLocaleString("en-AU", { dateStyle: "medium", timeStyle: "short" })}{(e.files as unknown[]).length ? ` · ${(e.files as unknown[]).length} attachment(s)` : ""}</p>
                  <p className="mt-1 line-clamp-3 whitespace-pre-wrap text-sm">{e.body_text}</p>
                </div>
                {s && <p className="text-sm">{s.code ? <>Claude suggests <span className="font-mono font-medium">{s.code}</span> ({s.confidence})</> : "Claude found no matching job"}{s.reason ? ` — ${s.reason}` : ""}</p>}
                <div className="flex flex-wrap items-center gap-2">
                  <select aria-label="Job to file on" className="h-9 rounded-md border bg-background px-2 text-sm" value={chosen} onChange={(ev) => setPick({ ...pick, [e.id]: ev.target.value })}>
                    <option value="">Choose a job…</option>
                    {(jobs.data ?? []).map((j) => <option key={j.id} value={j.id}>{j.code} · {j.name}</option>)}
                  </select>
                  <Button size="sm" disabled={!chosen} onClick={() => act(file({ data: { emailId: e.id, jobId: chosen } }), "Filed on the job")}>File</Button>
                  <Button size="sm" variant="ghost" onClick={() => act(ignore({ data: { emailId: e.id } }), "Ignored")}>Ignore</Button>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <Input className="h-9 max-w-xs" placeholder="New enquiry name" value={newName[e.id] ?? ""} onChange={(ev) => setNewName({ ...newName, [e.id]: ev.target.value })} />
                  <Button size="sm" variant="outline" disabled={!(newName[e.id] ?? "").trim()} onClick={() => act(enquiry({ data: { emailId: e.id, name: newName[e.id]!, sector: "domestic" } }), "Enquiry created")}>New enquiry</Button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
