import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { crewRoleLabel, isFinanceQuery, crewRatesQuery, workspaceListsQuery, type CrewRole, type CrewWithTickets } from "@/lib/crew";

type Form = {
  name: string; role: CrewRole; is_subcontractor: boolean; company_name: string;
  base_suburb: string; phone: string; email: string; skills: string[]; active: boolean;
  tickets: Record<string, { held: boolean; expires_on: string }>; day_rate: string;
};

export function PersonSheet({ workspaceId, person, open, onOpenChange }: {
  workspaceId: string; person: CrewWithTickets | null; open: boolean; onOpenChange: (o: boolean) => void;
}) {
  const qc = useQueryClient();
  const { data: lists } = useQuery(workspaceListsQuery(workspaceId));
  const { data: isFinance } = useQuery(isFinanceQuery(workspaceId));
  const { data: rates } = useQuery({ ...crewRatesQuery(workspaceId), enabled: !!isFinance });
  const [f, setF] = useState<Form | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open || !lists) return;
    const tickets: Form["tickets"] = {};
    for (const t of lists.ticketTypes) {
      const held = person?.crew_tickets.find((x) => x.ticket_type === t.name);
      tickets[t.name] = { held: !!held, expires_on: held?.expires_on ?? "" };
    }
    setF({
      name: person?.name ?? "", role: person?.role ?? "installer", is_subcontractor: person?.is_subcontractor ?? false,
      company_name: person?.company_name ?? "", base_suburb: person?.base_suburb ?? "", phone: person?.phone ?? "",
      email: person?.email ?? "", active: person?.active ?? true,
      // A new person starts with every workspace skill ticked.
      skills: person?.skills ?? [...lists.skills],
      tickets, day_rate: person && rates?.get(person.id) != null ? String(rates.get(person.id)) : "",
    });
  }, [open, person, lists, rates]);

  const save = async () => {
    if (!f || !lists) return;
    if (!f.name.trim()) { toast.error("Add a name"); return; }
    for (const t of lists.ticketTypes) {
      const v = f.tickets[t.name];
      if (v?.held && t.expires && !v.expires_on) { toast.error(`Add an expiry date for ${t.name}`); return; }
    }
    setBusy(true);
    try {
      const row = {
        workspace_id: workspaceId, name: f.name.trim(), role: f.role, is_subcontractor: f.is_subcontractor,
        company_name: f.is_subcontractor ? f.company_name.trim() || null : null,
        base_suburb: f.base_suburb.trim() || null, phone: f.phone.trim() || null,
        email: f.email.trim().toLowerCase() || null, skills: f.skills, active: f.active,
      };
      let id = person?.id;
      if (id) {
        const { error } = await supabase.from("crew_members").update(row).eq("id", id);
        if (error) throw error;
      } else {
        const { data, error } = await supabase.from("crew_members").insert(row).select("id").single();
        if (error) throw error;
        id = data.id;
      }
      const held = Object.entries(f.tickets).filter(([, v]) => v.held);
      const notHeld = Object.entries(f.tickets).filter(([, v]) => !v.held).map(([k]) => k);
      if (held.length) {
        const { error } = await supabase.from("crew_tickets").upsert(
          held.map(([k, v]) => ({ crew_member_id: id!, workspace_id: workspaceId, ticket_type: k, expires_on: v.expires_on || null })),
          { onConflict: "crew_member_id,ticket_type" },
        );
        if (error) throw error;
      }
      if (notHeld.length && person) {
        const { error } = await supabase.from("crew_tickets").delete().eq("crew_member_id", id).in("ticket_type", notHeld);
        if (error) throw error;
      }
      if (isFinance) {
        if (f.day_rate.trim()) {
          const { error } = await supabase.from("crew_rates").upsert({ crew_member_id: id, workspace_id: workspaceId, day_rate: Number(f.day_rate) });
          if (error) throw error;
        } else if (person) {
          const { error } = await supabase.from("crew_rates").delete().eq("crew_member_id", id);
          if (error) throw error;
        }
      }
      toast.success(person ? "Saved" : "Person added");
      qc.invalidateQueries({ queryKey: ["crew", workspaceId] });
      qc.invalidateQueries({ queryKey: ["crew_rates", workspaceId] });
      onOpenChange(false);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const set = <K extends keyof Form>(k: K, v: Form[K]) => f && setF({ ...f, [k]: v });

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full overflow-y-auto sm:max-w-lg">
        <SheetHeader><SheetTitle className="font-heading text-2xl uppercase">{person ? "Edit person" : "Add person"}</SheetTitle></SheetHeader>
        {f && lists && (
          <div className="mt-4 space-y-5 pb-safe">
            <div className="grid gap-3 sm:grid-cols-2">
              <F label="Name"><Input value={f.name} onChange={(e) => set("name", e.target.value)} /></F>
              <F label="Role">
                <select className="h-10 w-full rounded-md border bg-background px-3 text-sm" value={f.role} onChange={(e) => set("role", e.target.value as CrewRole)}>
                  {(Object.keys(crewRoleLabel) as CrewRole[]).map((r) => <option key={r} value={r}>{crewRoleLabel[r]}</option>)}
                </select>
              </F>
            </div>
            <label className="flex min-h-11 items-center gap-2 text-sm">
              <Checkbox checked={f.is_subcontractor} onCheckedChange={(c) => set("is_subcontractor", !!c)} /> Subcontractor
            </label>
            {f.is_subcontractor && <F label="Company name"><Input value={f.company_name} onChange={(e) => set("company_name", e.target.value)} /></F>}
            <F label="Home base (address or suburb)"><Input value={f.base_suburb} onChange={(e) => set("base_suburb", e.target.value)} /></F>
            <div className="grid gap-3 sm:grid-cols-2">
              <F label="Phone"><Input type="tel" value={f.phone} onChange={(e) => set("phone", e.target.value)} /></F>
              <F label="Email"><Input type="email" value={f.email} onChange={(e) => set("email", e.target.value)} /></F>
            </div>

            <div>
              <Label>Skills</Label>
              <p className="text-xs text-muted-foreground">Untick the ones they don't have.</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {lists.skills.map((s) => {
                  const on = f.skills.includes(s);
                  return (
                    <label key={s} className={`flex min-h-10 cursor-pointer items-center gap-2 rounded-sm border px-2 text-sm ${on ? "border-primary bg-primary/10" : ""}`}>
                      <Checkbox checked={on} onCheckedChange={(c) => set("skills", c ? [...f.skills, s] : f.skills.filter((x) => x !== s))} />
                      {s}
                    </label>
                  );
                })}
              </div>
            </div>

            <div>
              <Label>Tickets</Label>
              <ul className="mt-2 divide-y rounded-sm border">
                {lists.ticketTypes.map((t) => {
                  const v = f.tickets[t.name] ?? { held: false, expires_on: "" };
                  const upd = (nv: typeof v) => set("tickets", { ...f.tickets, [t.name]: nv });
                  return (
                    <li key={t.name} className="flex min-h-12 items-center gap-3 px-3 py-1 text-sm">
                      <label className="flex flex-1 items-center gap-2">
                        <Checkbox checked={v.held} onCheckedChange={(c) => upd({ ...v, held: !!c })} /> {t.name}
                      </label>
                      {v.held && t.expires && (
                        <Input type="date" aria-label={`${t.name} expiry`} className="w-40" value={v.expires_on} onChange={(e) => upd({ ...v, expires_on: e.target.value })} />
                      )}
                    </li>
                  );
                })}
              </ul>
            </div>

            {isFinance && (
              <F label="Day rate ($) — finance only"><Input type="number" min={0} value={f.day_rate} onChange={(e) => set("day_rate", e.target.value)} /></F>
            )}

            {person && (
              <label className="flex min-h-11 items-center gap-2 text-sm">
                <Checkbox checked={f.active} onCheckedChange={(c) => set("active", !!c)} /> Active (untick when someone leaves)
              </label>
            )}

            <Button className="h-11 w-full" onClick={save} disabled={busy}>{person ? "Save" : "Add person"}</Button>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}

function F({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="space-y-1.5"><Label>{label}</Label>{children}</div>;
}
