import { ticketExpiryStatus, todayIso } from "@/lib/rules/ticket-expiry";

const cls = {
  current: "border-fit/40 bg-fit-soft text-foreground",
  expiring: "border-warn/50 bg-warn-soft text-foreground",
  expired: "border-clash/50 bg-clash-soft text-foreground",
};
const dot = { current: "bg-fit", expiring: "bg-warn", expired: "bg-clash" };

export function TicketChip({ type, expiresOn }: { type: string; expiresOn: string | null }) {
  const s = ticketExpiryStatus(expiresOn, todayIso());
  return (
    <span
      title={expiresOn ? `${s === "expired" ? "Expired" : "Expires"} ${expiresOn}` : "No expiry"}
      className={`inline-flex items-center gap-1 rounded-sm border px-1.5 py-0.5 text-xs ${cls[s]}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${dot[s]}`} />
      {type}
    </span>
  );
}
