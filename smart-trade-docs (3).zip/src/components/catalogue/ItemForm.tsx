import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { CATEGORIES, CATEGORY_LABEL, UNITS } from "@/lib/rules/materials";
import type { CatalogueItem, Supplier } from "@/lib/catalogue";

export type ItemDraft = Partial<CatalogueItem> & { name: string };
const sel = "h-10 w-full rounded-md border bg-background px-2 text-sm";
const num = (v: string) => (v === "" ? null : Number(v));

const PACK_HINT: Record<string, string> = { box: "Box size (m²)", roll: "Roll width (m)", "linear metre": "Roll width (m)", bag: "Bag size (kg)", pail: "Pail size (L)", litre: "Pack size (L)" };
const COVER_HINT = (cat: string, unit: string) =>
  cat === "levelling and prep" ? "Coverage (kg per m² per mm)" : cat === "adhesive" ? `Coverage (m² per ${unit})` : `Coverage (m² per ${unit})`;

function L({ label, children }: { label: string; children: React.ReactNode }) { return <label className="grid gap-1 text-sm">{label}{children}</label>; }

/** Add or edit one catalogue item by hand. Returns the saved item id. */
export function ItemForm({ ws, item, suppliers, onSaved, onCancel }: {
  ws: string; item: ItemDraft; suppliers: Supplier[]; onSaved: (id: string) => void; onCancel?: () => void;
}) {
  const [f, setF] = useState<ItemDraft>({ category: "other", unit: "each", stocked: false, active: true, hazard_tags: [], ...item });
  const [busy, setBusy] = useState(false);
  const set = <K extends keyof ItemDraft>(k: K, v: ItemDraft[K]) => setF((x) => ({ ...x, [k]: v }));

  const save = async () => {
    if (!f.name.trim()) { toast.error("Give the item a name"); return; }
    setBusy(true);
    const row = {
      workspace_id: ws, name: f.name.trim(), supplier_id: f.supplier_id || null, supplier_code: f.supplier_code?.trim() || null,
      brand: f.brand?.trim() || null, range: f.range?.trim() || null, colour: f.colour?.trim() || null,
      category: f.category ?? "other", unit: f.unit ?? "each", pack_size: f.pack_size ?? null, coverage: f.coverage ?? null,
      coverage_basis: f.coverage_basis ?? null, waste_pct: f.waste_pct ?? null, stocked: !!f.stocked, lead_time_days: f.lead_time_days ?? null,
      spec_url: f.spec_url?.trim() || null, install_url: f.install_url?.trim() || null, sds_url: f.sds_url?.trim() || null, warranty_url: f.warranty_url?.trim() || null,
      hazard_tags: f.hazard_tags ?? [], active: f.active ?? true, source: f.source ?? "manual", updated_at: new Date().toISOString(),
    };
    const r = f.id ? await supabase.from("catalogue_items").update(row).eq("id", f.id).select("id").single()
      : await supabase.from("catalogue_items").insert(row).select("id").single();
    setBusy(false);
    if (r.error) { toast.error(r.error.message.includes("catalogue_items_supplier_code") ? "That supplier already has an item with this code" : r.error.message); return; }
    toast.success(f.id ? "Item saved" : "Added to the catalogue");
    onSaved(r.data.id);
  };

  return (
    <div className="grid gap-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <L label="Name"><Input value={f.name} onChange={(e) => set("name", e.target.value)} /></L>
        <L label="Category">
          <select className={sel} value={f.category ?? "other"} onChange={(e) => set("category", e.target.value)}>
            {CATEGORIES.map((c) => <option key={c} value={c}>{CATEGORY_LABEL[c]}</option>)}
          </select>
        </L>
        <L label="Supplier">
          <select className={sel} value={f.supplier_id ?? ""} onChange={(e) => set("supplier_id", e.target.value || null)}>
            <option value="">No supplier</option>
            {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </L>
        <L label="Supplier code"><Input value={f.supplier_code ?? ""} onChange={(e) => set("supplier_code", e.target.value)} /></L>
        <L label="Brand"><Input value={f.brand ?? ""} onChange={(e) => set("brand", e.target.value)} /></L>
        <L label="Range"><Input value={f.range ?? ""} onChange={(e) => set("range", e.target.value)} /></L>
        <L label="Colour"><Input value={f.colour ?? ""} onChange={(e) => set("colour", e.target.value)} /></L>
        <L label="Unit">
          <select className={sel} value={f.unit ?? "each"} onChange={(e) => set("unit", e.target.value)}>
            {UNITS.map((u) => <option key={u}>{u}</option>)}
          </select>
        </L>
        {PACK_HINT[f.unit ?? ""] && <L label={PACK_HINT[f.unit ?? ""]!}><Input type="number" min={0} step="0.01" value={f.pack_size ?? ""} onChange={(e) => set("pack_size", num(e.target.value))} /></L>}
        {f.unit !== "each" && <L label={COVER_HINT(f.category ?? "", f.unit ?? "")}><Input type="number" min={0} step="0.01" value={f.coverage ?? ""} onChange={(e) => set("coverage", num(e.target.value))} /></L>}
        <L label="Waste % (blank = Settings default)"><Input type="number" min={0} max={100} value={f.waste_pct ?? ""} onChange={(e) => set("waste_pct", num(e.target.value))} /></L>
        <L label="Lead time (working days)"><Input type="number" min={0} disabled={!!f.stocked} value={f.lead_time_days ?? ""} onChange={(e) => set("lead_time_days", num(e.target.value))} /></L>
        <L label="Spec sheet link"><Input type="url" value={f.spec_url ?? ""} onChange={(e) => set("spec_url", e.target.value)} /></L>
        <L label="Installation guide link"><Input type="url" value={f.install_url ?? ""} onChange={(e) => set("install_url", e.target.value)} /></L>
        <L label="Safety data sheet (SDS) link"><Input type="url" value={f.sds_url ?? ""} onChange={(e) => set("sds_url", e.target.value)} /></L>
        <L label="Warranty link"><Input type="url" value={f.warranty_url ?? ""} onChange={(e) => set("warranty_url", e.target.value)} /></L>
        <L label="Hazard tags (comma separated)"><Input value={(f.hazard_tags ?? []).join(", ")} onChange={(e) => set("hazard_tags", e.target.value.split(",").map((x) => x.trim()).filter(Boolean))} /></L>
      </div>
      <div className="flex flex-wrap gap-4 text-sm">
        <label className="flex items-center gap-2"><Checkbox checked={!!f.stocked} onCheckedChange={(c) => set("stocked", !!c)} /> Stocked (not order in)</label>
        <label className="flex items-center gap-2"><Checkbox checked={f.active ?? true} onCheckedChange={(c) => set("active", !!c)} /> Active</label>
      </div>
      <div className="flex justify-end gap-2">
        {onCancel && <Button variant="ghost" onClick={onCancel}>Cancel</Button>}
        <Button onClick={save} disabled={busy}>{f.id ? "Save item" : "Add to catalogue"}</Button>
      </div>
    </div>
  );
}
