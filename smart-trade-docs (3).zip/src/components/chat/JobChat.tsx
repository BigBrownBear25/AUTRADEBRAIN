import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { AlertTriangle, Camera, CornerUpLeft, Mic, MoveRight, Square, Trash2, X } from "lucide-react";
import { moveBrainPost } from "@/lib/brain.functions";
import { JobPicker, type PickedJob } from "@/components/brain/JobPicker";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { getJobFileUrls } from "@/lib/job-files.functions";
import { jobMessagesQuery, jobPeopleQuery, markRead, useMessagesLive, useUserId, type Message } from "@/lib/chat";
import { tagPhoto } from "@/lib/vision.functions";
import { resizeForAi } from "@/lib/resize-image";
import { PHOTO_TAGS, readingLines, type PhotoReadings } from "@/lib/rules/photos";

const time = (iso: string) => new Date(iso).toLocaleString("en-AU", { weekday: "short", day: "numeric", month: "short", hour: "numeric", minute: "2-digit" });
const sel = "h-9 rounded-md border bg-background px-2 text-sm";

export function JobChat({ workspaceId, jobId, office }: { workspaceId: string; jobId: string; office: boolean }) {
  const qc = useQueryClient();
  const me = useUserId();
  useMessagesLive(jobId);
  const { data } = useQuery(jobMessagesQuery(jobId));
  const { data: people = [] } = useQuery(jobPeopleQuery(jobId));
  const { data: tasks = [] } = useQuery({
    queryKey: ["chat-tasks", jobId],
    queryFn: async () => (await supabase.from("tasks").select("id, label").eq("job_id", jobId).order("sort")).data ?? [],
  });
  const signUrls = useServerFn(getJobFileUrls);
  const paths = useMemo(() => (data?.attachments ?? []).map((a) => a.storage_path).sort(), [data]);
  const { data: urls = {} } = useQuery({
    queryKey: ["file-urls", jobId, paths], enabled: paths.length > 0, staleTime: 45_000, refetchInterval: 50_000,
    queryFn: () => signUrls({ data: { jobId, paths } }),
  });

  const [filter, setFilter] = useState("");
  const [body, setBody] = useState("");
  const [kind, setKind] = useState<"message" | "problem">("message");
  const [taskId, setTaskId] = useState("");
  const [notify, setNotify] = useState<string[]>([]);
  const [replyTo, setReplyTo] = useState<Message | null>(null);
  const [moving, setMoving] = useState<string | null>(null);
  const move = useServerFn(moveBrainPost);
  const moveTo = async (id: string, j: PickedJob) => {
    if (!window.confirm(`Move this post, its files, tasks and proposals to ${j.code}?`)) return;
    try {
      const r = await move({ data: { messageId: id, jobId: j.id } });
      toast.success(`Moved to ${r.code}`); setMoving(null);
      qc.invalidateQueries({ queryKey: ["messages"] }); qc.invalidateQueries({ queryKey: ["job-messages"] }); qc.invalidateQueries();
    } catch (e) { toast.error((e as Error).message); }
  };
  const [files, setFiles] = useState<File[]>([]);
  const [voice, setVoice] = useState<{ blob: Blob; seconds: number } | null>(null);
  const [rec, setRec] = useState<{ mr: MediaRecorder; started: number } | null>(null);
  const [busy, setBusy] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  const msgs = data?.messages ?? [];
  const [photoTag, setPhotoTag] = useState("");
  const tagPhotoFn = useServerFn(tagPhoto);
  /** vision-tag after upload; failures never block the post. */
  const readPhoto = async (id: string, blob: Blob) => {
    try {
      const img = await resizeForAi(blob);
      const r = await tagPhotoFn({ data: { attachmentId: id, ...img } });
      if ("error" in r && r.error) toast.message(`Photo not read: ${r.error}`);
      else if (r.actions.length) toast.message(r.actions.join(". "));
    } catch { /* tagging is best-effort */ }
    qc.invalidateQueries({ queryKey: ["messages", jobId] });
  };
  const photoMsgIds = useMemo(() => new Set((data?.attachments ?? []).filter((a) => a.kind === "photo" && (!photoTag || a.ai_tags.includes(photoTag))).map((a) => a.message_id)), [data, photoTag]);
  const shown = msgs.filter((m) => (!filter || m.task_id === filter) && (!photoTag || photoMsgIds.has(m.id)));
  const nameOf = (uid: string | null) => people.find((p) => p.user_id === uid)?.name ?? (uid ? "Former member" : "System");
  const taskOf = (id: string | null) => tasks.find((t) => t.id === id)?.label;

  useEffect(() => { if (me && msgs.length) { markRead(jobId, me).then(() => qc.invalidateQueries({ queryKey: ["inbox"] })); } }, [me, jobId, msgs.length, qc]);
  useEffect(() => { endRef.current?.scrollIntoView({ block: "end" }); }, [shown.length]);

  const startRec = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      const chunks: Blob[] = [];
      const started = Date.now();
      mr.ondataavailable = (e) => chunks.push(e.data);
      mr.onstop = () => { stream.getTracks().forEach((t) => t.stop()); setVoice({ blob: new Blob(chunks, { type: mr.mimeType || "audio/webm" }), seconds: Math.round((Date.now() - started) / 1000) }); };
      mr.start();
      setRec({ mr, started });
    } catch { toast.error("Allow the microphone to record voice notes on site"); }
  };
  const stopRec = () => { rec?.mr.stop(); setRec(null); };

  const send = async () => {
    if (!me) return;
    if (!body.trim() && !files.length && !voice) return;
    setBusy(true);
    try {
      const { data: msg, error } = await supabase.from("messages").insert({
        job_id: jobId, workspace_id: workspaceId, author_user_id: me, kind, body: body.trim(),
        task_id: taskId || null, reply_to_id: replyTo?.id ?? null, mentions: notify,
      }).select("id").single();
      if (error) throw error;
      const uploads: { blob: Blob; kind: "photo" | "audio" | "file"; mime: string; ext: string; dur?: number }[] = [
        ...files.map((f) => ({ blob: f, kind: f.type.startsWith("image/") ? ("photo" as const) : ("file" as const), mime: f.type, ext: f.name.split(".").pop() || "bin" })),
        ...(voice ? [{ blob: voice.blob, kind: "audio" as const, mime: voice.blob.type, ext: voice.blob.type.includes("mp4") ? "m4a" : "webm", dur: voice.seconds }] : []),
      ];
      for (const u of uploads) {
        const path = `${workspaceId}/${jobId}/${crypto.randomUUID()}.${u.ext}`;
        const up = await supabase.storage.from("job-files").upload(path, u.blob, { contentType: u.mime });
        if (up.error) throw up.error;
        const at = await supabase.from("attachments").insert({ job_id: jobId, workspace_id: workspaceId, message_id: msg.id, kind: u.kind, storage_path: path, mime: u.mime, size: u.blob.size, duration_s: u.dur ?? null, created_by: me }).select("id").single();
        if (at.error) throw at.error;
        if (u.kind === "photo") void readPhoto(at.data.id, u.blob);
      }
      setBody(""); setFiles([]); setVoice(null); setReplyTo(null); setNotify([]); setKind("message");
      qc.invalidateQueries({ queryKey: ["messages", jobId] });
    } catch (e) { toast.error((e as Error).message); }
    setBusy(false);
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from("messages").update({ deleted_at: new Date().toISOString() }).eq("id", id);
    if (error) toast.error(error.message); else qc.invalidateQueries({ queryKey: ["messages", jobId] });
  };

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-2">
        <span className="text-sm text-muted-foreground">Thread</span>
        <select className={sel} value={filter} onChange={(e) => setFilter(e.target.value)} aria-label="Filter by task thread">
          <option value="">Whole job</option>{tasks.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}
        </select>
        <span className="text-sm text-muted-foreground">Photos</span>
        <select className={sel} value={photoTag} onChange={(e) => setPhotoTag(e.target.value)} aria-label="Filter photos by tag">
          <option value="">All posts</option>{PHOTO_TAGS.map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
      </div>

      <div className="max-h-[55vh] min-h-40 space-y-2 overflow-y-auto rounded-md border bg-muted/30 p-3">
        {shown.length === 0 && <p className="text-sm text-muted-foreground">No messages yet. Start the job chat below.</p>}
        {shown.map((m) => {
          const parent = m.reply_to_id ? msgs.find((x) => x.id === m.reply_to_id) : null;
          const att = (data?.attachments ?? []).filter((a) => a.message_id === m.id);
          const mine = m.author_user_id === me;
          return (
            <div key={m.id} className={`rounded-md border bg-card p-2 text-sm ${m.kind === "problem" ? "border-clash" : ""} ${m.mentions.includes(me ?? "") ? "ring-1 ring-primary" : ""}`}>
              <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                <span className="font-medium text-foreground">{m.speaker === "email" ? "Email" : nameOf(m.author_user_id)}</span>
                <span>{time(m.created_at)}</span>
                {m.kind === "problem" && <span className="flex items-center gap-1 rounded-sm bg-clash-soft px-1 text-clash"><AlertTriangle className="h-3 w-3" />Problem</span>}
                {m.task_id && <button className="rounded-sm bg-muted px-1" onClick={() => setFilter(m.task_id!)}>#{taskOf(m.task_id)}</button>}
                {m.mentions.length > 0 && <span>→ {m.mentions.map(nameOf).join(", ")}</span>}
                {m.via === "brain_bar" && <span className="rounded-sm bg-muted px-1">via Brain bar</span>}
              </div>
              {parent && <p className="mt-1 border-l-2 pl-2 text-xs text-muted-foreground">{nameOf(parent.author_user_id)}: {parent.deleted_at ? "deleted" : parent.body.slice(0, 120)}</p>}
              {m.deleted_at ? <p className="mt-1 italic text-muted-foreground">Message deleted</p> : (
                <>
                  {m.body && <p className="mt-1 whitespace-pre-wrap">{m.body}</p>}
                  {att.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-2">
                      {att.map((a) => {
                        const u = urls[a.storage_path];
                        if (!u) return <span key={a.id} className="text-xs text-muted-foreground">Loading file…</span>;
                        if (a.kind === "photo") {
                          const lines = readingLines(a.ai_readings as Partial<PhotoReadings> | null);
                          return (
                            <div key={a.id} className="flex gap-2">
                              <a href={u} target="_blank" rel="noreferrer" className="relative block">
                                <img src={u} alt="Job photo" className="h-28 w-28 rounded-sm object-cover" />
                                {a.ai_tags.length > 0 && <span className="absolute inset-x-1 bottom-1 flex flex-wrap gap-0.5">{a.ai_tags.map((t) => <span key={t} className="rounded-sm bg-background/90 px-1 text-[10px] leading-4 text-foreground">{t}</span>)}</span>}
                              </a>
                              {(lines.length > 0 || a.ai_tags.includes("damage")) && (
                                <div className="max-w-56 space-y-1 text-xs text-muted-foreground">
                                  {lines.map((l) => <p key={l}>{l}</p>)}
                                  {a.ai_tags.includes("damage") && <Button size="sm" variant="outline" className="h-7 px-2 text-xs" disabled title="Variations arrive in step B10">Raise variation</Button>}
                                </div>
                              )}
                            </div>
                          );
                        }
                        if (a.kind === "audio") return <audio key={a.id} controls src={u} className="h-9" />;
                        return <a key={a.id} href={u} target="_blank" rel="noreferrer" className="text-primary underline">File</a>;
                      })}
                    </div>
                  )}
                  <div className="mt-1 flex gap-1">
                    <Button size="sm" variant="ghost" className="h-7 px-2 text-xs" onClick={() => setReplyTo(m)}><CornerUpLeft className="mr-1 h-3 w-3" />Reply</Button>
                    {(mine || office) && <Button size="sm" variant="ghost" className="h-7 px-2 text-xs" onClick={() => remove(m.id)}><Trash2 className="mr-1 h-3 w-3" />Delete</Button>}
                    {m.via === "brain_bar" && (mine || office) && Date.now() - Date.parse(m.created_at) < 7 * 86_400_000 &&
                      <Button size="sm" variant="ghost" className="h-7 px-2 text-xs" onClick={() => setMoving(moving === m.id ? null : m.id)}><MoveRight className="mr-1 h-3 w-3" />Move to another job</Button>}
                  </div>
                  {moving === m.id && <div className="mt-2"><JobPicker ws={workspaceId} exclude={jobId} onPick={(j) => void moveTo(m.id, j)} /></div>}
                </>
              )}
            </div>
          );
        })}
        <div ref={endRef} />
      </div>

      {/* Composer */}
      <div className="space-y-2 rounded-md border bg-card p-3">
        {replyTo && <div className="flex items-center gap-2 text-xs text-muted-foreground">Replying to {nameOf(replyTo.author_user_id)}: {replyTo.body.slice(0, 60)}<button aria-label="Cancel reply" onClick={() => setReplyTo(null)}><X className="h-3 w-3" /></button></div>}
        <Textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder={kind === "problem" ? "Describe the problem" : "Write a message"} rows={2} />
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex rounded-md border p-0.5">
            {(["message", "problem"] as const).map((k) => (
              <button key={k} onClick={() => setKind(k)} className={`min-h-8 rounded-sm px-2 text-xs ${kind === k ? (k === "problem" ? "bg-clash text-primary-foreground" : "bg-primary text-primary-foreground") : "text-muted-foreground"}`}>{k === "message" ? "Message" : "Problem"}</button>
            ))}
          </div>
          <select className={sel} value={taskId} onChange={(e) => setTaskId(e.target.value)} aria-label="Tag a task">
            <option value="">No task</option>{tasks.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}
          </select>
          <label className="inline-flex h-9 cursor-pointer items-center gap-1 rounded-md border px-2 text-xs">
            <Camera className="h-4 w-4" />Photos
            <input type="file" accept="image/*" multiple capture="environment" className="hidden" onChange={(e) => setFiles([...files, ...Array.from(e.target.files ?? [])].slice(0, 10))} />
          </label>
          {rec ? <Button size="sm" variant="outline" onClick={stopRec}><Square className="mr-1 h-3 w-3 text-clash" />Stop</Button>
            : <Button size="sm" variant="outline" onClick={startRec}><Mic className="mr-1 h-4 w-4" />Voice note</Button>}
        </div>
        {(files.length > 0 || voice) && (
          <p className="text-xs text-muted-foreground">
            {files.length > 0 && `${files.length} photo${files.length === 1 ? "" : "s"}`} {voice && `· voice note ${voice.seconds}s`}
            <button className="ml-2 underline" onClick={() => { setFiles([]); setVoice(null); }}>clear</button>
          </p>
        )}
        <div className="flex flex-wrap items-center gap-1">
          <span className="text-xs text-muted-foreground">Notify:</span>
          {people.filter((p) => p.user_id !== me).map((p) => {
            const on = notify.includes(p.user_id);
            return <button key={p.user_id} onClick={() => setNotify(on ? notify.filter((x) => x !== p.user_id) : [...notify, p.user_id])} className={`min-h-8 rounded-sm border px-2 text-xs ${on ? "border-primary bg-primary/10" : "text-muted-foreground"}`}>@{p.name}</button>;
          })}
        </div>
        <Button className="h-10 w-full" onClick={send} disabled={busy || !!rec}>{busy ? "Sending…" : "Send"}</Button>
      </div>
    </div>
  );
}
