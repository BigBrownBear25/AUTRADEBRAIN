import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

const t = (iso: string) => new Date(iso).toLocaleTimeString("en-AU", { hour: "numeric", minute: "2-digit" });

/** Start / Finish for one booking; the database lets a person stamp only their own bookings. */
export function StartFinish({ assignmentId, actualStart, actualEnd }: { assignmentId: string; actualStart: string | null; actualEnd: string | null }) {
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);
  const mark = async (which: "start" | "finish" | "clear") => {
    setBusy(true);
    const { error } = await supabase.rpc("mark_assignment_time", { _assignment_id: assignmentId, _which: which });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["my-day"] });
  };
  return (
    <div className="mt-3 flex items-center gap-2">
      {!actualStart ? (
        <Button className="h-11 flex-1" disabled={busy} onClick={() => mark("start")}>Start</Button>
      ) : !actualEnd ? (
        <>
          <p className="flex-1 text-sm">Started <span className="font-mono">{t(actualStart)}</span></p>
          <Button className="h-11" disabled={busy} onClick={() => mark("finish")}>Finish</Button>
        </>
      ) : (
        <>
          <p className="flex-1 text-sm">Worked <span className="font-mono">{t(actualStart)}–{t(actualEnd)}</span></p>
          <Button variant="ghost" size="sm" disabled={busy} onClick={() => mark("clear")}>Reset</Button>
        </>
      )}
    </div>
  );
}
