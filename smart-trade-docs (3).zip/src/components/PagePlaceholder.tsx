import type { ReactNode } from "react";

export function PagePlaceholder({
  title,
  description,
  step,
  children,
}: {
  title: string;
  description: string;
  step?: string;
  children?: ReactNode;
}) {
  return (
    <div className="mx-auto max-w-[1600px] px-4 py-6 md:py-8">
      <h1 className="text-3xl font-semibold uppercase md:text-4xl">{title}</h1>
      <p className="mt-1 max-w-2xl text-muted-foreground">{description}</p>
      {children ?? (
        <div className="chalk-grid mt-6 grid min-h-72 place-items-center rounded-md border bg-card p-8 text-center">
          <div>
            <p className="font-heading text-xl uppercase tracking-wide text-muted-foreground">
              Coming soon
            </p>
            {step && <p className="mt-1 font-mono text-xs text-muted-foreground">{step}</p>}
          </div>
        </div>
      )}
    </div>
  );
}
