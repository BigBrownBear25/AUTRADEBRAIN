import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { roleLabel, FIELD_ROLES, type AppRole, type ActiveMembership } from "@/lib/session";
import { crewQuery } from "@/lib/crew";

const sel = "h-11 rounded-md border bg-background px-3 text-sm";

export function TeamInvites({ membership }: { membership: ActiveMembership }) {
  const qc = useQueryClient();
  const isOwner = membership.role === "owner";
  const roles: AppRole[] = isOwner ? ["office", ...FIELD_ROLES] : FIELD_ROLES;
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<AppRole>("installer");
  const [crewId, setCrewId] = useState("");
  const key = ["memberships", membership.workspaceId];
  const { data: crew = [] } = useQuery(crewQuery(membership.workspaceId));

  const { data: rows = [] } = useQuery({
    queryKey: key,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("memberships")
        .select("id, role, status, invited_email, user_id, crew_member_id, created_at")
        .eq("workspace_id", membership.workspaceId)
        .neq("status", "removed")
        .order("created_at");
      if (error) throw error;
      return data;
    },
  });

  const linked = new Set(rows.map((r) => r.crew_member_id).filter(Boolean));
  const crewName = (id: string | null) => crew.find((c) => c.id === id)?.name;
  const refresh = () => qc.invalidateQueries({ queryKey: key });

  const pickCrew = (id: string) => {
    setCrewId(id);
    const c = crew.find((x) => x.id === id);
    if (c?.email && !email) setEmail(c.email);
  };

  const invite = async (e: FormEvent) => {
    e.preventDefault();
    const { data: u } = await supabase.auth.getUser();
    const { error } = await supabase.from("memberships").insert({
      workspace_id: membership.workspaceId,
      role,
      status: "invited",
      invited_email: email.trim().toLowerCase(),
      invited_by: u.user!.id,
      crew_member_id: crewId || null,
    });
    if (error) { toast.error(error.message); return; }
    toast.success(`Invite created for ${email}`);
    setEmail(""); setCrewId("");
    refresh();
  };

  const cancel = async (id: string) => {
    const { error } = await supabase.from("memberships").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    refresh();
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from("memberships").update({ status: "removed" }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    refresh();
  };

  const link = async (id: string, crewMemberId: string) => {
    const { error } = await supabase.rpc("link_membership_crew", { _membership_id: id, _crew_member_id: (crewMemberId || null) as string });
    if (error) { toast.error(error.message); return; }
    toast.success("Linked");
    refresh();
  };

  return (
    <section className="rounded-md border bg-card p-5">
      <h2 className="text-xl font-semibold uppercase">Team and invites</h2>
      <form onSubmit={invite} className="mt-4 flex flex-col gap-2 lg:flex-row">
        <select value={crewId} onChange={(e) => pickCrew(e.target.value)} className={sel} aria-label="Crew record">
          <option value="">No crew record</option>
          {crew.filter((c) => !linked.has(c.id)).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <Input type="email" required placeholder="name@example.com" value={email} onChange={(e) => setEmail(e.target.value)} className="h-11" />
        <select value={role} onChange={(e) => setRole(e.target.value as AppRole)} className={sel} aria-label="Role">
          {roles.map((r) => <option key={r} value={r}>{roleLabel[r]}</option>)}
        </select>
        <Button type="submit" className="h-11">Invite</Button>
      </form>
      <p className="mt-1 text-xs text-muted-foreground">When they accept, their account is linked to the chosen crew record (or one with the same email).</p>
      <ul className="mt-4 divide-y">
        {rows.map((r) => (
          <li key={r.id} className="flex min-h-12 flex-wrap items-center gap-3 py-2 text-sm">
            <span className="min-w-40 flex-1 truncate">
              {r.invited_email ?? crewName(r.crew_member_id) ?? "Member"}{r.id === membership.id && " (you)"}
            </span>
            <span className="rounded-sm bg-muted px-2 py-0.5 text-xs">{roleLabel[r.role]}</span>
            <span className={`text-xs ${r.status === "invited" ? "text-warn" : "text-fit"}`}>{r.status}</span>
            {isOwner ? (
              <select className="h-9 rounded-md border bg-background px-2 text-xs" aria-label="Linked crew record"
                value={r.crew_member_id ?? ""} onChange={(e) => link(r.id, e.target.value)}>
                <option value="">Not linked to crew</option>
                {crew.filter((c) => c.id === r.crew_member_id || !linked.has(c.id)).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            ) : (
              <span className="text-xs text-muted-foreground">{crewName(r.crew_member_id) ?? "Not linked"}</span>
            )}
            {isOwner && r.role !== "owner" && (
              r.status === "invited"
                ? <Button size="sm" variant="ghost" onClick={() => cancel(r.id)}>Cancel</Button>
                : <Button size="sm" variant="ghost" onClick={() => remove(r.id)}>Remove</Button>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}
