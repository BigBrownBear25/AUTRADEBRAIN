import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Moon } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { applyProposal } from "@/lib/brain.functions";
import { invalidateAfterApply } from "@/lib/brain";

/** The overnight draft: one group of proposals, every item ticked; Apply ticked runs each through the normal apply path. */
export function DraftPlan({ workspaceId }: { workspaceId: string }) {
  const qc = useQueryClient();
  const apply = useServerFn(applyProposal);
  const q = useQuery({
    queryKey: ["proposals", workspaceId, "draft"],
    queryFn: async () => (await supabase.from("proposals").select("id, title, explanation, group_id, group_label, kind, jobs(code, name)").eq("workspace_id", workspaceId).eq("source", "overnight").eq("status", "open").order("created_at")).data ?? [],
  });
  const [off, setOff] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);
  const items = q.data ?? [];
  if (!items.length) return null;
  const label = items[0]!.group_label ?? "Draft plan";
  async function applyTicked() {
    setBusy(true); let ok = 0; const skipped: string[] = [];
    for (const p of items) {
      if (off.has(p.id)) continue;
      try { const r = await apply({ data: { id: p.id } }); if (r.applied) ok++; else skipped.push(p.title); }
      catch (e) { skipped.push(`${p.title} (${(e as Error).message})`); }
    }
    setBusy(false);
    invalidateAfterApply(qc, workspaceId);
    qc.invalidateQueries({ queryKey: ["proposals"] });
    toast.success(`Applied ${ok}`, skipped.length ? { description: `Left in the Brain feed: ${skipped.slice(0, 3).join("; ")}${skipped.length > 3 ? "…" : ""}` } : undefined);
  }
  return (
    <section className="rounded-md border border-primary/40 bg-card p-4">
      <div className="flex flex-wrap items-center gap-2">
        <Moon className="h-5 w-5 text-primary" />
        <h2 className="font-heading text-xl font-semibold uppercase">{label}</h2>
        <span className="text-sm text-muted-foreground">Untick anything you don't want.</span>
        <Button className="ml-auto" size="sm" disabled={busy || off.size === items.length} onClick={applyTicked}>{busy ? "Applying…" : `Apply ticked (${items.length - off.size})`}</Button>
      </div>
      <ul className="mt-3 space-y-2">
        {items.map((p) => (
          <li key={p.id}>
            <label className="flex min-h-11 items-start gap-3 rounded-md border bg-background p-2 text-sm">
              <Checkbox className="mt-0.5" checked={!off.has(p.id)} onCheckedChange={(v) => setOff((s) => { const n = new Set(s); v ? n.delete(p.id) : n.add(p.id); return n; })} />
              <span><span className="font-medium">{p.title}</span><span className="block text-xs text-muted-foreground">{(p.jobs as { name: string } | null)?.name} · {p.explanation}</span></span>
            </label>
          </li>
        ))}
      </ul>
    </section>
  );
}

/** The latest Monday look-ahead summary. */
export function LookAhead({ workspaceId }: { workspaceId: string }) {
  const q = useQuery({
    queryKey: ["brain_reports", workspaceId, "lookahead"],
    queryFn: async () => (await supabase.from("brain_reports").select("for_date, summary, data").eq("workspace_id", workspaceId).eq("kind", "lookahead").order("for_date", { ascending: false }).limit(1).maybeSingle()).data,
  });
  const r = q.data;
  if (!r) return null;
  const weeks = ((r.data as { weeks?: { week: string; loadPct: number; over: boolean }[] })?.weeks ?? []);
  return (
    <section className="rounded-md border bg-card p-4">
      <h2 className="font-heading text-xl font-semibold uppercase">Six-week look-ahead</h2>
      <p className="text-xs text-muted-foreground">Written {new Date(r.for_date + "T00:00:00").toLocaleDateString("en-AU", { weekday: "long", day: "numeric", month: "short" })}</p>
      <div className="mt-2 flex flex-wrap gap-2">
        {weeks.map((w) => <span key={w.week} className={`rounded px-2 py-1 font-mono text-xs ${w.over ? "bg-clash/15 text-clash" : w.loadPct > 75 ? "bg-warn/15 text-warn" : "bg-fit/15 text-fit"}`}>{w.week.slice(5)} · {w.loadPct}%</span>)}
      </div>
      <p className="mt-3 whitespace-pre-wrap text-sm">{r.summary}</p>
    </section>
  );
}
