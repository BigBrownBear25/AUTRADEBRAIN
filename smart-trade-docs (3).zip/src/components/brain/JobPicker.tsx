import { useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";

export type PickedJob = { id: string; code: string; name: string; address: string | null; suburb: string | null };

/** Search the jobs this person can see (RLS: field users only their own) by code, name, client or address. */
export function JobPicker({ ws, onPick, exclude }: { ws: string; onPick: (j: PickedJob) => void; exclude?: string | null }) {
  const [q, setQ] = useState("");
  const [rows, setRows] = useState<PickedJob[]>([]);
  useEffect(() => {
    const t = q.replace(/[%,()]/g, " ").trim();
    let live = true;
    const id = setTimeout(async () => {
      let req = supabase.from("jobs").select("id, code, name, address, suburb").eq("workspace_id", ws).order("created_at", { ascending: false }).limit(8);
      if (t) req = req.or(["code", "name", "client_name", "builder_company", "address", "suburb"].map((c) => `${c}.ilike.%${t}%`).join(","));
      const { data } = await req;
      if (live) setRows(((data ?? []) as PickedJob[]).filter((j) => j.id !== exclude));
    }, 200);
    return () => { live = false; clearTimeout(id); };
  }, [q, ws, exclude]);
  return (
    <div className="rounded-md border p-2">
      <Input autoFocus placeholder="Search by job code, name, client or address" value={q} onChange={(e) => setQ(e.target.value)} className="h-9" />
      <ul className="mt-1 max-h-48 overflow-y-auto">
        {rows.map((j) => (
          <li key={j.id}>
            <button type="button" onClick={() => onPick(j)} className="w-full rounded-sm px-2 py-1.5 text-left text-sm hover:bg-muted">
              <span className="font-mono">{j.code}</span> · {j.name}
              <span className="block text-xs text-muted-foreground">{[j.address, j.suburb].filter(Boolean).join(", ") || "No address"}</span>
            </button>
          </li>
        ))}
        {!rows.length && <li className="px-2 py-1.5 text-xs text-muted-foreground">No jobs found.</li>}
      </ul>
    </div>
  );
}
