import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { Candidate, CaptureCard, CaptureKind } from "@/lib/brain.functions";
import { JobPicker } from "./JobPicker";

const KINDS: { v: CaptureKind; label: string; office?: boolean }[] = [
  { v: "message", label: "Message" }, { v: "problem", label: "Problem" }, { v: "task", label: "Task" }, { v: "variation", label: "Variation draft" }, { v: "leave", label: "Leave" },
  { v: "enquiry", label: "New enquiry", office: true }, { v: "call_log", label: "Call log", office: true },
];
const JOB_KINDS = new Set<CaptureKind>(["message", "problem", "task", "variation"]);
const FIELD_LABEL: Record<string, string> = {
  name: "Job name", client_name: "Client", client_phone: "Client phone", builder_company: "Builder", builder_pm_name: "Builder PM", builder_pm_phone: "PM phone",
  address: "Address", suburb: "Suburb", flooring: "Flooring", area_m2: "Area (m²)", sector: "Sector", contact_name: "Who", contact_role: "Their role",
  direction: "Direction", leave_type: "Leave type", from_date: "From", to_date: "To", note: "Note", task_label: "Task",
};
const FIELDS_FOR: Partial<Record<CaptureKind, string[]>> = {
  enquiry: ["name", "client_name", "client_phone", "builder_company", "builder_pm_name", "builder_pm_phone", "address", "suburb", "flooring", "area_m2", "sector", "note"],
  call_log: ["contact_name", "contact_role", "direction"],
  leave: ["contact_name", "leave_type", "from_date", "to_date", "note"],
  task: ["task_label"],
};
const fmtDay = (d: string | null) => (d ? new Date(`${d}T00:00:00`).toLocaleDateString("en-AU", { weekday: "short", day: "numeric", month: "short" }) : "Not booked");
const where = (j: { address: string | null; suburb: string | null }) => [j.address, j.suburb].filter(Boolean).join(", ") || "No address";

/** The Brain bar card: the job first and large, kind editable, Confirm only once a job (or no-job choice) is picked. */
export function CaptureCardView({ ws, office, card, setCard, busy, setField, onCancel, onConfirm }: {
  ws: string; office: boolean; card: CaptureCard; setCard: (c: CaptureCard) => void; busy: boolean;
  setField: (k: string, v: string) => void; onCancel: () => void; onConfirm: () => void;
}) {
  const [picking, setPicking] = useState(false);
  const [extra, setExtra] = useState<Candidate[]>([]);
  const m = card.match;
  const all = [...(m?.candidates ?? []), ...extra];
  const chosen = all.find((c) => c.id === card.job_id) ?? null;
  const jobKind = JOB_KINDS.has(card.kind);
  const showJob = jobKind || card.kind === "call_log";
  const pickJob = (id: string | null) => setCard({ ...card, job_id: id, no_job: null });
  const needsPerson = !!card.people && card.people.length > 1 && !card.person_id;
  const canConfirm = !busy && !needsPerson && (!jobKind || !!card.job_id || !!card.no_job);
  const keys = FIELDS_FOR[card.kind] ?? [];

  return (
    <div className="fixed inset-x-2 bottom-[calc(5rem+env(safe-area-inset-bottom))] z-50 mx-auto max-h-[80vh] max-w-2xl overflow-y-auto rounded-md border bg-popover p-4 text-popover-foreground shadow-2xl md:bottom-20">
      <p className="text-xs uppercase text-muted-foreground">Here's what I understood</p>

      {showJob && (
        <section className="mt-2">
          {m?.notice && <p className="mb-2 rounded-sm bg-warn-soft px-2 py-1 text-sm">{m.notice}</p>}
          {chosen && !picking ? (
            <div className="rounded-md border-2 border-primary bg-card p-3">
              <div className="flex items-start gap-2">
                <div className="min-w-0 flex-1">
                  <p className="font-heading text-2xl font-semibold uppercase leading-tight"><span className="font-mono normal-case">{chosen.code}</span> · {chosen.name}</p>
                  <p className="text-sm">{where(chosen)}</p>
                </div>
                <Button size="sm" variant="outline" onClick={() => { pickJob(null); }}>Change</Button>
              </div>
              <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-0.5 text-xs sm:grid-cols-4">
                <div><dt className="text-muted-foreground">Client</dt><dd>{chosen.client_name || "—"}</dd></div>
                <div><dt className="text-muted-foreground">Builder</dt><dd>{chosen.builder_company || "—"}</dd></div>
                <div><dt className="text-muted-foreground">Next booked</dt><dd>{fmtDay(chosen.next_day)}</dd></div>
                <div><dt className="text-muted-foreground">Crew</dt><dd>{chosen.crew.length ? chosen.crew.join(", ") : "—"}</dd></div>
              </dl>
              {chosen.matchedOn.length > 0 && <p className="mt-2 text-xs text-muted-foreground">Matched on: {chosen.matchedOn.join(", ")}</p>}
            </div>
          ) : (
            <div>
              <p className="text-sm font-medium">{m?.how === "none" || !m?.candidates.length ? (m?.notice ? "Pick the job" : "I couldn't find a job for that") : "Which job is it?"}</p>
              {(m?.candidates.length ?? 0) > 0 && (
                <div className="mt-2 grid gap-2 sm:grid-cols-3">
                  {m!.candidates.slice(0, 3).map((c) => (
                    <button key={c.id} type="button" onClick={() => { pickJob(c.id); setPicking(false); }}
                      className={`rounded-md border p-2 text-left text-sm hover:border-primary ${card.job_id === c.id ? "border-primary bg-accent" : ""}`}>
                      <p className="font-mono font-medium">{c.code}</p>
                      <p className="truncate">{c.name}</p>
                      <p className="text-xs">{where(c)}</p>
                      <p className="text-xs text-muted-foreground">Next: {fmtDay(c.next_day)}</p>
                      {c.matchedOn.length > 0 && <p className="mt-1 text-[11px] text-muted-foreground">Matched on: {c.matchedOn.join(", ")}</p>}
                    </button>
                  ))}
                </div>
              )}
              <div className="mt-2 flex flex-wrap gap-2">
                <Button size="sm" variant="outline" onClick={() => setPicking(!picking)}>Another job…</Button>
                {jobKind && office && <Button size="sm" variant={card.no_job === "enquiry" ? "default" : "outline"} onClick={() => setCard({ ...card, job_id: null, no_job: "enquiry" })}>No job: new enquiry</Button>}
                {jobKind && <Button size="sm" variant={card.no_job === "unfiled" ? "default" : "outline"} onClick={() => setCard({ ...card, job_id: null, no_job: "unfiled" })}>No job: unfiled note</Button>}
              </div>
              {picking && <div className="mt-2"><JobPicker ws={ws} onPick={(j) => {
                setExtra((x) => [...x.filter((y) => y.id !== j.id), { ...j, client_name: null, builder_company: null, next_day: null, crew: [], score: 0, matchedOn: ["picked by you"] }]);
                pickJob(j.id); setPicking(false);
              }} /></div>}
            </div>
          )}
        </section>
      )}

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <label className="text-xs text-muted-foreground">Kind
          <select aria-label="Kind" className="ml-1 h-9 rounded-md border bg-background px-2 text-sm text-foreground" value={card.kind}
            onChange={(e) => { const k = e.target.value as CaptureKind; setCard({ ...card, kind: k, no_job: null, urgency: k === "problem" ? card.urgency ?? "today" : card.urgency }); }}>
            {KINDS.filter((k) => office || !k.office).map((k) => <option key={k.v} value={k.v}>{k.label}</option>)}
          </select>
        </label>
        {card.kind === "problem" && (
          <label className="text-xs text-muted-foreground">Urgency
            <select aria-label="Urgency" className="ml-1 h-9 rounded-md border bg-background px-2 text-sm text-foreground" value={card.urgency ?? "today"}
              onChange={(e) => setCard({ ...card, urgency: e.target.value as CaptureCard["urgency"] })}>
              <option value="now">Now</option><option value="today">Today</option><option value="this_week">This week</option>
            </select>
          </label>
        )}
      </div>
      <p className="mt-2 text-sm">{card.summary}</p>

      {keys.length > 0 && (
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {keys.map((k) => (
            <label key={k} className="text-xs text-muted-foreground">{FIELD_LABEL[k] ?? k}<Input className="mt-0.5" value={String(card.fields[k] ?? "")} onChange={(e) => setField(k, e.target.value)} /></label>
          ))}
        </div>
      )}

      {card.people && card.people.length > 1 && (
        <fieldset className="mt-3">
          <legend className="text-xs text-muted-foreground">More than one person matches. Who is it?</legend>
          <div className="mt-1 grid gap-1">
            {card.people.map((p) => (
              <label key={p.id} className={`flex cursor-pointer items-center gap-2 rounded border px-2 py-1.5 text-sm ${card.person_id === p.id ? "border-primary bg-accent" : ""}`}>
                <input type="radio" name="brain-person" checked={card.person_id === p.id} onChange={() => setCard({ ...card, person_id: p.id })} />
                <span className="font-medium">{p.name}</span>
                <span className="text-muted-foreground">{p.role ?? ""}{p.base_suburb ? ` · ${p.base_suburb}` : ""}</span>
              </label>
            ))}
          </div>
        </fieldset>
      )}

      <div className="mt-3 flex items-center justify-end gap-2">
        {jobKind && !card.job_id && !card.no_job && <span className="mr-auto text-xs text-muted-foreground">Pick a job, or a no-job choice, to confirm.</span>}
        <Button variant="ghost" onClick={onCancel}>Cancel</Button>
        <Button disabled={!canConfirm} onClick={onConfirm}>Confirm</Button>
      </div>
    </div>
  );
}
