import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Bell } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { supabase } from "@/integrations/supabase/client";
import { notificationsQuery, proposalsQuery, useBrainLive } from "@/lib/brain";
import { ProposalCard } from "./ProposalCard";

type Filter = "all" | "red" | "amber" | "info";
const DOT: Record<string, string> = { red: "bg-clash", amber: "bg-warn", info: "bg-primary" };

/** Bell with a count; the feed lists proposals and alerts, newest first, with a History tab. */
export function BrainFeed({ ws, userId, office }: { ws: string; userId: string; office: boolean }) {
  useBrainLive(ws, userId);
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<"open" | "history">("open");
  const [filter, setFilter] = useState<Filter>("all");
  const props = useQuery(proposalsQuery(ws, true));
  const hist = useQuery({ ...proposalsQuery(ws, false), enabled: open && tab === "history" });
  const notes = useQuery(notificationsQuery(userId));
  const unread = (notes.data ?? []).filter((n) => !n.read_at);
  const count = (office ? props.data?.length ?? 0 : 0) + unread.length;

  const markRead = async () => {
    if (!unread.length) return;
    await supabase.from("notifications").update({ read_at: new Date().toISOString() }).in("id", unread.map((n) => n.id));
    qc.invalidateQueries({ queryKey: ["notifications", userId] });
  };
  const list = (tab === "open" ? props.data : hist.data) ?? [];
  const shown = list.filter((p) => filter === "all" || p.level === filter);
  const alerts = (notes.data ?? []).filter((n) => !n.proposal_id && (filter === "all" || n.level === filter)).slice(0, 20);

  return (
    <>
      <button aria-label={`Brain feed, ${count} new`} onClick={() => { setOpen(true); }}
        className="relative grid h-11 w-11 place-items-center rounded-sm text-nav-foreground hover:bg-nav-foreground/10">
        <Bell className="h-5 w-5" />
        {count > 0 && <span className="absolute right-1 top-1 min-w-5 rounded-full bg-clash px-1 text-center font-mono text-[11px] leading-5 text-primary-foreground">{count > 99 ? "99+" : count}</span>}
      </button>
      <Sheet open={open} onOpenChange={(o) => { setOpen(o); if (!o) void markRead(); }}>
        <SheetContent side="right" className="w-full overflow-y-auto sm:max-w-md">
          <SheetHeader><SheetTitle className="font-heading text-2xl uppercase">Brain feed</SheetTitle></SheetHeader>
          <div className="mt-3 flex gap-1 text-sm">
            {(["open", "history"] as const).map((t) => (
              <button key={t} onClick={() => setTab(t)} className={`min-h-10 rounded-sm px-3 ${tab === t ? "bg-muted font-semibold" : "text-muted-foreground"}`}>{t === "open" ? "Open" : "History"}</button>
            ))}
            <div className="ml-auto flex gap-1">
              {(["all", "red", "amber", "info"] as Filter[]).map((f) => (
                <button key={f} aria-label={`Show ${f}`} onClick={() => setFilter(f)} className={`flex min-h-10 items-center gap-1 rounded-sm px-2 text-xs uppercase ${filter === f ? "bg-muted font-semibold" : "text-muted-foreground"}`}>
                  {f !== "all" && <span className={`h-2 w-2 rounded-full ${DOT[f]}`} />}{f}
                </button>
              ))}
            </div>
          </div>
          {tab === "open" && alerts.length > 0 && (
            <ul className="mt-3 space-y-2">
              {alerts.map((n) => (
                <li key={n.id} className={`rounded-md border p-3 text-sm ${n.read_at ? "opacity-70" : ""}`}>
                  <p className="flex items-center gap-2 font-medium"><span className={`h-2 w-2 rounded-full ${DOT[n.level]}`} />{n.title}</p>
                  {n.body && <p className="mt-1 whitespace-pre-line text-muted-foreground">{n.body}</p>}
                  {n.job_id && <Link to={office ? "/jobs" : "/my-jobs"} search={{ job: n.job_id }} className="mt-1 inline-block text-xs text-primary" onClick={() => setOpen(false)}>Open job</Link>}
                </li>
              ))}
            </ul>
          )}
          <div className="mt-3 space-y-2">
            {shown.length === 0 && <p className="rounded-md border p-4 text-sm text-muted-foreground">{tab === "open" ? "Nothing waiting. Suggestions from the Brain appear here." : "Applied and dismissed suggestions appear here."}</p>}
            {shown.map((p) => <ProposalCard key={p.id} p={p} ws={ws} office={office} />)}
          </div>
        </SheetContent>
      </Sheet>
    </>
  );
}
