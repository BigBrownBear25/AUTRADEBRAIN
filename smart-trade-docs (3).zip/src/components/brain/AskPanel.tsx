import { useEffect, useRef, useState, type ReactNode } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { Send, Plus } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { ProposalCard } from "./ProposalCard";

type Line = { role: "user" | "brain"; content: string; proposalIds?: string[] };
const STARTERS_OFFICE = ["Who's free Thursday with vinyl welding?", "What's at risk next week?", "What did the builder say about the slab at FZ-1052?"];
const STARTERS_FIELD = ["Where am I tomorrow?", "What's left to do on my job?", "Can I have next Friday off?"];

/** Turns job codes in an answer into links. */
function linkify(text: string, prefix: string, office: boolean, codes: Map<string, string>): ReactNode[] {
  const re = new RegExp(`\\b(${prefix}-\\d{3,6})\\b`, "g");
  return text.split(re).map((part, i) => {
    const id = codes.get(part);
    return i % 2 === 1 && id ? <Link key={i} to={office ? "/jobs" : "/my-jobs"} search={{ job: id }} className="font-mono text-primary underline">{part}</Link> : <span key={i}>{part}</span>;
  });
}

export function AskPanel({ open, onOpenChange, ws, userId, office, seed }: { open: boolean; onOpenChange: (o: boolean) => void; ws: string; userId: string; office: boolean; seed?: string | null }) {
  const qc = useQueryClient();
  const [thread, setThread] = useState<string | null>(null);
  const [lines, setLines] = useState<Line[]>([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  const prefix = useQuery({ queryKey: ["ws-prefix", ws], queryFn: async () => (await supabase.from("workspaces").select("code_prefix").eq("id", ws).single()).data?.code_prefix ?? "FZ" });
  const codes = useQuery({ queryKey: ["ask-codes", ws], enabled: open, queryFn: async () => new Map(((await supabase.from("jobs").select("id, code").eq("workspace_id", ws)).data ?? []).map((j) => [j.code, j.id])) });
  const threads = useQuery({
    queryKey: ["ask-threads", userId], enabled: open,
    queryFn: async () => {
      const { data } = await supabase.from("ask_messages").select("thread_id, content, created_at").eq("user_id", userId).eq("role", "user").order("created_at", { ascending: false }).limit(60);
      const seen = new Map<string, string>();
      for (const r of data ?? []) if (!seen.has(r.thread_id)) seen.set(r.thread_id, r.content);
      return [...seen.entries()].slice(0, 10);
    },
  });
  const proposals = useQuery({
    queryKey: ["proposals", "ask", lines.flatMap((l) => l.proposalIds ?? []).join(",")],
    enabled: lines.some((l) => l.proposalIds?.length),
    queryFn: async () => (await supabase.from("proposals").select("*, jobs(code, name, locked)").in("id", lines.flatMap((l) => l.proposalIds ?? []))).data ?? [],
  });
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [lines]);
  useEffect(() => { if (open && seed) void ask(seed); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [open, seed]);

  async function load(id: string) {
    const { data } = await supabase.from("ask_messages").select("role, content, proposal_ids").eq("user_id", userId).eq("thread_id", id).order("created_at");
    setThread(id);
    setLines((data ?? []).map((m) => ({ role: m.role as Line["role"], content: m.content, proposalIds: m.proposal_ids })));
  }

  async function ask(q: string) {
    const question = q.trim();
    if (!question || busy) return;
    setText(""); setBusy(true);
    setLines((l) => [...l, { role: "user", content: question }, { role: "brain", content: "" }]);
    const { data: s } = await supabase.auth.getSession();
    try {
      const res = await fetch("/api/brain-ask", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${s.session?.access_token ?? ""}` }, body: JSON.stringify({ thread_id: thread, text: question }) });
      if (!res.ok || !res.body) { const j = await res.json().catch(() => ({})); throw new Error(j.error ?? `The Brain couldn't answer (${res.status})`); }
      const reader = res.body.getReader(); const dec = new TextDecoder(); let buf = "";
      for (;;) {
        const { done, value } = await reader.read(); if (done) break;
        buf += dec.decode(value, { stream: true });
        let i;
        while ((i = buf.indexOf("\n")) >= 0) {
          const line = buf.slice(0, i); buf = buf.slice(i + 1);
          if (!line.trim()) continue;
          const ev = JSON.parse(line);
          if (ev.t === "thread") setThread(ev.v);
          else if (ev.t === "text") setLines((l) => { const c = [...l]; const last = c[c.length - 1]!; c[c.length - 1] = { ...last, content: last.content + ev.v }; return c; });
          else if (ev.t === "done") setLines((l) => { const c = [...l]; c[c.length - 1] = { role: "brain", content: ev.text || c[c.length - 1]!.content, proposalIds: ev.proposalIds }; return c; });
          else if (ev.t === "error") setLines((l) => { const c = [...l]; c[c.length - 1] = { role: "brain", content: `⚠ ${ev.v}` }; return c; });
        }
      }
      qc.invalidateQueries({ queryKey: ["ask-threads", userId] });
    } catch (e) {
      setLines((l) => { const c = [...l]; c[c.length - 1] = { role: "brain", content: `⚠ ${(e as Error).message}` }; return c; });
    } finally { setBusy(false); }
  }

  const byId = new Map((proposals.data ?? []).map((p) => [p.id, p]));
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="flex w-full flex-col sm:max-w-lg">
        <SheetHeader className="flex-row items-center gap-2">
          <SheetTitle className="font-heading text-2xl uppercase">Ask Trade Brain</SheetTitle>
          <Button size="sm" variant="ghost" className="ml-auto" onClick={() => { setThread(null); setLines([]); }}><Plus className="h-4 w-4" />New</Button>
        </SheetHeader>
        <div className="flex-1 space-y-3 overflow-y-auto py-3">
          {lines.length === 0 && (
            <div className="space-y-3">
              <div className="flex flex-wrap gap-2">
                {(office ? STARTERS_OFFICE : STARTERS_FIELD).map((s) => <Button key={s} size="sm" variant="outline" className="h-auto whitespace-normal py-2 text-left" onClick={() => ask(s)}>{s}</Button>)}
              </div>
              {(threads.data ?? []).length > 0 && (
                <div>
                  <p className="text-xs uppercase text-muted-foreground">Earlier conversations</p>
                  <ul className="mt-1 divide-y rounded-md border">
                    {threads.data!.map(([id, first]) => <li key={id}><button className="min-h-11 w-full truncate px-3 text-left text-sm hover:bg-muted" onClick={() => load(id)}>{first}</button></li>)}
                  </ul>
                </div>
              )}
            </div>
          )}
          {lines.map((l, i) => (
            <div key={i} className={l.role === "user" ? "ml-8 rounded-md bg-primary/10 p-3 text-sm" : "mr-4 text-sm"}>
              <div className="whitespace-pre-wrap">{l.role === "brain" ? (l.content ? linkify(l.content, prefix.data ?? "FZ", office, codes.data ?? new Map()) : <span className="text-muted-foreground">Thinking…</span>) : l.content}</div>
              {(l.proposalIds ?? []).map((id) => byId.get(id) && <div key={id} className="mt-2"><ProposalCard p={byId.get(id)!} ws={ws} office={office} compact /></div>)}
            </div>
          ))}
          <div ref={end} />
        </div>
        <form className="flex gap-2 border-t pt-3" onSubmit={(e) => { e.preventDefault(); void ask(text); }}>
          <Textarea value={text} onChange={(e) => setText(e.target.value)} rows={2} placeholder="Ask about jobs, crew, dates…" className="min-h-11 flex-1 resize-none"
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void ask(text); } }} />
          <Button type="submit" size="icon" className="h-11 w-11" disabled={busy || !text.trim()} aria-label="Ask"><Send className="h-4 w-4" /></Button>
        </form>
      </SheetContent>
    </Sheet>
  );
}
