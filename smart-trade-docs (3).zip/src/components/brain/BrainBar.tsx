import { useEffect, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Mic, Sparkles, X, MessageCircleQuestion } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { brainCapture, confirmCapture, type CaptureCard } from "@/lib/brain.functions";
import { AskPanel } from "./AskPanel";
import { CaptureCardView } from "./CaptureCardView";
import { recentJobIds, unpinBrain, usePinnedJob } from "@/lib/brain-pin";


/** Hold to talk (browser dictation) while the button is pressed. */
function useDictation(onText: (t: string) => void) {
  const rec = useRef<any>(null);
  const [listening, setListening] = useState(false);
  const supported = typeof window !== "undefined" && !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
  const start = () => {
    if (!supported || listening) return;
    const R = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const r = new R(); r.lang = "en-AU"; r.interimResults = false; r.continuous = true;
    let acc = "";
    r.onresult = (e: any) => { for (let i = e.resultIndex; i < e.results.length; i++) if (e.results[i].isFinal) acc += e.results[i][0].transcript + " "; };
    r.onend = () => { setListening(false); onText(acc.trim()); };
    r.onerror = () => setListening(false);
    rec.current = r; r.start(); setListening(true);
  };
  const stop = () => rec.current?.stop();
  return { supported, listening, start, stop };
}

export function BrainBar({ ws, userId, office }: { ws: string; userId: string; office: boolean }) {
  const qc = useQueryClient();
  const capture = useServerFn(brainCapture);
  const confirm = useServerFn(confirmCapture);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [card, setCard] = useState<CaptureCard | null>(null);
  const [said, setSaid] = useState("");
  const [askOpen, setAskOpen] = useState(false);
  const [askSeed, setAskSeed] = useState<string | null>(null);
  const [phoneOpen, setPhoneOpen] = useState(false);
  // Desktop office bar: a small "Brain" button until clicked or "/" is pressed.
  const [deskOpen, setDeskOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement | null;
      const typing = el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT" || el.isContentEditable);
      if (e.key === "/" && !typing && !e.metaKey && !e.ctrlKey) { e.preventDefault(); setDeskOpen(true); }
      else if (e.key === "Escape" && !card) setDeskOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [card]);
  useEffect(() => { if (deskOpen) setTimeout(() => inputRef.current?.focus(), 0); }, [deskOpen]);
  const pinned = usePinnedJob();
  const dict = useDictation((t) => { setText(t); void understand(t); });

  async function understand(t: string) {
    const v = t.trim(); if (busy) return;
    if (!v) { toast.error("I didn't catch that. Try again."); return; }
    setBusy(true); setSaid(v);
    try {
      const r = await capture({ data: { text: v, pinnedJobId: pinned?.id ?? null, recent: recentJobIds() } });
      if (r.card.kind === "question") { setAskSeed(r.card.question || v); setAskOpen(true); setText(""); return; }
      setCard(r.card);
    } catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
  }
  async function doConfirm() {
    if (!card) return;
    setBusy(true);
    try {
      const r = await confirm({ data: { card, transcript: said } });
      toast.success(r.done);
      qc.invalidateQueries({ queryKey: ["proposals"] });
      setCard(null); setText(""); setPhoneOpen(false); setDeskOpen(false);
    } catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
  }
  useEffect(() => { if (!askOpen) setAskSeed(null); }, [askOpen]);

  const setField = (k: string, v: string) => card && setCard({ ...card, ...(k === "contact_name" ? { people: [], person_id: null } : {}), fields: { ...card.fields, [k]: k === "area_m2" ? (v === "" ? null : Number(v)) : v || null } });

  const bar = (
    <div>
    {pinned && (
      <p className="mb-1 flex items-center gap-1 text-xs text-muted-foreground">
        About <span className="font-mono text-foreground">{pinned.code}</span>{pinned.label ? ` · ${pinned.label}` : ""}
        <button type="button" aria-label="Unpin job" className="ml-1 rounded-sm p-0.5 hover:bg-muted" onClick={() => unpinBrain()}><X className="h-3 w-3" /></button>
      </p>
    )}
    <form className="flex items-center gap-2" onSubmit={(e) => { e.preventDefault(); void understand(text); }}>
      {dict.supported && (
        <Button type="button" size="icon" variant={dict.listening ? "destructive" : "outline"} className="h-11 w-11 shrink-0" aria-label="Hold to talk"
          onPointerDown={dict.start} onPointerUp={dict.stop} onPointerLeave={() => dict.listening && dict.stop()}>
          <Mic className="h-5 w-5" />
        </Button>
      )}
      <Input ref={inputRef} value={text} onChange={(e) => setText(e.target.value)} placeholder={dict.listening ? "Listening…" : office ? "Tell the Brain: a call, an enquiry, leave, a job update…" : "Tell the Brain: a problem, an update, leave…"} className="h-11" />
      <Button type="submit" className="h-11" disabled={busy || !text.trim()}><Sparkles className="h-4 w-4" />{busy ? "…" : "Go"}</Button>
      <Button type="button" variant="outline" className="h-11" onClick={() => setAskOpen(true)} aria-label="Ask Trade Brain"><MessageCircleQuestion className="h-4 w-4" /><span className="hidden lg:inline">Ask</span></Button>
    </form>
    </div>
  );

  return (
    <>
      {/* Desktop office: a bar along the bottom of every screen */}
      {office && (deskOpen
        ? <div className="fixed inset-x-0 bottom-0 z-30 hidden border-t bg-card/95 px-4 py-2 backdrop-blur md:block">
            <div className="mx-auto flex max-w-3xl items-center gap-2"><div className="flex-1">{bar}</div>
              <Button size="icon" variant="ghost" aria-label="Collapse Brain bar" onClick={() => setDeskOpen(false)}><X className="h-4 w-4" /></Button></div>
          </div>
        : <Button className="fixed bottom-4 right-4 z-30 hidden h-10 shadow-lg md:inline-flex" onClick={() => setDeskOpen(true)} title="Open the Brain bar (press /)">
            <Sparkles className="h-4 w-4" />Brain <kbd className="ml-1 rounded border border-primary-foreground/40 px-1 font-mono text-[10px]">/</kbd>
          </Button>)}
      {/* Phones (and field on desktop): a microphone button */}
      <button aria-label="Brain bar" onClick={() => setPhoneOpen(true)}
        className={`fixed right-4 z-40 grid h-14 w-14 place-items-center rounded-full bg-primary text-primary-foreground shadow-lg bottom-[calc(5rem+env(safe-area-inset-bottom))] ${office ? "md:hidden" : "md:bottom-6"}`}>
        <Mic className="h-6 w-6" />
      </button>
      {phoneOpen && (
        <div className="fixed inset-x-0 bottom-0 z-50 border-t bg-card p-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))] shadow-2xl">
          <div className="mb-2 flex items-center"><p className="font-heading text-lg uppercase">Brain bar</p><Button size="icon" variant="ghost" className="ml-auto" aria-label="Close" onClick={() => setPhoneOpen(false)}><X className="h-4 w-4" /></Button></div>
          {bar}
        </div>
      )}

      {card && (
        <CaptureCardView ws={ws} office={office} card={card} setCard={setCard} busy={busy} setField={setField}
          onCancel={() => { setCard(null); setText(""); setDeskOpen(false); }} onConfirm={doConfirm} />
      )}
      <AskPanel open={askOpen} onOpenChange={setAskOpen} ws={ws} userId={userId} office={office} seed={askSeed} />
    </>
  );
}
