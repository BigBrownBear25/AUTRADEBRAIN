import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { pushPublicKey, pushTest } from "@/lib/push.functions";

const b64ToBytes = (s: string) => { const p = "=".repeat((4 - (s.length % 4)) % 4); const r = atob((s + p).replace(/-/g, "+").replace(/_/g, "/")); return Uint8Array.from(r, (c) => c.charCodeAt(0)); };

/** "Push on this device": registers the service worker and saves this browser's subscription. */
export function PushToggle() {
  const getKey = useServerFn(pushPublicKey);
  const test = useServerFn(pushTest);
  const [on, setOn] = useState(false);
  const [supported, setSupported] = useState(false);
  useEffect(() => {
    const ok = "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
    setSupported(ok);
    if (ok) void navigator.serviceWorker.getRegistration("/sw.js").then(async (r) => setOn(!!(await r?.pushManager.getSubscription())));
  }, []);
  if (!supported) {
    const iphone = /iPhone|iPad|iPod/.test(navigator.userAgent);
    const standalone = window.matchMedia("(display-mode: standalone)").matches || (navigator as { standalone?: boolean }).standalone === true;
    return <p className="text-xs text-muted-foreground">{iphone && !standalone
      ? "On iPhone, tap Share, then Add to Home Screen. Open Trade Brain from the new icon and turn alerts on here."
      : "Push notifications aren't available in this browser."}</p>;
  }

  async function toggle(next: boolean) {
    try {
      const reg = await navigator.serviceWorker.register("/sw.js");
      if (!next) {
        const s = await reg.pushManager.getSubscription();
        if (s) { await supabase.from("push_subscriptions").delete().eq("endpoint", s.endpoint); await s.unsubscribe(); }
        setOn(false); return;
      }
      if ((await Notification.requestPermission()) !== "granted") { toast.error("Notifications are blocked for this site in your browser settings."); return; }
      const { key } = await getKey();
      if (!key) { toast.error("Push isn't set up yet."); return; }
      const s = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToBytes(key) });
      const j = s.toJSON() as { endpoint: string; keys: { p256dh: string; auth: string } };
      const { data: u } = await supabase.auth.getUser();
      await supabase.from("push_subscriptions").delete().eq("endpoint", j.endpoint);
      const { error } = await supabase.from("push_subscriptions").insert({ user_id: u.user!.id, endpoint: j.endpoint, p256dh: j.keys.p256dh, auth: j.keys.auth, device_label: navigator.userAgent.slice(0, 120) });
      if (error && error.code !== "23505") throw error;
      setOn(true);
      const r = await test();
      toast.success(r.sent ? "Push is on for this device" : "Saved — a test notification didn't arrive yet");
    } catch (e) { toast.error((e as Error).message); }
  }
  return (
    <label className="flex min-h-11 items-center justify-between gap-3 rounded-md border px-3 text-sm">
      Push notifications on this device
      <Switch checked={on} onCheckedChange={toggle} />
    </label>
  );
}
