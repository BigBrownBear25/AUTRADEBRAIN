import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { applyProposal, dismissProposal, undoProposal } from "@/lib/brain.functions";
const SCHEDULING = new Set(["place", "move", "swap", "add_person", "remove_person"]);
import { DISMISS_REASONS, KIND_LABEL, SOURCE_LABEL, invalidateAfterApply, type Proposal } from "@/lib/brain";

type FitRow = { person: string; level: "good" | "warning" | "clash"; reasons: { level: string; check: string; text: string }[] };
const LEVEL_BAR: Record<string, string> = { red: "border-l-clash", amber: "border-l-warn", info: "border-l-primary" };
const FIT_TEXT: Record<string, string> = { good: "text-fit", warning: "text-warn", clash: "text-clash" };

export function ProposalCard({ p, ws, office, compact }: { p: Proposal & { jobs?: { code: string; name: string; locked: boolean } | null }; ws: string; office: boolean; compact?: boolean }) {
  const qc = useQueryClient();
  const apply = useServerFn(applyProposal);
  const dismiss = useServerFn(dismissProposal);
  const undo = useServerFn(undoProposal);
  const [busy, setBusy] = useState(false);
  const [clash, setClash] = useState<FitRow[] | null>(null);
  const [asking, setAsking] = useState(false);
  const fit = (clash ?? (Array.isArray(p.fit) ? (p.fit as unknown as FitRow[]) : null));
  const locked = !!p.jobs?.locked;
  const canApply = p.status === "open" && !locked && !["send_email", "send_sms"].includes(p.kind) && (office || p.kind === "leave_request");

  async function doApply(anyway: boolean) {
    setBusy(true);
    try {
      const r = await apply({ data: { id: p.id, anyway } });
      if (!r.applied) { setClash(r.fit as FitRow[]); toast.warning("This now clashes. Check the reasons, then Apply anyway if it's right."); return; }
      invalidateAfterApply(qc, ws);
      toast.success(`Applied: ${p.title}`, {
        duration: 7000,
        action: { label: "Undo", onClick: async () => { try { await undo({ data: { id: p.id } }); invalidateAfterApply(qc, ws); toast("Change undone"); } catch (e) { toast.error((e as Error).message); } } },
      });
    } catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
  }
  async function doDismiss(reason: string | null) {
    setBusy(true);
    try { await dismiss({ data: { id: p.id, reason } }); invalidateAfterApply(qc, ws); setAsking(false); } catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
  }
  async function doUndo() {
    setBusy(true);
    try { await undo({ data: { id: p.id } }); invalidateAfterApply(qc, ws); toast("Change undone"); } catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
  }

  return (
    <article className={`rounded-md border border-l-4 bg-card p-3 ${LEVEL_BAR[p.level] ?? ""}`}>
      <div className="flex flex-wrap items-baseline gap-x-2 text-xs uppercase text-muted-foreground">
        <span className="font-semibold">{KIND_LABEL[p.kind]}</span>
        <span>· {SOURCE_LABEL[p.source]}</span>
        {p.jobs && <span className="font-mono normal-case">· {p.jobs.code}</span>}
        {p.status !== "open" && <span className="ml-auto font-semibold">{p.status}{p.dismiss_reason ? ` (${p.dismiss_reason.replace("_", " ")})` : ""}</span>}
      </div>
      <p className="mt-1 text-sm font-medium">{p.title || KIND_LABEL[p.kind]}</p>
      {!compact && p.explanation && <p className="mt-1 text-sm text-muted-foreground">{p.explanation}</p>}
      {fit && fit.length > 0 && (
        <ul className="mt-2 space-y-0.5 text-xs">
          {fit.map((f, i) => (
            <li key={i}><span className={`font-semibold uppercase ${FIT_TEXT[f.level]}`}>{f.level === "good" ? "Fits" : f.level === "warning" ? "Warn" : "Clash"}</span> {f.person}
              {f.reasons.filter((r) => r.level !== "good").slice(0, 3).map((r, k) => <span key={k} className="text-muted-foreground"> · {r.text}</span>)}
            </li>
          ))}
        </ul>
      )}
      {locked && p.status === "open" && <p className="mt-2 flex items-center gap-1 text-xs text-muted-foreground"><Lock className="h-3 w-3" /> Job is locked — unlock it to apply.</p>}
      <div className="mt-2 flex flex-wrap gap-2">
        {canApply && (clash?.some((f) => f.level === "clash")
          ? office && <Button size="sm" variant="destructive" disabled={busy} onClick={() => doApply(true)}>Apply anyway</Button>
          : <Button size="sm" disabled={busy} onClick={() => doApply(false)}>Apply</Button>)}
        {p.status === "open" && office && (SCHEDULING.has(p.kind) && p.job_id
          ? <Button size="sm" variant="outline" asChild><Link to="/schedule" search={{ place: p.job_id, proposal: p.id }}>Edit</Link></Button>
          : (p.job_id || p.kind === "create_job") && <Button size="sm" variant="outline" asChild><Link to="/jobs" search={p.job_id ? { job: p.job_id, proposal: p.id } : { proposal: p.id }}>Edit</Link></Button>)}
        {p.status === "open" && (office || p.created_by) && !asking && <Button size="sm" variant="ghost" disabled={busy} onClick={() => setAsking(true)}>Dismiss</Button>}
        {asking && DISMISS_REASONS.map((r) => <Button key={r.value} size="sm" variant="outline" disabled={busy} onClick={() => doDismiss(r.value)}>{r.label}</Button>)}
        {p.status === "applied" && office && <Button size="sm" variant="ghost" disabled={busy} onClick={doUndo}>Undo</Button>}
        {p.job_id && !compact && <Button size="sm" variant="ghost" asChild><Link to={office ? "/jobs" : "/my-jobs"} search={{ job: p.job_id } as never}>Open job</Link></Button>}
      </div>
    </article>
  );
}
