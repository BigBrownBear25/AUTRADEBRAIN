import type { ReactNode } from "react";

export function AuthCard({ title, subtitle, children }: { title: string; subtitle?: string; children: ReactNode }) {
  return (
    <div className="chalk-grid flex min-h-screen items-center justify-center bg-background px-4 pt-safe pb-safe">
      <div className="w-full max-w-md rounded-md border bg-card p-6 shadow-sm">
        <div className="mb-5 flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-sm bg-primary font-heading text-lg font-bold text-primary-foreground">
            TB
          </span>
          <span className="font-heading text-xl font-semibold uppercase tracking-wide">Trade Brain</span>
        </div>
        <h1 className="text-2xl font-semibold uppercase">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}
        <div className="mt-5">{children}</div>
      </div>
    </div>
  );
}
