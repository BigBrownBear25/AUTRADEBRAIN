import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Sun, AlertTriangle, Mail, Undo2, ArrowRightLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { Json } from "@/integrations/supabase/types";
import { Button } from "@/components/ui/button";
import { BriefTop } from "./BriefTop";
import { useServerFn } from "@tanstack/react-start";
import { applyProposal, undoProposal } from "@/lib/brain.functions";
import { hm } from "@/lib/assignments";
import { leaveQuery } from "@/lib/leave";
import { invalidateSchedule, toRuleJob, useSchedulingData } from "@/lib/scheduling";
import { findCrew } from "@/lib/rules/fit-check";
import { addDays } from "@/lib/rules/board";
import { nextWorkingDays } from "@/lib/rules/working-days";
import { freeForBlocks, leaveClashesInWindow, overnightSince, swapRows, type BriefBooking } from "@/lib/rules/morning-brief";

const fmt = (d: string) => new Date(`${d}T00:00:00`).toLocaleDateString("en-AU", { weekday: "short", day: "numeric", month: "short" });
type Applied = { label: string; jobId: string; proposalId: string };

/** Office morning brief: overnight leave over bookings (with swaps), problems posted overnight, unfiled email. */
export function MorningBrief({ workspaceId }: { workspaceId: string }) {
  const qc = useQueryClient();
  const apply = useServerFn(applyProposal);
  const undoP = useServerFn(undoProposal);
  const api = useSchedulingData(workspaceId);
  const leave = useQuery(leaveQuery(workspaceId));
  const settings = useQuery({
    queryKey: ["workspace_settings", workspaceId, "brief"],
    queryFn: async () => (await supabase.from("workspace_settings").select("day_end").eq("workspace_id", workspaceId).single()).data,
  });
  const [applied, setApplied] = useState<Record<string, Applied>>({});
  const [busy, setBusy] = useState(false);

  const since = (() => {
    if (!api || !settings.data) return null;
    const ctx = api.ctxFor({ id: "", sector: "domestic", crew_size: 1, hazards: [], extra_tickets: [], main_skill: null, other_skills: [], duration_value: 1, duration_unit: "days", start_time: null, due_by: null, due_hard: false, access_window: { days: [] }, locked: false });
    // Previous working day: walk back up to 10 days.
    let prev = addDays(api.today, -1);
    for (let i = 0; i < 10 && nextWorkingDays(prev, 1, ctx.week)[0] !== prev; i++) prev = addDays(prev, -1);
    const window = nextWorkingDays(api.today, 2, ctx.week);
    return { iso: overnightSince(api.today, prev, settings.data.day_end), from: api.today, to: window[1] ?? window[0] ?? api.today, ctx };
  })();

  const problems = useQuery({
    enabled: !!since,
    queryKey: ["brief-problems", workspaceId, since?.iso],
    queryFn: async () => (await supabase.from("messages").select("id, job_id, body, created_at").eq("workspace_id", workspaceId).eq("kind", "problem").is("deleted_at", null).gte("created_at", since!.iso).order("created_at")).data ?? [],
  });
  const unfiled = useQuery({
    queryKey: ["inbound_emails", workspaceId, "count"],
    queryFn: async () => (await supabase.from("inbound_emails").select("id", { count: "exact", head: true }).eq("workspace_id", workspaceId).eq("status", "unfiled")).count ?? 0,
  });

  if (!api || !since || !leave.data) return <section className="rounded-md border bg-card p-4 text-sm text-muted-foreground">Preparing the morning brief…</section>;

  const bookings: BriefBooking[] = api.bookingsRaw.map((b) => ({ id: b.id, crew_member_id: b.crew_member_id, job_id: b.job_id, date: b.date, start: hm(b.start_time), end: hm(b.end_time) }));
  const clashes = leaveClashesInWindow(leave.data, bookings, since.from, since.to, since.iso);
  const name = (id: string) => api.people.find((p) => p.id === id)?.name ?? "Someone";
  const todays = new Set(bookings.filter((b) => b.date === api.today).map((b) => b.job_id));
  const crewToday = new Set(bookings.filter((b) => b.date === api.today).map((b) => b.crew_member_id));

  /** Each swap is a proposal (source: brief) applied through the shared apply/undo path, so it's audited as "Brain: brief". */
  async function swap(key: string, jobId: string, ids: string[], from: string, to: string) {
    const job = api!.jobMap.get(jobId)!;
    setBusy(true);
    try {
      const { data: prev, error: pe } = await supabase.from("assignments").select("id, crew_member_id, date, start_time, end_time, is_lead").eq("job_id", jobId);
      if (pe || !prev) throw new Error(pe?.message ?? "Couldn't read the bookings");
      const { data: u } = await supabase.auth.getUser();
      const label = `${name(to)} in for ${name(from)} on ${job.code}`;
      const { data: prop, error } = await supabase.from("proposals").insert({
        workspace_id: workspaceId, job_id: jobId, source: "brief", kind: "swap", level: "red", title: label,
        explanation: `${name(from)} is away; ${name(to)} is free for the same blocks.`, created_by: u.user!.id, created_by_brain: true,
        payload: { rows: swapRows(prev, ids, to), start_date: job.start_date, start_time: job.start_time, status: job.status } as unknown as Json,
        dedupe_key: `brief:${key}:${to}`,
      }).select("id").single();
      if (error) throw error;
      const r = await apply({ data: { id: prop.id } });
      if (!r.applied) { toast.warning("That swap now clashes — it's waiting in the Brain feed for a decision."); qc.invalidateQueries({ queryKey: ["proposals"] }); return; }
      setApplied((a) => ({ ...a, [key]: { label, jobId, proposalId: prop.id } }));
      invalidateSchedule(qc, workspaceId, jobId);
      qc.invalidateQueries({ queryKey: ["proposals"] });
      toast.success(`${label}`);
    } catch (e) { toast.error((e as Error).message); }
    finally { setBusy(false); }
  }
  async function undo(key: string) {
    const a = applied[key]!;
    setBusy(true);
    try {
      await undoP({ data: { id: a.proposalId } });
      setApplied(({ [key]: _, ...rest }) => rest);
      invalidateSchedule(qc, workspaceId, a.jobId);
      qc.invalidateQueries({ queryKey: ["proposals"] });
      toast("Swap undone");
    } catch (e) { toast.error((e as Error).message); }
    finally { setBusy(false); }
  }

  return (
    <section className="rounded-md border bg-card p-4">
      <div className="flex flex-wrap items-baseline gap-2">
        <Sun className="h-5 w-5 self-center text-primary" />
        <h2 className="font-heading text-xl font-semibold uppercase">Morning brief</h2>
        <span className="text-sm text-muted-foreground">{fmt(api.today)} · {todays.size} job{todays.size === 1 ? "" : "s"} on today · {crewToday.size} crew out · changes since {new Date(since.iso).toLocaleString("en-AU", { weekday: "short", hour: "numeric", minute: "2-digit" })}</span>
      </div>

      <div className="mt-3"><BriefTop workspaceId={workspaceId} /></div>

      <div className="mt-4 space-y-3 border-t pt-3">
        <h3 className="text-sm font-semibold">Overnight leave over bookings</h3>
        {clashes.length === 0 && <p className="text-sm">No leave over bookings today or next working day.</p>}
        {clashes.map((c) => {
          const job = api.jobMap.get(c.jobId);
          if (!job) return null;
          const rj = toRuleJob(job);
          const ctx = api.ctxFor(rj);
          const others = bookings.filter((b) => !c.bookings.some((x) => x.id === b.id));
          const options = findCrew(rj, job.start_date ?? c.bookings[0]!.date, ctx, 30)
            .filter((r) => freeForBlocks(r.personId, c.bookings, others, ctx.leave))
            .slice(0, 3);
          const done = applied[c.key];
          return (
            <div key={c.key} className={`rounded-md border-l-4 p-3 ${c.leave.status === "approved" ? "border-l-clash" : "border-l-warn"} bg-background`}>
              <p className="text-sm font-medium">
                <AlertTriangle className="mr-1 inline h-4 w-4 text-clash" />
                {name(c.leave.crew_member_id)} — {c.leave.type} ({c.leave.status}){c.overnight && <span className="ml-1 rounded bg-muted px-1.5 text-xs">entered overnight</span>}
              </p>
              <p className="text-sm text-muted-foreground">
                Booked on <span className="font-mono text-foreground">{job.code}</span> {job.name} · {c.bookings.map((b) => fmt(b.date)).join(", ")}
              </p>
              {done ? (
                <div className="mt-2 flex items-center gap-2 text-sm">
                  <span className="text-fit">Applied: {done.label}</span>
                  <Button size="sm" variant="outline" disabled={busy} onClick={() => undo(c.key)}><Undo2 className="mr-1 h-4 w-4" />Undo</Button>
                </div>
              ) : options.length ? (
                <ul className="mt-2 space-y-1">
                  {options.map((o) => (
                    <li key={o.personId} className="flex flex-wrap items-center gap-2 text-sm">
                      <span className="w-8 text-right font-mono font-semibold">{o.score}</span>
                      <span className="font-medium">{name(o.personId)}</span>
                      <span className="text-xs text-muted-foreground">{o.reasons.join(" · ")}</span>
                      <Button size="sm" disabled={busy} onClick={() => swap(c.key, c.jobId, c.bookings.map((b) => b.id), c.leave.crew_member_id, o.personId)}>
                        <ArrowRightLeft className="mr-1 h-4 w-4" />Swap in
                      </Button>
                    </li>
                  ))}
                </ul>
              ) : <p className="mt-2 text-sm">Nobody is free for those blocks. Open the job to move it or find a slot.</p>}
            </div>
          );
        })}

        {(problems.data ?? []).length > 0 && (
          <div>
            <h3 className="text-sm font-semibold">Problems posted overnight</h3>
            <ul className="mt-1 space-y-1 text-sm">
              {problems.data!.map((p) => (
                <li key={p.id}><Link to="/messages" search={{ job: p.job_id }} className="font-mono underline">{api.jobMap.get(p.job_id)?.code ?? "Job"}</Link> {p.body.slice(0, 140)}</li>
              ))}
            </ul>
          </div>
        )}
        {(unfiled.data ?? 0) > 0 && (
          <p className="text-sm"><Mail className="mr-1 inline h-4 w-4" /><Link to="/messages" className="underline">{unfiled.data} unfiled email{unfiled.data === 1 ? "" : "s"}</Link> waiting.</p>
        )}
      </div>
    </section>
  );
}
