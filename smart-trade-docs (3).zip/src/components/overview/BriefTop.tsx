import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { RefreshCw, Check, ExternalLink, X, ChevronDown, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getMorningBrief, markBriefItem, type BriefRow } from "@/lib/brief.functions";
import { applyProposal } from "@/lib/brain.functions";
import { invalidateSchedule } from "@/lib/scheduling";
import type { BriefItemStatus } from "@/lib/rules/morning-brief";

const OUTCOME: Record<Exclude<BriefItemStatus, "open">, string> = { applied: "Applied", opened: "Opened", dismissed: "Not today" };

/** Top of the morning brief: written summary, Today strip, Since you last looked, Sort first. */
export function BriefTop({ workspaceId }: { workspaceId: string }) {
  const qc = useQueryClient();
  const nav = useNavigate();
  const get = useServerFn(getMorningBrief);
  const mark = useServerFn(markBriefItem);
  const apply = useServerFn(applyProposal);
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState<boolean | null>(null);
  const key = ["morning-brief", workspaceId];
  const q = useQuery({ queryKey: key, queryFn: () => get({ data: {} }), staleTime: 5 * 60_000 });

  async function refresh() {
    setBusy(true);
    try { qc.setQueryData(key, await get({ data: { refresh: true } })); }
    catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
  }
  async function setStatus(b: BriefRow, k: string, status: BriefItemStatus) {
    await mark({ data: { id: b.id, key: k, status } });
    qc.setQueryData<BriefRow | null>(key, (old) => old && { ...old, items: old.items.map((i) => (i.key === k ? { ...i, status } : i)) });
  }

  if (q.isLoading) return <p className="text-sm text-muted-foreground">Writing today's brief…</p>;
  if (q.error) return <p className="text-sm text-clash">The brief couldn't be built: {(q.error as Error).message}</p>;
  const b = q.data;
  if (!b) return null;
  const allDone = b.items.length > 0 && b.items.every((i) => i.status !== "open");
  const expanded = open ?? !allDone;
  const sinceLabel = new Date(b.since).toLocaleString("en-AU", { weekday: "short", hour: "numeric", minute: "2-digit" });

  return (
    <div className="space-y-3">
      <div className="flex items-start gap-2">
        <p className="flex-1 text-base leading-snug">{b.summary}</p>
        <Button size="sm" variant="outline" disabled={busy} onClick={refresh}><RefreshCw className={`mr-1 h-4 w-4 ${busy ? "animate-spin" : ""}`} />Refresh</Button>
      </div>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {[["Crew working", b.today.crewWorking], ["Jobs starting", b.today.jobsStarting], ["Away", b.today.away.length], ["Booked today", `${b.today.utilisationPct}%`]].map(([l, v]) => (
          <div key={l as string} className="rounded-md border bg-background px-3 py-2">
            <div className="text-xs uppercase text-muted-foreground">{l}</div>
            <div className="font-heading text-2xl font-semibold">{v}</div>
          </div>
        ))}
      </div>
      {b.today.away.length > 0 && <p className="text-sm text-muted-foreground">Away: {b.today.away.map((a) => `${a.name} (${a.type})`).join(", ")}</p>}

      <div>
        <h3 className="text-sm font-semibold">Since you last looked <span className="font-normal text-muted-foreground">({sinceLabel})</span></h3>
        <ul className="mt-1 grid gap-x-6 text-sm sm:grid-cols-2">
          {b.changes.map((c) => (
            <li key={c.kind} className={c.count ? "" : "text-muted-foreground"}>
              <Link to={c.to} className="hover:underline"><span className="inline-block w-7 text-right font-mono font-semibold">{c.count}</span> {c.label}</Link>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <button className="flex items-center gap-1 text-sm font-semibold" onClick={() => setOpen(!expanded)}>
          {expanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          Sort first {allDone && <span className="font-normal text-fit">— all dealt with</span>}
        </button>
        {expanded && (b.items.length === 0 ? <p className="mt-1 text-sm">Nothing needs attention in the next 10 working days.</p> : (
          <ul className="mt-2 space-y-2">
            {b.items.map((i) => (
              <li key={i.key} className={`rounded-md border-l-4 bg-background p-3 ${i.level === "red" ? "border-l-clash" : "border-l-warn"} ${i.status !== "open" ? "opacity-60" : ""}`}>
                <p className="text-sm"><span className="font-mono font-semibold">{i.code}</span> {i.name}{i.suburb ? ` · ${i.suburb}` : ""}{i.start ? ` · ${new Date(`${i.start}T00:00:00`).toLocaleDateString("en-AU", { weekday: "short", day: "numeric", month: "short" })}` : ""}</p>
                <p className="text-sm font-medium">{i.problem}{i.reasons.length ? <span className="font-normal text-muted-foreground"> · {i.reasons.join(" · ")}</span> : null}</p>
                {i.status !== "open" ? <p className="mt-1 text-xs text-muted-foreground">{OUTCOME[i.status]}</p> : (
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    {i.fix && (
                      <Button size="sm" disabled={busy} onClick={async () => {
                        setBusy(true);
                        try {
                          const r = await apply({ data: { id: i.fix!.proposal_id } });
                          if (!r.applied) { toast.warning("That fix now clashes — it's waiting in the Brain feed for a decision."); return; }
                          await setStatus(b, i.key, "applied");
                          invalidateSchedule(qc, workspaceId, i.job_id);
                          qc.invalidateQueries({ queryKey: ["proposals"] });
                          toast.success(i.fix!.title);
                        } catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
                      }}><Check className="mr-1 h-4 w-4" />Apply: {i.fix.title}</Button>
                    )}
                    <Button size="sm" variant="outline" onClick={async () => { await setStatus(b, i.key, "opened"); nav({ to: "/jobs", search: { job: i.job_id } }); }}><ExternalLink className="mr-1 h-4 w-4" />Open job</Button>
                    <Button size="sm" variant="ghost" onClick={() => setStatus(b, i.key, "dismissed")}><X className="mr-1 h-4 w-4" />Not today</Button>
                  </div>
                )}
              </li>
            ))}
          </ul>
        ))}
      </div>
    </div>
  );
}
