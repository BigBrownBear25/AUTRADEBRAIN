import { Fragment } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ExternalLink } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { crewQuery, crewRatesQuery, isFinanceQuery } from "@/lib/crew";
import { jobChildrenQuery, jobFinanceQuery, materialCostsQuery, statusLabel, type Job } from "@/lib/jobs";
import { getDriveTimes } from "@/lib/drive-times.functions";
import { hm, jobAssignmentsQuery } from "@/lib/assignments";
import { toRuleJob, useSchedulingData } from "@/lib/scheduling";
import { needsAttention } from "@/lib/rules/attention";
import { jobCost, margin } from "@/lib/rules/availability";
import { personTicketStatus } from "@/lib/rules/fit-check";
import { PRIORITY_LABEL, priorityOf } from "@/lib/rules/priority";
import { requiredTickets, type HazardSetting, type TicketRule } from "@/lib/rules/tickets";
import { todayIso } from "@/lib/rules/ticket-expiry";
import { leaveBy, overnight, travelCost, utes } from "@/lib/rules/travel";
import { jobDays } from "@/lib/rules/working-days";
import { SchedulingPanel } from "@/components/schedule/SchedulingPanel";
import { CrewTab } from "./CrewTab";

const money = (n: number) => n.toLocaleString("en-AU", { style: "currency", currency: "AUD", maximumFractionDigits: 0 });
const dmy = (d: string | null) => (d ? new Date(`${d}T00:00:00`).toLocaleDateString("en-AU", { weekday: "short", day: "numeric", month: "short" }) : "—");
const mins = (m: number | null) => (m == null ? "—" : m >= 60 ? `${Math.floor(m / 60)} h ${m % 60} min` : `${m} min`);

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return <section className="mt-5"><h3 className="mb-2 font-heading text-base font-semibold uppercase tracking-wide">{title}</h3>{children}</section>;
}

/** Shared settings + drive times for one job. */
function useJobContext(workspaceId: string, job: Job) {
  const settings = useQuery({
    queryKey: ["workspace_settings", workspaceId, "jobfile"],
    queryFn: async () => {
      const { data, error } = await supabase.from("workspace_settings")
        .select("working_days, day_start, day_end, hazards, ticket_rules, unload_buffer_min, overnight_minutes").eq("workspace_id", workspaceId).single();
      if (error) throw error;
      return data;
    },
  });
  const fetchDrive = useServerFn(getDriveTimes);
  const drive = useQuery({
    queryKey: ["drive", job.id, job.address, job.suburb],
    queryFn: () => fetchDrive({ data: { jobId: job.id } }),
    staleTime: 10 * 60_000,
  });
  return { settings: settings.data, drive: drive.data, driveLoading: drive.isLoading, driveError: drive.error as Error | null };
}

/** Finance only — callers render this only when is_finance is true; RLS also returns nothing otherwise. */
function useJobMoney(workspaceId: string, job: Job, enabled: boolean) {
  const { data: fin } = useQuery({ ...jobFinanceQuery(job.id), enabled });
  const { data: rates } = useQuery({ ...crewRatesQuery(workspaceId), enabled });
  const { data: unit } = useQuery({ ...materialCostsQuery(job.id), enabled });
  const { data: fs } = useQuery({
    queryKey: ["finance_settings", workspaceId], enabled,
    queryFn: async () => (await supabase.from("workspace_finance_settings").select("*").eq("workspace_id", workspaceId).maybeSingle()).data,
  });
  return { fin, rates, unit, fs };
}

export function OverviewTab({ workspaceId, job }: { workspaceId: string; job: Job }) {
  const api = useSchedulingData(workspaceId);
  const { data: kids } = useQuery(jobChildrenQuery(job.id));
  const { data: finance } = useQuery(isFinanceQuery(workspaceId));
  const today = todayIso();
  const lj = api?.jobMap.get(job.id);
  const flags = api && lj && kids ? needsAttention({ job: toRuleJob(lj), ctx: api.ctxFor(toRuleJob(lj)), crew: api.ctxFor(toRuleJob(lj)).jobCrew, materials: kids.materials, tasks: kids.tasks }) : [];
  const facts: [string, string | null][] = [
    ["Priority", `P${priorityOf(job, today)} · ${PRIORITY_LABEL[priorityOf(job, today)]}`],
    ["Status", statusLabel[job.status]], ["Sector", job.sector === "commercial" ? "Commercial" : "Domestic"],
    ["Site", [job.address, job.suburb].filter(Boolean).join(", ") || null], ["Dates", job.start_date ? `${dmy(job.start_date)} · ${job.duration_value} ${job.duration_unit}` : "Not scheduled"],
    ["Due by", job.due_by ? `${dmy(job.due_by)}${job.due_hard ? " (hard)" : ""}` : null], ["Flooring", job.flooring], ["Area", job.area_m2 ? `${job.area_m2} m²` : null],
    ["Crew size", String(job.crew_size)], ["Client", [job.client_name, job.client_phone, job.client_contact].filter(Boolean).join(" · ") || null],
    ["Builder", [job.builder_company, job.builder_pm_name, job.builder_pm_phone, job.builder_pm_email].filter(Boolean).join(" · ") || null], ["Type", job.job_type],
  ];
  const t = kids?.tasks ?? [], d = kids?.dependencies ?? [], m = kids?.materials ?? [];
  return (
    <div className="pt-2">
      <Section title="Needs attention">
        {flags.length === 0 ? <p className="text-sm text-muted-foreground">Nothing needs attention.</p> : (
          <div className="flex flex-wrap gap-1">{flags.map((f, i) => <span key={i} className={`rounded-sm px-1.5 py-0.5 text-xs ${f.level === "red" ? "bg-clash-soft text-clash" : "bg-warn-soft text-warn"}`}>{f.text}</span>)}</div>
        )}
      </Section>
      <Section title="Facts">
        <dl className="grid grid-cols-[110px_1fr] gap-x-3 gap-y-1 text-sm">
          {facts.filter(([, v]) => v).map(([k, v]) => <Fragment key={k}><dt className="text-muted-foreground">{k}</dt><dd>{v}</dd></Fragment>)}
        </dl>
      </Section>
      {job.unique_notes && <Section title="What makes this job different"><p className="whitespace-pre-wrap text-sm">{job.unique_notes}</p></Section>}
      <Section title="Schedule and crew"><SchedulingPanel workspaceId={workspaceId} jobId={job.id} /><CrewTab workspaceId={workspaceId} jobId={job.id} startDate={job.start_date} /></Section>
      <Section title="At a glance">
        <ul className="space-y-1 text-sm">
          <li>Tasks: {t.filter((x) => x.done).length} of {t.length} done</li>
          <li>Dependencies: {d.filter((x) => x.status === "pending").length} pending{d.some((x) => x.status === "failed") && <span className="text-clash"> · {d.filter((x) => x.status === "failed").length} failed</span>}</li>
          <li>Materials: {m.filter((x) => x.status === "delivered").length} of {m.length} delivered</li>
        </ul>
      </Section>
      {finance === true && <CostSection workspaceId={workspaceId} job={job} />}
    </div>
  );
}

function CostSection({ workspaceId, job }: { workspaceId: string; job: Job }) {
  const { settings, drive } = useJobContext(workspaceId, job);
  const { fin, rates, unit, fs } = useJobMoney(workspaceId, job, true);
  const { data: rows = [] } = useQuery(jobAssignmentsQuery(job.id));
  const { data: kids } = useQuery(jobChildrenQuery(job.id));
  if (!settings || !fs) return null;
  const crew = [...new Set(rows.map((r) => r.crew_member_id))];
  const days = job.duration_unit === "days" ? Number(job.duration_value) : 1;
  const tc = travelFor(job, settings, drive?.legs ?? [], days, Number(fs.km_rate), Number(fs.accommodation_rate));
  const mats = (kids?.materials ?? []).reduce((a, x) => a + Number(unit?.get(x.id) ?? 0) * Number(x.qty ?? 0), 0);
  const c = jobCost({ days: job.duration_unit === "days" ? days : Number(job.duration_value) / 8, crewDayRates: crew.map((id) => Number(rates?.get(id) ?? fs.default_day_rate)), openSpots: Math.max(0, job.crew_size - crew.length), defaultDayRate: Number(fs.default_day_rate), travel: tc.cost ?? 0, accommodation: 0, materials: mats });
  const q = fin?.quote_value != null ? Number(fin.quote_value) : null;
  const mg = margin(q, c.total);
  return (
    <Section title="Expected cost and margin (finance)">
      <dl className="grid grid-cols-[140px_1fr] gap-y-1 text-sm">
        <dt className="text-muted-foreground">Labour</dt><dd>{money(c.labour)}</dd>
        <dt className="text-muted-foreground">Travel</dt><dd>{tc.cost == null ? "Needs a drive distance" : money(tc.cost)}</dd>
        <dt className="text-muted-foreground">Materials</dt><dd>{money(mats)}</dd>
        <dt className="font-medium">Expected cost</dt><dd className="font-medium">{money(c.total)}</dd>
        <dt className="text-muted-foreground">Quote</dt><dd>{q == null ? "No quote" : money(q)}</dd>
        <dt className="text-muted-foreground">Margin</dt>
        <dd className={mg.level === "red" ? "text-clash" : mg.level === "amber" ? "text-warn" : ""}>{mg.margin == null ? "—" : `${Math.round(mg.margin * 100)}%`}</dd>
      </dl>
    </Section>
  );
}

type TravelSettings = { overnight_minutes: number };
function travelFor(job: Job, s: TravelSettings, legs: { key: string; km: number | null; minutes: number | null }[], days: number, kmRate: number, accomRate: number) {
  const depot = legs.find((l) => l.key === "depot");
  const ref = depot?.km != null ? depot : legs.find((l) => l.km != null);
  const on = overnight(ref?.minutes ?? 0, days, s.overnight_minutes);
  const cost = ref?.km != null ? travelCost({ oneWayKm: ref.km, crewSize: job.crew_size, trips: on.trips, nights: on.nights, kmRate, accommodationRate: accomRate }) : null;
  return { ref, on, cost };
}

export function SafetyTab({ workspaceId, job }: { workspaceId: string; job: Job }) {
  const { settings } = useJobContext(workspaceId, job);
  const { data: rows = [] } = useQuery(jobAssignmentsQuery(job.id));
  const { data: people = [] } = useQuery(crewQuery(workspaceId));
  if (!settings) return <p className="pt-4 text-sm text-muted-foreground">Loading…</p>;
  const hazards = settings.hazards as HazardSetting[];
  const req = requiredTickets(job, hazards, settings.ticket_rules as TicketRule[]);
  const crew = people.filter((p) => rows.some((r) => r.crew_member_id === p.id));
  const today = todayIso();
  const last = job.start_date ? jobDays(job.start_date, { value: Number(job.duration_value), unit: job.duration_unit }, { workingDays: settings.working_days, closures: [] }).at(-1)! : today;
  const tone = { current: "bg-fit-soft text-fit", expires: "bg-warn-soft text-warn", expired: "bg-clash-soft text-clash", missing: "bg-clash-soft text-clash" } as const;
  return (
    <div className="pt-2">
      <Section title="Tickets required">
        {req.length === 0 ? <p className="text-sm text-muted-foreground">No tickets required.</p> : crew.length === 0 ? (
          <ul className="text-sm">{req.map((r) => <li key={r.ticket}>{r.ticket} — {r.who === "everyone" ? "everyone" : "at least one person"}</li>)}</ul>
        ) : (
          <div className="overflow-x-auto"><table className="w-full text-sm">
            <thead><tr><th className="py-1 text-left font-medium text-muted-foreground">Ticket</th>{crew.map((p) => <th key={p.id} className="px-1 text-left font-medium">{p.name}</th>)}</tr></thead>
            <tbody>{req.map((r) => (
              <tr key={r.ticket} className="border-t">
                <td className="py-1 pr-2">{r.ticket}<p className="text-xs text-muted-foreground">{r.who === "everyone" ? "Everyone" : "At least one"} · {r.reasons.join(", ")}</p></td>
                {crew.map((p) => { const st = personTicketStatus({ id: p.id, name: p.name, role: p.role, skills: p.skills ?? [], tickets: p.crew_tickets }, r.ticket, today, last); return <td key={p.id} className="px-1"><span className={`rounded-sm px-1.5 py-0.5 text-xs ${tone[st]}`}>{st}</span></td>; })}
              </tr>
            ))}</tbody>
          </table></div>
        )}
      </Section>
      <Section title="Hazards and controls">
        {job.hazards.length === 0 ? <p className="text-sm text-muted-foreground">No hazards recorded.</p> : (
          <ul className="space-y-2">{job.hazards.map((h) => (
            <li key={h} className="rounded-md border p-3 text-sm"><p className="font-medium">{h}</p>
              <ul className="ml-4 list-disc text-muted-foreground">{(hazards.find((x) => x.name === h)?.controls ?? ["No controls set in Settings"]).map((c) => <li key={c}>{c}</li>)}</ul></li>
          ))}</ul>
        )}
      </Section>
      <Section title="Site safety notes"><p className="whitespace-pre-wrap text-sm">{job.safety_notes || "No site safety notes."}</p></Section>
    </div>
  );
}

export function TravelTab({ workspaceId, job }: { workspaceId: string; job: Job }) {
  const { settings, drive, driveLoading, driveError } = useJobContext(workspaceId, job);
  const { data: finance } = useQuery(isFinanceQuery(workspaceId));
  const { fs } = useJobMoney(workspaceId, job, finance === true);
  const { data: rows = [] } = useQuery(jobAssignmentsQuery(job.id));
  if (!settings) return <p className="pt-4 text-sm text-muted-foreground">Loading…</p>;
  const site = [job.address, job.suburb].filter(Boolean).join(", ");
  const days = job.duration_unit === "days" ? Number(job.duration_value) : 1;
  const legs = drive?.legs ?? [];
  const t = travelFor(job, settings, legs, days, Number(fs?.km_rate ?? 0), Number(fs?.accommodation_rate ?? 0));
  const firstDay = rows.filter((r) => r.date === job.start_date);
  const startOf = (id: string) => { const r = firstDay.find((x) => x.crew_member_id === id); return r ? hm(r.start_time) : job.start_time ? hm(job.start_time) : hm(settings.day_start); };
  const onSite = job.start_time ? hm(job.start_time) : hm(settings.day_start);
  const depot = legs.find((l) => l.key === "depot");
  const src = (s: string) => (s === "none" ? "" : " · Google Maps");
  return (
    <div className="pt-2">
      <Section title="Site">
        <p className="text-sm">{site || "No site address yet."}</p>
        {site && <Button asChild variant="outline" size="sm" className="mt-2"><a href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${site}, Australia`)}`} target="_blank" rel="noreferrer">Directions <ExternalLink className="ml-1 h-3.5 w-3.5" /></a></Button>}
      </Section>
      {driveError && <p className="mt-3 text-sm text-clash">Couldn't get drive times: {driveError.message}</p>}
      {driveLoading && <p className="mt-3 text-sm text-muted-foreground">Getting drive times…</p>}
      <Section title="From the depot">
        <dl className="grid grid-cols-[130px_1fr] gap-y-1 text-sm">
          <dt className="text-muted-foreground">Distance and drive</dt><dd>{depot ? (depot.km == null ? depot.error ?? "No route" : `${depot.km} km · ${mins(depot.minutes)}${src(depot.source)}`) : "Add a depot address in Settings"}</dd>
          <dt className="text-muted-foreground">On site</dt><dd>{onSite} on {dmy(job.start_date)}</dd>
          <dt className="text-muted-foreground">Utes</dt><dd>{utes(job.crew_size)}</dd>
          <dt className="text-muted-foreground">Overnight</dt><dd>{t.on.overnight ? `Yes — drive up once, ${t.on.nights} night${t.on.nights === 1 ? "" : "s"}` : "No"}</dd>
          {finance === true && <><dt className="text-muted-foreground">Travel cost</dt><dd>{t.cost == null ? "Needs a drive distance" : money(t.cost)}</dd></>}
        </dl>
      </Section>
      <Section title="Crew">
        {legs.filter((l) => l.crewMemberId).length === 0 ? <p className="text-sm text-muted-foreground">No crew with a home base on this job yet.</p> : (
          <table className="w-full text-sm">
            <thead><tr className="text-left text-muted-foreground"><th className="py-1 font-medium">Person</th><th className="font-medium">Distance</th><th className="font-medium">Drive</th><th className="font-medium">Leave by</th></tr></thead>
            <tbody>{legs.filter((l) => l.crewMemberId).map((l) => (
              <tr key={l.key} className="border-t">
                <td className="py-1">{l.label}</td><td>{l.km == null ? "—" : `${l.km} km`}</td><td>{l.minutes == null ? l.error ?? "—" : mins(l.minutes)}</td>
                <td className="font-mono">{l.minutes == null || !job.start_date ? "—" : leaveBy(startOf(l.crewMemberId!), l.minutes, settings.unload_buffer_min)}</td>
              </tr>
            ))}</tbody>
          </table>
        )}
      </Section>
    </div>
  );
}
