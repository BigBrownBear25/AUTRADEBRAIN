import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Sparkles, Pencil, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { jobMessagesQuery, useUserId, useMessagesLive } from "@/lib/chat";
import { aiInspectionSummary, aiInstallGuidance } from "@/lib/ai.functions";
import {
  SUMMARY_KEYS, SUMMARY_LABEL, GUIDANCE_KEYS, GUIDANCE_LABEL, checkShape, type AiResult,
} from "@/lib/ai-config";

type Speaker = "client" | "owner" | "foreman";
const SPEAKERS: Speaker[] = ["client", "owner", "foreman"];

const aiQuery = (jobId: string) => ({
  queryKey: ["job_ai", jobId],
  queryFn: async () => {
    const { data, error } = await supabase.from("jobs").select("inspection_summary, guidance").eq("id", jobId).single();
    if (error) throw error;
    return data as { inspection_summary: AiResult<Record<string, string[]>> | null; guidance: AiResult<Record<string, string[]>> | null };
  },
});

const when = (iso: string) => new Date(iso).toLocaleString("en-AU", { dateStyle: "medium", timeStyle: "short" });

/** Inspection notes (each with a speaker) plus the Claude summary. canEdit = office or foreman on the job. */
export function InspectionTab({ workspaceId, jobId, canEdit }: { workspaceId: string; jobId: string; canEdit: boolean }) {
  const qc = useQueryClient();
  const userId = useUserId();
  useMessagesLive(jobId);
  const msgs = useQuery(jobMessagesQuery(jobId));
  const ai = useQuery(aiQuery(jobId));
  const run = useServerFn(aiInspectionSummary);
  const [body, setBody] = useState("");
  const [speaker, setSpeaker] = useState<Speaker>("client");
  const [busy, setBusy] = useState(false);

  const notes = (msgs.data?.messages ?? []).filter((m) => m.kind === "inspection" && !m.deleted_at);

  async function add() {
    if (!body.trim() || !userId) return;
    const { error } = await supabase.from("messages").insert({ workspace_id: workspaceId, job_id: jobId, kind: "inspection", speaker, body: body.trim(), author_user_id: userId });
    if (error) { toast.error(error.message); return; }
    setBody("");
    qc.invalidateQueries({ queryKey: ["messages", jobId] });
  }
  async function remove(id: string) {
    const { error } = await supabase.from("messages").update({ deleted_at: new Date().toISOString() }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["messages", jobId] });
  }
  async function summarise() {
    setBusy(true);
    try { await run({ data: { jobId } }); qc.invalidateQueries({ queryKey: ["job_ai", jobId] }); toast.success("Summary written"); }
    catch (e) { toast.error(e instanceof Error ? e.message : "Couldn't write the summary"); }
    finally { setBusy(false); }
  }

  return (
    <div className="space-y-5 pt-2">
      <section className="space-y-2">
        <h3 className="font-heading text-lg font-semibold">Inspection notes</h3>
        {notes.length === 0 && <p className="text-sm text-muted-foreground">No notes yet. Type or dictate what was said on the walkthrough.</p>}
        <ul className="space-y-1.5">
          {notes.map((n) => (
            <li key={n.id} className="flex items-start gap-2 rounded-md border bg-card p-2 text-sm">
              <span className="shrink-0 rounded bg-muted px-1.5 py-0.5 text-xs font-medium capitalize">{n.speaker ?? "office"}</span>
              <span className="flex-1 whitespace-pre-wrap">{n.body}</span>
              {canEdit && n.author_user_id === userId && (
                <button aria-label="Delete note" onClick={() => remove(n.id)} className="text-muted-foreground hover:text-destructive"><Trash2 className="h-4 w-4" /></button>
              )}
            </li>
          ))}
        </ul>
        {canEdit && (
          <div className="space-y-2 rounded-md border bg-card p-2">
            <div className="flex gap-1" role="radiogroup" aria-label="Who said it">
              {SPEAKERS.map((s) => (
                <Button key={s} size="sm" type="button" variant={speaker === s ? "default" : "outline"} onClick={() => setSpeaker(s)} className="capitalize">{s}</Button>
              ))}
            </div>
            <Textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder="e.g. Client wants the hallway done first; slab looks uneven near the laundry" rows={3} />
            <Button size="sm" onClick={add} disabled={!body.trim()}>Add note</Button>
          </div>
        )}
      </section>

      <AiBlock
        title="Inspection summary" jobId={jobId} field="inspection_summary" result={ai.data?.inspection_summary ?? null}
        keys={SUMMARY_KEYS} labels={SUMMARY_LABEL} canEdit={canEdit} busy={busy}
        onGenerate={notes.length ? summarise : undefined} generateLabel="Summarise with Claude"
        meta={(r) => `Written ${when(r.at)} from ${r.notes} note${r.notes === 1 ? "" : "s"}${r.edited ? " · edited" : ""}`}
      />
    </div>
  );
}

/** Claude install guidance (crew brief). */
export function GuidanceTab({ jobId, canEdit }: { jobId: string; canEdit: boolean }) {
  const qc = useQueryClient();
  const ai = useQuery(aiQuery(jobId));
  const run = useServerFn(aiInstallGuidance);
  const [busy, setBusy] = useState(false);
  async function go() {
    setBusy(true);
    try { await run({ data: { jobId } }); qc.invalidateQueries({ queryKey: ["job_ai", jobId] }); toast.success("Guidance written"); }
    catch (e) { toast.error(e instanceof Error ? e.message : "Couldn't write the guidance"); }
    finally { setBusy(false); }
  }
  return (
    <div className="space-y-3 pt-2">
      <AiBlock
        title="Install guidance" jobId={jobId} field="guidance" result={ai.data?.guidance ?? null}
        keys={GUIDANCE_KEYS} labels={GUIDANCE_LABEL} canEdit={canEdit} busy={busy}
        onGenerate={go} generateLabel="Write guidance with Claude"
        meta={(r) => `Written ${when(r.at)} ${r.notes ? "using the inspection summary" : "without an inspection summary"}${r.edited ? " · edited" : ""}`}
      />
      <p className="text-sm font-medium">Check against the manufacturer's instructions.</p>
    </div>
  );
}

function AiBlock<K extends string>(p: {
  title: string; jobId: string; field: "inspection_summary" | "guidance"; result: AiResult<Record<string, string[]>> | null;
  keys: readonly K[]; labels: Record<K, string>; canEdit: boolean; busy: boolean;
  onGenerate?: (() => void) | undefined; generateLabel: string; meta: (r: AiResult<Record<string, string[]>>) => string;
}) {
  const qc = useQueryClient();
  const [editing, setEditing] = useState<Record<string, string> | null>(null);
  const r = p.result;

  async function saveEdit() {
    if (!r || !editing) return;
    const data = checkShape(Object.fromEntries(p.keys.map((k) => [k, (editing[k] ?? "").split("\n")])), p.keys)!;
    const { error } = await supabase.rpc("set_job_ai", { _job_id: p.jobId, _field: p.field, _value: { ...r, data, edited: true } });
    if (error) { toast.error(error.message); return; }
    setEditing(null);
    qc.invalidateQueries({ queryKey: ["job_ai", p.jobId] });
  }

  return (
    <section className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="font-heading text-lg font-semibold">{p.title}</h3>
        {p.canEdit && !editing && (
          <div className="flex gap-2">
            {r && <Button size="sm" variant="outline" onClick={() => setEditing(Object.fromEntries(p.keys.map((k) => [k, (r.data[k] ?? []).join("\n")])))}><Pencil className="mr-1 h-4 w-4" />Edit</Button>}
            {p.onGenerate && <Button size="sm" onClick={p.onGenerate} disabled={p.busy}><Sparkles className="mr-1 h-4 w-4" />{p.busy ? "Writing…" : r ? "Rewrite" : p.generateLabel}</Button>}
          </div>
        )}
      </div>
      {r && <p className="text-xs text-muted-foreground">{p.meta(r)}</p>}
      {!r && <p className="text-sm text-muted-foreground">Nothing written yet.</p>}
      {editing ? (
        <div className="space-y-3">
          {p.keys.map((k) => (
            <label key={k} className="block space-y-1">
              <span className="text-sm font-medium">{p.labels[k]} <span className="text-xs text-muted-foreground">(one item per line)</span></span>
              <Textarea rows={3} value={editing[k] ?? ""} onChange={(e) => setEditing({ ...editing, [k]: e.target.value })} />
            </label>
          ))}
          <div className="flex gap-2"><Button size="sm" onClick={saveEdit}>Save</Button><Button size="sm" variant="ghost" onClick={() => setEditing(null)}>Cancel</Button></div>
        </div>
      ) : r && (
        <div className="grid gap-3 sm:grid-cols-2">
          {p.keys.map((k) => (
            <div key={k} className="rounded-md border bg-card p-3">
              <h4 className="mb-1 text-sm font-semibold">{p.labels[k]}</h4>
              {(r.data[k] ?? []).length ? (
                <ul className="list-disc space-y-0.5 pl-4 text-sm">{(r.data[k] ?? []).map((x, i) => <li key={i}>{x}</li>)}</ul>
              ) : <p className="text-sm text-muted-foreground">Not mentioned</p>}
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
