/** Job file materials (spec section 13 "Screens"): add from the catalogue with the working shown, order-by dates, and "Add to catalogue" for free text. */
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { X } from "lucide-react";
import type { Database } from "@/integrations/supabase/types";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { isFinanceQuery } from "@/lib/crew";
import { jobChildrenQuery, materialCostsQuery } from "@/lib/jobs";
import { catalogueQuery, suppliersQuery, wasteDefaultsQuery, type CatalogueItem } from "@/lib/catalogue";
import { useDaysOff } from "@/lib/leave";
import { guessFromWords, kindOf, orderByDate, quantity } from "@/lib/rules/materials";
import { ItemForm } from "@/components/catalogue/ItemForm";

type Material = Database["public"]["Tables"]["materials"]["Row"];
type Calc = { working: string; note?: string; area: number | null; depth_mm?: number | null; edited?: boolean };

export function JobMaterials({ workspaceId, job }: { workspaceId: string; job: { id: string; area_m2: number | null; start_date: string | null } }) {
  const qc = useQueryClient();
  const { data } = useQuery(jobChildrenQuery(job.id));
  const { data: isFinance } = useQuery(isFinanceQuery(workspaceId));
  const { data: costs } = useQuery({ ...materialCostsQuery(job.id), enabled: !!isFinance });
  const cat = useQuery(catalogueQuery(workspaceId));
  const sups = useQuery(suppliersQuery(workspaceId));
  const waste = useQuery(wasteDefaultsQuery(workspaceId));
  const ws = useQuery({ queryKey: ["workspace_settings", workspaceId, "week"], queryFn: async () =>
    (await supabase.from("workspace_settings").select("working_days, holiday_states").eq("workspace_id", workspaceId).single()).data });
  const closures = useDaysOff(workspaceId, ws.data?.holiday_states);
  const week = useMemo(() => ({ workingDays: ws.data?.working_days ?? [1, 2, 3, 4, 5], closures: closures ?? [] }), [ws.data, closures]);
  const refresh = () => { qc.invalidateQueries({ queryKey: ["job_children", job.id] }); qc.invalidateQueries({ queryKey: ["material_costs", job.id] }); };
  const err = (e: { message: string } | null) => { if (e) toast.error(e.message); return !e; };

  const mats = (data?.materials ?? []) as Material[];
  const items = useMemo(() => new Map((cat.data ?? []).map((i) => [i.id, i])), [cat.data]);
  const [m, setM] = useState({ item: "", qty: "", unit: "" });
  const [search, setSearch] = useState("");
  const [pick, setPick] = useState<{ item: CatalogueItem; area: string; depth: string; qty: string } | null>(null);
  const [toCatalogue, setToCatalogue] = useState<Material | null>(null);

  const leadOf = (i: CatalogueItem) => i.lead_time_days ?? (sups.data ?? []).find((s) => s.id === i.supplier_id)?.lead_time_days ?? null;
  const obFor = (i: CatalogueItem) => orderByDate(job.start_date, leadOf(i), i.stocked, week);
  const hits = search.trim().length >= 2 ? (cat.data ?? []).filter((i) => i.active && [i.name, i.brand, i.colour, i.supplier_code].some((x) => x?.toLowerCase().includes(search.trim().toLowerCase()))).slice(0, 8) : [];
  const calc = pick ? quantity(pick.item, { area: pick.area === "" ? null : Number(pick.area), depthMm: pick.depth === "" ? null : Number(pick.depth), entered: pick.qty === "" ? null : Number(pick.qty), wasteDefaults: waste.data ?? {} }) : null;

  const addFree = async () => {
    if (!m.item.trim()) return;
    if (err((await supabase.from("materials").insert({ job_id: job.id, workspace_id: workspaceId, item: m.item.trim(), qty: m.qty ? Number(m.qty) : null, unit: m.unit || null, sort: mats.length + 1 })).error)) { setM({ item: "", qty: "", unit: "" }); refresh(); }
  };
  const addPicked = async () => {
    if (!pick || !calc) return;
    const edited = pick.qty !== "" && Number(pick.qty) !== calc.qty;
    const qty = pick.qty !== "" ? Number(pick.qty) : calc.qty;
    const c: Calc = { working: edited ? `${calc.working} (changed to ${qty})` : calc.working, area: pick.area === "" ? null : Number(pick.area), depth_mm: pick.depth === "" ? null : Number(pick.depth), edited, ...(calc.note ? { note: calc.note } : {}) };
    const label = [pick.item.name, pick.item.colour].filter(Boolean).join(" · ");
    const ok = err((await supabase.from("materials").insert({
      job_id: job.id, workspace_id: workspaceId, item: label, qty, unit: calc.unit, sort: mats.length + 1,
      catalogue_item_id: pick.item.id, supplier_id: pick.item.supplier_id, calc: c, order_by_date: obFor(pick.item),
    })).error);
    if (ok) { setPick(null); setSearch(""); refresh(); }
  };
  const upd = async (id: string, patch: Database["public"]["Tables"]["materials"]["Update"]) => { if (err((await supabase.from("materials").update(patch).eq("id", id)).error)) refresh(); };
  const setStatus = (x: Material, status: Material["status"]) =>
    upd(x.id, { status, ...(status === "to order" ? { ordered_at: null } : x.ordered_at ? {} : { ordered_at: new Date().toISOString() }) });
  const del = async (id: string) => { if (err((await supabase.from("materials").delete().eq("id", id)).error)) refresh(); };
  const setCost = async (id: string, v: string) => {
    const r = v === "" ? await supabase.from("material_costs").delete().eq("material_id", id)
      : await supabase.from("material_costs").upsert({ material_id: id, workspace_id: workspaceId, unit_cost: Number(v) });
    if (err(r.error)) refresh();
  };

  return (
    <div className="space-y-3 pt-2">
      <ul className="divide-y rounded-md border">
        {mats.length === 0 && <li className="px-3 py-3 text-sm text-muted-foreground">No materials.</li>}
        {mats.map((x) => {
          const it = x.catalogue_item_id ? items.get(x.catalogue_item_id) : undefined;
          const ob = it ? obFor(it) ?? x.order_by_date : x.order_by_date;
          const c = x.calc as Calc | null;
          return (
            <li key={x.id} className="space-y-1 px-3 py-2 text-sm">
              <div className="flex flex-wrap items-center gap-2">
                <span className="flex-1">{x.item}{x.qty != null && <span className="text-muted-foreground"> · {Number(x.qty)} {x.unit}</span>}</span>
                {isFinance && (
                  <Input type="number" min={0} step="0.01" className="h-9 w-28" placeholder="Unit $" aria-label="Unit cost"
                    defaultValue={costs?.get(x.id) ?? ""} onBlur={(e) => setCost(x.id, e.target.value)} />
                )}
                <select className="h-9 rounded-md border bg-background px-2 text-xs" value={x.status} onChange={(e) => setStatus(x, e.target.value as Material["status"])} aria-label="Status">
                  <option value="to order">To order</option><option value="ordered">Ordered</option><option value="delivered">Delivered</option>
                </select>
                {!x.catalogue_item_id && <Button size="sm" variant="outline" onClick={() => setToCatalogue(x)}>Add to catalogue</Button>}
                <Button size="icon" variant="ghost" aria-label="Delete" onClick={() => del(x.id)}><X className="h-4 w-4" /></Button>
              </div>
              {(c?.working || ob) && (
                <p className="text-xs text-muted-foreground">
                  {c?.working}{c?.note ? ` · ${c.note}` : ""}{ob ? `${c?.working ? " · " : ""}Order by ${ob}` : ""}{x.ordered_at ? ` · ordered ${x.ordered_at.slice(0, 10)}` : ""}
                </p>
              )}
            </li>
          );
        })}
      </ul>

      <div className="space-y-2 rounded-md border p-3">
        <p className="text-sm font-medium">Add from the catalogue</p>
        <Input placeholder="Search the catalogue" value={search} onChange={(e) => { setSearch(e.target.value); setPick(null); }} aria-label="Search the catalogue" />
        {!pick && hits.length > 0 && (
          <ul className="divide-y rounded-md border text-sm">
            {hits.map((i) => (
              <li key={i.id}><button className="w-full px-3 py-2 text-left hover:bg-muted" onClick={() => setPick({ item: i, area: job.area_m2 == null ? "" : String(job.area_m2), depth: "", qty: "" })}>
                {i.name}{i.colour ? ` · ${i.colour}` : ""} <span className="text-xs text-muted-foreground">({i.unit})</span>
              </button></li>
            ))}
          </ul>
        )}
        {pick && calc && (
          <div className="space-y-2">
            <div className="flex flex-wrap gap-2">
              {kindOf(pick.item) !== "entered" && <label className="grid gap-1 text-xs">Area (m²)<Input className="w-28" type="number" min={0} value={pick.area} onChange={(e) => setPick({ ...pick, area: e.target.value })} /></label>}
              {kindOf(pick.item) === "leveller" && <label className="grid gap-1 text-xs">Depth (mm)<Input className="w-28" type="number" min={0} value={pick.depth} onChange={(e) => setPick({ ...pick, depth: e.target.value })} /></label>}
              <label className="grid gap-1 text-xs">Quantity{kindOf(pick.item) !== "entered" ? " (change if needed)" : ""}<Input className="w-28" type="number" min={0} placeholder={calc.qty == null ? "" : String(calc.qty)} value={pick.qty} onChange={(e) => setPick({ ...pick, qty: e.target.value })} /></label>
            </div>
            <p className="rounded-sm bg-muted px-3 py-2 text-sm">{calc.working}{calc.note ? ` · ${calc.note}` : ""}{obFor(pick.item) ? ` · Order by ${obFor(pick.item)}` : ""}</p>
            <div className="flex justify-end gap-2">
              <Button variant="ghost" onClick={() => setPick(null)}>Cancel</Button>
              <Button onClick={addPicked} disabled={pick.qty === "" && calc.qty == null}>Add {pick.item.name}</Button>
            </div>
          </div>
        )}
      </div>

      <div className="flex flex-wrap gap-2">
        <Input className="flex-1" placeholder="Or type an item" value={m.item} onChange={(e) => setM({ ...m, item: e.target.value })} />
        <Input className="w-24" type="number" placeholder="Qty" value={m.qty} onChange={(e) => setM({ ...m, qty: e.target.value })} />
        <Input className="w-24" placeholder="Unit" value={m.unit} onChange={(e) => setM({ ...m, unit: e.target.value })} />
        <Button variant="outline" onClick={addFree}>Add</Button>
      </div>

      <Sheet open={!!toCatalogue} onOpenChange={(o) => !o && setToCatalogue(null)}>
        <SheetContent className="w-full overflow-y-auto sm:max-w-xl">
          <SheetHeader><SheetTitle>Add to catalogue</SheetTitle></SheetHeader>
          <p className="mt-2 text-sm text-muted-foreground">Filled from the words where possible. Check everything before saving.</p>
          {toCatalogue && (
            <div className="mt-4">
              <ItemForm ws={workspaceId} suppliers={sups.data ?? []} item={{ ...guessFromWords(toCatalogue.item), source: "job" }}
                onCancel={() => setToCatalogue(null)}
                onSaved={async (id) => {
                  await supabase.from("materials").update({ catalogue_item_id: id }).eq("id", toCatalogue.id);
                  qc.invalidateQueries({ queryKey: ["catalogue_items", workspaceId] });
                  setToCatalogue(null); refresh();
                }} />
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
