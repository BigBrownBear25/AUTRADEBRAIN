import { CalendarDays, MapPin, Lock } from "lucide-react";
import { PRIORITY_LABEL, priorityOf } from "@/lib/rules/priority";
import { todayIso } from "@/lib/rules/ticket-expiry";
import { jobEndDate, statusLabel, type JobListItem } from "@/lib/jobs";

const prioCls = {
  1: "bg-clash text-primary-foreground",
  2: "bg-warn text-foreground",
  3: "bg-primary/15 text-foreground",
  4: "bg-muted text-muted-foreground",
} as const;

function fmt(d: string) {
  return new Date(`${d}T00:00:00`).toLocaleDateString("en-AU", { day: "numeric", month: "short" });
}

export function JobCard({ job, onOpen }: { job: JobListItem; onOpen: () => void }) {
  const today = todayIso();
  const p = priorityOf(job, today);
  const end = jobEndDate(job);
  // "On site" is shown automatically when today falls within the booked dates.
  const onSite = job.status === "scheduled" && job.start_date && end && job.start_date <= today && today <= end;
  const status = onSite ? "on site" : job.status;
  const done = job.tasks.filter((t) => t.done).length;
  const commercial = job.sector === "commercial";

  return (
    <button onClick={onOpen} className="group flex w-full overflow-hidden rounded-md border bg-card text-left shadow-sm transition hover:shadow-md">
      <span className={`w-1.5 shrink-0 ${commercial ? "bg-commercial" : "bg-domestic"}`} aria-hidden />
      <div className="flex-1 p-3">
        <div className="flex items-center gap-2">
          <span className="font-mono text-sm font-medium">{job.code}</span>
          <span className={`rounded-sm px-1.5 py-0.5 font-heading text-xs font-semibold uppercase ${prioCls[p]}`} title={PRIORITY_LABEL[p]}>P{p}</span>
          <span className={`rounded-sm px-1.5 py-0.5 text-xs ${commercial ? "bg-commercial-soft" : "bg-domestic-soft"}`}>{commercial ? "Commercial" : "Domestic"}</span>
          {job.locked && <Lock className="h-3.5 w-3.5 text-muted-foreground" aria-label="Locked" />}
          <span className="ml-auto rounded-sm border px-1.5 py-0.5 text-xs">{statusLabel[status]}</span>
        </div>
        <p className="mt-1.5 truncate font-medium">{job.name}</p>
        <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
          <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{job.suburb ?? "No suburb"}</span>
          <span className="flex items-center gap-1">
            <CalendarDays className="h-3.5 w-3.5" />
            {job.start_date ? `${fmt(job.start_date)}${end && end !== job.start_date ? ` – ${fmt(end)}` : ""}` : "No dates"}
          </span>
          {job.due_by && <span className={job.due_hard ? "font-medium text-clash" : ""}>Due {fmt(job.due_by)}{job.due_hard ? " (hard)" : ""}</span>}
        </div>
        <div className="mt-1 flex flex-wrap gap-x-4 text-xs">
          <span>{job.flooring ?? "—"}</span>
          {job.area_m2 != null && <span>{Number(job.area_m2)} m²</span>}
          <span className="text-muted-foreground">{job.duration_value} {job.duration_unit} · crew {job.crew_size}</span>
          <span className="ml-auto text-muted-foreground">Tasks {done}/{job.tasks.length}</span>
        </div>
      </div>
    </button>
  );
}
