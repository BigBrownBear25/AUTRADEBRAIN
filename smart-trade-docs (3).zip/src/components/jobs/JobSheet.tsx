import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState, type ReactNode } from "react";
import { pinBrain, unpinBrain } from "@/lib/brain-pin";
import { toast } from "sonner";
import { X } from "lucide-react";
import type { Database } from "@/integrations/supabase/types";
import { supabase } from "@/integrations/supabase/client";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { isFinanceQuery, crewQuery } from "@/lib/crew";
import {
  JOB_STATUSES, statusLabel, jobChildrenQuery, jobFinanceQuery, jobSettingsQuery, materialCostsQuery,
  type AccessWindow, type Job, type JobInsert, type Dependency, type Material,
} from "@/lib/jobs";
import { requiredTickets, type HazardSetting, type TicketRule } from "@/lib/rules/tickets";
import { PRIORITY_LABEL, priorityOf } from "@/lib/rules/priority";
import { SchedulingPanel } from "@/components/schedule/SchedulingPanel";
import { todayIso } from "@/lib/rules/ticket-expiry";
import { JobChat } from "@/components/chat/JobChat";
import { JobMaterials } from "./JobMaterials";
import { OverviewTab, SafetyTab, TravelTab } from "./JobFileTabs";
import { InspectionTab, GuidanceTab } from "./AiTabs";

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const selCls = "h-10 w-full rounded-md border bg-background px-3 text-sm";

type Form = Omit<JobInsert, "workspace_id" | "access_window"> & { access_window: AccessWindow; quote_value: string };

const blank = (): Form => ({
  name: "", client_name: "", client_contact: "", client_phone: "", builder_company: "", builder_pm_name: "", builder_pm_email: "", builder_pm_phone: "",
  job_type: "", sector: "domestic", address: "", suburb: "", flooring: "", area_m2: null,
  duration_value: 1, duration_unit: "days", crew_size: 1, start_date: null, start_time: null,
  status: "ready", importance: "standard", urgency: "soon", due_by: null, due_hard: false,
  main_skill: "", other_skills: [], hazards: [], extra_tickets: [],
  access_window: { days: [], from: null, to: null, note: "" }, locked: false,
  unique_notes: "", safety_notes: "", quote_value: "",
});

export function JobSheet({ workspaceId, job, open, onOpenChange, prefill }: {
  workspaceId: string; job: Job | null; open: boolean; onOpenChange: (o: boolean) => void;
  /** Proposed values (from a Brain proposal's Edit) laid over the form; saved only when the person presses Save. */
  prefill?: Record<string, unknown> | null;
}) {
  // Opening a job file pins the Brain bar to it; closing unpins.
  useEffect(() => {
    if (open && job) { pinBrain(job); return () => unpinBrain(job.id); } return undefined;
  }, [open, job?.id]);
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full overflow-y-auto sm:max-w-2xl">
        <SheetHeader>
          <SheetTitle className="font-heading text-2xl uppercase">
            {job ? <><span className="font-mono text-lg">{job.code}</span> · {job.name}</> : "New job"}
          </SheetTitle>
        </SheetHeader>
        {open && (job ? (
          <Tabs defaultValue={prefill ? "details" : "overview"} className="mt-4">
            <TabsList className="grid h-auto w-full grid-cols-4 sm:grid-cols-8">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="chat">Chat</TabsTrigger>
              <TabsTrigger value="tasks">Tasks</TabsTrigger>
              <TabsTrigger value="materials">Materials</TabsTrigger>
              <TabsTrigger value="deps">Depend.</TabsTrigger>
              <TabsTrigger value="safety">Safety</TabsTrigger>
              <TabsTrigger value="travel">Travel</TabsTrigger>
              <TabsTrigger value="inspection">Inspection</TabsTrigger>
              <TabsTrigger value="guidance">Guidance</TabsTrigger>
              <TabsTrigger value="details">Edit</TabsTrigger>
            </TabsList>
            <TabsContent value="overview"><OverviewTab workspaceId={workspaceId} job={job} /></TabsContent>
            <TabsContent value="chat"><div className="pt-2"><JobChat workspaceId={workspaceId} jobId={job.id} office /></div></TabsContent>
            <TabsContent value="tasks"><TasksTab workspaceId={workspaceId} jobId={job.id} /></TabsContent>
            <TabsContent value="materials"><JobMaterials workspaceId={workspaceId} job={job} /></TabsContent>
            <TabsContent value="deps"><DepsTab jobId={job.id} /></TabsContent>
            <TabsContent value="safety"><SafetyTab workspaceId={workspaceId} job={job} /></TabsContent>
            <TabsContent value="travel"><TravelTab workspaceId={workspaceId} job={job} /></TabsContent>
            <TabsContent value="inspection"><InspectionTab workspaceId={workspaceId} jobId={job.id} canEdit /></TabsContent>
            <TabsContent value="guidance"><GuidanceTab jobId={job.id} canEdit /></TabsContent>
            <TabsContent value="details"><JobForm workspaceId={workspaceId} job={job} prefill={prefill ?? null} onDone={() => onOpenChange(false)} /></TabsContent>
          </Tabs>
        ) : (
          <div className="mt-4"><JobForm workspaceId={workspaceId} job={null} prefill={prefill ?? null} onDone={() => onOpenChange(false)} /></div>
        ))}
      </SheetContent>
    </Sheet>
  );
}

function F({ label, children, className }: { label: string; children: ReactNode; className?: string }) {
  return <div className={`space-y-1.5 ${className ?? ""}`}><Label>{label}</Label>{children}</div>;
}
function Group({ title, children }: { title: string; children: ReactNode }) {
  return (
    <fieldset className="rounded-md border p-4">
      <legend className="px-1 font-heading text-sm font-semibold uppercase tracking-wide">{title}</legend>
      <div className="grid gap-3 sm:grid-cols-2">{children}</div>
    </fieldset>
  );
}
function Chips({ options, value, onChange }: { options: string[]; value: string[]; onChange: (v: string[]) => void }) {
  return (
    <div className="flex flex-wrap gap-1.5 sm:col-span-2">
      {options.map((o) => {
        const on = value.includes(o);
        return (
          <button type="button" key={o} onClick={() => onChange(on ? value.filter((x) => x !== o) : [...value, o])}
            className={`min-h-9 rounded-sm border px-2 text-xs ${on ? "border-primary bg-primary/10 font-medium" : "text-muted-foreground"}`}>
            {o}
          </button>
        );
      })}
    </div>
  );
}

/** Only proposed keys that are real form fields, with no blanks. */
const pick = (pre: Record<string, unknown> | null | undefined, form: object) =>
  Object.fromEntries(Object.entries(pre ?? {}).filter(([k, v]) => k in form && v != null && v !== "")) as Partial<Form>;

function JobForm({ workspaceId, job, onDone, prefill }: { workspaceId: string; job: Job | null; onDone: () => void; prefill?: Record<string, unknown> | null }) {
  const qc = useQueryClient();
  const { data: settings } = useQuery(jobSettingsQuery(workspaceId));
  const { data: fullSettings } = useQuery({
    queryKey: ["workspace_settings", workspaceId, "ticket_rules"],
    queryFn: async () => {
      const { data, error } = await supabase.from("workspace_settings").select("hazards, ticket_rules").eq("workspace_id", workspaceId).single();
      if (error) throw error;
      return { hazards: data.hazards as HazardSetting[], rules: data.ticket_rules as TicketRule[] };
    },
  });
  const { data: isFinance } = useQuery(isFinanceQuery(workspaceId));
  const { data: finance } = useQuery({ ...jobFinanceQuery(job?.id ?? ""), enabled: !!job && !!isFinance });
  const [f, setF] = useState<Form | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (job) {
      // Drop joined lists (e.g. the jobs page's tasks) so only real job columns are saved back.
      const { id: _i, workspace_id: _w, code: _c, created_at: _ca, updated_at: _u, tasks: _t, ...rest } = job as typeof job & { tasks?: unknown };
      setF({ ...rest, access_window: job.access_window as AccessWindow, quote_value: finance?.quote_value != null ? String(finance.quote_value) : "", ...pick(prefill, rest) });
    } else setF({ ...blank(), ...pick(prefill, blank()) });
  }, [job, finance, prefill]);

  if (!f || !settings) return <p className="text-sm text-muted-foreground">Loading…</p>;
  const set = <K extends keyof Form>(k: K, v: Form[K]) => setF({ ...f, [k]: v });
  const n = (s: string) => (s === "" ? null : Number(s));
  const aw = f.access_window;
  const today = todayIso();
  const prio = priorityOf({ importance: f.importance!, urgency: f.urgency!, due_by: f.due_by ?? null, due_hard: !!f.due_hard, status: f.status! }, today);
  const needs = fullSettings
    ? requiredTickets({ sector: f.sector!, crew_size: f.crew_size ?? 1, hazards: f.hazards ?? [], extra_tickets: f.extra_tickets ?? [] }, fullSettings.hazards, fullSettings.rules)
    : [];

  const save = async () => {
    if (!f.name.trim()) { toast.error("Give the job a name"); return; }
    setBusy(true);
    try {
      const { quote_value, ...row } = f;
      const clean = Object.fromEntries(Object.entries(row).map(([k, v]) => [k, v === "" ? null : v])) as typeof row;
      const payload = { ...clean, name: f.name.trim(), workspace_id: workspaceId };
      let id = job?.id;
      if (id) {
        const { error } = await supabase.from("jobs").update(payload).eq("id", id);
        if (error) throw error;
      } else {
        const { data, error } = await supabase.from("jobs").insert(payload).select("id").single();
        if (error) throw error;
        id = data.id;
      }
      if (isFinance && (quote_value.trim() || finance)) {
        const { error } = await supabase.from("job_finance").upsert({ job_id: id, workspace_id: workspaceId, quote_value: n(quote_value.trim()), notes: finance?.notes ?? null });
        if (error) throw error;
      }
      toast.success(job ? "Job saved" : "Job created");
      qc.invalidateQueries({ queryKey: ["jobs", workspaceId] });
      qc.invalidateQueries({ queryKey: ["job_finance", id] });
      onDone();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4 pb-safe">
      <Group title="Job">
        <F label="Job name" className="sm:col-span-2"><Input value={f.name} onChange={(e) => set("name", e.target.value)} /></F>
        <F label="Job type">
          <select className={selCls} value={f.job_type ?? ""} onChange={(e) => set("job_type", e.target.value)}>
            <option value="">—</option>{settings.jobTypes.map((t) => <option key={t}>{t}</option>)}
          </select>
        </F>
        <F label="Sector">
          <select className={selCls} value={f.sector} onChange={(e) => set("sector", e.target.value as Form["sector"])}>
            <option value="domestic">Domestic</option><option value="commercial">Commercial</option>
          </select>
        </F>
        <F label="Status">
          <select className={selCls} value={f.status} onChange={(e) => set("status", e.target.value as Form["status"])}>
            {JOB_STATUSES.map((s) => <option key={s} value={s}>{statusLabel[s]}</option>)}
          </select>
        </F>
        <F label="Flooring"><Input value={f.flooring ?? ""} onChange={(e) => set("flooring", e.target.value)} placeholder="e.g. Hybrid plank, 7mm" /></F>
        <F label="Area (m²)"><Input type="number" min={0} value={f.area_m2 ?? ""} onChange={(e) => set("area_m2", n(e.target.value))} /></F>
        <label className="flex min-h-10 items-center gap-2 text-sm"><Checkbox checked={!!f.locked} onCheckedChange={(c) => set("locked", !!c)} /> Locked (don't move when re-planning)</label>
      </Group>

      <Group title="Client and builder">
        <F label="Client name"><Input value={f.client_name ?? ""} onChange={(e) => set("client_name", e.target.value)} /></F>
        <F label="Client contact"><Input value={f.client_contact ?? ""} onChange={(e) => set("client_contact", e.target.value)} placeholder="Email or other contact" /></F>
        <F label="Client phone"><Input type="tel" value={f.client_phone ?? ""} onChange={(e) => set("client_phone", e.target.value)} /></F>
        <F label="Builder company"><Input value={f.builder_company ?? ""} onChange={(e) => set("builder_company", e.target.value)} /></F>
        <F label="Builder PM name"><Input value={f.builder_pm_name ?? ""} onChange={(e) => set("builder_pm_name", e.target.value)} /></F>
        <F label="Builder PM email"><Input type="email" value={f.builder_pm_email ?? ""} onChange={(e) => set("builder_pm_email", e.target.value)} /></F>
        <F label="Builder PM phone"><Input type="tel" value={f.builder_pm_phone ?? ""} onChange={(e) => set("builder_pm_phone", e.target.value)} /></F>
      </Group>

      <Group title="Site">
        <F label="Address"><Input value={f.address ?? ""} onChange={(e) => set("address", e.target.value)} /></F>
        <F label="Suburb"><Input value={f.suburb ?? ""} onChange={(e) => set("suburb", e.target.value)} /></F>
      </Group>

      <Group title="Timing and crew">
        <F label="Duration">
          <div className="flex gap-2">
            <Input type="number" min={0.25} step={0.25} value={f.duration_value ?? 1} onChange={(e) => set("duration_value", Number(e.target.value))} />
            <select className={selCls} value={f.duration_unit} onChange={(e) => set("duration_unit", e.target.value as Form["duration_unit"])}>
              <option value="hours">hours</option><option value="days">days</option>
            </select>
          </div>
        </F>
        <F label="Crew size"><Input type="number" min={1} value={f.crew_size ?? 1} onChange={(e) => set("crew_size", Number(e.target.value))} /></F>
        <F label="Start date (leave empty if not scheduled)"><Input type="date" value={f.start_date ?? ""} onChange={(e) => set("start_date", e.target.value || null)} /></F>
        <F label="Start time"><Input type="time" value={f.start_time?.slice(0, 5) ?? ""} onChange={(e) => set("start_time", e.target.value || null)} /></F>
        <F label="Due by"><Input type="date" value={f.due_by ?? ""} onChange={(e) => set("due_by", e.target.value || null)} /></F>
        <label className="flex min-h-10 items-end gap-2 pb-2 text-sm"><Checkbox checked={!!f.due_hard} onCheckedChange={(c) => set("due_hard", !!c)} /> Hard deadline</label>
      </Group>

      <Group title="Priority">
        <F label="Importance">
          <select className={selCls} value={f.importance} onChange={(e) => set("importance", e.target.value as Form["importance"])}>
            <option value="key">Key</option><option value="standard">Standard</option><option value="minor">Minor</option>
          </select>
        </F>
        <F label="Urgency">
          <select className={selCls} value={f.urgency} onChange={(e) => set("urgency", e.target.value as Form["urgency"])}>
            <option value="critical">Critical</option><option value="soon">Soon</option><option value="flexible">Flexible</option>
          </select>
        </F>
        <p className="text-sm sm:col-span-2">Priority: <strong>P{prio} {PRIORITY_LABEL[prio]}</strong></p>
      </Group>

      <Group title="Skills">
        <F label="Main skill" className="sm:col-span-2">
          <select className={selCls} value={f.main_skill ?? ""} onChange={(e) => set("main_skill", e.target.value)}>
            <option value="">—</option>{settings.skills.map((s) => <option key={s}>{s}</option>)}
          </select>
        </F>
        <Label className="sm:col-span-2">Other skills</Label>
        <Chips options={settings.skills.filter((s) => s !== f.main_skill)} value={f.other_skills ?? []} onChange={(v) => set("other_skills", v)} />
      </Group>

      <Group title="Safety">
        <Label className="sm:col-span-2">Hazards</Label>
        <Chips options={settings.hazards} value={f.hazards ?? []} onChange={(v) => set("hazards", v)} />
        <Label className="sm:col-span-2">Extra tickets</Label>
        <Chips options={settings.ticketTypes} value={f.extra_tickets ?? []} onChange={(v) => set("extra_tickets", v)} />
        <div className="rounded-sm bg-muted p-3 text-sm sm:col-span-2">
          <p className="font-medium">Tickets this job needs</p>
          {needs.length === 0 ? <p className="text-muted-foreground">None</p> : (
            <ul className="mt-1 space-y-0.5">
              {needs.map((t) => <li key={t.ticket}>{t.ticket} — {t.who === "everyone" ? "everyone" : "at least one person"} <span className="text-muted-foreground">({t.reasons.join("; ")})</span></li>)}
            </ul>
          )}
        </div>
        <F label="Site safety notes" className="sm:col-span-2"><Textarea rows={2} value={f.safety_notes ?? ""} onChange={(e) => set("safety_notes", e.target.value)} /></F>
      </Group>

      <Group title="Access window">
        <div className="flex flex-wrap gap-1.5 sm:col-span-2">
          {DAYS.map((d, i) => {
            const on = aw.days.includes(i + 1);
            return (
              <button type="button" key={d} onClick={() => set("access_window", { ...aw, days: on ? aw.days.filter((x) => x !== i + 1) : [...aw.days, i + 1].sort() })}
                className={`min-h-9 rounded-sm border px-2 text-xs ${on ? "border-primary bg-primary/10 font-medium" : "text-muted-foreground"}`}>{d}</button>
            );
          })}
        </div>
        <F label="From"><Input type="time" value={aw.from ?? ""} onChange={(e) => set("access_window", { ...aw, from: e.target.value || null })} /></F>
        <F label="To"><Input type="time" value={aw.to ?? ""} onChange={(e) => set("access_window", { ...aw, to: e.target.value || null })} /></F>
        <F label="Access note" className="sm:col-span-2"><Input value={aw.note} onChange={(e) => set("access_window", { ...aw, note: e.target.value })} placeholder="e.g. Keys from site office, no access before 8" /></F>
      </Group>

      <Group title="What makes this job different">
        <Textarea rows={3} className="sm:col-span-2" value={f.unique_notes ?? ""} onChange={(e) => set("unique_notes", e.target.value)} placeholder="Anything the crew wouldn't expect" />
      </Group>

      {isFinance && (
        <Group title="Finance">
          <F label="Quote value ($)"><Input type="number" min={0} value={f.quote_value} onChange={(e) => set("quote_value", e.target.value)} /></F>
        </Group>
      )}

      <Button className="h-11 w-full" onClick={save} disabled={busy}>{job ? "Save job" : "Create job"}</Button>
      {!job && <p className="text-center text-xs text-muted-foreground">Five standard tasks are added automatically. A job without dates is saved as Ready.</p>}
    </div>
  );
}

function useRefresh(keys: unknown[][]) {
  const qc = useQueryClient();
  return () => keys.forEach((k) => qc.invalidateQueries({ queryKey: k }));
}
const err = (e: { message: string } | null) => { if (e) toast.error(e.message); return !e; };

function TasksTab({ workspaceId, jobId }: { workspaceId: string; jobId: string }) {
  const { data } = useQuery(jobChildrenQuery(jobId));
  const { data: crew = [] } = useQuery(crewQuery(workspaceId));
  const refresh = useRefresh([["job_children", jobId], ["jobs", workspaceId]]);
  const [label, setLabel] = useState("");
  const tasks = data?.tasks ?? [];
  const add = async () => {
    if (!label.trim()) return;
    if (err((await supabase.from("tasks").insert({ job_id: jobId, workspace_id: workspaceId, label: label.trim(), sort: tasks.length + 1 })).error)) { setLabel(""); refresh(); }
  };
  const upd = async (id: string, patch: Database["public"]["Tables"]["tasks"]["Update"]) => { if (err((await supabase.from("tasks").update(patch).eq("id", id)).error)) refresh(); };
  const del = async (id: string) => { if (err((await supabase.from("tasks").delete().eq("id", id)).error)) refresh(); };
  return (
    <div className="space-y-3 pt-2">
      <ul className="divide-y rounded-md border">
        {tasks.map((t) => (
          <li key={t.id} className="flex flex-wrap items-center gap-2 px-3 py-2 text-sm">
            <Checkbox checked={t.done} onCheckedChange={(c) => upd(t.id, { done: !!c })} />
            <span className={`flex-1 ${t.done ? "text-muted-foreground line-through" : ""}`}>{t.label}</span>
            <Input type="date" className="h-9 w-36" value={t.due_date ?? ""} onChange={(e) => upd(t.id, { due_date: e.target.value || null })} aria-label="Due" />
            <select className="h-9 rounded-md border bg-background px-2 text-xs" value={t.owner_crew_member_id ?? ""} onChange={(e) => upd(t.id, { owner_crew_member_id: e.target.value || null })} aria-label="Owner">
              <option value="">Office</option>{crew.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
            <Button size="icon" variant="ghost" aria-label="Delete task" onClick={() => del(t.id)}><X className="h-4 w-4" /></Button>
          </li>
        ))}
      </ul>
      <div className="flex gap-2"><Input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Add a task" /><Button variant="outline" onClick={add}>Add</Button></div>
    </div>
  );
}

function DepsTab({ jobId }: { jobId: string }) {
  const { data } = useQuery(jobChildrenQuery(jobId));
  const refresh = useRefresh([["job_children", jobId]]);
  const blankDep = { kind: "trade handover" as const, description: "", party: "", due_date: "", blocks_start: false };
  const [d, setD] = useState(blankDep);
  const deps = data?.dependencies ?? [];
  const add = async () => {
    if (!d.description.trim()) { toast.error("Describe the dependency"); return; }
    const { data: j } = await supabase.from("jobs").select("workspace_id").eq("id", jobId).single();
    if (err((await supabase.from("dependencies").insert({ job_id: jobId, workspace_id: j!.workspace_id, kind: d.kind, description: d.description.trim(), party: d.party || null, due_date: d.due_date || null, blocks_start: d.blocks_start })).error)) { setD(blankDep); refresh(); }
  };
  const upd = async (id: string, patch: Database["public"]["Tables"]["dependencies"]["Update"]) => { if (err((await supabase.from("dependencies").update(patch).eq("id", id)).error)) refresh(); };
  const del = async (id: string) => { if (err((await supabase.from("dependencies").delete().eq("id", id)).error)) refresh(); };
  return (
    <div className="space-y-3 pt-2">
      <ul className="divide-y rounded-md border">
        {deps.length === 0 && <li className="px-3 py-3 text-sm text-muted-foreground">No dependencies.</li>}
        {deps.map((x) => (
          <li key={x.id} className="flex flex-wrap items-center gap-2 px-3 py-2 text-sm">
            <span className="rounded-sm bg-muted px-1.5 py-0.5 text-xs">{x.kind}</span>
            <span className="flex-1">{x.description}{x.party && <span className="text-muted-foreground"> · {x.party}</span>}{x.due_date && <span className="font-mono text-xs"> · {x.due_date}</span>}{x.blocks_start && <span className="text-clash"> · blocks start</span>}</span>
            <select className="h-9 rounded-md border bg-background px-2 text-xs" value={x.status} onChange={(e) => upd(x.id, { status: e.target.value as Dependency["status"] })} aria-label="Status">
              <option value="pending">Pending</option><option value="confirmed">Confirmed</option><option value="failed">Failed</option>
            </select>
            <Button size="icon" variant="ghost" aria-label="Delete" onClick={() => del(x.id)}><X className="h-4 w-4" /></Button>
          </li>
        ))}
      </ul>
      <div className="grid gap-2 rounded-md border p-3 sm:grid-cols-2">
        <select className={selCls} value={d.kind} onChange={(e) => setD({ ...d, kind: e.target.value as typeof d.kind })}>
          {["trade handover", "test result", "delivery", "approval", "other"].map((k) => <option key={k}>{k}</option>)}
        </select>
        <Input placeholder="Description" value={d.description} onChange={(e) => setD({ ...d, description: e.target.value })} />
        <Input placeholder="Party (who)" value={d.party} onChange={(e) => setD({ ...d, party: e.target.value })} />
        <Input type="date" value={d.due_date} onChange={(e) => setD({ ...d, due_date: e.target.value })} aria-label="Due date" />
        <label className="flex items-center gap-2 text-sm"><Checkbox checked={d.blocks_start} onCheckedChange={(c) => setD({ ...d, blocks_start: !!c })} /> Blocks start</label>
        <Button variant="outline" onClick={add}>Add dependency</Button>
      </div>
    </div>
  );
}

