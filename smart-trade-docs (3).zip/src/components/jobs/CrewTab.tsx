import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { crewQuery, crewRoleLabel } from "@/lib/crew";
import { hm, jobAssignmentsQuery, standardHoursQuery } from "@/lib/assignments";
import { datesInRange, isValidBlock, presetOf, presetTimes, type BlockPreset } from "@/lib/rules/assignments";
import { todayIso } from "@/lib/rules/ticket-expiry";

const PRESET_LABEL: Record<BlockPreset, string> = { full: "Full day", morning: "Morning", afternoon: "Afternoon", custom: "Custom" };

function fmtDate(d: string) {
  return new Date(`${d}T00:00:00`).toLocaleDateString("en-AU", { weekday: "short", day: "numeric", month: "short" });
}

/** Office: add people to days on a job, and see the crew for each day. */
export function CrewTab({ workspaceId, jobId, startDate }: { workspaceId: string; jobId: string; startDate: string | null }) {
  const qc = useQueryClient();
  const { data: crew = [] } = useQuery(crewQuery(workspaceId));
  const { data: hours } = useQuery(standardHoursQuery(workspaceId));
  const { data: rows = [] } = useQuery(jobAssignmentsQuery(jobId));

  const [people, setPeople] = useState<string[]>([]);
  const [from, setFrom] = useState(startDate ?? todayIso());
  const [to, setTo] = useState(startDate ?? todayIso());
  const [workingOnly, setWorkingOnly] = useState(true);
  const [preset, setPreset] = useState<BlockPreset>("full");
  const [start, setStart] = useState("09:00");
  const [end, setEnd] = useState("10:00");
  const [busy, setBusy] = useState(false);

  const nameOf = useMemo(() => new Map(crew.map((c) => [c.id, c])), [crew]);
  const byDate = useMemo(() => {
    const m = new Map<string, typeof rows>();
    for (const r of rows) m.set(r.date, [...(m.get(r.date) ?? []), r]);
    return [...m.entries()];
  }, [rows]);

  if (!hours) return <p className="mt-4 text-sm text-muted-foreground">Loading…</p>;
  const times = preset === "custom" ? { start, end } : presetTimes(preset, hours);
  const dates = datesInRange(from, to, hours.working_days, workingOnly);

  const add = async () => {
    if (!people.length) { toast.error("Pick at least one person"); return; }
    if (!dates.length) { toast.error("No days in that range"); return; }
    if (!isValidBlock(times.start, times.end)) { toast.error("Finish time must be after start time"); return; }
    setBusy(true);
    const payload = people.flatMap((p) =>
      dates.map((date) => ({ job_id: jobId, workspace_id: workspaceId, crew_member_id: p, date, start_time: times.start, end_time: times.end })),
    );
    const { error } = await supabase.from("assignments").insert(payload);
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success(`Added ${payload.length} booking${payload.length === 1 ? "" : "s"}`);
    setPeople([]);
    qc.invalidateQueries({ queryKey: ["assignments", jobId] });
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from("assignments").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["assignments", jobId] });
  };

  return (
    <div className="mt-4 space-y-4 pb-safe">
      <fieldset className="space-y-3 rounded-md border p-4">
        <legend className="px-1 font-heading text-sm font-semibold uppercase tracking-wide">Add people to days</legend>
        <div className="flex flex-wrap gap-1.5">
          {crew.filter((c) => c.active).map((c) => {
            const on = people.includes(c.id);
            return (
              <button type="button" key={c.id} onClick={() => setPeople(on ? people.filter((x) => x !== c.id) : [...people, c.id])}
                className={`min-h-9 rounded-sm border px-2 text-xs ${on ? "border-primary bg-primary/10 font-medium" : "text-muted-foreground"}`}>
                {c.name} · {crewRoleLabel[c.role]}
              </button>
            );
          })}
          {!crew.length && <p className="text-sm text-muted-foreground">Add people in Crew first.</p>}
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5"><Label>From</Label><Input type="date" value={from} onChange={(e) => { setFrom(e.target.value); if (e.target.value > to) setTo(e.target.value); }} /></div>
          <div className="space-y-1.5"><Label>To</Label><Input type="date" value={to} min={from} onChange={(e) => setTo(e.target.value)} /></div>
        </div>
        <label className="flex items-center gap-2 text-sm"><Checkbox checked={workingOnly} onCheckedChange={(c) => setWorkingOnly(!!c)} /> Working days only</label>
        <div className="flex flex-wrap gap-1.5">
          {(Object.keys(PRESET_LABEL) as BlockPreset[]).map((p) => (
            <button type="button" key={p} onClick={() => setPreset(p)}
              className={`min-h-9 rounded-sm border px-3 text-sm ${preset === p ? "border-primary bg-primary/10 font-medium" : "text-muted-foreground"}`}>
              {PRESET_LABEL[p]}{p !== "custom" && <span className="ml-1 font-mono text-xs">{presetTimes(p, hours).start}–{presetTimes(p, hours).end}</span>}
            </button>
          ))}
        </div>
        {preset === "custom" && (
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5"><Label>Start</Label><Input type="time" value={start} onChange={(e) => setStart(e.target.value)} /></div>
            <div className="space-y-1.5"><Label>Finish</Label><Input type="time" value={end} onChange={(e) => setEnd(e.target.value)} /></div>
          </div>
        )}
        <div className="flex items-center justify-between gap-3">
          <p className="text-sm text-muted-foreground">{people.length} {people.length === 1 ? "person" : "people"} × {dates.length} day{dates.length === 1 ? "" : "s"}</p>
          <Button onClick={add} disabled={busy}>Add to job</Button>
        </div>
      </fieldset>

      <section className="space-y-3">
        <h3 className="font-heading text-lg font-semibold uppercase">Crew by day</h3>
        {!byDate.length && <p className="text-sm text-muted-foreground">Nobody is booked on this job yet.</p>}
        {byDate.map(([date, list]) => (
          <div key={date} className="rounded-md border bg-card">
            <p className="border-b px-3 py-2 text-sm font-medium">{fmtDate(date)}</p>
            <ul className="divide-y">
              {list.map((a) => {
                const p = nameOf.get(a.crew_member_id);
                const pr = presetOf(a.start_time, a.end_time, hours);
                return (
                  <li key={a.id} className="flex items-center justify-between gap-2 px-3 py-2 text-sm">
                    <span>{p?.name ?? "Unknown"} <span className="text-muted-foreground">· {p ? crewRoleLabel[p.role] : ""}</span></span>
                    <span className="flex items-center gap-2">
                      <span className="font-mono text-xs">{hm(a.start_time)}–{hm(a.end_time)}</span>
                      {pr !== "custom" && <span className="text-xs text-muted-foreground">{PRESET_LABEL[pr]}</span>}
                      <ActualTimes id={a.id} date={a.date} start={a.actual_start} end={a.actual_end} onSaved={() => qc.invalidateQueries({ queryKey: ["assignments", jobId] })} />
                      <Button size="icon" variant="ghost" aria-label="Remove booking" onClick={() => remove(a.id)}><Trash2 className="h-4 w-4" /></Button>
                    </span>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </section>
    </div>
  );
}

const clock = (iso: string | null) => (iso ? new Date(iso).toLocaleTimeString("en-AU", { hour: "2-digit", minute: "2-digit", hour12: false }) : "");

/** Office correction of a booking's actual start/finish (any day). Field users stamp only today's on My day. */
function ActualTimes({ id, date, start, end, onSaved }: { id: string; date: string; start: string | null; end: string | null; onSaved: () => void }) {
  const [open, setOpen] = useState(false);
  const [s, setS] = useState(clock(start));
  const [e, setE] = useState(clock(end));
  const label = start ? `Worked ${clock(start)}–${end ? clock(end) : "…"}` : "Times";
  const save = async () => {
    const at = (t: string) => (t ? new Date(`${date}T${t}:00`).toISOString() : null);
    const { error } = await supabase.rpc("correct_assignment_time", { _assignment_id: id, _start: at(s) as string, _end: at(e) as string });
    if (error) { toast.error(error.message); return; }
    toast.success("Booking times corrected"); setOpen(false); onSaved();
  };
  if (!open) return <Button size="sm" variant="ghost" className="font-mono text-xs" onClick={() => { setS(clock(start)); setE(clock(end)); setOpen(true); }}>{label}</Button>;
  return (
    <span className="flex items-center gap-1">
      <Input aria-label="Actual start" type="time" className="h-8 w-24" value={s} onChange={(x) => setS(x.target.value)} />
      <Input aria-label="Actual finish" type="time" className="h-8 w-24" value={e} onChange={(x) => setE(x.target.value)} />
      <Button size="sm" onClick={save}>Save</Button>
      <Button size="sm" variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
    </span>
  );
}
