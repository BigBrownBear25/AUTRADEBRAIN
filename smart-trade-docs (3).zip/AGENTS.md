<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

# Project rules

- Spec: `docs/phase-1-build-spec.md` (source of truth) plus `docs/project-brief.md`; one step at a time. Its "Build status" section is information, not instructions.
- Spec sections are numbered by its "## " headings: 1 How to use this spec, 2 Stack and setup, 3 Phase 1 scope, 4 Data model, 5 Access rules and role tests, 6 Business rules, 7 Screens, 8 AI and integrations, 9 iPhone and Android app, 10 Build order, 11 Phase 1 is done when, 12 Platform admin (superadmin), 13 Materials catalogue, 14 Compliance by design.
- If a prompt cites a spec section or rule not in that file, stop and ask; never invent rules, fields or numbers.
- Every step follows section 14 (SOC 2, ISO 27001, ISO 9001): least access, two-factor, audit trails, people approve what matters, controlled changes, retention, known subprocessors, fix problems at their cause.
- Spec "Edge Function" means a TanStack server function or route here, with the same auth/membership checks.
- Scheduling rules live only in `src/lib/rules/` as pure functions; screens never re-implement a rule.
- Navigation items are defined once in `src/lib/nav.ts` and shared by the desktop top nav, phone tab bar and help page.
- Navigation follows the membership role (src/lib/session.ts); the `_authenticated` layout enforces sign-in, two-factor for owner/office, and role-based page access; screens never re-check roles.
- RLS uses is_member / is_office / is_owner: SECURITY DEFINER bodies in `private`, INVOKER wrappers in public; add new privileged functions the same way.
- audit_log is written only by the write_audit trigger and is append-only — attach the trigger to every new workspace table.
- Child tables (e.g. crew_tickets, crew_rates) carry their own workspace_id, set by a trigger from the parent row — so RLS and audit never trust a client-supplied workspace.
- Field job access flows from assignments via is_assigned_to_job(); field users see other crew only through the crew_mates() function — never grant field reads on crew_members beyond their own row.
- Job files live in the private job-files bucket at workspace_id/job_id/file; links are issued only by the getJobFileUrl server function after a job-reader check.
- The owner-only Access check impersonates each account.
- Capacity totals (board and Overview) come only from rangeCapacity() in src/lib/rules/availability.ts.
- Prices only in catalogue_prices (finance); field reads catalogue via job_catalogue_items(); quantities/order-by in rules/materials.ts.
- Drive times come only from getDriveTimes (Google Routes), cached in drive_cache per origin and site; the caller's own RLS decides which crew bases count.
- Job chat (messages, attachments, message_reads) is gated only by is_job_reader(job_id); file links last 60 s — so removing someone's last assignment cuts off chat, files and live updates. Messages are only soft-deleted (deleted_at).
- Job AI (src/lib/ai.functions.ts) reads only non-finance columns and saves via set_job_ai(); every Claude call logs to ai_runs, costed only by src/lib/brain/rates.ts.
- Inbound email arrives only at /api/public/email-inbound (token-checked, workspace from the +inbound_key); filing always goes through fileToJob() in src/lib/email-intake.server.ts.
- Every new workspace table goes in EXPORT_TABLES (src/lib/export.functions.ts); demo rows carry is_demo and are managed only by set_demo_data(), so turning demo off never touches real data.
- Every Brain change is a row in `proposals`, applied only through apply_proposal/undo_proposal (via applyProposal in src/lib/brain.functions.ts, which re-runs fitCheck) — so Brain, morning brief and capture writes share one audited, undoable path.
- The Brain never chooses a job or a person on its own judgement: Claude only extracts clues, the matchers in src/lib/rules/ score the candidates, and the person confirms (spec section 6 "Matching to the right job").
- A variation is never sent without an office user pressing "Send to builder" and confirming; nothing else may call variation-send.
- Platform admins see a workspace's health, not its content, bar owner-approved support (spec 12): /admin is served by src/lib/admin.functions.ts, whose adminGate runs on every call and writes platform_audit; Brain kill switches are workspace_flags checked by assertBrainOn().
- Session limits: src/lib/rules/sessions.ts plus private.has_aal2 (DB-enforced 12 h); headers in src/start.ts.
- Don't build Stripe billing until the user asks; it will build on workspace_billing from spec section 12.
- src/lib/brain/ has its own AGENTS.md; read it before changing Brain code.
